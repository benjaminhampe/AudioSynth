#include "GPluginGroup.hpp"
#include <QVBoxLayout>

GPluginGroup::GPluginGroup( QWidget* parent )
   : QWidget( parent )
{
   setObjectName( "GPluginGroup" );
   setContentsMargins( 0,0,0,0 );

   connect( m_btnEnabled, SIGNAL(toggled(bool)), this, SLOT(on_buttonToggled_enabled(bool)) );
   connect( m_btnMore, SIGNAL(toggled(bool)), this, SLOT(on_buttonToggled_more(bool)) );
   connect( m_btnVisible, SIGNAL(toggled(bool)), this, SLOT(on_buttonToggled_visible(bool)) );
}

GPluginGroup::~GPluginGroup()
{
}

void GPluginGroup::on_buttonToggled_enabled(bool checked)
{
   if ( checked )
   {
      m_btnEnabled->setText("E");
      m_btnEnabled->setToolTip("This DSP element is now enabled = not bypassed");
   }
   else
   {
      m_btnEnabled->setText("B");
      m_btnEnabled->setToolTip("This DSP element is now disabled = bypassed");
   }
   emit toggledBypass( !checked );
}

void GPluginGroup::on_buttonToggled_more(bool checked)
{
   if ( checked )
   {
      m_btnMore->setText("-");
      m_btnMore->setToolTip("Press to show less");
   }
   else
   {
      m_btnMore->setText("+");
      m_btnMore->setToolTip("Press to show more");
   }
   emit toggledMore( checked );
}

void GPluginGroup::on_buttonToggled_visible(bool checked)
{
   if ( m_btnVisible->isChecked() )
   {
      m_btnVisible->setText("S");
      m_btnVisible->setToolTip("This DSP element is fully visible now");
      m_btnMore->setVisible( true );
   }
   else
   {
      m_btnVisible->setText("H");
      m_btnVisible->setToolTip("This DSP element is fully hidden now");
      m_btnMore->setVisible( false );
   }
   emit toggledHideAll( !checked );
}
