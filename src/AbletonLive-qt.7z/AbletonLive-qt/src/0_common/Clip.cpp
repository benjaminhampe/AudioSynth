#include "Clip.hpp"

// using de::midi::MidiTools;
