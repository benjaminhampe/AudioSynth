#include "MainWindow.hpp"

#include <QWidget>

#include <QVBoxLayout>
#include <QHBoxLayout>

MainWindow::MainWindow( QWidget* parent )
   : QMainWindow( parent )
   , m_GlyphView( nullptr )
{
   setAcceptDrops( true );
   setContentsMargins( 5, 5, 5, 5 );

   m_FontToolBar = new FontBar( nullptr );
   addToolBar( m_FontToolBar );

   m_GlyphView = new FontGlyphInfoWidget( nullptr );

//   QVBoxLayout* v = new QVBoxLayout;
//   v->setContentsMargins( 0,0,0,0 );
//   v->addWidget( m_FontBar );
//   v->addWidget( m_GlyphView, 1 );
//   setLayout( v );

   setCentralWidget( m_GlyphView );

   connect( m_FontToolBar, SIGNAL(fontChanged(QFont)), m_GlyphView, SLOT(on_setFont(QFont)) );
}

MainWindow::~MainWindow()
{

}
