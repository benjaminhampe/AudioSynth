#ifndef DE_QMAINWINDOW_FONTVIEWER_HPP
#define DE_QMAINWINDOW_FONTVIEWER_HPP

#include <QWidget>
#include <QMainWindow>
#include "FontBar.hpp"
#include "FontGlyphInfoWidget.hpp"

class MainWindow : public QMainWindow
{
   Q_OBJECT
public:
   explicit MainWindow( QWidget* parent = nullptr );
   ~MainWindow() override;
protected:

   FontBar* m_FontToolBar;
   FontGlyphInfoWidget* m_GlyphView;

};

#endif
