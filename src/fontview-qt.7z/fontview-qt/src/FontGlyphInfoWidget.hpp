#ifndef DE_FONTGLYPHINFOWIDGET_HPP
#define DE_FONTGLYPHINFOWIDGET_HPP

#include <QWidget>
#include <QString>
#include <QPushButton>
#include <QLineEdit>
#include <QTreeWidget>
#include <QFont>
#include <QVBoxLayout>
#include <QHBoxLayout>
#include <QGridLayout>
#include <QPushButton>
#include <vector>
// #include <FontAwesome.hpp>

class FontGlyphInfoWidget : public QWidget
{
   Q_OBJECT
public:
   explicit FontGlyphInfoWidget( QWidget* parent = nullptr );
   ~FontGlyphInfoWidget() override;

public slots:
   on_setFont( QFont const & font );

protected:

   std::vector< QPushButton* > m_Buttons;

};

#endif // FONTGLYPHINFOWIDGET_HPP
