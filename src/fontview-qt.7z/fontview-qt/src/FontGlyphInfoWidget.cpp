#include "FontGlyphInfoWidget.hpp"

namespace {

void
computeMinSize( QPushButton* btn )
{
   if (!btn) return;
   QSize s = btn->fontMetrics().tightBoundingRect( btn->text() ).size() + QSize(6,6);
   btn->setMinimumSize( QSize( std::min( s.width(), 128 ), std::min( s.height(), 48 ) ) );
}

QPushButton*
createButton( QString text, uint16_t value, QWidget* parent )
{
   QPushButton* btn = new QPushButton( text, parent );
   btn->setToolTip( QString("Unicode char: ") + QString::number( value, 16 ) );
   //btn->setMinimumWidth( 32 );
   btn->setSizePolicy( QSizePolicy::Expanding, QSizePolicy::Expanding );
   // QFont font = btn->fontMetrics().size( 0, text );
   //font.setPixelSize( 32 );
   //btn->setFont( font );
   computeMinSize( btn );
   return btn;
}

}

FontGlyphInfoWidget::FontGlyphInfoWidget( QWidget* parent )
   : QWidget( parent )
{
   setAcceptDrops( true );
   setContentsMargins( 5, 5, 5, 5 );

   QHBoxLayout* h = new QHBoxLayout;
   h->setContentsMargins( 0,0,0,0 );

//   for ( int k = 0; k < 3; ++k )
//   {
      QGridLayout* grid = new QGridLayout;
      grid->setContentsMargins( 0,0,0,0 );
      grid->setSpacing( 4 );
      for ( int y = 0; y < 16; ++y )
      {
         for ( int x = 0; x < 16; ++x )
         {
            uint16_t const unicode = y * 16 + x;
            QPushButton* btn = createButton( QChar( unicode ), unicode, this );
            grid->addWidget( btn, y, x, 1, 1 );
            m_Buttons.emplace_back( btn );
         }
      }
      h->addLayout( grid );
//   }

   setLayout( h );
}

FontGlyphInfoWidget::~FontGlyphInfoWidget()
{

}

FontGlyphInfoWidget::on_setFont( QFont const & font )
{
   setFont( font );

   for ( size_t i = 0; i < m_Buttons.size(); ++i )
   {
      QPushButton* btn = m_Buttons[ i ];
      computeMinSize( btn );
   }

   //adjustSize();
   update();
}
