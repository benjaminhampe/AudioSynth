#ifndef DE_QWIDGET_FONTCHOOSEBAR_HPP
#define DE_QWIDGET_FONTCHOOSEBAR_HPP

#include <QWidget>
#include <QPushButton>
#include <QToolBar>
#include <QToolButton>
#include <QComboBox>
#include "ColorButton.hpp"

class FontBar : public QToolBar
{
   Q_OBJECT
public:
   FontBar( QWidget * parent = nullptr );
   ~FontBar() override;

signals:
   void fontChanged( QFont const & font );

public slots:
   void onButtonClick_Font( bool );
   void onComboIndex_Family( int );
   void onComboIndex_Size( int );
   void onButtonClick_Bold( bool );
   void onButtonClick_Italic( bool );
   void onButtonClick_Underline( bool );
   void onButtonClick_StrikeThrough( bool );

public:
   void updateFont();

   // current state
   QString m_CurrFamily;
   QColor m_CurrLineColor;
   QColor m_CurrFillColor;
   int m_CurrPointSize;
   int m_CurrWeight;
   bool m_IsBold;
   bool m_IsItalic;
   bool m_IsStriked;
   bool m_IsUnderlined;
   int m_CurrTextAlign;
   QFont m_CurrFont;

   // ui
   QPushButton* m_FontInfo;
   QComboBox* m_FontFamily;
   QComboBox* m_FontSize;
   ColorButton* m_LineColor;
   ColorButton* m_FillColor;

   QToolButton* m_Bold;
   QToolButton* m_Italic;
   QToolButton* m_Underline;
   QToolButton* m_StrikeThrough;
};

#endif
