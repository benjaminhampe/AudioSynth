#ifndef PAINT_COMMAND_HISTORY_HPP
#define PAINT_COMMAND_HISTORY_HPP

#include "DrawCommand.hpp"

class DrawCommandHistory
{
public:
   std::vector< DrawCommand > m_Commands;
   size_t m_CurrIndex;

   DrawCommandHistory()
   {

   }

   void
   addCommand( DrawCommand && drawCommand )
   {
      m_Commands.emplace_back( std::move( drawCommand ) );
   }

};

#endif
