#ifndef PAINT_DrawCommand_HPP
#define PAINT_DrawCommand_HPP

#include "CompileConfig.hpp"

inline std::ostream&
operator<< ( std::ostream & o, QColor const & color )
{
   o << color.red() << "," << color.green() << "," << color.blue() << "," << color.alpha();
   return o;
}

inline std::ostream&
operator<< ( std::ostream & o, PaintMode::EPaintMode paintMode )
{
   o << PaintMode::toString( paintMode );
   return o;
}

template < typename T >
struct Rect2d
{
   T x;
   T y;
   T w;
   T h;

   Rect2d()
      : x(0), y(0), w(0), h(0)
   {}

   Rect2d( T x, T y, T w, T h )
      : x( x ), y( y ), w( w ), h( h )
   {}
};

typedef Rect2d< int > Rect2di;
typedef Rect2d< float > Rect2df;

template < typename T >
struct Point2d
{
   T x;
   T y;

   Point2d()
      : x(0), y(0)
   {}

   Point2d( T x, T y )
      : x( x ), y( y )
   {}
};

typedef Point2d< int > Point2di;
typedef Point2d< float > Point2df;

template< typename T >
inline std::ostream&
operator<< ( std::ostream & o, Rect2d< T > const & boundingRect )
{
   o << boundingRect.x << "," << boundingRect.y << "," << boundingRect.w << "," << boundingRect.h;
   return o;
}

struct Pixel
{
   int x;
   int y;
   QColor color;

   Pixel() : x(-10000), y(-10000), color(0,0,0,0) {}
   Pixel( int x, int y, QColor color ) : x(x), y(y), color(color) {}
};

class DrawCommand
{
public:
   PaintMode::EPaintMode m_DrawMode;
   Rect2di m_BoundingRect;
   float m_LineWidth;
   QColor m_LineColor;
   QColor m_FillColor;
   // IShape & m_Shape;
   std::vector< Pixel > m_NewPixels; // allows arbitrary forms, and is expensive. D.k. about blending yet

   ~DrawCommand()
   {

   }

   DrawCommand()
      : m_DrawMode( PaintMode::Point )
      , m_BoundingRect()
      , m_LineWidth( 1.0f )
      , m_LineColor( 0,0,0,255 )
      , m_FillColor( 0,0,0,0 )
   {}

   std::string
   toString() const
   {
      std::stringstream s;
      s << "type:" << m_DrawMode << "; view-box:" << m_BoundingRect << "; stroke-width:" << m_LineWidth << "; stroke-color:" << m_LineColor << "; "
         "fill-color:" << m_FillColor << "; pixel-count:" << m_NewPixels.size();
      return s.str();
   }
};



#endif
