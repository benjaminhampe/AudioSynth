//////////////////////////////////////////////////////////////////////////////
/// @file main_paint.cpp
/// @author Benjamin Hampe <benjamin.hampe@gmx.de>
//////////////////////////////////////////////////////////////////////////////

#include "ui/MainWindow.hpp"

int
dbAddFontFamily( QString const & fontFamily )
{
   QFileInfo fileInfo( fontFamily );
   if ( !fileInfo.exists() )
   {
      qDebug() << "[Error] " << __FUNCTION__ << "(" << fontFamily << ") File does not exist";
      return -1;
   }

   if ( !fileInfo.isFile() )
   {
      qDebug() << "[Error] " << __FUNCTION__ << "(" << fontFamily << ") Is not a file";
      return -1;
   }

   int fontId = QFontDatabase::addApplicationFont( fontFamily );
   if ( fontId >= 0 )
   {
      QStringList fonts = QFontDatabase::applicationFontFamilies( fontId );

      qDebug() << __FUNCTION__ << "(" << fontFamily << ") -> fontId(" << fontId << "), familyCount(" << fonts.size() << ")";
      for ( int i = 0; i < fonts.size(); ++i )
      {
         qDebug() << "Font[" << i << "] " << fonts[ i ];
      }
   }
   else {
      qDebug() << __FUNCTION__ << "(" << fontFamily << ") -> Cannot load.";
   }
   return fontId;
}




int main( int argc, char** argv )
{
   // init random number generator
   srand( static_cast< uint32_t >( time( nullptr ) ) );

   QApplication::setStyle("windows");
   QApplication app( argc, argv );
   QString const appName = "Paint2D Application";
   app.setApplicationName( appName );
//   QString const appPath = qApp->applicationDirPath() + "/";
//   QString const stylePath( appPath + "themes/darcula.css" );
//   app.setStyleSheet( "file:///" + stylePath );

   dbAddFontFamily( "fontawesome.ttf" );
   dbAddFontFamily( "la-regular-400.ttf" );
   dbAddFontFamily( "la-brands-400.ttf" );
   dbAddFontFamily( "la-solid-900.ttf" );

//   QString const appPath = qApp->applicationDirPath() + "/";
//   QString const cssPath( appPath + "themes/darcula.css" );
//   app.setStyleSheet( "file:///" + cssPath );
   MainWindow win( nullptr );
   win.newCanvasImage();
   win.setWindowTitle( appName + " | " + win.getImageURI() );
   win.show();
   return app.exec();
}



#if 0

void testAssimp( irr::scene::ISceneManager * smgr )
{
   std::cout << "// ==========================================================\n";
   std::cout << "// TEST_ASSIMP:\n";
   std::cout << "// ==========================================================\n";

   std::vector< std::string > models;
   models.push_back( irrExt::getAbsoluteFileName( "../../media/test/3D_Printer_test_fixed_stl_3rd_gen.STL" ) );
   loadAssimpModelList( smgr, models );

   std::string testFile = "../../media/3d/T-Rex.3mf";
   std::string fileName = irrExt::getAbsoluteFileName( testFile );
   std::cout << "[Info] Model[0].FileName = " << fileName << "\n";

   irrExt::AutoSceneNode* node = nullptr;

   irrExt::AssimpFile file;
   if ( file.open( fileName ) )
   {
      node = irrExt::createSceneNode( smgr, file );

      auto rtv = irrExt::mkRect( 100, 20, 500, 1000 );
      irr::gui::IGUIWindow* tvWin = env->addWindow( rtv, false, L"Assimp Model Stat", nullptr, -1 );

      irr::gui::IGUITreeView* tv = irrExt::createTreeView( file, env, tvWin, tvWin->getClientRect() );

   }

   if ( node )
   {
      node->setPosition( irr::core::vector3df( 0.0f, 0.0f, 0.0f ) );
      node->setMaterialFlag( irr::video::EMF_LIGHTING, true );
      node->setMaterialFlag( irr::video::EMF_WIREFRAME, false );
      node->setMaterialFlag( irr::video::EMF_FOG_ENABLE, true );

      modelEditor->setSceneNode( node );
   }

}


#include <irrExt/libAssimp.hpp>
#include <irrExt/CGUICameraEditor.hpp>
#include <irrExt/CGUIObjectEditor.hpp>

struct DarkGL_GlobalState
{
   std::string m_Dir;
   std::string m_MediaDir;

   std::vector< irr::gui::IGUIFont* > m_Fonts;

public:
   DarkGL_GlobalState()
    : m_Dir( "./" )
    , m_MediaDir("../../media")
   {}

   static DarkGL_GlobalState &
   get()
   {
      static DarkGL_GlobalState singleton;
      return singleton;
   }

};

std::string dbGetDir()
{
   return DarkGL_GlobalState::get().m_Dir;
}

void dbSetDir( std::string dir )
{
   DarkGL_GlobalState::get().m_Dir = dir;
}

std::string dbGetMediaDir()
{
   return DarkGL_GlobalState::get().m_MediaDir;
}

void dbSetMediaDir( std::string mediaDir )
{
   DarkGL_GlobalState::get().m_MediaDir = mediaDir;
}

irr::gui::CGUITTFont*
loadFont( std::string const & fileName, irr::gui::IGUIEnvironment* env, int32_t pxSize, bool aa, bool transparent )
{
   if ( !env )
   {
      std::cout << "[Error] " << __FUNCTION__ << " :: Invalid pointer to IGUIEnvironment.\n";
      return nullptr;
   }

   if ( !irrExt::existFile( fileName ) )
   {
      std::cout << "[Error] " << __FUNCTION__ << " :: File not exist. (" << fileName << ")\n";
      return nullptr;
   }

   irr::core::stringw const irrName( fileName.c_str() );
   std::wcout << "[Error] " << __FUNCTION__ << " :: irrName(" << irrName.c_str() << ")\n";

   irr::gui::CGUITTFont* font = irr::gui::CGUITTFont::create( env, irrName.c_str(), pxSize, aa, transparent );
   if ( !font )
   {
      std::cout << "[Error] " << __FUNCTION__ << " :: Could not create class TTFont. (" << fileName << ")\n";
   }

   return font;
}

// std::string fontFile400 = "../../media/fonts/FontAwesome590-regular-400.ttf";
std::vector < std::string >
readModelFiles( std::string const & fileName = "../../media/test/test.txt" )
{
   std::vector < std::string > fileNames = irrExt::loadStringVector( fileName );

   std::string baseDir = irrExt::getAbsoluteFilePath( fileName );
}

// TEST ASSIMP:
void loadAssimpModelList( irr::scene::ISceneManager * smgr, std::vector< std::string > const & models )
{
   std::cout << "[Info] " << __FUNCTION__ << "(" << models.size() << "):\n";

   float32_t x = 0.0f;
   for ( size_t i = 0; i < models.size(); ++i )
   {
      std::cout << "[Info] Model[" << i << "].FileName = " << models[ i ] << "\n";

      irr::scene::ISceneNode* model = irrExt::loadAssimpSceneNode( smgr, models[ i ] );
      if ( model )
      {
         model->setPosition( irr::core::vector3df( x, 0.0f, 0.0f ) );
         model->setMaterialFlag( irr::video::EMF_LIGHTING, true );
         model->setMaterialFlag( irr::video::EMF_WIREFRAME, false );
         model->setMaterialFlag( irr::video::EMF_FOG_ENABLE, true );
         irr::core::vector3df const & modelSize = model->getBoundingBox().getExtent();
         // std::cout << "[Info] Model[" << i << "].Size = " << modelSize << "\n";
         x += modelSize.X;
         x += 1.0f;
      }
   }
}

// TEST ASSIMP:
void testAssimp( irr::scene::ISceneManager * smgr )
{
   std::cout << "// ==========================================================\n";
   std::cout << "// TEST_ASSIMP:\n";
   std::cout << "// ==========================================================\n";

//   std::string lstFile = irrExt::getAbsoluteFileName( "../../media/test/test.txt" );
//   std::string lstDir = irrExt::getAbsoluteFilePath( lstFile );
//   std::cout << "lstFile = " << lstFile << "\n";
//   std::cout << "lstDir = " << lstDir << "\n";

   std::vector< std::string > models;
   models.push_back( irrExt::getAbsoluteFileName( "../../media/test/3D_Printer_test_fixed_stl_3rd_gen.STL" ) );
   loadAssimpModelList( smgr, models );
}

int main( int argc, char * argv[] )
{
   std::cout << "// ==========================================================\n";
   std::cout << "// prgm-name: " << argv[0] << ":\n";
   std::cout << "// ==========================================================\n";
   std::cout << ">" << std::endl;

   ::srand( static_cast< uint32_t >( ::time( nullptr ) ) );

   const char* appName = "test.assimp (c) 2019 by Benjamin Hampe <benjaminhampe@gmx.de>";
   // if ( argc > 1 )
   // {
      // testModelFileName = argv[1];
   // }

   /// =========================================================
   irrExt::OpenGLDevice oglDevice( 1280, 800, 32 );
   irr::IrrlichtDevice* device = oglDevice.getDevice();
   if ( !device )
   {
      std::cout << "[Error] " << __FUNCTION__ << " :: Cannot create IrrlichtDevice\n";
      return 0;
   }
   device->setResizable( true );
   device->setWindowCaption( irr::core::stringw( appName ).c_str() );

   irrExt::BaseEventReceiver receiver( device );
   irr::video::IVideoDriver* driver = device->getVideoDriver();
   irr::scene::ISceneManager* smgr = device->getSceneManager();
   irr::scene::ISceneNode* smgrRoot = smgr->getRootSceneNode();
   irr::gui::IGUIEnvironment* env = device->getGUIEnvironment();
   irr::core::dimension2du screenSize = driver->getScreenSize();
   irr::video::SColor clearColor( 255,80,80,200 );

   driver->setFog( irr::video::SColor(255, 100, 100, 255 ),
                   irr::video::EFT_FOG_EXP, 900.0f, 1000.0f );

   irr::video::ITexture* top = driver->getTexture( "../../media/skybox/ct/top.jpg" );
   irr::video::ITexture* bottom = driver->getTexture( "../../media/skybox/ct/bottom.jpg" );
   irr::video::ITexture* left = driver->getTexture( "../../media/skybox/ct/left.jpg" );
   irr::video::ITexture* right = driver->getTexture( "../../media/skybox/ct/right.jpg" );
   irr::video::ITexture* front = driver->getTexture( "../../media/skybox/ct/front.jpg" );
   irr::video::ITexture* back = driver->getTexture( "../../media/skybox/ct/back.jpg" );
   smgr->addSkyBoxSceneNode( top, bottom, left, right, front, back, smgrRoot, -1 );
   smgr->setAmbientLight( irr::video::SColorf( 0.2f, 0.15f, 0.05f, 1.0f ) );

   //std::string fontFile400 = "../../media/fonts/FontAwesome590-regular-400.ttf";
   //std::string fontFile900 = "../../media/fonts/FontAwesome590-solid-900.ttf";
   std::string fontFileMono400 = "../../media/fonts/DejaVuSansMono.ttf";
   std::string fontFileMono900 = "../../media/fonts/DejaVuSansMono-Bold.ttf";

   //irr::gui::CGUITTFont* fontAwesome400 = loadFont( fontFile400, env, 36, true, true );
   //irr::gui::CGUITTFont* fontAwesome900 = loadFont( fontFile900, env, 36, true, true );
   irr::gui::CGUITTFont* fontMono400 = loadFont( fontFileMono400, env, 14, true, true );
   irr::gui::CGUITTFont* fontMono900 = loadFont( fontFileMono900, env, 12, true, true );

   env->getSkin()->setFont( fontMono400, irr::gui::EGDF_DEFAULT );
   env->getSkin()->setFont( fontMono900, irr::gui::EGDF_BUTTON );
   env->getSkin()->setFont( fontMono900, irr::gui::EGDF_WINDOW );
   env->getSkin()->setFont( fontMono400, irr::gui::EGDF_MENU );
   env->getSkin()->setFont( fontMono400, irr::gui::EGDF_TOOLTIP );

   irr::scene::ICameraSceneNode* cam = irrExt::FpsCamera::create( smgr, smgrRoot );
   cam->setNearValue( 1.0f );
   cam->setFarValue( 10000.0f );
   cam->setPosition( irr::core::vector3df( 0.0f, 200.0f, -300.0f ) );
   cam->setTarget( irr::core::vector3df( 0.0f, 0.0f, 0.0f ) );

   irr::core::vector3df l0pos( 0.0f, 1000.0f, 0.0f );
   irr::video::SColorf l0color( 1.0f, 1.0f, .8f, .2f );
   irr::f32 l0radius = 1000.0f;
   irr::s32 l0id = -1;
   //irr::scene::ILightSceneNode* l0 =
   smgr->addLightSceneNode( smgrRoot, l0pos, l0color, l0radius, l0id );

   irr::core::vector3df l1pos( 0.0f, 0.0f, 0.0f );
   irr::video::SColorf l1color( 1.0f, 1.0f, .8f, .6f );
   irr::f32 l1radius = 500.0f;
   irr::s32 l1id = -1;
   //irr::scene::ILightSceneNode* l1 =
   smgr->addLightSceneNode( smgrRoot, l1pos, l1color, l1radius, l1id );


   /// Test ObjectEditor
   // irrExt::ObjectEditor* objeditor = new irrExt::ObjectEditor( env, env->getRootGUIElement(), -1 );

   /// Test CGUICameraEditor
   irrExt::CGUICameraEditor* cameraEditor =
      new irrExt::CGUICameraEditor( env,
            env->getRootGUIElement(), -1,
            irrExt::mkRect( 10, 10, 300, 500 ) );

   /// Test CGUIObjectEditor
   irrExt::CGUIObjectEditor* modelEditor =
      new irrExt::CGUIObjectEditor( env,
            env->getRootGUIElement(), -1,
            irrExt::mkRect( 500, 10, 400, 800 ) );


   /// Test libAssimp
   // testAssimp( smgr );
   //std::string testFile = "../../media/3d/3D_Printer_test_fixed_stl_3rd_gen.STL";
   std::string testFile = "../../media/3d/T-Rex.3mf";
   std::string fileName = irrExt::getAbsoluteFileName( testFile );
   std::cout << "[Info] Model[0].FileName = " << fileName << "\n";

   irrExt::AutoSceneNode* node = nullptr;

   irrExt::AssimpFile file;
   if ( file.open( fileName ) )
   {
      node = irrExt::createSceneNode( smgr, file );

      auto rtv = irrExt::mkRect( 100, 20, 500, 1000 );
      irr::gui::IGUIWindow* tvWin = env->addWindow( rtv, false, L"Assimp Model Stat", nullptr, -1 );

      irr::gui::IGUITreeView* tv = irrExt::createTreeView( file, env, tvWin, tvWin->getClientRect() );

   }

   if ( node )
   {
      node->setPosition( irr::core::vector3df( 0.0f, 0.0f, 0.0f ) );
      node->setMaterialFlag( irr::video::EMF_LIGHTING, true );
      node->setMaterialFlag( irr::video::EMF_WIREFRAME, false );
      node->setMaterialFlag( irr::video::EMF_FOG_ENABLE, true );

      modelEditor->setSceneNode( node );
   }




    //
    //
    //	User stuff happens now ( before entering main loop ) ...
    //
    //

    // ...

    //
    //
    //	User stuff ends now, run main loop ...
    //
    //

   /// MAIN LOOP
   uint64_t timeNow = device->getTimer()->getRealTime();
   uint64_t timeStart = timeNow;
   uint64_t timeLastScreenUpdate = device->getTimer()->getRealTime();
   uint64_t timeLastWindowTitleUpdate = device->getTimer()->getRealTime();
   uint64_t waitUpdateScreen = 0;
   uint64_t waitUpdateWindowTitle = 1000 / 10;
   irr::core::dimension2du lastWindowSize = irr::core::dimension2du( 0,0 );

   while (device && device->run())
   {
      timeNow = device->getTimer()->getRealTime();
      if ( driver )
      {
         screenSize = driver->getScreenSize();
         if ( lastWindowSize != irr::core::dimension2du( 0,0 )
            && lastWindowSize != screenSize )
         {
            float aspect = 1.0f;
            if ( screenSize.Height > 0 )
            {
               aspect = float( screenSize.Width ) / float( screenSize.Height );
            }

            irr::scene::ICameraSceneNode* camera = smgr->getActiveCamera();
            if ( camera )
            {
               camera->setAspectRatio( aspect );
            }
         }
      }

      if ( device->isWindowActive() &&
           timeNow - timeLastScreenUpdate >= waitUpdateScreen )
      {
         timeLastScreenUpdate = timeNow;

         if ( driver )
         {
            driver->beginScene( true, true, clearColor );
            if ( smgr ) { smgr->drawAll(); }
            if ( env ) { env->drawAll(); }
            driver->endScene();

            if ( timeNow - timeLastWindowTitleUpdate >= waitUpdateWindowTitle )
            {
               timeLastWindowTitleUpdate = timeNow;

               std::stringstream s;
               s << appName;
               s << "- FPS(" << driver->getFPS() << ")";
               s << ", Prim(" << device->getVideoDriver()->getPrimitiveCountDrawn() << ")";
               s << ", Tex(" << device->getVideoDriver()->getTextureCount() << ")";
               s << ", Screen(" << screenSize.Width << "," << screenSize.Height << ")";

               irr::scene::ICameraSceneNode* camera = smgr->getActiveCamera();
               if ( camera )
               {
                  irr::core::vector3df const & p = camera->getAbsolutePosition();
                  irr::core::vector3df const & t = camera->getTarget();
                  irr::core::vector3df const & r = camera->getRotation();
                  s << ", CamPos(" << int32_t( p.X ) << ',' << int32_t( p.Y ) << ',' << int32_t( p.Z ) << ")";
                  s << ", CamEye(" << int32_t( t.X ) << ',' << int32_t( t.Y ) << ',' << int32_t( t.Z ) << ")";
                  s << ", CamAng(" << int32_t( r.X ) << ',' << int32_t( r.Y ) << ',' << int32_t( r.Z ) << ")";
               }
               device->setWindowCaption( irr::core::stringw( s.str().c_str() ).c_str() );
            }
         }

      }
      else
      {
         device->yield();
      }
   }

   file.close();
   return 0;
}


#endif

