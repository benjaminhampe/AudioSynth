#ifndef PAINT_MODE_CONTROL_HPP
#define PAINT_MODE_CONTROL_HPP

#include "CompileConfig.hpp"

class MainWindow;

class ModeControl : public QWidget
{
   Q_OBJECT
public:
   ModeControl( QWidget * parent = 0 );
   ~ModeControl();

   PaintMode::EPaintMode
   getPaintMode() const { return m_PaintMode; }

signals:
   void paintModeChanged( PaintMode::EPaintMode paintMode );

public slots:
   void emit_paintModeChanged();

   void onModeSelectRect( bool checked );
   void onModeSelectEllipse( bool checked );
   void onModeSelectManual( bool checked );
   void onModeSelectPolygon( bool checked );

   void onModeDrawText( bool checked );
   void onModeDrawPoint( bool checked );
   void onModeDrawLine( bool checked );
   void onModeDrawLineStrip( bool checked );
   void onModeDrawRect( bool checked );
   void onModeDrawEllipse( bool checked );

   void onModeSprayDose( bool checked );
   void onModeFloodFill( bool checked );
   void onModeDrawBrush( bool checked );
   void onModeDrawArc( bool checked );
   void onModeDrawPolygon( bool checked );

//protected:
//   void keyPressEvent( QKeyEvent * );
//   void closeEvent( QCloseEvent * );

private:
   MainWindow* m_MainWindow;
   PaintMode::EPaintMode m_PaintMode;

   // QPushButton* m_BtnNone;

   QPushButton* m_SelectRect;
   QPushButton* m_SelectEllipse;
   QPushButton* m_SelectManual;
   QPushButton* m_SelectPolygon;

   QPushButton* m_DrawText;
   QPushButton* m_DrawPoint;
   QPushButton* m_DrawLine;
   QPushButton* m_DrawLineStrip;
   QPushButton* m_DrawRect;
   QPushButton* m_DrawEllipse;

   QPushButton* m_DrawBrush;
   QPushButton* m_SprayDose;
   QPushButton* m_FloodFill;
   QPushButton* m_DrawArc;
   QPushButton* m_DrawPolygon;
};

#endif
