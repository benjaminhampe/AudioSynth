#ifndef FONT_WIDGET_HPP
#define FONT_WIDGET_HPP

#include "CompileConfig.hpp"
#include <QDialog>
class FontWidget : public QDialog
{
   Q_OBJECT
public:
   FontWidget( QWidget * parent = 0 );
   ~FontWidget() override;

public slots:
   void fontFamilyIndexChanged( int );
private:
   QString m_Family;
   int m_PointSize;
   int m_Weight;
   bool m_IsItalic;

   QComboBox* m_Families;
   std::vector< QLabel* > m_Items;

};

#endif
