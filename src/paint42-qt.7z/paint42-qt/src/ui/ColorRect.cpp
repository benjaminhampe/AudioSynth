#include "ColorRect.hpp"

ColorRect::ColorRect( QWidget * parent )
   : QWidget( parent )
   , m_Image()
{
   setContentsMargins( 0,0,0,0 );
   setMinimumSize( 64,32 );
   setSizePolicy( QSizePolicy::Expanding, QSizePolicy::Expanding );
}

ColorRect::~ColorRect()
{

}

void
ColorRect::resizeEvent( QResizeEvent* event )
{
   int w = event->size().width();
   int h = event->size().height();
   qDebug() << "ColorRect." << __FUNCTION__ << "(" << w << "," << h << ")";
}

void
ColorRect::paintEvent( QPaintEvent* event )
{
   int x = event->rect().left();
   int y = event->rect().top();
   int w = event->rect().width();
   int h = event->rect().height();
   qDebug() << "ColorRect." << __FUNCTION__ << "(" << x << "," << y << "," << w << "," << h << ")";
}

void
ColorRect::mousePressEvent( QMouseEvent* event )
{
   int x = event->x();
   int y = event->y();
   qDebug() << "ColorRect." << __FUNCTION__ << "(" << x << "," << y << ")";
}

void
ColorRect::mouseReleaseEvent( QMouseEvent* event )
{
   int x = event->x();
   int y = event->y();
   qDebug() << "ColorRect." << __FUNCTION__ << "(" << x << "," << y << ")";
}

