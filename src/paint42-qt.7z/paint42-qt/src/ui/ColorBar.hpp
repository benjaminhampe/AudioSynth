#ifndef PAINT_COLORBAR_HPP
#define PAINT_COLORBAR_HPP

#include "ColorButton.hpp"
#include <QLineEdit>
#include <QSlider>

class ColorBar : public QWidget
{
   Q_OBJECT
public:
   ColorBar( QWidget * parent = nullptr );
   ~ColorBar() override;

signals:
   void fillColorChanged( QColor color );
   void lineColorChanged( QColor color );
   void lineWidthChanged( float lineWidth );

public slots:
   void setLineColor( QColor color );
   void setFillColor( QColor color );


   void emit_lineColor();
   void emit_lineWidth();
   void emit_fillColor();
   void setColorEditText( QColor color );
   void onEditedForeground( QString const & text );
   void onEditedBackground( QString const & text );
   void onChangedFgAlpha( int value );
   void onChangedBgAlpha( int value );
protected:

public:
   bool m_IsBgSelected;

   QLineEdit* m_FgEdit;
   QLineEdit* m_BgEdit;
   QSlider* m_FgAlpha;
   QSlider* m_BgAlpha;
   ColorButton* m_FgColor;
   ColorButton* m_BgColor;

   std::vector< ColorButton* > m_Colors;
};

#endif
