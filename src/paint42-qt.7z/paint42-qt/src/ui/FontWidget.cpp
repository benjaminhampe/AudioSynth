#include "FontWidget.hpp"

#include "MainWindow.hpp"
#include <QDebug>
#include <fontawesome.hpp>
#include <QVBoxLayout>
#include <QHBoxLayout>

FontWidget::FontWidget( QWidget * parent )
   : QDialog( parent )
   , m_Families( nullptr )
{
   m_Families = new QComboBox( this );
   m_Families->setSizePolicy( QSizePolicy::Expanding, QSizePolicy::Preferred );
   QFontDatabase fontDB;
   QStringList families = fontDB.families();
   for ( int i = 0; i < families.size(); ++i )
   {
      m_Families->addItem( families.at( i ) );
   }

   QGridLayout* g = new QGridLayout( this );
   g->setContentsMargins( 0,0,0,0 );
   g->setSpacing( 1 );
   std::stringstream s;

   int w = 32;
   int h = 32;
   for ( int y = 0; y < h; ++y )
   {
      for ( int x = 0; x < w; ++x )
      {
         int c = x + y * w; // ( 0xF000 ) +
         QString labelText = QString( QChar( c ) );
         QLabel* label = new QLabel( labelText, this );
         label->setSizePolicy( QSizePolicy::Expanding, QSizePolicy::Expanding );
         s.str("");
         s << labelText.toStdString() << " " << std::hex << c;

         label->setToolTip( QString::fromStdString( s.str() ) );

         g->addWidget( label, y, x, 1, 1 );

         m_Items.push_back( label );
      }
   }

   QWidget* panel = new QWidget( this );
   panel->setLayout( g );

   QVBoxLayout* v = new QVBoxLayout( this );
   v->addWidget( m_Families );
   v->addWidget( panel, 1 );
   setLayout( v );
   connect( m_Families, SIGNAL( currentIndexChanged( int ) ), this, SLOT( fontFamilyIndexChanged( int ) ) );
}

FontWidget::~FontWidget()
{

}

void
FontWidget::fontFamilyIndexChanged( int )
{
   m_Family = m_Families->currentText();
   m_PointSize = font().pointSize();
   m_Weight = font().weight();
   m_IsItalic = font().italic();
   setFont( QFont( m_Family, m_PointSize, m_Weight, m_IsItalic ) );

   for ( size_t i = 0; i < m_Items.size(); ++i)
   {
      if ( m_Items[ i ] )
      {
         m_Items[ i ]->setFont( font() );
      }
   }
}
