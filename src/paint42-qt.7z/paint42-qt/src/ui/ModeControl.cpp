#include "ModeControl.hpp"

#include "MainWindow.hpp"
#include <QDebug>
#include <fontawesome.hpp>

QPushButton* createButton( QString text, QWidget* parent )
{
   QPushButton* b = new QPushButton( text, parent );
   b->setSizePolicy( QSizePolicy::Expanding, QSizePolicy::Expanding );
   //b->setMinimumHeight( 16 );
   return b;
}

ModeControl::ModeControl( QWidget * parent )
   : QWidget( parent )
   , m_PaintMode( PaintMode::Max )
{
   m_MainWindow = dynamic_cast< MainWindow* >( parent );
   m_SelectRect = createButton( QString( QChar( fa::reddit ) ) + " SelRect", this );
   m_SelectEllipse = createButton( QString( QChar( fa::ellipsish ) ) + " SelEllipse", this );
   m_SelectManual = createButton( QString( QChar( fa::pencil ) ) + " SelManual", this );
   m_SelectPolygon = createButton( QString( QChar( fa::play ) ) + " SelPolygon", this );

   m_DrawText = createButton( QString( QChar( fa::filetext ) ) + " Text", this );
   m_DrawPoint = createButton( QString( QChar( fa::pencil ) ) + " Point", this );
   m_DrawLine = createButton( QString( QChar( fa::pencil ) ) + " Line", this );
   m_DrawLineStrip = createButton( QString( QChar( fa::pencil ) ) + " LineStrip", this );
   m_DrawRect = createButton( QString( QChar( fa::stop ) ) + " Rect", this );
   m_DrawEllipse = createButton( QString( QChar( fa::ellipsish ) ) + " Ellipse", this );

   m_DrawBrush = createButton( QString( QChar( fa::pencil ) ) + " Brush", this );
   m_SprayDose = createButton( QString( QChar( fa::pencil ) ) + " SprayCan", this );
   m_FloodFill = createButton( QString( QChar( fa::fileimageo ) ) + " FloodFill", this );
   m_DrawArc = createButton( QString( QChar( fa::pencil ) ) + " Arc", this );
   m_DrawPolygon = createButton( QString( QChar( fa::pencil ) ) + " Polygon", this );

   QGridLayout* g = new QGridLayout( this );
   g->setContentsMargins( 0,0,0,0 );

   int row = 0;
   int col = 0;
   g->addWidget( m_SelectRect, row, col, 1, 1 ); ++row;
   g->addWidget( m_SelectEllipse, row, col, 1, 1 ); ++row;
   g->addWidget( m_SelectManual, row, col, 1, 1 ); ++row;
   g->addWidget( m_SelectPolygon, row, col, 1, 1 ); ++row;
   g->addWidget( m_SprayDose, row, col, 1, 1 ); ++row;
   g->addWidget( m_DrawArc, row, col, 1, 1 ); ++row;
   g->addWidget( m_DrawPolygon, row, col, 1, 1 ); ++row;

   row = 0;
   col = 1;
   g->addWidget( m_DrawText, row, col, 1, 1 ); ++row;
   g->addWidget( m_DrawPoint, row, col, 1, 1 ); ++row;
   g->addWidget( m_DrawRect, row, col, 1, 1 ); ++row;
   g->addWidget( m_DrawLine, row, col, 1, 1 ); ++row;
   g->addWidget( m_DrawLineStrip, row, col, 1, 1 ); ++row;
   g->addWidget( m_DrawEllipse, row, col, 1, 1 ); ++row;
   g->addWidget( m_DrawBrush, row, col, 1, 1 ); ++row;
   g->addWidget( m_FloodFill, row, col, 1, 1 ); ++row;

   setLayout( g );

   connect( m_SelectRect,     &QPushButton::clicked, this, &ModeControl::onModeSelectRect );
   connect( m_SelectEllipse,  &QPushButton::clicked, this, &ModeControl::onModeSelectEllipse );
   connect( m_SelectManual,   &QPushButton::clicked, this, &ModeControl::onModeSelectManual );
   connect( m_SelectPolygon,  &QPushButton::clicked, this, &ModeControl::onModeSelectPolygon );
   connect( m_SprayDose,      &QPushButton::clicked, this, &ModeControl::onModeSprayDose );
   connect( m_FloodFill,      &QPushButton::clicked, this, &ModeControl::onModeFloodFill );
   connect( m_DrawArc,        &QPushButton::clicked, this, &ModeControl::onModeDrawArc );
   connect( m_DrawPolygon,    &QPushButton::clicked, this, &ModeControl::onModeDrawPolygon );

   connect( m_DrawText,       &QPushButton::clicked, this, &ModeControl::onModeDrawText );
   connect( m_DrawPoint,      &QPushButton::clicked, this, &ModeControl::onModeDrawPoint );
   connect( m_DrawLine,       &QPushButton::clicked, this, &ModeControl::onModeDrawLine );
   connect( m_DrawLineStrip,  &QPushButton::clicked, this, &ModeControl::onModeDrawLineStrip );
   connect( m_DrawRect,       &QPushButton::clicked, this, &ModeControl::onModeDrawRect );
   connect( m_DrawEllipse,    &QPushButton::clicked, this, &ModeControl::onModeDrawEllipse );
   connect( m_DrawBrush,      &QPushButton::clicked, this, &ModeControl::onModeDrawBrush );
}

ModeControl::~ModeControl()
{

}

void ModeControl::emit_paintModeChanged()
{
   emit paintModeChanged( m_PaintMode );
}

void ModeControl::onModeSelectRect( bool checked )
{
   qDebug() << "Set paint mode to 'Select Rectangle'.";
   m_PaintMode = PaintMode::SelectRect;
   emit_paintModeChanged();
}
void ModeControl::onModeDrawRect( bool checked )
{
   qDebug() << "Set paint mode to 'Draw Rect'.";
   m_PaintMode = PaintMode::Rect;
   emit_paintModeChanged();
}
void ModeControl::onModeSelectManual( bool checked )
{
   qDebug() << "Set paint mode to 'Select Manual FreeHand Form'.";
   m_PaintMode = PaintMode::SelectManual;
   emit_paintModeChanged();
}
void ModeControl::onModeDrawPoint( bool checked )
{
   qDebug() << "Set paint mode to 'Draw Point'.";
   m_PaintMode = PaintMode::Point;
   emit_paintModeChanged();
}
void ModeControl::onModeSelectPolygon( bool checked )
{
   qDebug() << "Set paint mode to 'Select Polygon'.";
   m_PaintMode = PaintMode::SelectPolygon;
   emit_paintModeChanged();
}
void ModeControl::onModeDrawLine( bool checked )
{
   qDebug() << "Set paint mode to 'Draw Line'.";
   m_PaintMode = PaintMode::Line;
   emit_paintModeChanged();
}
void ModeControl::onModeDrawLineStrip( bool checked )
{
   qDebug() << "Set paint mode to 'Draw LineStrip'.";
   m_PaintMode = PaintMode::LineStrip;
   emit_paintModeChanged();
}
void ModeControl::onModeDrawBrush( bool checked )
{
   qDebug() << "Set paint mode to 'Draw Brush'.";
   m_PaintMode = PaintMode::Brush;
   emit_paintModeChanged();
}
void ModeControl::onModeSprayDose( bool checked )
{
   qDebug() << "Set paint mode to 'Draw SprayDose'.";
   m_PaintMode = PaintMode::SprayDose;
   emit_paintModeChanged();
}
void ModeControl::onModeFloodFill( bool checked )
{
   qDebug() << "Set paint mode to 'Draw FloodFill'.";
   m_PaintMode = PaintMode::FloodFill;
   emit_paintModeChanged();
}
void ModeControl::onModeDrawText( bool checked )
{
   qDebug() << "Set paint mode to 'Draw Text'.";
   m_PaintMode = PaintMode::Text;
   emit_paintModeChanged();
}
void ModeControl::onModeSelectEllipse( bool checked )
{
   qDebug() << "Set paint mode to 'Select Ellipse'.";
   m_PaintMode = PaintMode::SelectEllipse;
   emit_paintModeChanged();
}
void ModeControl::onModeDrawEllipse( bool checked )
{
   qDebug() << "Set paint mode to 'Draw Ellipse'.";
   m_PaintMode = PaintMode::Ellipse;
   emit_paintModeChanged();
}
void ModeControl::onModeDrawArc( bool checked )
{
   qDebug() << "Set paint mode to 'Draw Arc'.";
   m_PaintMode = PaintMode::Arc;
   emit_paintModeChanged();
}
void ModeControl::onModeDrawPolygon( bool checked )
{
   qDebug() << "Set paint mode to 'Draw Polygon'.";
   m_PaintMode = PaintMode::Polygon;
   emit_paintModeChanged();
}
