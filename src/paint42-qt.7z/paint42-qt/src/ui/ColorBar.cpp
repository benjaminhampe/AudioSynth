#include "ColorBar.hpp"
#include <QLabel>

QSlider*
createAlphaSlider( Qt::Orientation orientation, QWidget * parent )
{
   QSlider* slider = new QSlider( orientation, parent );
   slider->setTickInterval( 5 );
   slider->setMinimum( 0 );
   slider->setMaximum( 255 );
   return slider;
}


ColorBar::ColorBar( QWidget * parent )
   : QWidget( parent )
   , m_IsBgSelected( false )
   , m_FgColor( nullptr )
   , m_BgColor( nullptr )
{
   setContentsMargins( 0,0,0,0 );
   setMinimumHeight( 64 );

   m_FgEdit = new QLineEdit( "rgba(255,255,255,255)", this );
   m_BgEdit = new QLineEdit( "#FFFFFFFF", this );

   m_FgAlpha = createAlphaSlider( Qt::Horizontal, this );
   m_BgAlpha = createAlphaSlider( Qt::Horizontal, this );

   m_FgColor = new ColorButton( "FG", 0xFF000000, this );
   m_BgColor = new ColorButton( "BG", 0xFFFFFFFF, this );

   std::vector< uint32_t > colors{
      0xFFFFFFFF,
      0xFF0000FF,
      0xFF00FF00,
      0xFFFF0000,
      0xFFFF00FF,
      0xFF00FFFF,
      0xFF0080FF,
      0xFF0040FF,
      0xFF0080FF,
      0xFF0040FF,
      0xFFFFFFFF,
      0xFF0000FF,
      0xFF00FF00,
      0xFFFF0000,
      0xFFFF00FF,
      0xFF00FFFF,
      0xFF0080FF,
      0xFF0040FF,
      0xFF0080FF,
      0xFF0040FF };

   m_Colors.reserve( colors.size() );
   for ( size_t i = 0; i < colors.size(); ++i )
   {
      ColorButton* btn = new ColorButton( QString::number( i ), colors[ i ], this );
      m_Colors.push_back( btn );
   }

   QGridLayout* g = new QGridLayout( this );
   g->setContentsMargins( 0,0,0,0 );
   g->setSpacing( 1 );

   int row = 0;
   int col = 0;
   g->addWidget( m_FgEdit, 0, 0, 1, 1 );
   g->addWidget( m_BgEdit, 1, 0, 1, 1 ); ++col;
   g->addWidget( m_FgColor, 0, col, 1, 1 );
   g->addWidget( m_BgColor, 1, col, 1, 1 ); ++col;
   g->addWidget( m_FgAlpha, 0, col, 1, 1 );
   g->addWidget( m_BgAlpha, 1, col, 1, 1 ); ++col;
   //g->setColumnStretch( 1, 1 );

   for ( size_t i = 0; i < m_Colors.size() / 2; ++i )
   {
      row = 0;
      g->addWidget( m_Colors[ 2*i + 0 ], row, col, 1, 1 );
      ++row;
      g->addWidget( m_Colors[ 2*i + 1 ], row, col, 1, 1 );
      ++col;
   }

   if ( m_Colors.size() - ((m_Colors.size() / 2) * 2) > 0 )
   {
      row = 0;
      g->addWidget( m_Colors[ m_Colors.size() - 1 ], row, col, 1, 1 );
   }

   connect( m_FgEdit, &QLineEdit::textChanged, this, &ColorBar::onEditedForeground );
   connect( m_BgEdit, &QLineEdit::textChanged, this, &ColorBar::onEditedBackground );
   connect( m_FgAlpha, &QSlider::valueChanged, this, &ColorBar::onChangedFgAlpha );
   connect( m_BgAlpha, &QSlider::valueChanged, this, &ColorBar::onChangedBgAlpha );

   for ( size_t i = 0; i < m_Colors.size(); ++i )
   {
      connect( m_Colors[ i ], &ColorButton::fgcolorChanged, this, &ColorBar::setLineColor );
      connect( m_Colors[ i ], &ColorButton::bgcolorChanged, this, &ColorBar::setFillColor );
   }
}

ColorBar::~ColorBar()
{

}

void
ColorBar::setLineColor( QColor color )
{
   if ( m_FgColor ) m_FgColor->setColor( color );
   color.setAlpha( 255 - m_FgAlpha->value() );
   m_FgColor->setColor( color );
   setColorEditText( color );
   emit_lineColor();
}
void
ColorBar::setFillColor( QColor color )
{
   if ( m_BgColor ) m_BgColor->setColor( color );
   color.setAlpha( 255 - m_BgAlpha->value() );
   m_BgColor->setColor( color );
   setColorEditText( color );
   emit_fillColor();
}


void
ColorBar::onEditedForeground( QString const & text )
{
   QColor c = m_FgColor->getColor();
   qDebug() << __FUNCTION__ << "(" << c.red() << "," << c.green() << "," << c.blue() << "," << c.alpha() << ")";
//   emit lineColorChanged( c );
}
void
ColorBar::onEditedBackground( QString const & text )
{
   QColor c = m_FgColor->getColor();
   qDebug() << __FUNCTION__ << "(" << c.red() << "," << c.green() << "," << c.blue() << "," << c.alpha() << ")";
//   emit lineColorChanged( c );
}
void
ColorBar::onChangedFgAlpha( int value )
{
   QColor c = m_FgColor->getColor();
   c.setAlpha( 255 - value );
   m_FgColor->setColor( c );
   setColorEditText( c );
   emit lineColorChanged( c );
   qDebug() << __FUNCTION__ << "(" << c.red() << "," << c.green() << "," << c.blue() << "," << c.alpha() << ")";
}
void
ColorBar::onChangedBgAlpha( int value )
{
   QColor c = m_BgColor->getColor();
   c.setAlpha( 255 - value );
   m_BgColor->setColor( c );
   setColorEditText( c );
   emit fillColorChanged( c );
   qDebug() << __FUNCTION__ << "(" << c.red() << "," << c.green() << "," << c.blue() << "," << c.alpha() << ")";
}

void
ColorBar::setColorEditText( QColor color )
{
   std::stringstream s;
   s << "rgba(" << color.red() << "," << color.green() << "," << color.blue() << "," << color.alpha() << ")";
   m_FgEdit->setText( QString::fromStdString( s.str() ) );
   s.str(""); s << std::hex << "#" << color.rgba();
   m_BgEdit->setText( QString::fromStdString( s.str() ) );
}

void
ColorBar::emit_lineColor()
{
   QColor c = m_FgColor->getColor();
   qDebug() << __FUNCTION__ << "(" << c.red() << "," << c.green() << "," << c.blue() << "," << c.alpha() << ")";
   emit lineColorChanged( c );
}
void
ColorBar::emit_lineWidth()
{
   // QColor c = m_FgColor->getColor();
   qDebug() << __FUNCTION__ << "()"; // << c.red() << "," << c.green() << "," << c.blue() << "," << c.alpha() << ")";
   // emit lineWidthChanged( m_StrokeWidth );
}
void
ColorBar::emit_fillColor()
{
   QColor c = m_BgColor->getColor();
   qDebug() << __FUNCTION__ << "(" << c.red() << "," << c.green() << "," << c.blue() << "," << c.alpha() << ")";
   emit fillColorChanged( c );
}
