#ifndef PAINT_HISTORY_HPP
#define PAINT_HISTORY_HPP

#include "DrawCommandList.hpp"
#include <QLabel>
#include <QListWidget>
#include <QTextBlock>
#include <QTextEdit>

// <path d="M16 16s-1.5-2-4-2-4 2-4 2"></path>
// <path d="M5 5.5A3.5 3.5 0 0 1 8.5 2H12v7H8.5A3.5 3.5 0 0 1 5 5.5z"></path>
// <path d="M12 2h3.5a3.5 3.5 0 1 1 0 7H12V2z"></path>
// <path d="M12 12.5a3.5 3.5 0 1 1 7 0 3.5 3.5 0 1 1-7 0z"></path>
// <path d="M5 19.5A3.5 3.5 0 0 1 8.5 16H12v3.5a3.5 3.5 0 1 1-7 0z"></path>
// <path d="M5 12.5A3.5 3.5 0 0 1 8.5 9H12v7H8.5A3.5 3.5 0 0 1 5 12.5z"></path>
struct SvgPath
{
   enum ECommands
   {
      MoveTo = 0,
      LineTo,
      HorzTo,
      VertTo,
      ArcTo,
      SplineTo
   };

   std::vector< Point2df > m_Points;
};

class History : public QWidget
{
   Q_OBJECT
public:
   History( QWidget * parent = nullptr );
   ~History() override;
   DrawCommandHistory const * getDrawCommandHistory() const { return &m_History; }
   DrawCommandHistory*        getDrawCommandHistory() { return &m_History; }
signals:
public slots:
   void begin();
   void end();
   void cutImage( int x1, int y1, int x2, int y2 );
   void pasteImage( QImage img, int x, int y );
   //void copyRect( int x1, int y1, int x2, int y2 );
   void setLineColor( QColor const & color );
   void setLineWidth( float lineWidth = 1.0f );
   void setFillColor( QColor const & color );
   void drawPoint( int x, int y );
   void drawLine( int x1, int y1, int x2, int y2 );
   void drawRect( int x1, int y1, int x2, int y2 );
   void drawText( QString txt, int x, int y, TextAlignment::EAlignment align = TextAlignment::LeftTop );

   void drawCircle( int cx, int cy, int radius );
   void drawEllipse( int cx, int cy, int a, int b );

   void drawLineStrip( std::vector< Point2di > const & lineStrip );
   void drawPath( SvgPath svgPath );
private:
   QTextEdit* m_Text;
   DrawCommandHistory m_History;
};

#endif
