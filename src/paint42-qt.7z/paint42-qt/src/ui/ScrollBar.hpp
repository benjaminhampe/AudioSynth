#ifndef PAINT_SCROLLBAR_HPP
#define PAINT_SCROLLBAR_HPP

#include <QScrollBar>

class ScrollBar : public QScrollBar
{
public:
   ScrollBar( Qt::Orientation orientation, QWidget* parent ) : QScrollBar( orientation, parent ) {}
protected:
   QSize sizeHint() const override
   {
      return QSize(32, 32);
   }

   QSize minimumSizeHint() const override
   {
      return QSize(32, 32);
   }
};

#endif
