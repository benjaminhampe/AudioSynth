#ifndef PAINT_MAINWINDOW_HPP
#define PAINT_MAINWINDOW_HPP

#include "CompileConfig.hpp"
#include "ScrollBar.hpp"
#include "PasteBar.hpp"
#include "ZoomBar.hpp"
#include "FontWidget.hpp"
#include "Thumbnail.hpp"
#include "ZoomView.hpp"
#include "ColorBar.hpp"
#include "ToolBar.hpp"
#include "TextBar.hpp"
#include "StatusBar.hpp"
#include "ModeControl.hpp"
#include "History.hpp"
#include "Canvas.hpp"

#include <QScrollArea>

class MainWindow : public QMainWindow
{
   Q_OBJECT
public:

   MainWindow( QWidget * parent = nullptr );
   ~MainWindow() override;

   QString getImageURI() const { return m_Canvas->getImageUri(); }
   QImage const & getImage() const { return m_Canvas->getImage(); }
   ZoomBar* getZoomBar() const { return m_ZoomBar; }
   History* getHistory() const { return m_History; }
   Thumbnail* getThumbnail() const { return m_Thumbnail; }
   ZoomView* getZoomView() const { return m_ZoomView; }
   ModeControl* getModeControl() const { return m_ModeControl; }
   Canvas* getCanvas() const { return m_Canvas; }
   ColorBar* getColorBar() const { return m_ColorBar; }
   StatusBar* getStatusBar() const { return m_StatusBar; }
   TextBar* getTextBar() const { return m_TextBar; }

signals:
   void moveCursorLeft();
   void moveCursorRight();
   void moveCursorUp();
   void moveCursorDown();

public slots:
   void on_menu_file_exit();
   void on_menu_file_new();
   void on_menu_file_load();
   void on_menu_file_save();
   void on_menu_file_saveAs();


   void on_show_fontwidget( bool checked );
   void on_show_about();
   void on_scroll_h( int );
   void on_scroll_v( int );

   void newCanvasImage();
   void setCanvasImage( QImage img, QString uri );
   void loadCanvasImage( QString uri );
   void saveCanvasImage( QString uri );

protected:
   void keyPressEvent( QKeyEvent* event ) override;
   void createMenuBar();
   void createStatusBar();

#if 0
protected:
   void keyPressEvent( QKeyEvent * );
   void closeEvent( QCloseEvent * );
#endif

public:
   QScrollArea* m_ScrollArea;
   ScrollBar* m_ScrollH;
   ScrollBar* m_ScrollV;
   Canvas* m_Canvas;


   PasteBar* m_PasteBar;
   ZoomBar* m_ZoomBar;
   History* m_History;
   FontWidget* m_FontWidget;
   QMenuBar* m_MenuBar;
   Thumbnail* m_Thumbnail;
   QCheckBox * m_ZoomCheck;
   ZoomView* m_ZoomView;
   ToolBar* m_ToolBar;
   ModeControl* m_ModeControl;

   ColorBar* m_ColorBar;
   TextBar* m_TextBar;
   StatusBar* m_StatusBar;

   bool m_ZoomViewEnabled;
};

#endif
