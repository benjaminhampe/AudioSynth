#include "StatusBar.hpp"
#include <QLabel>

StatusBar::StatusBar( QWidget * parent )
   : QStatusBar( parent )
{
//   setContentsMargins( 0,0,0,0 );
//   setMinimumHeight( 64 );

//   QStatusBar* statusBar = new QStatusBar( this );
//   setMinimumWidth( 32 );
//   setContentsMargins( 0,0,0,0 );
   m_ImageInfo = new QLabel( parent );
   m_CanvasInfo = new QLabel( parent );
   m_MouseInfo = new QLabel( parent );
   m_DrawModeInfo = new QLabel( parent );
   // QString modeString = QString::fromStdString( PaintMode::toString( m_ModeControl->getPaintMode() ) );
   m_DrawModeInfo->setText( "Mode: None" );
   addWidget( m_DrawModeInfo, 1 );
   addWidget( m_ImageInfo, 1 );
   addWidget( m_CanvasInfo, 1 );
   addWidget( m_MouseInfo, 1 );

}

StatusBar::~StatusBar()
{

}
