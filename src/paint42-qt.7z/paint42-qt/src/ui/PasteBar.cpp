#include "PasteBar.hpp"
#include <fontawesome.hpp>

#include <QToolBar>
#include <QToolButton>

namespace {

QToolButton*
createToolButton( QString const & buttonText, QWidget* parent )
{
   QToolButton* b = nullptr;
   b = new QToolButton( parent );
   b->setMinimumSize( 32, 32 );
   b->setText( buttonText );
   b->setFont( QFont( "fontawesome", 16 ) );
   return b;
}

}

PasteBar::PasteBar( QWidget * parent )
   : QToolBar( "Cut, copy 'n paste tools", parent )
{
   m_Cut = createToolButton( QChar( fa::cut ), parent );
   m_Copy = createToolButton( QChar( fa::copy ), parent );
   m_Paste = createToolButton( QChar( fa::paste ), parent );
   addWidget( m_Cut );
   addWidget( m_Copy );
   addWidget( m_Paste );
}

PasteBar::~PasteBar()
{

}
