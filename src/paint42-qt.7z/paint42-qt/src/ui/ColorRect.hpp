#ifndef PAINT_COLORRECT_HPP
#define PAINT_COLORRECT_HPP

#include "ColorButton.hpp"
#include <QLineEdit>
#include <QSlider>
#include <QLabel>

class ColorRect : public QWidget
{
   Q_OBJECT
public:
   ColorRect( QWidget * parent = nullptr );
   ~ColorRect() override;
   QColor const & getColor() const { return m_Color; }
signals:
   void lineColorChanged( QColor color );
   void fillColorChanged( QColor color );
public slots:
protected:
   void resizeEvent( QResizeEvent* event );
   void paintEvent( QPaintEvent* event );
   void mousePressEvent( QMouseEvent* event );
   void mouseReleaseEvent( QMouseEvent* event );
public:
   QColor m_Color;
   QImage m_Image;
};

#endif
