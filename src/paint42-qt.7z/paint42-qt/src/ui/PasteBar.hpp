#ifndef PAINT_PASTEBAR_HPP
#define PAINT_PASTEBAR_HPP

#include "CompileConfig.hpp"
#include <QToolBar>
#include <QToolButton>
#include <QComboBox>

class PasteBar : public QToolBar
{
   Q_OBJECT
public:
   PasteBar( QWidget * parent = nullptr );
   ~PasteBar() override;
   QToolButton* m_Cut;
   QToolButton* m_Copy;
   QToolButton* m_Paste;
};

#endif
