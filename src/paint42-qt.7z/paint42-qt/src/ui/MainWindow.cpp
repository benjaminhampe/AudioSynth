#include "MainWindow.hpp"
#include <QScrollBar>

namespace {

//QDockWidget*
//createDockWidget( QWidget* content, QString title, QWidget* parent )
//{
//   QDockWidget* dock = new QDockWidget( title, parent );
//   dock->setWidget( content );
//   dock->setStyleSheet( "QDockWidget::title { font-weight:900; text-align:center; }" );
//   QFont font = dock->font();
//   font.setBold( true );
//   dock->setFont( font );
//   return dock;
//}

}

// --- Status bar ---

void
MainWindow::createStatusBar()
{
   m_StatusBar = new StatusBar( this );
   this->setStatusBar( m_StatusBar );
}

// --- MenuBar ---

void
MainWindow::createMenuBar()
{
   //   newAct = new QAction(tr("&New"), this);
   //   newAct->setShortcuts(QKeySequence::New);
   //   newAct->setStatusTip(tr("Create a new file"));
   //   connect(newAct, &QAction::triggered, this, &MainWindow::newFile);
   //#ifndef QT_NO_CONTEXTMENU
   //    QMenu menu(this);
   //    menu.addAction(cutAct);
   //    menu.addAction(copyAct);
   //    menu.addAction(pasteAct);
   //    menu.exec(event->globalPos());
   //#endif // QT_NO_CONTEXTMENU
   QMenu* menuFiles = new QMenu( "&Dateien" );
   QAction* menuFileLoad = new QAction("&Lade Datei", menuFiles );
   QAction* menuFileNew = new QAction("&Neue Datei", menuFiles );
   QAction* menuFileSave = new QAction("&Speichern", menuFiles );
   QAction* menuFileSaveAs = new QAction("Speichere &als", menuFiles );
   QAction* menuFilePrint = new QAction("&Drucken", menuFiles );
   QAction* menuFileExit = new QAction("B&eende das Programm", menuFiles );
   menuFiles->addAction( menuFileLoad );
   menuFiles->addSeparator();
   menuFiles->addAction( menuFileNew );
   menuFiles->addSeparator();
   menuFiles->addAction( menuFileSave );
   menuFiles->addAction( menuFileSaveAs );
   menuFiles->addSeparator();
   menuFiles->addAction( menuFilePrint );
   menuFiles->addSeparator();
   menuFiles->addAction( menuFileExit );

   // --- MenuBar::Edit ---
   QMenu* menuEdit = new QMenu( "&Edit" );
   QAction* actionCut = new QAction("Cut selection", menuEdit );
   QAction* actionCopy = new QAction("Copy selection", menuEdit );
   QAction* actionPaste = new QAction("Paste selection", menuEdit );
   QAction* actionPasteNew = new QAction("Paste to new image", menuEdit );
   QAction* actionSelectAll = new QAction("Select all", menuEdit );
   QAction* actionInvSelect = new QAction("Invert selection", menuEdit );
   menuEdit->addAction( actionCut );
   menuEdit->addAction( actionCopy );
   menuEdit->addAction( actionPaste );
   menuEdit->addAction( actionPasteNew );
   menuEdit->addSeparator();
   menuEdit->addAction( actionInvSelect );
   menuEdit->addSeparator();
   menuEdit->addAction( actionSelectAll );

   // --- MenuBar::Windows ---
   QMenu* menuWindows = new QMenu( "&Windows" );
   QAction* actionFontWidget = new QAction("Show FontWidget", menuWindows );
   QAction* actionShowCanvas = new QAction("Show Canvas", menuWindows );
   QAction* actionShowPreview = new QAction("Show Preview", menuWindows );
   QAction* actionShowZoomView = new QAction("Show ZoomView", menuWindows );
   QAction* actionShowModes = new QAction("Show Modes", menuWindows );
   QAction* actionShowTextBar = new QAction("Show TextBar", menuWindows );
   QAction* actionShowColorBar = new QAction("Show ColorBar", menuWindows );
   QAction* actionShowAbout = new QAction("Show About", menuWindows );
   menuWindows->addAction( actionFontWidget );
   menuWindows->addSeparator();
   menuWindows->addAction( actionShowCanvas );
   menuWindows->addAction( actionShowPreview );
   menuWindows->addAction( actionShowZoomView );
   menuWindows->addAction( actionShowModes );
   menuWindows->addAction( actionShowTextBar );
   menuWindows->addAction( actionShowColorBar );
   menuWindows->addSeparator();
   menuWindows->addAction( actionShowAbout );
   actionFontWidget->setCheckable( true );
   actionFontWidget->setChecked( true );
   actionShowCanvas->setCheckable( true );
   actionShowCanvas->setChecked( true );
   actionShowAbout->setCheckable( true );
   actionShowAbout->setChecked( true );

   // --- MenuBar ---
   m_MenuBar = new QMenuBar( this );
   m_MenuBar->addMenu( menuFiles );
   m_MenuBar->addMenu( menuEdit );
   m_MenuBar->addMenu( menuWindows );

   setMenuBar( m_MenuBar );
   connect( actionFontWidget, &QAction::triggered, this, &MainWindow::on_show_fontwidget );

   connect( menuFileNew, &QAction::triggered, this, &MainWindow::on_menu_file_new );
   connect( menuFileLoad, &QAction::triggered, this, &MainWindow::on_menu_file_load );
   connect( menuFileSave, &QAction::triggered, this, &MainWindow::on_menu_file_save );
   connect( menuFileSaveAs, &QAction::triggered, this, &MainWindow::on_menu_file_saveAs);
   // connect( menuFilePrint, &QAction::triggered, this, &MainWindow::on_menu_file_new );
   connect( menuFileExit, &QAction::triggered, this, &MainWindow::on_menu_file_exit );
}

// --- MainWindow ---

MainWindow::MainWindow( QWidget * parent )
   : QMainWindow( parent )
{
   // init random number generator
   srand( static_cast< uint32_t >( time( nullptr ) ) );

   m_History = new History( this ); // Pointer needs to be valid before m_Canvas is created!

   createMenuBar();
   createStatusBar();

   // --- ToolBars ---
   m_ToolBar = new ToolBar( this );
   this->addToolBar( m_ToolBar );
   m_PasteBar = new PasteBar( this );
   this->addToolBar( m_PasteBar );
   m_ZoomBar = new ZoomBar( this );
   this->addToolBar( m_ZoomBar );
   m_TextBar = new TextBar( this );
   this->addToolBar( m_TextBar );

   // --- Central widget with GridLayout ---
   m_Canvas = new Canvas( this );

   m_ScrollArea = new QScrollArea( this );
   m_ScrollArea->setSizePolicy( QSizePolicy::Expanding, QSizePolicy::Expanding );
   m_ScrollArea->setBackgroundRole(QPalette::Dark);
   m_ScrollArea->setWidget( m_Canvas );
   m_ScrollArea->setWidgetResizable( true );

   m_ScrollH = new ScrollBar( Qt::Horizontal, this );
   m_ScrollV = new ScrollBar( Qt::Vertical, this );
   m_ScrollArea->setHorizontalScrollBar( m_ScrollH );
   m_ScrollArea->setVerticalScrollBar( m_ScrollV );

   m_ColorBar = new ColorBar( this );
   QSplitter* m_SplitterV = new QSplitter( this ); // divides right content widget into canvas and colorbar
   m_SplitterV->setOrientation( Qt::Vertical );
   m_SplitterV->addWidget( m_ScrollArea );
   m_SplitterV->addWidget( m_ColorBar );
   m_SplitterV->setHandleWidth( 20 );
   m_SplitterV->setStretchFactor( 0, 1 );
   m_SplitterV->setStretchFactor( 1, 0 );
   m_SplitterV->setCollapsible( 0, false );
   m_SplitterV->setCollapsible( 1, true );
   // m_SplitterV->setSizes( QList< int >{ 200, -1 } );
   qDebug() << "orientation-v:" << m_SplitterV->orientation();
   // Create left menu widget (carrying many sub-widgets like zoomview, preview, paintmodectl, etc... )
   m_Thumbnail = new Thumbnail( this );
   m_ZoomCheck = new QCheckBox( "Enable ZoomView", this );
   m_ZoomView = new ZoomView( this );
   m_ModeControl = new ModeControl( this );
   m_ModeControl->setContentsMargins( 0,0,0,0 );
   m_ModeControl->setMinimumWidth( 100 );
   QVBoxLayout* leftLayout = new QVBoxLayout( this );
   leftLayout->addWidget( m_Thumbnail );
   leftLayout->addWidget( m_ZoomCheck );
   leftLayout->addWidget( m_ZoomView );
   leftLayout->addWidget( m_ModeControl, 1 );


   QWidget* m_LeftWidget = new QWidget( this );
   m_LeftWidget->setLayout( leftLayout );
   QSplitter* m_SplitterH = new QSplitter( this ); // divides body widget into left menu and right content.
   m_SplitterH->addWidget( m_LeftWidget );
   m_SplitterH->addWidget( m_SplitterV );
   m_SplitterH->addWidget( m_History );
   m_SplitterH->setCollapsible( 0, true );
   m_SplitterH->setCollapsible( 1, false );
   m_SplitterH->setCollapsible( 2, true );
   m_SplitterH->setHandleWidth( 20 );
   m_SplitterH->setStretchFactor( 0, 0 );
   m_SplitterH->setStretchFactor( 1, 1 );
   m_SplitterH->setStretchFactor( 2, 0 );

   // m_SplitterH->setSizes( QList< int >{ 100, 300 } );
   qDebug() << "orientation-h:" << m_SplitterH->orientation();
   setCentralWidget( m_SplitterH );

   connect( m_ZoomBar, &ZoomBar::zoomChanged, m_Canvas, &Canvas::setZoom );
   connect( m_ZoomCheck, &QCheckBox::toggled, m_ZoomView, &ZoomView::setEnabled );
   // Connect from any to canvas widget
   connect( m_ScrollH, &QScrollBar::valueChanged, this, &MainWindow::on_scroll_h ); // should be canvas
   connect( m_ScrollV, &QScrollBar::valueChanged, this, &MainWindow::on_scroll_v );
   connect( this, &MainWindow::moveCursorLeft, m_Canvas, &Canvas::on_move_cursor_left );
   connect( m_ZoomCheck, &QCheckBox::toggled, m_Canvas, &Canvas::on_zoom_view_enabled );
   connect( m_ModeControl, &ModeControl::paintModeChanged, m_Canvas, &Canvas::on_paintModeChanged );
   connect( m_ColorBar, &ColorBar::fillColorChanged, m_Canvas, &Canvas::on_fillColorChanged );
   connect( m_ColorBar, &ColorBar::lineColorChanged, m_Canvas, &Canvas::on_lineColorChanged );
   connect( m_ColorBar, &ColorBar::lineWidthChanged, m_Canvas, &Canvas::on_lineWidthChanged );
   // Connect from canvas widget to others
   connect( m_Canvas, &Canvas::cursorPosChanged, m_Thumbnail, &Thumbnail::onCursorPosChanged );
   connect( m_Canvas, &Canvas::cursorPosChanged, m_ZoomView, &ZoomView::onCursor );
   connect( m_Canvas, &Canvas::zoomChanged, m_ZoomView, &ZoomView::onZoom );
   // connect( m_Canvas, &Canvas::signalMouseMoved, m_ZoomView, &ZoomView::setMousePos );

   m_ZoomView->setImage( &m_Canvas->getImage() );
   m_Thumbnail->setImage( &m_Canvas->getImage() );
   m_Canvas->setFocus();
   m_FontWidget = new FontWidget( this );
   m_ZoomCheck->setChecked( true );
}

MainWindow::~MainWindow()
{
}

//=================================
// Menu events
//=================================

void
MainWindow::on_menu_file_exit()
{
   bool ok = false;
   while ( !ok )
   {
      QMessageBox box;
      //box.setText( "Möchten Sie speichern bevor Sie beenden?" );
      box.setText("The document has been modified.");
      box.setInformativeText("Do you want to save your changes?");
      box.setStandardButtons(QMessageBox::Save | QMessageBox::Discard | QMessageBox::Cancel );
      box.setDefaultButton( QMessageBox::Save );
      int retVal = box.exec();

      switch ( retVal )
      {
      case QMessageBox::Save:
         {
            QFileDialog dlg( this, tr( "Save image file ..." ), QDir::homePath() );
            dlg.setAcceptMode( QFileDialog::AcceptOpen );
            dlg.setFileMode( QFileDialog::AnyFile );
            if ( dlg.exec() == QDialog::Accepted )
            {
               QString uri = dlg.selectedFiles().first();
               qDebug() << __func__ << " :: Ok save now uri" << uri;
               // save_imagefile( uri );
               ok = true;
               close();
            }
            // If no image was saved the loop begins again
         }
         break;

      case QMessageBox::Discard:
         // Don't Save was clicked
         ok = true;
         // terminate app
         close();
         break;
      case QMessageBox::Cancel:
         // Cancel was clicked
         ok = true;
         // Return to app
         break;
      default:
         // should never be reached
         ok = true;
         break;
      }
   }
}

void
MainWindow::on_menu_file_new()
{
   qDebug() << __func__;
   newCanvasImage();
}

void
MainWindow::on_menu_file_load()
{
   qDebug() << __func__;
   QFileDialog dlg( this, tr( "Load image file ..." ), QDir::homePath() );
   dlg.setAcceptMode( QFileDialog::AcceptOpen );
   dlg.setFileMode( QFileDialog::AnyFile );
   //dlg.selectMimeTypeFilter( "image/png" );
   //dlg.setDefaultSuffix( "png" );
   if ( dlg.exec() != QDialog::Accepted )
   {
      qDebug() << __func__ << " :: User abort";
      return;
   }

   QString uri = dlg.selectedFiles().first();
   loadCanvasImage( uri );
}

void
MainWindow::on_menu_file_save()
{
   qDebug() << __func__;
   QFileDialog dlg( this, tr( "Save image file ..." ), QDir::homePath() );
   dlg.setAcceptMode( QFileDialog::AcceptSave );
   dlg.setFileMode( QFileDialog::AnyFile );
   //dlg.selectMimeTypeFilter( "image/png" );
   //dlg.setDefaultSuffix( "png" );
   if ( dlg.exec() != QDialog::Accepted )
   {
      qDebug() << __func__ << " :: User abort";
      return;
   }

   QString uri = dlg.selectedFiles().first();
   saveCanvasImage( uri );
}

void
MainWindow::on_menu_file_saveAs()
{
   qDebug() << __func__;
   QFileDialog dlg( this, tr( "Save image file ..." ), QDir::homePath() );
   dlg.setAcceptMode( QFileDialog::AcceptSave );
   dlg.setFileMode( QFileDialog::AnyFile );
   //dlg.selectMimeTypeFilter( "image/png" );
   //dlg.setDefaultSuffix( "png" );
   if ( dlg.exec() != QDialog::Accepted )
   {
      qDebug() << __func__ << " :: User abort";
      return;
   }

   QString uri = dlg.selectedFiles().first();
   saveCanvasImage( uri );
}

//=================================
// Canvas manip stuff
//=================================

void
MainWindow::setCanvasImage( QImage img, QString uri )
{
   if ( img.isNull() )
   {
      qDebug() << __func__ << " :: Cant set empty image";
   }
   else
   {
      m_Canvas->setImage( img, uri );
      m_ZoomView->setImage( &m_Canvas->getImage() );
      m_Thumbnail->setImage( &m_Canvas->getImage() );
      qDebug() << __func__ << " :: Set image(" << img.width() << "," << img.height() << ")";
      setWindowTitle( getImageURI() );
   }
}

void
MainWindow::newCanvasImage()
{
   QString uri = "Untitled1.png";
   QImage img( 320,240, QImage::Format_ARGB32 );
   img.fill( QColor( 255,255,255,255 ) );
   qDebug() << __func__ << " :: New image uri(" << uri << ")";
   setCanvasImage( img, uri );
}

void
MainWindow::loadCanvasImage( QString uri )
{
   QImage img;
   if ( img.load( uri ) )
   {
      setCanvasImage( img, uri );
      qDebug() << __func__ << " :: Loaded image uri(" << uri << ")";
   }
   else
   {
      qDebug() << __func__ << " :: Cant load image uri(" << uri << ")";
   }
}

void
MainWindow::saveCanvasImage( QString uri )
{
   // m_Canvas->setImageUri( );
   QImage const & img = m_Canvas->getImage();
   if ( img.save( uri ) )
   {
      qDebug() << __func__ << " :: Saved image uri(" << uri << ")";
   }
   else
   {
      qDebug() << __func__ << " :: Cant save image uri(" << uri << ")";
   }
}

/////////////////////////////
/// --- Button events --- ///
/////////////////////////////

void
MainWindow::on_show_fontwidget( bool checked )
{
   if ( m_FontWidget )
   {
      m_FontWidget->show();
      m_FontWidget->raise();
      m_FontWidget->exec();
      m_FontWidget->hide();
   }
}

/////////////////////////////
/// --- Button events --- ///
/////////////////////////////

void
MainWindow::on_show_about()
{
   QMessageBox msgBox;
   msgBox.setWindowTitle("About");
   msgBox.setText( "Paint 2D Application" );
   msgBox.exec();
}

void
MainWindow::on_scroll_h( int value )
{
   qDebug() << "Paint::onScrollBarH(" << value << ")";
}

void
MainWindow::on_scroll_v( int value )
{
   qDebug() << "Paint::onScrollBarV(" << value << ")";
}

/////////////////////////////
/// --- Button events --- ///
/////////////////////////////

void
MainWindow::keyPressEvent( QKeyEvent* event )
{


}


#if 0
void
on_btnScreenshot_clicked()
{
   if ( !m_View ) return;

   QScreen * screen = QGuiApplication::primaryScreen();
   if ( !screen ) return;

   auto shot = screen->grabWindow( winId() );

   QString     path = QDir::homePath() + "/";
   QFileDialog saveFileDialog( this, tr( "Save screenshot as ..." ), path );
   saveFileDialog.setAcceptMode( QFileDialog::AcceptSave );
   saveFileDialog.setFileMode( QFileDialog::AnyFile );
   saveFileDialog.selectMimeTypeFilter( "image/png" );
   saveFileDialog.setDefaultSuffix( "png" );

   if ( saveFileDialog.exec() != QDialog::Accepted ) return;

   QString name = saveFileDialog.selectedFiles().first();

   if ( !shot.save( name ) ) QMessageBox::warning( this, tr( "Save Error" ), tr( "The screenshot could not be saved!" ) );
}

void
MainWindow::on_frameTimerTick()
{
   if ( m_Closing ) return;

   using tsd::common::system::HighResolutionTimer;
   static uint64_t const freq               = HighResolutionTimer::getFrequency() / 1000;
   static uint64_t       lastStartTimeFrame = HighResolutionTimer::getTicks();
   uint64_t const        startTime          = HighResolutionTimer::getTicks();

   // calculate elapsed time of last frame
   uint64_t const elapsedTime = ( startTime - lastStartTimeFrame ) / freq;
   lastStartTimeFrame         = startTime;

   // calculate the amount of time needed to process this cycle
   int duration = static_cast< int >( ( HighResolutionTimer::getTicks() - lastStartTimeFrame ) / freq );

   // log the status of mapdisplay every 15 seconds
   static uint64_t lastLogTime = startTime;
   if ( ( startTime - lastLogTime ) / freq > 15000 )
   {
      logMapdisplayStatus();
      lastLogTime = startTime;
   }

   int wait = std::max( 1, 16 - duration );
   m_FrameTimer.singleShot( wait, this, SLOT( on_frameTimerTick() ) );
}
void
MainWindow::on_btnCreateView_clicked()
{

}

void
MainWindow::keyPressEvent( QKeyEvent * ke )
{
   if ( Qt::Key_Escape == ke->key() )
   {
      this->close();
   }
}

void
MainWindow::closeEvent( QCloseEvent * )
{
   m_Closing = true;

   // save window geometry
   QSettings settings( "tsd.nav.mapgyver", "mapgyver" );
   settings.setValue( "geometry", saveGeometry() );

   // at first close all child windows ...
   for ( auto ovw : m_ObserverViewWindows )
      ovw->close();

   for ( auto mvw : *m_MapViewWindows )
      mvw->close();

   // ... and then the main window
   this->close();
}

void
MainWindow::on_tbSelectTrafficRecord_clicked()
{
   auto dir = ui->leTrafficRecord->text();
   if(dir.size() == 0 || !QDir( dir ).exists() )
   {
      dir = QDir::homePath();
   }
   QFileDialog dialog( this );
   dialog.setFileMode( QFileDialog::Directory );
   dir = dialog.getExistingDirectory( this, "Select Traffic directory", dir );
   if( dir.size() != 0 )
   {
      ui->leTrafficRecord->setText( dir );
   }
}

#endif
