#ifndef PAINT_STATUSBAR_HPP
#define PAINT_STATUSBAR_HPP

#include "CompileConfig.hpp"
#include <QStatusBar>
#include <QLabel>

class StatusBar : public QStatusBar
{
   Q_OBJECT
public:
   StatusBar( QWidget * parent = nullptr );
   ~StatusBar() override;
   QLabel* m_ImageInfo;
   QLabel* m_CanvasInfo;
   QLabel* m_MouseInfo;
   QLabel* m_DrawModeInfo;
};

#endif
