#include "ZoomBar.hpp"

namespace {
   QToolButton*
   createToolButton( QString const & buttonText, QWidget* parent )
   {
      QToolButton* b = nullptr;
      b = new QToolButton( parent );
      b->setMinimumSize( 32, 32 );
      b->setText( buttonText );
      b->setFont( QFont( "fontawesome", 16 ) );
      return b;
   }
}

ZoomBar::ZoomBar( QWidget * parent )
   : QToolBar( "Paint Tools in a bar", parent )
{
   auto fa_icon_zoom_in = QChar( 0xF00E );
   auto fa_icon_zoom_out = QChar( 0xF010 );
   m_ZoomOut = createToolButton( fa_icon_zoom_out, parent );
   m_ZoomIn = createToolButton( fa_icon_zoom_in, parent );
   m_ZoomCombo = new QComboBox( parent );
   m_ZoomCombo->addItem( "10%",  QVariant( 0.1f ) );
   m_ZoomCombo->addItem( "12,5%",QVariant( 0.125f ) );
   m_ZoomCombo->addItem( "25%",  QVariant( 0.25f ) );
   m_ZoomCombo->addItem( "50%",  QVariant( 0.5f ) );
   m_ZoomCombo->addItem( "75%",  QVariant( 0.75f ) );
   m_ZoomCombo->addItem( "100%", QVariant( 1.0f ) );
   m_ZoomCombo->addItem( "150%", QVariant( 1.5f ) );
   m_ZoomCombo->addItem( "2x", QVariant( 2.0f ) );
   m_ZoomCombo->addItem( "3x", QVariant( 3.0f ) );
   m_ZoomCombo->addItem( "4x", QVariant( 4.0f ) );
   m_ZoomCombo->addItem( "5x", QVariant( 5.0f ) );
   m_ZoomCombo->addItem( "6x", QVariant( 6.0f ) );
   m_ZoomCombo->addItem( "8x", QVariant( 8.0f ) );
   m_ZoomCombo->addItem( "10x", QVariant( 10.0f ) );
   m_ZoomCombo->addItem( "12x", QVariant( 12.0f ) );
   m_ZoomCombo->addItem( "16x", QVariant( 16.0f ) );

   int found = -1;
   for ( int i = 0; i < m_ZoomCombo->count(); ++i )
   {
      if ( m_ZoomCombo->itemData( i ).toFloat() == 1.0f )
      {
         found = i;
         break;
      }
   }

   if ( found > -1 )
   {
      m_ZoomCombo->setCurrentIndex( found );
   }

   addWidget( m_ZoomOut );
   addWidget( m_ZoomCombo );
   addWidget( m_ZoomIn );

   connect( m_ZoomOut,   &QToolButton::clicked, this, &ZoomBar::onButton_zoomOut );
   connect( m_ZoomIn,    &QToolButton::clicked, this, &ZoomBar::onButton_zoomIn  );
   connect( m_ZoomCombo, SIGNAL( currentIndexChanged( int ) ), this, SLOT( onComboZoom( int ) ) );
}

ZoomBar::~ZoomBar()
{}

void
ZoomBar::onComboZoom( int )
{
   float scale = m_ZoomCombo->currentData().toFloat();
   qDebug() << __FUNCTION__ << "(" << m_ZoomCombo->currentIndex() << ") = " << scale << "%";
   emit zoomChanged( int( scale * 100.0f ) );
}
void
ZoomBar::onButton_zoomOut( bool ckecked )
{
   int index = m_ZoomCombo->currentIndex();
   index--;
   if ( index < 0 ) index = 0;
   m_ZoomCombo->setCurrentIndex( index );
}
void
ZoomBar::onButton_zoomIn( bool ckecked )
{
   int index = m_ZoomCombo->currentIndex();
   index++;
   if ( index >= m_ZoomCombo->count() ) index = m_ZoomCombo->count() - 1;
   m_ZoomCombo->setCurrentIndex( index );
}
