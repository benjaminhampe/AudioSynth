#include "ColorButton.hpp"
#include <QImage>
#include <QColorDialog>

ColorButton::ColorButton( QString name, uint32_t colorRGBA, QWidget * parent )
   : QPushButton( "", parent )
   , m_Color( 0,0,0,0 )
   , m_Index( 0 )
{
   setColorRGBA( colorRGBA );
}

ColorButton::~ColorButton()
{

}


void
ColorButton::updateButtonImage()
{
   QImage img( 16, 16, QImage::Format_ARGB32 );
   if ( m_Color.alpha() < 255 )
   {
      img.fill( Qt::white );
      int dx = 8;
      int dy = 8;
      QColor evenLineColor = QColor( 150,150,150,255 );
      QColor evenFillColor = QColor( 150,150,150,255 );
      QColor oddLineColor = QColor( 100,100,100,255 );
      QColor oddFillColor = QColor( 100,100,100,255 );
      // drawCheckered( img, 0, 0, img.width() - 1, img.height() - 1, dx, dy );
      drawRect( img, 0, 0, 8, 8, evenFillColor, evenLineColor );
      drawRect( img, 8, 0, 8, 8, oddFillColor, oddLineColor );
      drawRect( img, 0, 8, 8, 8, oddFillColor, oddLineColor );
      drawRect( img, 8, 8, 8, 8, evenFillColor, evenLineColor );

      for ( int j = 0; j < img.height(); ++j )
      {
         for ( int i = 0; i < img.width(); ++i )
         {
            setPixel( img, i, j, m_Color, true );
         }
      }
   }
   else
   {
      img.fill( m_Color ); // Fill solid, no transparency with check pattern necessary.
   }

//   if ( m_IsSelected )
//   {
//      QColor borderColor = Qt::black;
//      if ( averageRGB( m_Color ) < int( 127 ) )
//      {
//         borderColor = Qt::white;
//      }

//      drawLineRect( img, 0, 0, img.width(), img.height(), borderColor, 2, false );
//   }

   QPixmap pix = QPixmap::fromImage( img );
   setIcon( QIcon( pix ) );
   update();
}

void
ColorButton::emit_fgcolor()
{
   emit fgcolorChanged( m_Color );
   qDebug() << __FUNCTION__ << "(" << m_Color.red() << "," << m_Color.green() << "," << m_Color.blue() << "," << m_Color.alpha() << ")";
}
void
ColorButton::emit_bgcolor()
{
   emit bgcolorChanged( m_Color );
   qDebug() << __FUNCTION__ << "(" << m_Color.red() << "," << m_Color.green() << "," << m_Color.blue() << "," << m_Color.alpha() << ")";
}

void
ColorButton::setColorRGBA( uint32_t colorRGBA )
{
   QColor color( colorRGBA & 0xFF,
              ( colorRGBA >> 8 ) & 0xFF,
              ( colorRGBA >> 16 ) & 0xFF,
              ( colorRGBA >> 24 ) & 0xFF );
   setColor( color );
}

void
ColorButton::setColor( QColor color )
{
   if ( m_Color == color ) return;
   m_Color = color;
   updateButtonImage();
   std::stringstream s;
   s << "rgba(" << m_Color.red() << "," << m_Color.green() << "," << m_Color.blue() << "," << m_Color.alpha() << ")";
   s << std::hex
     << "\n#" << uint8_t( m_Color.red() )
              << uint8_t( m_Color.green() )
              << uint8_t( m_Color.blue() )
              << uint8_t( m_Color.alpha() );
   setToolTip( QString::fromStdString( s.str() ) );
}

void
ColorButton::mousePressEvent( QMouseEvent * me )
{
   if ( me->buttons() & Qt::LeftButton )
   {
      emit_fgcolor();
   }
   else if ( me->buttons() & Qt::RightButton )
   {
      emit_bgcolor();
   }
   QPushButton::mousePressEvent( me );
}

void
ColorButton::mouseReleaseEvent( QMouseEvent * me )
{
   QPushButton::mouseReleaseEvent( me );
}

void
ColorButton::mouseDoubleClickEvent( QMouseEvent * me )
{
   if ( me->buttons() & Qt::LeftButton )
   {
      QColorDialog dlg( m_Color, this );
      dlg.exec();
      setColor( dlg.currentColor() );
      emit_fgcolor();
   }
   else if ( me->buttons() & Qt::RightButton )
   {
      QColorDialog dlg( m_Color, this );
      dlg.exec();
      setColor( dlg.currentColor() );
      emit_bgcolor();
   }
}
