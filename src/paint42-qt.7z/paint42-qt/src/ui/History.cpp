#include "History.hpp"

History::History( QWidget * parent )
   : QWidget( parent )
{
   setContentsMargins( 0,0,0,0 );

   // char const * svg_example = R"(<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-airplay"><path d="M5 17H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2v10a2 2 0 0 1-2 2h-1"></path><polygon points="12 15 17 21 7 21 12 15"></polygon></svg>)";
   // char const * svg_begin = R"(<svg xmlns="http://www.w3.org/2000/svg" )";
   // char const * svg_end = "</svg>";

   m_Text = new QTextEdit( this );
   m_Text->append( "<svg width height viewBox fill:none class>\n" );
   m_Text->append( "<svg stroke stroke-width stroke-linecap stroke-linejoin>\n" );
   QVBoxLayout* v = new QVBoxLayout( this );
   v->addWidget( m_Text, 1 );
   setLayout( v );

   // connect( m_FgColor, &ColorButton::pressed, this, &History::onSetForeground );
   // connect( m_BgColor, &ColorButton::pressed, this, &History::onSetBackground );
}

History::~History()
{

}

void History::begin()
{

}

void History::end()
{

}

void History::cutImage( int x1, int y1, int x2, int y2 )
{

}

void History::pasteImage( QImage img, int x, int y )
{

}

void History::setLineColor( QColor const & color )
{
   std::stringstream s;
   s << "stroke-color:rgba(" << color << ");";
   m_Text->append( QString::fromStdString( s.str() ) );
}

void History::setLineWidth( float lineWidth )
{
   std::stringstream s;
   s << "stroke-width:" << lineWidth << ";";
   m_Text->append( QString::fromStdString( s.str() ) );
}

void History::setFillColor( QColor const & color )
{
   std::stringstream s;
   s << "fill-color:rgba(" << color << ");";
   m_Text->append( QString::fromStdString( s.str() ) );
}

void History::drawPoint( int x, int y )
{
}

void History::drawLine( int x1, int y1, int x2, int y2 )
{
   std::stringstream s;
   std::string const a = "=\"";
   std::string const b = "\" ";
   s << "<line "
           << "x1" << a << x1 << b
           << "y1" << a << y1 << b
           << "x2" << a << x2 << b
           << "y2" << a << y2 << b << "></line>";
   m_Text->append( QString::fromStdString( s.str() ) );
}

void History::drawLineStrip( std::vector< Point2di > const & points )
{
   // <polyline points="12 6 12 12 16 14"></polyline>
   std::stringstream s;
   std::string const a = "=\"";
   std::string const b = "\" ";
   s << "<polyline points" << a;
   for ( size_t i = 0; i < points.size(); ++i )
   {
      if ( i > 0 ) s << " ";
      s << points[ i ].x << " " << points[ i ].x;
   }
   s << b << "></polyline>";
   m_Text->append( QString::fromStdString( s.str() ) );
}


void History::drawRect( int x1, int y1, int x2, int y2 )
{
   std::stringstream s;
   std::string const a = "=\"";
   std::string const b = "\" ";
   s << "<rect "
           << "x1" << a << x1 << b
           << "y1" << a << y1 << b
           << "x2" << a << x2 << b
           << "y2" << a << y2 << b << "></rect>";
   m_Text->append( QString::fromStdString( s.str() ) );
}

void History::drawCircle( int cx, int cy, int radius )
{

}

void History::drawEllipse( int cx, int cy, int a, int b )
{
   std::stringstream s;
   std::string const SVG1 = "=\"";
   std::string const SVG2 = "\" ";
   std::string const SVG3 = "\"";
   if ( a == b )
   {
      s << "<circle "
        << "cx" << SVG1 << cx << SVG2
        << "cy" << SVG1 << cy << SVG2
        << "r" << SVG1 << a << SVG3 << "></circle>";
   }
   else
   {
      s << "<ellipse "
        << "cx" << SVG1 << cx << SVG2
        << "cy" << SVG1 << cy << SVG2
        << "a" << SVG1 << a << SVG2
        << "b" << SVG1 << b << SVG3 << "></ellipse>";
   }
   m_Text->append( QString::fromStdString( s.str() ) );
}

void History::drawPath( SvgPath svgPath )
{
   // <path d="M16 16s-1.5-2-4-2-4 2-4 2"></path>

}


void History::drawText( QString txt, int x, int y, TextAlignment::EAlignment align )
{

}

