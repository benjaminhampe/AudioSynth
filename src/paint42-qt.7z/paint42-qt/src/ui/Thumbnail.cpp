#include "Thumbnail.hpp"
#include "MainWindow.hpp"

Thumbnail::Thumbnail( QWidget * parent )
   : QWidget( parent )
   , m_Display( nullptr )
   , m_RefreshDisplay( true )
   , m_CursorX( 0 )
   , m_CursorY( 0 )
   , m_ZoomRectX( -1.0f )
   , m_ZoomRectY( -1.0f )
   , m_ZoomRectW( -1.0f )
   , m_ZoomRectH( -1.0f )
{
   setContentsMargins( 0,0,0,0 );
   setMinimumSize( 32, 32 );
   //setSizePolicy( QSizePolicy::Expanding, QSizePolicy::Expanding );
   setFocusPolicy( Qt::StrongFocus );
   m_MainWindow = dynamic_cast< MainWindow* >( parent );
}

Thumbnail::~Thumbnail()
{

}

void
Thumbnail::setImage( QImage const * img )
{
   if ( img == m_Image )
   {
      return; // nothing todo
   }

   m_Image = img;
   m_RefreshDisplay = true;
   updateDisplayImage();
   update();
}

QImage const *
Thumbnail::getImage() const
{
   return m_Image;
}

void
Thumbnail::onCursorPosChanged( int x, int y )
{
   m_CursorX = x;
   m_CursorY = y;
   update();
}

void
Thumbnail::paintEvent( QPaintEvent* event )
{
   updateDisplayImage();

   QPainter dc;
   if ( dc.begin( this ) )
   {
      dc.setBrush( Qt::NoBrush );

      // draw image thumbnail
      int x = ( width() - m_Display.width() ) / 2;
      int y = ( height() - m_Display.height() ) / 2;
      dc.drawImage( QPoint(x, y), m_Display );

      if ( m_Image && m_Image->width() > 0 && m_Image->height() > 0 )
      {
         float m_MouseXf = float( m_CursorX ) / float( m_Image->width() );
         float m_MouseYf = float( m_CursorY ) / float( m_Image->height() );

         // draw horizontal line mouse pos
         int y1 = int( float( y ) + m_MouseYf * float( m_Display.height() ) );
         dc.setPen( QPen( QColor(255,255,255,255) ) );
         dc.drawLine( x, y1, x + m_Display.width() - 1, y1 );

         // draw vertical line mouse pos
         int x1 = int( float( x ) + m_MouseXf * float( m_Display.width() ) );
         dc.setPen( QPen( QColor(255,255,200,255) ) );
         dc.drawLine( x1, y, x1, y + m_Display.height() - 1 );
      }

/*
      // draw zoom rect
      if ( m_ZoomRectW > 0.0f && m_ZoomRectH > 0.0f )
      {
         int zx = int( float( x ) + m_ZoomRectX * float( m_Display.width() ) );
         int zy = int( float( y ) + m_ZoomRectY * float( m_Display.height() ) );
         int zw = int( m_ZoomRectW * float( m_Display.width() ) );
         int zh = int( m_ZoomRectH * float( m_Display.height() ) );
         dc.setPen( QPen( QColor(255,100,50,255) ) );
         dc.drawRect( zx, zy, zw, zh );
      }
*/
      // draw text
      std::stringstream s;
      s << "preview(" << m_Display.width() << "," << m_Display.height() << ")";
      QString t = QString::fromStdString( s.str() );
      QSize ts = dc.fontMetrics().size( 0, t );
      dc.drawText( (width() - ts.width())/2, ts.height() + 2, t );

      if ( m_Image )
      {
         std::stringstream s;
         s << "image(" << m_Image->width() << "," << m_Image->height() << ")";
         QString t = QString::fromStdString( s.str() );
         QSize ts = dc.fontMetrics().size( 0, t );
         dc.drawText( (width() - ts.width())/2, 2 * (ts.height() + 2), t );

// Draw image aspect ratio
         {
         std::stringstream s;
         float aspect = float( m_Image->width() ) / float( m_Image->height() );
         s << "aspect-ratio(" << aspect << ")";
         QString t = QString::fromStdString( s.str() );
         QSize ts = dc.fontMetrics().size( 0, t );
         dc.drawText( (width() - ts.width())/2, height() - 8, t );
         }

      }
      dc.end();
   }
}

void
Thumbnail::resizeEvent( QResizeEvent* event )
{
   m_RefreshDisplay = true;

   int w = event->size().width();
   int h = event->size().height();

   std::stringstream s;
   s << "ResizeEvent( w:" << w << ", h:" << h << " )";
   getMainWindow()->getStatusBar()->m_ImageInfo->setText( QString::fromStdString( s.str() ) );
}

void
Thumbnail::updateDisplayImage()
{
   if ( !m_RefreshDisplay )
   {
      return;
   }

   if ( width() < 1 || height() < 1 || !m_Image || m_Image->isNull() || m_Image->width() < 1 || m_Image->height() < 1 )
   {
      setMinimumHeight( -1 );
      return;
   }

   if ( m_Image->width() >= m_Image->height() )
   {
      int w = width();
      int h = int( float( w ) * float( m_Image->height() ) / float( m_Image->width() ) );
      m_Display = m_Image->scaledToWidth( width(), Qt::SmoothTransformation );
      qDebug() << "Scale image to width(" << w << "," << h << ") -> result(" << m_Display.width() << "," << m_Display.height() << ")";
   }
   else
   {
      int h = height();
      int w = int( float( h ) * float( m_Image->width() ) / float( m_Image->height() ) );
      m_Display = m_Image->scaledToHeight( height(), Qt::SmoothTransformation );
      qDebug() << "Scale image to height(" << w << "," << h << ") -> result(" << m_Display.width() << "," << m_Display.height() << ")";
   }

   setMinimumHeight( m_Display.height() );
   m_RefreshDisplay = false;
}

/*
void
Thumbnail::onScreenshot()
{
   QScreen * screen = QGuiApplication::primaryScreen();
   if ( !screen ) return;
   auto shot = screen->grabWindow( this->winId() );

   QString     path = QDir::homePath() + "/";
   QFileDialog saveFileDialog( this, tr( "Save screenshot as ..." ), path );
   saveFileDialog.setAcceptMode( QFileDialog::AcceptSave );
   saveFileDialog.setFileMode( QFileDialog::AnyFile );
   saveFileDialog.selectMimeTypeFilter( "image/png" );
   saveFileDialog.setDefaultSuffix( "png" );

   if ( saveFileDialog.exec() != QDialog::Accepted ) return;

   QString name = saveFileDialog.selectedFiles().first();

   if ( !shot.save( name ) ) QMessageBox::warning( this, tr( "Save Error" ), tr( "The screenshot could not be saved!" ) );
}
*/

