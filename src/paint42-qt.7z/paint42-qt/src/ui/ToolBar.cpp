#include "ToolBar.hpp"
#include <fontawesome.hpp>

#include <QToolBar>
#include <QToolButton>

namespace {

QToolButton*
createToolButton( QString const & buttonText, QWidget* parent )
{
   QToolButton* b = nullptr;
   b = new QToolButton( parent );
   b->setMinimumSize( 32, 32 );
   b->setText( buttonText );
   b->setFont( QFont( "fontawesome", 16 ) );
   return b;
}

}

ToolBar::ToolBar( QWidget * parent )
   : QToolBar( "Paint Tools in a bar", parent )
   , m_New( nullptr )
   , m_OpenFile( nullptr )
   , m_SaveFile( nullptr )
   , m_Undo( nullptr )
   , m_Redo( nullptr )
{
   m_New = createToolButton( QChar( fa::file ), parent );
   m_OpenFile = createToolButton( QChar( fa::folderopen ), parent );
   m_SaveFile = createToolButton( QChar( fa::save ), parent );
   m_Undo = createToolButton( QChar( fa::arrowleft ), parent );
   m_Redo = createToolButton( QChar( fa::arrowright ), parent );

   //   m_OpenFolder = createToolButton( QChar( fa::folderopen ), parent );
   //   m_SaveFileAs = createToolButton( QChar( fa::save ), parent );
   //   m_Rename = createToolButton( QChar( fa::edit ), parent );
   //   m_Delete = createToolButton( QChar( fa::trash ), parent );

   addWidget( m_New );
   addWidget( m_OpenFile );
   addWidget( m_SaveFile );
   addSeparator();
   addWidget( m_Undo );
   addWidget( m_Redo );

//   addWidget( m_Delete );
//   addWidget( m_Rename );
//   addWidget( m_OpenFolder );
//   addWidget( m_SaveFileAs );

}

ToolBar::~ToolBar()
{

}
