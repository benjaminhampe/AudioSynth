#ifndef PAINT_TOOLBAR_HPP
#define PAINT_TOOLBAR_HPP

#include "CompileConfig.hpp"
#include <QToolBar>
#include <QToolButton>
#include <QComboBox>

class ToolBar : public QToolBar
{
   Q_OBJECT
public:
   ToolBar( QWidget * parent = nullptr );
   ~ToolBar() override;
   QToolButton* m_New;
   QToolButton* m_OpenFile;
   QToolButton* m_SaveFile;
   QToolButton* m_Undo;
   QToolButton* m_Redo;
   //   QToolButton* m_OpenFolder;
   //   QToolButton* m_SaveFileAs;
   //   QToolButton* m_Rename;
   //   QToolButton* m_Delete;
};

#endif
