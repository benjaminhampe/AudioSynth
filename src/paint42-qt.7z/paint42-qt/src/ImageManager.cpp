#include "ImageManager.hpp"

// static
bool
ImageManager::hasSupportedFileExtension( QString const & fileName )
{
   QFileInfo fileInfo( fileName );
   if ( !fileInfo.exists() )
   {
      return false;
   }

   if ( !fileInfo.isFile() )
   {
      return false;
   }

   QString fileExt = fileInfo.suffix().toLower();
   if ( fileExt == "jpg" ) { return true; }
   if ( fileExt == "jpeg" ) { return true; }
   if ( fileExt == "j2k" ) { return true; }
   if ( fileExt == "bmp" ) { return true; }
   if ( fileExt == "png" ) { return true; }
   if ( fileExt == "pcx" ) { return true; }
   if ( fileExt == "tga" ) { return true; }
   if ( fileExt == "tif" ) { return true; }
   if ( fileExt == "tiff" ) { return true; }
   if ( fileExt == "pgm" ) { return true; }
   if ( fileExt == "gif" ) { return true; }
   if ( fileExt == "svg" ) { return true; }
   return false;
}

// static
QStringList
ImageManager::chooseFileNames()
{
   QFileDialog dlg;
   dlg.setFilter( QDir::Files );
   dlg.exec();
   return dlg.selectedFiles();
}

// static
QStringList
ImageManager::chooseDirectory()
{
   QFileDialog dlg;
   dlg.setFilter( QDir::Dirs );
   dlg.exec();
   return dlg.selectedFiles();
}

ImageManager::ImageManager()
   : m_CurrFile( "/" )
   , m_CurrDir( "/" )
{

}

ImageManager::~ImageManager()
{

}

bool
ImageManager::loadImage( QString fileName )
{
   if ( m_CurrFile == fileName )
   {
      return false;
   }

   QFileInfo fileInfo( fileName );
   if ( !fileInfo.exists() && !fileInfo.isFile() )
   {
      qDebug() << "File not found (" << fileName << ")";
      return false;
   }

   QImage img;
   if ( !img.load( fileName ) )
   {
      qDebug() << "Cant load image (" << fileName << ")";
      return false;
   }

   m_CurrImage = img;
   m_CurrFile = fileName;
   qDebug() << "Loaded image file(" << m_CurrFile << "), image( w:" << m_CurrImage.width() << ", h:" << m_CurrImage.height() << ")";

   // emit imageUpdated();
   return true;
}

bool
ImageManager::saveImage()
{
   return false;
}

bool
ImageManager::saveImageAs( QString fileName )
{
   return false;
}


void
ImageManager::setUri( QString uri )
{
   QFileInfo uriInfo( uri );
   if ( !uriInfo.exists() )
   {
      return;
   }

   if ( uriInfo.isFile() )
   {
      m_CurrFile = uri;
      m_CurrDir = uriInfo.path();
      qDebug() << "setFileName(" << m_CurrFile << ") with path(" << m_CurrDir << ")";
   }
   else if ( uriInfo.isDir() )
   {
      m_CurrFile = uri;
      m_CurrDir = uri;
      qDebug() << "setDirectory(" << m_CurrFile << ") with path(" << m_CurrDir << ")";
   }

   QDirIterator dirIter( m_CurrDir );
   size_t fileCount = 0;
   size_t imageCount = 0;

   while ( dirIter.hasNext() )
   {
      dirIter.next();
      QFileInfo fileInfo = dirIter.fileInfo();

      if ( fileInfo.isFile() )
      {
         m_FileNames.push_back( fileInfo.canonicalFilePath() );

         ++fileCount;

         if ( hasSupportedFileExtension( fileInfo.canonicalFilePath() ) )
         {
            ++imageCount;
         }
      }
   }

   m_FileInfos = QDir( m_CurrDir ).entryInfoList();

   qDebug() << "Directory (" << m_CurrDir << ") has (" << fileCount << ") files and (" << imageCount << ") images.";
}

void
ImageManager::setFileName( QString fileName )
{
   setUri( fileName );
}

void
ImageManager::setDirectory( QString dirName )
{
   setUri( dirName );
}

void
ImageManager::prevFile()
{
   bool found = false;
   QString fileName = m_CurrFile;
   for ( size_t i = 0; i < m_FileNames.size(); ++i )
   {
      if ( m_FileNames[ i ] == fileName )
      {
         if ( i > 0 )
         {
            fileName = m_FileNames[ i - 1 ];
            found = true;
            break;
         }
      }
   }

   if ( !found && m_FileNames.size() > 0 )
   {
      fileName = m_FileNames[ 0 ];
   }

   loadImage( fileName );
}

void
ImageManager::nextFile()
{
   bool found = false;
   QString fileName = m_CurrFile;
   for ( size_t i = 0; i < m_FileNames.size(); ++i )
   {
      if ( m_FileNames[ i ] == fileName )
      {
         if ( i < m_FileNames.size() - 1 )
         {
            fileName = m_FileNames[ i + 1 ];
            found = true;
            break;
         }
      }
   }

   if ( !found && m_FileNames.size() > 0 )
   {
      fileName = m_FileNames[ 0 ];
   }

   loadImage( fileName );
}
