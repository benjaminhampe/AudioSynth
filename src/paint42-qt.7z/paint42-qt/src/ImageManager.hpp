#ifndef PAINT_IMAGEMANAGER_HPP
#define PAINT_IMAGEMANAGER_HPP

#include "CompileConfig.hpp"

class ImageManager
{
public:
   ImageManager();
   ~ImageManager();

   //static bool hasFileExtension( QString fileName );
   static bool hasSupportedFileExtension( QString const & fileName );

   static QStringList chooseFileNames();
   static QStringList chooseDirectory();

   QString const & getDir() const { return m_CurrDir; }
   QString const & getFileName() const { return m_CurrFile; }
   QImage const & getImage() const { return m_CurrImage; }
   //QImage & getImage() { return m_CurrImage; }

   void setUri( QString uri );
   void setFileName( QString fileName );
   void setDirectory( QString dirName );

   void nextFile();
   void prevFile();

   bool loadImage( QString fileName );
   bool saveImage();
   bool saveImageAs( QString fileName );
private:
   QString m_CurrFile;
   QString m_CurrDir; // the directory path part of the full m_Current filename

   std::vector< QString > m_FileNames;
   QFileInfoList m_FileInfos;

   QImage m_CurrImage;
};

#endif
