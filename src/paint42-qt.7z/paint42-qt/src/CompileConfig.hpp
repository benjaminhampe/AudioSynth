#ifndef WITHQT_COMPILE_CONFIG_HPP
#define WITHQT_COMPILE_CONFIG_HPP

#include <cstdlib>
#include <ctime>
#include <fstream>
#include <iostream>
#include <sstream>
#include <limits>
#include <memory>
#include <random>

#include <QApplication>
#include <QCommandLineParser>
#include <QString>
#include <QUrl>
#include <QTimer>
#include <QColor>
#include <QDebug>
#include <QDir>
#include <QDirIterator>
#include <QFile>
#include <QFileInfo>
#include <QTextStream>

#include <QDesktopServices>
#include <QSettings>
#include <QScreen>

#include <QMainWindow>
#include <QMessageBox>
#include <QFileDialog>
#include <QFontDialog>
#include <QColorDialog>

#include <QMouseEvent>
#include <QPushButton>
#include <QButtonGroup>
//#include <QStringListModel>

#include <QPaintEvent>
#include <QPainter>

#include <QMenuBar>
#include <QMenu>

#include <QToolBar>
#include <QToolButton>

#include <QHBoxLayout>
#include <QVBoxLayout>
#include <QStatusBar>

#include <QTextEdit>
#include <QLineEdit>

#include <QComboBox>
#include <QPushButton>
#include <QLabel>
#include <QFontDatabase>

#include <QLabel>
#include <QScrollBar>
// #include <QDockWidget>
#include <QSplitter>
#include <QCheckBox>


#include <DarkImage.hpp>

// Qt Wrappers
inline bool
isMouseOver( int mx, int my, QRect const & r )
{
   return dbIsMouseOver( mx, my, r.left(), r.top(), r.right(), r.bottom() );
}

inline float
almostEquals( float a, float b, float eps = 0.00001f )
{
   return ( std::abs( b - a ) < eps );
}


inline QRect
clipTo( QRect r_src, QRect r_clip )
{
   QRect r = r_src;
   if ( r.left() < r_clip.left() ) r.setLeft( r_clip.left() );
   if ( r.top() < r_clip.top() ) r.setTop( r_clip.top() );
   if ( r.right() > r_clip.right() ) r.setRight( r_clip.right() );
   if ( r.bottom() > r_clip.bottom() ) r.setBottom( r_clip.bottom() );
   return r;
}


struct TextAlignment
{
   enum EAlignment
   {
      None = 0,
      Left = 1,
      Center = 2,
      Right = 4,
      Top = 8,
      Middle = 16,
      Bottom = 32,

      TopLeft = Left | Top,
      TopCenter = Center | Top,
      TopRight = Right | Top,
      MiddleLeft = Left | Middle,
      MiddleCenter = Center | Middle,
      MiddleRight = Right | Middle,
      BottomLeft = Left | Bottom,
      BottomCenter = Center | Bottom,
      BottomRight = Right | Bottom,

      LeftTop = Left | Top,
      CenterTop = Center | Top,
      RightTop = Right | Top,
      LeftMiddle = Left | Middle,
      CenterMiddle = Center | Middle,
      RightMiddle = Right | Middle,
      LeftBottom = Left | Bottom,
      CenterBottom = Center | Bottom,
      RightBottom = Right | Bottom,

      Default = TopLeft
   };
};

inline void
drawText( QPainter & dc, std::string const & txt, int x, int y, int align = 0 )
{
   //std::stringstream s; s << m_MouseX << " px";
   //QString t = QString::fromStdString( s.str() );
   //QSize ts = dc.fontMetrics().size( 0, t );
   QString t = QString::fromStdString( txt );
   QSize txt_size = dc.fontMetrics().size( 0, t );

   if ( align & TextAlignment::Left )
   {

   }
   else if ( align & TextAlignment::Center )
   {
      x -= txt_size.width() / 2;
   }
   else if ( align & TextAlignment::Right )
   {
      x -= txt_size.width();
   }

   if ( align & TextAlignment::Top )
   {
      y += 3*txt_size.height()/4;
   }
   else if ( align & TextAlignment::Middle )
   {
      y += txt_size.height() / 2 - 2;
   }
   else if ( align & TextAlignment::Bottom )
   {

   }

   dc.drawText( x, y, t );
}



inline QColor
getPixel( QImage const & img, int x, int y, QColor const & colorKey = QColor( 0,0,0,0 ) )
{
   if ( x < 0 || y < 0 || x >= img.width() || y >= img.height() ) return colorKey;
   return img.pixelColor( x, y );
}

inline void
setPixel( QImage & img, int x, int y, QColor const & color, bool blend = false, QColor const & colorKey = QColor( 0,0,0,0 ) )
{
   if ( x < 0 || y < 0 || x >= img.width() || y >= img.height() ) return;
   if ( !blend )
   {
      img.setPixelColor( x, y, color );
   }
   else
   {
      if ( color.alpha() >= 255 ) return;
      QColor oldColor = getPixel( img, x, y, colorKey );
      auto r1 = float( oldColor.redF() );
      auto g1 = float( oldColor.greenF() );
      auto b1 = float( oldColor.blueF() );
      //auto a1 = float( oldColor.alphaF() );
      auto dr = float( color.redF() ) - r1;
      auto dg = float( color.greenF() ) - g1;
      auto db = float( color.blueF() )- b1;
      //auto da = float( color.alphaF() ) - a1;

      auto a = float( color.alphaF() );
      float r = r1 + dr * a;
      float g = g1 + dg * a;
      float b = b1 + db * a;
      QColor finalColor = QColor::fromRgbF( r, g, b, 1.0 );
      setPixel( img, x, y, finalColor );
   }
}

inline void
drawHLine( QImage & img, int x1, int x2, int y, QColor lineColor, bool blend = false )
{
   if ( img.isNull() || img.width() < 1 || img.height() < 1 ) return;
   if ( x1 > x2 ) std::swap( x1, x2 );
   for ( int x = x1; x <= x2; ++x )
   {
      setPixel( img, x, y, lineColor, blend );
   }
}

inline void
drawVLine( QImage & img, int y1, int y2, int x, QColor lineColor, bool blend = false )
{
   if ( img.isNull() || img.width() < 1 || img.height() < 1 ) return;
   if ( y1 > y2 ) std::swap( y1, y2 );
   for ( int y = y1; y <= y2; ++y )
   {
      setPixel( img, x, y, lineColor, blend );
   }
}

inline void
drawLineRect( QImage & img, int x, int y, int w, int h, QColor lineColor, int lineWidth = 1, bool blend = false )
{
   if ( img.isNull() || img.width() < 1 || img.height() < 1 ) return;
   for ( int i = 0; i < lineWidth; ++i )
   {
      drawHLine( img, x+i, x+w-1-i, y+i, lineColor, blend );
      drawVLine( img, y+i, y+h-1-i, x+i, lineColor, blend );
      drawVLine( img, y+i, y+h-1-i, x+w-1-i, lineColor, blend );
      drawHLine( img, x+i, x+w-1-i, y+h-1-i, lineColor, blend );
   }
}

inline void
drawFillRect( QImage & img, int x, int y, int w, int h, QColor fillColor, bool blend = false )
{
   if ( img.isNull() || img.width() < 1 || img.height() < 1 ) return;
   for ( int j = 0; j < h; ++j )
   {
      for ( int i = 0; i < w; ++i )
      {
         setPixel( img, x + i, y + j, fillColor, blend );
      }
   }
}

inline void
drawRect( QImage & img, int x, int y, int w, int h, QColor fillColor, QColor lineColor, int lineWidth = 1, bool blend = false )
{
   if ( fillColor.alpha() > 0 )
   {
      drawFillRect( img, x, y, w, h, fillColor, blend );
   }
   if ( lineColor.alpha() > 0 )
   {
      drawLineRect( img, x, y, w, h, lineColor, lineWidth, blend );
   }
}

inline QColor
invertedColorRGB( QColor const & color )
{
   return QColor(255 - color.red(), 255-color.green(), 255-color.blue(), 255 );
}

inline int
averageRGB( QColor const & color )
{
   int average = ( color.red() + color.green()*2 + color.blue() ) / 4;
   qDebug() << __FUNCTION__ << "(" << color.red() << "," << color.green() << "," << color.blue() << ") = " << average << ".";
   return average;
}

inline QColor
averageColorRGB( QColor const & color )
{
   int average = averageRGB( color );
   return QColor( average, average, average, 255 );
}

inline void
drawCheckered( QImage & img,
               int x1, int y1, int x2, int y2,
               int dx = 8,
               int dy = 8,
               QColor evenLineColor = QColor( 60,60,60,255 ),
               QColor evenFillColor = QColor( 50,50,50,255 ),
               QColor oddLineColor = QColor( 20,20,20,255 ),
               QColor oddFillColor = QColor( 10,10,10,255 ) )
{
   if ( img.isNull() || img.width() < 1 || img.height() < 1 ) return;
   if ( x1 > x2 ) std::swap( x1, x2 );
   if ( y1 > y2 ) std::swap( y1, y2 );
   int w = x2 - x1;
   int h = y2 - y1;
   int n = w / dx;
   int m = h / dy;
   QColor lineColor;
   QColor fillColor;
   for ( int j = 0; j < m; ++j )
   {
      for ( int i = 0; i < n; ++i )
      {
         int x = dx * i;
         int y = dy * j;
         if ( ( i % 2 == 0 && j % 2 != 0 ) || ( i % 2 != 0 && j % 2 == 0 ) )
         {
             lineColor = evenLineColor;
             fillColor = evenFillColor;
         }
         else
         {
            lineColor = oddLineColor;
            fillColor = oddFillColor;
         }
         drawRect( img, x, y, x + dx - 1, y + dy - 1, lineColor, fillColor );
      }
   }
}

class PaintMode
{
public:
   enum EPaintMode
   {
      None = 0,
      ResizeX,
      ResizeY,
      ResizeXY,
      SelectRect, // takes a rect of pixels
      SelectEllipse, // takes ellipse of pixels
      SelectManual, // maybe from simple to highly complex shapes with layers and command history possible.
      SelectPolygon, // takes polygon made up of border/hull lines of pixels
      Text,
      Rect,
      Ellipse, // = circle
      Point,     // GL_POINT
      Line,      // GL_LINES
      LineStrip,  // GL_LINE_STRIP
      Brush,
      SprayDose,
      FloodFill,
      Arc,
      Polygon,
      Max,
   };

   static std::string
   toString( EPaintMode paintMode )
   {
      switch ( paintMode )
      {
      case None: return "None";
      case ResizeX: return "ResizeX";
      case ResizeY: return "ResizeY";
      case ResizeXY: return "ResizeXY";
      case SelectRect: return "SelectRect";
      case SelectEllipse: return "SelectEllipse";
      case SelectManual: return "SelectManual";
      case SelectPolygon: return "SelectPolygon";
      case Rect: return "Rect";
      case Point: return "Point";
      case Line: return "Line";
      case LineStrip: return "LineStrip";
      case Brush: return "Brush";
      case SprayDose: return "SprayDose";
      case FloodFill: return "FloodFill";
      case Text: return "Text";
      case Ellipse: return "Ellipse";
      case Arc: return "Arc";
      case Polygon: return "Polygon";
      default: return "Unknown ( This is the end ? My friend )";
      }
   }
};



#endif
