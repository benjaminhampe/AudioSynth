#ifndef DE_AUDIO_BUFFERQUEUETEST_HPP
#define DE_AUDIO_BUFFERQUEUETEST_HPP

#include <de/audio/buffer/BufferQueue.hpp>

namespace de {
namespace audio {

struct BufferQueueTest
{
   DE_CREATE_LOGGER("de.audio.BufferQueueTest")

   static void
   test();
};

} // end namespace audio
} // end namespace de

#endif










