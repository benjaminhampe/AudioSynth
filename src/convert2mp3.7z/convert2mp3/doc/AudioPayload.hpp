#ifndef DE_MEDIA_FILE_FFMPEG_HPP
#define DE_MEDIA_FILE_FFMPEG_HPP

#include <vector>
#include <sstream>
#include <functional>

typedef void* PlayHandle;

// Payload is always float 32 bit
// Payload is always interleaved channels
struct AudioPayload
{
   uint64_t frames = 0;
   uint32_t channels = 0;
   uint32_t rate = 0;
   std::vector< float > samples;
}

typedef std::function< void(AudioPayload &&) > ON_AUDIO_PAYLOAD;

PlayHandle dbPlay( std::string uri, ON_AUDIO_PAYLOAD const & eventHandler );

std::string dbPlayGetFileName( PlayHandle );


#endif
