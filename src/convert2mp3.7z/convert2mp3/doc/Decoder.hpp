/*
#ifndef DE_AUDIO_DECODER_HPP
#define DE_AUDIO_DECODER_HPP

#include <de/audio/decoder/DecoderTools.hpp>

namespace de {
namespace audio {
namespace decoder {


// ===========================================================================
struct Decoder
// ===========================================================================
{
   DE_CREATE_LOGGER("de.audio.Decoder")
   DecoderStream m_ds;

   Decoder();
   ~Decoder();

//   uint64_t fillAudioBuffer( audio::Buffer & dst, double pts ) override;
//   bool fillImageBuffer( Image & dst, double pts ) override;

   int32_t readFrame( ON_AUDIO_PAYLOAD const & onGetData );

   std::string getUri() const { return m_Uri; }
   bool is_open() const;
   bool open( std::string uri, bool debug = false );
   void close();

//   int32_t getBestAudioStreamIndex() const { return Utils::findBestAudio( m_avFormatCtx ); }
//   int32_t getBestVideoStreamIndex() const { return Utils::findBestVideo( m_avFormatCtx ); }
   bool isSeekable() const;
   void seek( double pts );
   double tell() const;
//   double getPosition() const;
//   void setPosition( double positionInSeconds );
   //bool hasDuration() const;
//   double getDuration() const;
//   bool getCoverArt( Image & img );
//   void fillCache();

//protected:
//   void fillCacheUnguarded();
};


} // end namespace decoder
} // end namespace audio
} // end namespace de


#endif

*/
