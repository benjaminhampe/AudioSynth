#ifndef DE_MEDIA_FILE_FFMPEG_HPP
#define DE_MEDIA_FILE_FFMPEG_HPP

#include <de/ffmpeg/Utils.hpp>
// #include <de/audio/IBufferFiller.hpp>
// #include <de/audio/BufferQueue.hpp>
// #include <de/ffmpeg/IImageFiller.hpp>
// #include <de/ffmpeg/ImageQueue.hpp>

namespace de {
namespace ffmpeg {


// ============================================================
struct FilePayload
// ============================================================
{
   typedef std::unique_ptr< FilePayload > UniquePtr;
   typedef std::shared_ptr< FilePayload > SharedPtr;
   AVMediaType typ;
   int streamIndex;
   AVRational time_base;
   double benni_pts;
   int64_t pts;
   int64_t dts;
   int64_t duration;
   //std::shared_ptr< de::Image > img;
   //std::shared_ptr< de::audio::Buffer > buf;
   std::unique_ptr< de::Image > img;
   std::unique_ptr< de::audio::Buffer > buf;

   FilePayload()
      : typ(AVMEDIA_TYPE_UNKNOWN), streamIndex(-1), benni_pts(0.0), pts(0), dts(0), duration(0)
   {
      time_base.num = time_base.den = 1;
   }
   bool isAudio() const { return buf != nullptr; }
   bool isVideo() const { return img != nullptr; }
   double getDuration() const { return Utils::toDouble( time_base ) * duration; }
   double getPTS() const { return Utils::toDouble( time_base ) * pts; }

   std::string toString() const
   {
      std::stringstream s;
      if ( isAudio() ) { s << "AUDIO, "; }
      if ( isVideo() ) { s << "VIDEO, "; }
      s << "bts(" << benni_pts << "), ";
      s << "tb(" << Utils::toString( time_base ) << "), ";
      if ( pts == AV_NOPTS_VALUE )
      {
         s << "pts(AV_NOPTS_VALUE), ";
      }
      else
      {
         //auto t = dbStrSeconds( Utils::toDouble( time_base ) * pts );
         s << "pts(" << pts << "), ";
         //<< " = " << t << "), ";
      }
      if ( dts == AV_NOPTS_VALUE )
      {
         s << "dts(AV_NOPTS_VALUE), ";
      }
      else
      {
         //auto t = dbStrSeconds( Utils::toDouble( time_base ) * dts );
         s << "dts(" << dts << "), ";
         //<< " = " << t << "), ";
      }
      if ( duration == AV_NOPTS_VALUE )
      {
         s << "dur(AV_NOPTS_VALUE)";
      }
      else
      {
         //auto t = dbStrSeconds( Utils::toDouble( time_base ) * duration );
         s << "dur(" << duration << ")";
         //<< " = " << t << ")";
      }
      return s.str();
   }
};

// ============================================================
struct FileStream
// ============================================================
{
   FileStream( AVFormatContext* avFormatCtx, int avStreamIndex );
   ~FileStream();
   int32_t getMediaType() const { return m_avCodecParams ? int32_t( m_avCodecParams->codec_type ) : int32_t( AVMEDIA_TYPE_UNKNOWN ); }
   bool isAudio() const { return getMediaType() == AVMEDIA_TYPE_AUDIO; }
   bool isVideo() const { return getMediaType() == AVMEDIA_TYPE_VIDEO; }
   bool isEnabled() const { return m_IsEnabled; }
   void enable() { m_IsEnabled = true; }
   void disable() { m_IsEnabled = false; }
   void toggleEnabled() { m_IsEnabled = !m_IsEnabled; }

   bool isSeekable() const;
   bool seek( double pts );
   double tell() const;

   double getDuration() const { return m_Duration; }
   //double getPosition() const;
   //bool setPosition( double pts );

   std::string getDetailName() const;

   DE_CREATE_LOGGER("de.FileStream")
   AVFormatContext* m_avFormatCtx;
   AVStream* m_avStream;
   AVRational m_avTimeBase;
   int64_t m_avDuration;
   AVCodecParameters* m_avCodecParams;
   AVCodecID m_avCodecId;
   AVCodec* m_avCodec;
   AVCodecContext* m_avCodecCtx;
   SwrContext* m_swResampler;
   SwsContext* m_swScaler;
   bool m_IsEnabled;
   bool m_IsSeekable;
   //bool m_HasDuration;
   int m_avStreamIndex;
   double m_Position;
   double m_Duration;
};


// ===========================================================================
struct File //: public audio::IBufferFiller, public IImageFiller
// ===========================================================================
{
   DE_CREATE_LOGGER("de.ffmpeg.File")
   std::string m_Uri;
   std::vector< FileStream* > m_Streams;
   bool m_IsOpen;
   bool m_IsDebug;
   bool m_IsSeekable;
   double m_Position;
   double m_Duration;

   AVFormatContext* m_avFormatCtx;
   AVPacket* m_avPacket;
   AVFrame* m_avFrame;
//   double m_VideoPTS; // ?
//   double m_AudioPTS; // ?

   audio::ESampleType m_AudioOutputType; // output format of audio decoder

//   double m_AudioFrameRate = 0.0;
//   uint32_t m_AudioQueueThresholdLoadStart;
//   uint32_t m_AudioQueueThresholdLoadStop;
//   audio::BufferQueue m_AudioQueue;
//   ImageQueue m_ImageQueue;
//   Image m_CoverArt;
//   std::thread* m_ThreadPtr;
//   mutable std::mutex m_Mutex;

//   double m_PrecacheDuration; // 300ms

   File();
   ~File();

//   uint64_t fillAudioBuffer( audio::Buffer & dst, double pts ) override;
//   bool fillImageBuffer( Image & dst, double pts ) override;

   typedef std::function< void(std::unique_ptr< FilePayload >&&) > ON_GET_DATA;

   std::string getUri() const { return m_Uri; }
   bool is_open() const;
   bool open( std::string uri, bool debug = false );
   void close();
   int32_t readFrame( ON_GET_DATA const & onGetData );

   int32_t getBestAudioStreamIndex() const { return Utils::findBestAudio( m_avFormatCtx ); }
   int32_t getBestVideoStreamIndex() const { return Utils::findBestVideo( m_avFormatCtx ); }

   bool isStream( int i ) const;
   uint32_t getStreamCount() const;
   FileStream* getStream( int i );
   FileStream const* getStream( int i ) const;

   void enableStream( int i );
   void disableStream( int i );
   void enableStreams();
   void disableStreams();

   bool isSeekable() const;

   void seek( double pts );
   double tell() const;

//   double getPosition() const;
//   void setPosition( double positionInSeconds );

   //bool hasDuration() const;
//   double getDuration() const;

//   bool getCoverArt( Image & img );


//   uint32_t getAudioStreamCount() const;
//   uint32_t getVideoStreamCount() const;
//   FileStream* getVideoStream( int i ) const;
//   FileStream* getAudioStream( int i ) const;

//   int selectedAudioStreamIndex() const { return m_AudioStreamIndex; }
//   int selectedVideoStreamIndex() const { return m_VideoStreamIndex; }

   void setAudioOutFormat( audio::ESampleType sampleType = audio::ST_Unknown );

//   void selectAudioStream( int i )
//   {
//      FileStream* stream = getStream( i );
//      if ( !stream ) { DE_ERROR("No stream i = ",i) return; }
//      if ( !stream->isAudio() ){ DE_ERROR("No audio stream i = ",i) return; }
//      stream->enable();
//      m_AudioStreamIndex = i;
//   }

//   void selectVideoStream( int i )
//   {
//      FileStream* stream = getStream( i );
//      if ( !stream ) { DE_ERROR("No stream i = ",i) return; }
//      if ( !stream->isVideo() ){ DE_ERROR("No video stream i = ",i) return; }
//      stream->enable();
//      m_VideoStreamIndex = i;
//   }

//   void fillCache();

//protected:
//   void fillCacheUnguarded();



};

} // end namespace ffmpeg
} // end namespace de


#endif
