#include "libPA.h"

#ifdef USE_PORTAUDIO

namespace audio {
namespace PA {

SharedLib g_Lib = SharedLib(nullptr);

// ============================================================================
SharedLib getLib()
// ============================================================================
{
    if (!g_Lib)
    {
        g_Lib = SharedLib( new Lib() );
    }

    return g_Lib;
}

// ============================================================================
void CHECK( PaError e, bool bFatal )
// ============================================================================
{
    if (e == paNoError) return;

//    std::stringstream s;
//    s << "audio::Error: " << e << ", " << Pa_GetErrorText(e);

    if (bFatal)
    {
        throw std::runtime_error( Pa_GetErrorText(e) );
    }
//    else
//    {
//        MMError( "%s\n", s.str().c_str() )
//    }
}

// ============================================================================
std::string getDeviceName( PaDeviceIndex index  )
// ============================================================================
{
    const PaDeviceInfo* info = Pa_GetDeviceInfo( index );
    if (info)
    {
        return info->name;
    }
    else
    {
        return "unknown";
    }
}

// ============================================================================
std::string PaHostApiIndex_toString( const PaHostApiIndex index )
// ============================================================================
{
    if (index < 0)
        return "Invalid index";

    const int count = Pa_GetHostApiCount();
    if (index >= count)
        return "Invalid index";

    const PaHostApiInfo* p = Pa_GetHostApiInfo(index);
    if (!p)
        return "Invalid pointer to ApiInfo";

    std::stringstream s;

    s << "Api[" << index << "] " << p->name << '\n'
      << "ApiType = " << p->type << " = " << eDriverType_getName(PaHostApiTypeId_to_eDriverType(p->type)) << '\n'
      << "DeviceCount = " << p->deviceCount << '\n'
      << "Default InputDevice = " << p->defaultInputDevice << '\n'
      << "Default OutputDevice = " << p->defaultOutputDevice << '\n';
    return s.str();
}


// ============================================================================
std::string PaDeviceIndex_toString( const PaDeviceIndex index )
// ============================================================================
{
    if (index < 0)
        return "Invalid index";

    const int count = Pa_GetDeviceCount();
    if (index >= count)
        return "Invalid index";

    const PaDeviceInfo* p = Pa_GetDeviceInfo(index);
    if (!p)
        return "Invalid pointer to DeviceInfo";

    const eDriverType driverType = PaHostApiIndex_to_eDriverType( p->hostApi );

    std::stringstream s;
    s << "Device[" << index << "] " << p->name
      << ", " << eDriverType_getName(driverType)
      << ", I:" << p->maxInputChannels
      << ", O:" << p->maxOutputChannels
      << ", SR = " << p->defaultSampleRate << " Hz"
      << ", lat-In[min:" << 1000.0 * p->defaultLowInputLatency
      << ",max:" << 1000.0* p->defaultHighInputLatency
      << ", lat-Out[min:" << 1000.0* p->defaultLowOutputLatency
      << ",max:" << 1000.0* p->defaultHighOutputLatency;
    return s.str();
}

/// Print all important portaudio settings/infos
// ============================================================================
std::string dump()
// ============================================================================
{
    getLib();

    std::stringstream s;
//    s << "GetVersion() = " << Pa_GetVersion() << '\n'
//    << "GetVersionText() = " << Pa_GetVersionText() << '\n'
//    << "GetApiCount() = " << (int)Pa_GetHostApiCount() << '\n'
//    << "GetDeviceCount() = " << (int)Pa_GetDeviceCount() << '\n'
//    << "GetDefaultHostApi() = " << (int)Pa_GetDefaultHostApi() << '\n'
//    << "GetDefaultOutputDevice() = " << (int)Pa_GetDefaultOutputDevice() << '\n'
//    << "GetDefaultInputDevice() = " << (int)Pa_GetDefaultInputDevice() << "\n\n";

//    for ( PaHostApiIndex i = 0 ; i < Pa_GetHostApiCount(); ++i )
//    {
//        s << PaHostApiIndex_toString( i ) << '\n';
//    }

//    for ( PaDeviceIndex i = 0 ; i < Pa_GetDeviceCount(); ++i )
//    {
//        s << PaDeviceIndex_toString( i ) << '\n';
//    }

    return s.str();
}


/// Print all important portaudio settings/infos
// ============================================================================
std::string getGlobalInfoString()
// ============================================================================
{
    std::stringstream s;
    s << "GetVersion() = " << Pa_GetVersion() << '\n'
    << "GetVersionText() = " << Pa_GetVersionText() << '\n'
    << "GetHostApiCount() = " << (int)Pa_GetHostApiCount() << '\n'
    << "GetDeviceCount() = " << (int)Pa_GetDeviceCount() << '\n'
    << "GetDefaultHostApi() = " << (int)Pa_GetDefaultHostApi() << '\n'
    << "GetDefaultOutputDevice() = " << (int)Pa_GetDefaultOutputDevice() << '\n'
    << "GetDefaultInputDevice() = " << (int)Pa_GetDefaultInputDevice() << '\n';
    return s.str();
}

// ============================================================================
std::string getHostApiInfoString( int api )
// ============================================================================
{
    const int apiCount = Pa_GetHostApiCount();
    if (api<0 || api>=apiCount)
        return "Invalid api index";

    const PaHostApiInfo* p = Pa_GetHostApiInfo(api);
    if (!p)
        return "Cannot get ApiInfo";

    std::stringstream s;
    s << "hostApi["<<api<<"] " << p->name << ", type-id = " << p->type << '\n'
    << "\tDevice-count = " << p->deviceCount << '\n'
    << "\tdefault-in = " << p->defaultInputDevice << '\n'
    << "\tdefault-out = " << p->defaultOutputDevice << '\n';
    return s.str();
}


// ============================================================================
std::string getDeviceInfoString( int api, int index )
// ============================================================================
{
    const int apiCount = Pa_GetHostApiCount();
    if (api<0 || api>=apiCount)
        return "Invalid api index";
    const PaHostApiInfo* apiInfo = Pa_GetHostApiInfo(api);
    if (!apiInfo)
        return "Cannot get ApiInfo";

    const int devCount = apiInfo->deviceCount;
    if ( index < 0 || index >= devCount )
    {
        return "Invalid device-index";
    }

    PaDeviceIndex found = -1;
    int counter = 0;
    for ( PaDeviceIndex i = 0; i < Pa_GetDeviceCount(); ++i )
    {
        const PaDeviceInfo* inf = Pa_GetDeviceInfo(i);
        if (inf && (inf->hostApi == (PaHostApiIndex)api))
        {
            if (index == counter)
            {
                found = i;
                break;
            }
            counter++;
        }
    }

    if (found < 0 )
    {
        return "Cannot find device";
    }

    return getDeviceInfoString( Pa_GetDeviceInfo( found ) );
}

// ============================================================================
std::string getDeviceInfoString( const PaDeviceInfo* p )
// ============================================================================
{
    if (!p)
    {
        return "";
    }

    std::stringstream s;
    s << "device["<< p->hostApi << "][" << getDeviceIndex(p) << "]: "
      << p->name << ", struct-ver" << p->structVersion << '\n'
    << "\tSR = " << p->defaultSampleRate << '\n'
    << "\tInputChannels = " << p->maxInputChannels << '\n'
    << "\tOutputChannels = " << p->maxOutputChannels << '\n'
    << "\tlatency-in-low = " << 1000.0 * p->defaultLowInputLatency << '\n'
    << "\tlatency-in-high = " << 1000.0* p->defaultHighInputLatency << '\n'
    << "\tlatency-out-low = " << 1000.0* p->defaultLowOutputLatency << '\n'
    << "\tlatency-out-high = " << 1000.0* p->defaultHighOutputLatency << '\n';
    return s.str();
}

// ============================================================================
PaDeviceIndex getDeviceIndex( const PaDeviceInfo* p )
// ============================================================================
{
    if (!p)
        return -1;

    for ( int i = 0; i < (int)Pa_GetDeviceCount(); ++i )
    {
        const PaDeviceInfo* p2 = Pa_GetDeviceInfo((PaDeviceIndex)i);
        if (p2 == p)
            return i;
    }

    return -1;
}

// ============================================================================
std::vector<const PaDeviceInfo*> getOutputDevices( PaHostApiIndex index )
// ============================================================================
{
    std::vector<const PaDeviceInfo*> liste;

    if (index < 0)
        index = (int)Pa_GetDefaultHostApi();

    const int apiCount = Pa_GetHostApiCount();
    if (index >= apiCount)
        return liste;

    const int c = (int)Pa_GetDeviceCount();
    for ( int i = 0; i < c; ++i )
    {
        const PaDeviceInfo* dev = Pa_GetDeviceInfo( i );
        if (dev && (dev->hostApi == (PaHostApiIndex)index))
        {
            if (dev->maxOutputChannels > 0)
            {
                liste.push_back(dev);
            }
        }
    }

    return liste;
}


// ============================================================================
std::vector<const PaDeviceInfo*> getInputDevices( PaHostApiIndex index )
// ============================================================================
{
    std::vector<const PaDeviceInfo*> liste;

    if (index < 0)
        index = (int)Pa_GetDefaultHostApi();

    const int apiCount = Pa_GetHostApiCount();
    if (index >= apiCount)
        return liste;

    const int deviceCount = Pa_GetDeviceCount();

    for ( int i = 0; i < deviceCount; ++i )
    {
        const PaDeviceInfo* dev = Pa_GetDeviceInfo( i );
        if (dev && (dev->hostApi == (PaHostApiIndex)index))
        {
            if (dev->maxInputChannels > 0)
            {
                 liste.push_back(dev);
            }
        }
    }

    return liste;
}


// ============================================================================
eDriverType PaHostApiTypeId_to_eDriverType( PaHostApiTypeId typeId )
// ============================================================================
{
    eDriverType res = MM_UNKNOWN;

    switch( typeId )
    {
    case paDirectSound: res = MM_DSOUND; break;
    case paMME:         res = MM_MME; break;
    case paASIO:        res = MM_ASIO; break;
    case paAL:          res = MM_OPEN_AL; break;
    case paWDMKS:       res = MM_WDMKS; break;
    case paWASAPI:      res = MM_WASAPI; break;
//    case paInDevelopment:
//    case paSoundManager:
//    case paCoreAudio:
//    case paOSS:
//    case paALSA:
//    case paBeOS:
//    case paJACK:
//    case paAudioScienceHPI: break;
    default:
        res = MM_UNKNOWN;
        break;
    }

    return res;
}

// ============================================================================
PaHostApiTypeId eDriverType_to_PaHostApiTypeId( eDriverType api )
// ============================================================================
{
    PaHostApiTypeId res = paInDevelopment;

    switch( api )
    {
    case MM_DSOUND: res = paDirectSound; break;
    case MM_MME:    res = paMME; break;
    case MM_ASIO:   res = paASIO; break;
    case MM_OPEN_AL:res = paAL; break;
    case MM_WDMKS:  res = paWDMKS; break;
    case MM_WASAPI: res = paWASAPI; break;
//    case paInDevelopment:
//    case paSoundManager:
//    case paCoreAudio:
//    case paOSS:
//    case paALSA:
//    case paBeOS:
//    case paJACK:
//    case paAudioScienceHPI: break;
    default:
        res = paInDevelopment;
        break;
    }

    return res;
}


// ============================================================================
PaDeviceIndex PaDeviceIndex_from_PaDeviceInfo( const PaDeviceInfo* info )
// ============================================================================
{
    PaDeviceIndex found = -1;

    if (!info)
        return found;

    for ( PaDeviceIndex i = 0; i < Pa_GetDeviceCount(); ++i )
    {
        if (Pa_GetDeviceInfo(i) == info)
        {
            found = i;
            break;
        }
    }

    return found;
}

// ============================================================================
PaHostApiTypeId PaHostApiIndex_to_PaHostApiTypeId( PaHostApiIndex index )
// ============================================================================
{
    const PaHostApiInfo* api_info = Pa_GetHostApiInfo( index );
    if (api_info)
    {
        return api_info->type;
    }
    else
    {
        return paInDevelopment;
    }
}

// ============================================================================
PaHostApiIndex eDriverType_to_PaHostApiIndex( eDriverType api )
// ============================================================================
{
    PaHostApiTypeId api_type = eDriverType_to_PaHostApiTypeId( api );

    for ( PaHostApiIndex i = 0 ; i < Pa_GetHostApiCount(); ++i )
    {
        const PaHostApiInfo* api_info = Pa_GetHostApiInfo( i );
        if (api_info &&
            api_info->type == api_type)
        {
            return i;
        }
    }

    return -1;
}

// ============================================================================
eDriverType PaHostApiIndex_to_eDriverType( PaHostApiIndex apiIndex )
// ============================================================================
{
    if (apiIndex < 0 || apiIndex >= Pa_GetHostApiCount() )
    {
        return MM_UNKNOWN;
    }

    const PaHostApiInfo* apiInfo = Pa_GetHostApiInfo(apiIndex);
    if (!apiInfo)
    {
        return MM_UNKNOWN;
    }

    return PaHostApiTypeId_to_eDriverType( apiInfo->type );
}

// ============================================================================
PaHostApiIndex PaHostApiTypeId_to_PaHostApiIndex( PaHostApiTypeId typeId )
// ============================================================================
{
    for ( PaHostApiIndex i = 0; i < Pa_GetHostApiCount(); ++i )
    {
        const PaHostApiInfo* p = Pa_GetHostApiInfo( i );
        if (p && (p->type == typeId))
        {
            return i;
        }
    }

    return -1;
}

// ============================================================================
std::vector<int> getSupportedSampleRates( PaDeviceIndex outDevice, int outCh,
                                          PaDeviceIndex inDevice, int inCh )
// ============================================================================
{
    std::vector<int> sampleRates;

    const PaDeviceIndex deviceCount = Pa_GetDeviceCount();

    if (outDevice < 0 || outDevice >= deviceCount )
    {
        MMError("getSupportedSampleRates() - Invalid out-device-index (%d) of (%d), abort\n", outDevice, deviceCount)
        return sampleRates;
    }

    if (inDevice < 0 || inDevice >= deviceCount )
    {
        MMError("getSupportedSampleRates() - Invalid in-device-index (%d) of (%d), abort\n", inDevice, deviceCount)
        return sampleRates;
    }

    PaStreamParameters outParams;
    PaStreamParameters inParams;
    memset( &outParams, 0, sizeof(PaStreamParameters) );
    memset( &inParams, 0, sizeof(PaStreamParameters) );

    outParams.device = outDevice;
    outParams.channelCount = outCh;
    outParams.sampleFormat = paFloat32;
    outParams.suggestedLatency = 0;
    outParams.hostApiSpecificStreamInfo = nullptr;

    inParams.device = inDevice;
    inParams.channelCount = inCh;
    inParams.sampleFormat = paFloat32;
    inParams.suggestedLatency = 0;
    inParams.hostApiSpecificStreamInfo = nullptr;

    for ( int i = 0; i < SAMPLERATE_COUNT; ++i )
    {
        int sampleRate = SAMPLERATES[i];

        PaStreamParameters* pInParams = &inParams;
        PaStreamParameters* pOutParams = &outParams;
        if (inCh <= 0)
        {
            pInParams = nullptr;
        }
        if (outCh <= 0)
        {
            pOutParams = nullptr;
        }

        PaError error = Pa_IsFormatSupported( pInParams, pOutParams, (double)sampleRate);

        if ( error == paFormatIsSupported )
        {
            sampleRates.push_back( sampleRate );
        }
        else
        {
            //MMError("getSupportedSampleRates() - %s\n", Pa_GetErrorText(error) )
        }
    }

    return sampleRates;
}


/// Little Helper for the audio dialog
// ============================================================================
bool isValidPaHostApiTypeId( const PaHostApiTypeId apiType )
// ============================================================================
{
    for ( PaHostApiIndex i = 0; i < Pa_GetHostApiCount(); ++i )
    {
        const PaHostApiInfo* p = Pa_GetHostApiInfo(i);
        if (p && p->type == apiType)
        {
            return true;
        }
    }

    return false;
}

/// Little Helper for the audio dialog
// ============================================================================
bool isValidPaHostApiIndex( const PaHostApiIndex apiIndex )
// ============================================================================
{
    if ( apiIndex < 0 )
        return false;

    if ( apiIndex >= Pa_GetHostApiCount() )
        return false;

//    const PaHostApiInfo* p = Pa_GetHostApiInfo(apiIndex);
//    if (!p)
//        return false;

    return true;
}

/// Little Helper for the audio dialog
// ============================================================================
bool isValidPaDeviceIndex( const PaDeviceIndex deviceIndex )
// ============================================================================
{
    if ( deviceIndex < 0 )
        return false;

    if ( deviceIndex >= Pa_GetDeviceCount() )
        return false;

    return true;
}

// ============================================================================
int getDeviceDefaultSampleRate( const PaDeviceIndex deviceIndex )
// ============================================================================
{
    if (deviceIndex < 0 || deviceIndex >= Pa_GetDeviceCount() )
    {
        return -1;
    }

    const PaDeviceInfo* info = Pa_GetDeviceInfo( deviceIndex );
    if (!info)
        return -1;

    return (int)info->defaultSampleRate;
}

} // end namespace PA
} // end namespace audio

#endif // USE_PORTAUDIO
