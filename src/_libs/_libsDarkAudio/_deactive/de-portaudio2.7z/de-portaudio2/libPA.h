#ifndef MMAUDIO_LIB_PORTAUDIO_H
#define MMAUDIO_LIB_PORTAUDIO_H

/// PortAudio API

#include <audio.Base.h>

#ifdef USE_PORTAUDIO

#ifdef __cplusplus
    extern "C"
    {
#endif

#include <portaudio.h>
#include <pa_asio.h>
#include <pa_win_waveformat.h>
#include <pa_win_wmme.h>
#include <pa_win_ds.h>
#include <pa_win_wasapi.h>
#include <pa_win_wdmks.h>
//#include <pa_linux_alsa.h>

#ifdef __cplusplus
    }
#endif

namespace audio {
namespace PA {

    /// This prints errors coming from PortAudio
    /// if (bFatal), it throws a runtime exception
    void CHECK( PaError error, bool bFatal = false );

    /// This is our singleton PortAudio instance ( always use this )
    /// and never call Pa_Initialize and Pa_Terminate elsewhere
    class Lib
    {
    public:
//        static Lib& getInstance()
//        {
//            static Lib singleton;
//            return singleton;
//        }

        Lib()
        {
            //MMDebug("audio::PA::Lib()\n")

            m_paError = Pa_Initialize();

            // throws exception on error, because the whole program is useless
            CHECK( m_paError, true );
        }

        ~Lib()
        {
            m_paError = Pa_Terminate();

            CHECK( m_paError );

            //MMDebug("audio::PA::~Lib()\n")
        }

    private:
        PaError m_paError;
    };


    typedef std::shared_ptr<Lib> SharedLib;

    SharedLib getLib();

    std::string getDeviceName( PaDeviceIndex index );

    std::string getGlobalInfoString();
    std::string getHostApiInfoString( int api );
    std::string getDeviceInfoString( int api, int index );
    std::string getDeviceInfoString( const PaDeviceInfo* p );

    PaDeviceIndex getDeviceIndex( const PaDeviceInfo* p );

    std::vector<const PaDeviceInfo*> getOutputDevices( PaHostApiIndex index );
    std::vector<const PaDeviceInfo*> getInputDevices( PaHostApiIndex index );

    // ============================================================================

    PaDeviceIndex PaDeviceIndex_from_PaDeviceInfo( const PaDeviceInfo* info );

    // ============================================================================
    eDriverType PaHostApiIndex_to_eDriverType( PaHostApiIndex apiIndex );
    eDriverType PaHostApiTypeId_to_eDriverType( PaHostApiTypeId typeId );
    PaHostApiTypeId eDriverType_to_PaHostApiTypeId( eDriverType api );
    PaHostApiTypeId PaHostApiIndex_to_PaHostApiTypeId( PaHostApiIndex index );
    PaHostApiIndex eDriverType_to_PaHostApiIndex( eDriverType api );
    PaHostApiIndex PaHostApiTypeId_to_PaHostApiIndex( PaHostApiTypeId typeId );

// ============================================================================

    /// get supported sample-rates by brute-force

    std::vector<int> getSupportedSampleRates( PaDeviceIndex outDevice, int outCh,
                                              PaDeviceIndex inDevice, int inCh );

// ============================================================================

    /// Little Helper for the audio dialog
    bool isValidPaHostApiTypeId( const PaHostApiTypeId apiType );
    bool isValidPaHostApiIndex( const PaHostApiIndex apiIndex );
    bool isValidPaDeviceIndex( const PaDeviceIndex deviceIndex );

    int getDeviceDefaultSampleRate( const PaDeviceIndex deviceIndex );

    std::string PaHostApiIndex_toString( const PaHostApiIndex index );
    std::string PaDeviceIndex_toString( const PaDeviceIndex index );
    std::string dump();

} // end namespace PA
} // end namespace audio

#endif // USE_PORTAUDIO

#endif // MM_AUDIO_LIB_PORTAUDIO_H
