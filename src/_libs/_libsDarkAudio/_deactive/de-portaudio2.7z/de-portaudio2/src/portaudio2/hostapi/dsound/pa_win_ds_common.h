#ifndef PA_WIN_DS_COMMON_H
#define PA_WIN_DS_COMMON_H

#include <assert.h>
#include <stdio.h>
#include <string.h> /* strlen() */

#define _WIN32_WINNT 0x0400 /* required to get waitable timer APIs */
#include <initguid.h> /* make sure ds guids get defined */
#include <windows.h>
#include <mmsystem.h>
#include <objbase.h>
#pragma comment( lib, "winmm.lib" )
#pragma comment( lib, "kernel32.lib" )


/*
  Use the earliest version of DX required, no need to polute the namespace
*/
#ifdef PAWIN_USE_DIRECTSOUNDFULLDUPLEXCREATE
#define DIRECTSOUND_VERSION 0x0800
#else
#define DIRECTSOUND_VERSION 0x0300
#endif

// #ifndef DIRECTSOUND_VERSION
// #define DIRECTSOUND_VERSION 0x0800
// #endif

#include <dsound.h>
#pragma comment( lib, "dsound.lib" )


/* Until May 2011 PA/DS has used a multimedia timer to perform the callback.
   We're replacing this with a new implementation using a thread and a different timer mechanim.
   Defining PA_WIN_DS_USE_WMME_TIMER uses the old (pre-May 2011) behavior.
*/
//#define PA_WIN_DS_USE_WMME_TIMER

/*
  Use the earliest version of DX required, no need to polute the namespace
*/

#ifdef PAWIN_USE_WDMKS_DEVICE_INFO
#include <dsconf.h>
#endif /* PAWIN_USE_WDMKS_DEVICE_INFO */
#ifndef PA_WIN_DS_USE_WMME_TIMER
#ifndef UNDER_CE
#include <process.h>
#endif
#endif

#endif
