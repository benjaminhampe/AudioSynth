//////////////////////////////////////////////////////////////////////////////
/// @file main_test.cpp
/// @author Benjamin Hampe <benjamin.hampe@gmx.de>
//////////////////////////////////////////////////////////////////////////////

#include <amrnb/interf_dec.h>
#include <amrnb/interf_enc.h>
#include <amrnb/interf_rom.h>
#include <iostream>

int main( int argc, char** argv )
{  
   std::cout << "[Test] amrnb\n";

   return 0;
}