// This file is auto-generated, manual changes will be lost if the code is regenerated.

#include "geometries.hpp"

namespace mapbox {
namespace fixtures {

static const Fixture<short> issue45("issue45", 10, 1e-14, 0.094, {
    {{10,10},{25,10},{25,40},{10,40}},
    {{15,30},{20,35},{10,40}},
    {{15,15},{15,20},{20,15}},
});

}
}
