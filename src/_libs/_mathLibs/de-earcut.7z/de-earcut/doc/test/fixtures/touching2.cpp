// This file is auto-generated, manual changes will be lost if the code is regenerated.

#include "geometries.hpp"

namespace mapbox {
namespace fixtures {

static const Fixture<short> touching2("touching2", 8, 1e-14, 0.000001, {
    {{120,2031},{92,2368},{94,2200},{33,2119},{42,2112},{53,2068}},
    {{44,2104},{79,2132},{88,2115},{44,2104}},
});

}
}
