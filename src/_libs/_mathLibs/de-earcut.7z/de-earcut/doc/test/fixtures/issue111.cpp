// This file is auto-generated, manual changes will be lost if the code is regenerated.

#include "geometries.hpp"

namespace mapbox {
namespace fixtures {

static const Fixture<short> issue111("issue111", 19, 1e-14, 0.000001, {
    {{800,4520},{800,4700},{796,4702},{800,4692},{734,4644},{734,4628},{730,4632},{726,4630},{718,4640},{690,4623},{722,4598},{690,4608},{690,4520},{800,4520}},
    {{718,4640},{716,4630},{710,4628},{718,4640}},
    {{734,4610},{734,4628},{740,4622},{734,4610}},
    {{734,4610},{745,4600},{734,4602},{734,4610}},
});

}
}
