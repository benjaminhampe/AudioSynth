#ifndef UNICODE

#include <de/AudioDecoderFFMPEG.hpp>
#include <de/VideoDecoderFFMPEG.hpp>

#include <de/FileSystem.hpp>
#include <de/os/CommonDialogs.hpp>
// #include <de/audio/buffer/BufferIO.hpp>

namespace de {

std::string
repairString( std::wstring loadUri )
{
   //std::wstring w = dbStrW( loadUri );
   //std::wcout << "LoadUri = " << w << L'\n';

   std::stringstream s;
   for ( size_t i = 0; i < loadUri.size(); ++i )
   {
      uint32_t c = loadUri[ i ];
      if ( c <= 30 ) c = '_';
      if ( c > 'z' ) c = '_';
      s << char( c );
   }

   std::string r = s.str();
   std::cout << "RepairedUri = " << r << std::endl;
   return r;

}

struct extractCoverArt
{
   DE_CREATE_LOGGER("extractCoverArt")

   static bool
   run( int argc, char** argv )
   {
      std::wstring loadUri;
//      if ( argc > 1 )
//      {
//         loadUri = argv[1];
//      }

      if ( !dbExistFile(loadUri) )
      {
         loadUri = dbOpenFileDlgW(
            L"Load file (mp3,wav,mkv,avi,mp4,etc..) that is supported by libAVCodec ( vlc )",
            0,0,800,600,
            L"",
            L"../../", true );
      }

//      if ( !dbExistFile(loadUri) )
//      {
//         DE_ERROR("Empty loadUri, program exits now... Bye bye, loadUri = ", loadUri)
//         DE_FLUSH
//         return false;
//      }

      std::string saveUri;
      if ( argc > 2 )
      {
         saveUri = argv[ 2 ];
      }

      //repairString( loadUri );

      auto loadUriSTL = repairString( loadUri );

      saveUri = loadUriSTL + ".coverArt.png";

      //DE_DEBUG("[LoadMP3] loadUri = ", loadUri )
      //Buffer workBuffer;

      PerformanceTimer perf;
      perf.start();

      VideoFile file;
      if ( !file.open( loadUri, -1, true ) )
      {
         DE_ERROR("No decoder open, ",loadUriSTL)
         return false;
      }

      bool foundCoverArt = false;

      int loopCounter = 0;

      std::shared_ptr< Image > img;

      //auto handlePayload =

      while ( !foundCoverArt )
      {
         int e = file.readFrame(
            [&]( ImagePayload payload )
            {
               if ( payload.img && !payload.img->empty() )
               {
                  foundCoverArt = true;
                  img = payload.img;
                  loopCounter++;
               }
            }, true );
         if ( e == AVERROR_EOF )
         {
            break;
         }
      }

      file.close();

      perf.stop();

      if ( img )
      {
         DE_DEBUG("Loaded CoverArt img(",img->toString(),") after ",loopCounter," loops. ",loadUriSTL )
         dbSaveImage( *img, saveUri );
         return true;
      }
      else
      {
         DE_ERROR("No CoverArt after ",loopCounter," loops. ",loadUriSTL )
         return false;
      }

      DE_FLUSH

   }

};

} // end namespace de


//========================================================================
int main(int argc, char** argv)
//========================================================================
{
   bool ok = de::extractCoverArt::run( argc, argv );
   return 0;
}

#endif
