#ifndef DE_LIVE_AUDIO_PLUGIN_SHELL_WITH_LEVELMETER_HPP
#define DE_LIVE_AUDIO_PLUGIN_SHELL_WITH_LEVELMETER_HPP

#include "Plugin.hpp"

// Class is a container for exactly one audio ( or midi ) plugin ( benni or VST2x )
// Mostly has one VST plugin and one audio LevelMeter
// Has plugin editor ui to be added to track editor ui chain.

// ============================================================================
class PluginShell : public QWidget, public de::audio::IDspChainElement
// ============================================================================
{
   Q_OBJECT
public:
   PluginShell( App & app, QWidget* parent = 0 );
   ~PluginShell();
   bool hasFocus() const { return m_hasFocus; }
   
signals:
public slots:
   void setInputSignal( int i, de::audio::IDspChainElement* input ) override;
   void clearInputSignals() override;
   uint64_t readSamples( double pts, float* dst, uint32_t dstFrames, uint32_t dstChannels, uint32_t dstRate ) override;

   //void stopUpdateTimer();
   //void startUpdateTimer( int ms = 37 );

protected:
   //void timerEvent( QTimerEvent* event) override;
   void paintEvent( QPaintEvent* event ) override;
   void resizeEvent( QResizeEvent* event ) override;
   void enterEvent( QEvent* event ) override;
   void leaveEvent( QEvent* event ) override;
   void focusInEvent( QFocusEvent* event ) override;
   void focusOutEvent( QFocusEvent* event ) override;

   void drawLevelMeter( QPaintEvent* event, int x, int y, int w, int h );
   void drawPluginShell( QPaintEvent* event, int x, int y, int w, int h );

private:
   DE_CREATE_LOGGER("PluginShell")
   App & m_app;
   bool m_isHovered;
   bool m_hasFocus;
   int m_updateTimerId;

   de::audio::IDspChainElement* m_inputSignal;
   float m_Lmin;
   float m_Lmax;
   float m_Rmin;
   float m_Rmax;

//   std::vector< float > m_accumBuffer;
   QFont5x8 m_font5x8;
   de::LinearColorGradient m_ColorGradient;
};

#endif // DE_Q_IMAGEWIDGET_HPP
