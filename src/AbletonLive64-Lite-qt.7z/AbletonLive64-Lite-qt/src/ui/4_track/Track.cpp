/// (c) 2017 - 20180 Benjamin Hampe <benjaminhampe@gmx.de>

#include "Track.hpp"
#include "App.hpp"

Track::Track( App & app, QWidget* parent )
   : QWidget( parent )
   , m_app( app )
   , m_audioInput( nullptr )
   , m_audioEnd( nullptr )
   , m_audioSynth( nullptr )
   , m_audioSynthMeter( nullptr )
{
   setObjectName( "Track" );
   setContentsMargins( 0,0,0,0 );
   setMouseTracking( true );
   //setAcceptDrops( true );         // We can drop plugins ( Midi or Audio ) into this editor widget.

   m_midiMeter = new MidiMeter( m_app, this );

   m_dropTarget = new DropTarget( m_app, this );
   m_dropTarget->setAudioOnly( false );
}

Track::~Track()
{
   clearWidgets();
}

void
Track::sendNote( de::audio::Note const & note )
{
   if ( m_audioSynth ) m_audioSynth->sendNote( note );
}

void
Track::allNotesOff()
{
   if ( m_audioSynth ) m_audioSynth->allNotesOff();
}

void
Track::setVolume( int volume )
{
   m_trackInfo.m_volume = volume;
}

void
Track::clearWidgets()
{
   if ( m_audioSynth )
   {
      delete m_audioSynth;
      m_audioSynth = nullptr;
   }

   if ( m_audioSynthMeter )
   {
      delete m_audioSynthMeter;
      m_audioSynthMeter = nullptr;
   }

   m_audioInput = nullptr;
   m_audioEnd = nullptr;

   for ( auto effect : m_audioEffects )
   {
      if ( effect ) delete effect;
   }
   m_audioEffects.clear();

   for ( auto meter : m_audioEffectsMeter )
   {
      if ( meter ) delete meter;
   }
   m_audioEffectsMeter.clear();
}

void
Track::updateLayout()
{
   int w = width();
   int h = height();
   int x = 0;
   int y = 0;

   int mmw = 4;   // Midi Meter Width
   int amw = 9;   // Audio Meter Width
   int editorW = 158;

   // Layout Midi Meter
   setWidgetBounds( m_midiMeter, QRect(x,y,mmw,h) ); x += mmw + 2;

   // Layout Audio Plugin
   if ( m_audioSynth )
   {
      //editorW = m_audioSynth->maximumWidth();
      setWidgetBounds( m_audioSynth, QRect(x,y,editorW,h) ); x += editorW;
   }
   // Layout Audio Plugin Meter
   if ( m_audioSynthMeter )
   {
      setWidgetBounds( m_audioSynthMeter, QRect(x,y,amw,h) ); x += amw;
   }

   for ( size_t i = 0; i < m_audioEffects.size(); ++i )
   {
      auto fx = m_audioEffects[ i ];
      if ( fx )
      {
         // Layout Audio Plugin
         //editorW = fx->maximumWidth();
         setWidgetBounds( fx, QRect(x,y,editorW,h) ); x += editorW;

         // Layout Audio Plugin Meter
         if ( i < m_audioEffectsMeter.size() )
         {
            auto fx_meter = m_audioEffectsMeter[ i ];
            if ( fx_meter )
            {
               setWidgetBounds( fx_meter, QRect(x,y,amw,h) ); x += amw;
            }
         }
      }
   }

   // Layout Drop dummy
   int dummyW = w - x;
   if ( dummyW < 50 ) dummyW = 50;
   setWidgetBounds( m_dropTarget, QRect(x,y,dummyW,h) );

   update();
}

/*
void
Plugin::updateLayout()
{
   int w = 17 + 9;
   int h = 190;

   if ( m_isMinimized )
   {
      setMinimumSize( QSize( w, h ) );
      setMaximumSize( QSize( w, h ) );
      m_rcPanel = QRect( 0,0,w - 9,h );
      m_rcMeter = QRect( w-1-9,0,9,h );
      m_rcHeader = m_rcPanel;
      setWidgetBounds( m_audioMeter, m_rcMeter );
      //setWidgetBounds( m_levelMeter, m_rcMeter );

      int x = 2;
      int y = 2;
      setWidgetBounds( m_btnEnabled, QRect( x,y,13,13 ) ); y += 16;
      setWidgetBounds( m_btnEditor, QRect( x,y,13,13 ) ); y += 16;
      setWidgetBounds( m_btnMore, QRect() );
      setWidgetBounds( m_btnLoadPreset, QRect() );
      setWidgetBounds( m_btnSavePreset, QRect() );
   }
   else
   {
      w = 158 + 9;
      setMinimumSize( QSize( w, h ) );
      setMaximumSize( QSize( w, h ) );
      m_rcMeter = QRect( w-1-9,0,9,h );
      setWidgetBounds( m_audioMeter, m_rcMeter );
      //setWidgetBounds( m_levelMeter, m_rcMeter );
      m_rcPanel = QRect( 0,0,w - 9,h );
      m_rcHeader = QRect( 0,0,w - 9,17 );

      int x = 2;
      int y = 2;
      setWidgetBounds( m_btnEnabled, QRect( x,y,13,13 ) ); x += 16;
      setWidgetBounds( m_btnMore, QRect( x,y,13,13 ) ); x += 16;
      setWidgetBounds( m_btnEditor, QRect( x,y,13,13 ) ); x += 16;

      x = 8;
      y = 22;
      setWidgetBounds( m_btnLoadPreset, QRect( x,y,13,13 ) ); x += 16;
      setWidgetBounds( m_btnSavePreset, QRect( x,y,13,13 ) ); x += 16;
   }

   update();
}
*/

void
Track::resizeEvent( QResizeEvent* event )
{
   updateLayout();
   QWidget::resizeEvent( event );
}

//void
//Track::paintEvent( QPaintEvent* event )
//{
//   QWidget::paintEvent( event );
//}


void
Track::dropEvent( QDropEvent* event )
{
   std::cout << "Track::" << __func__ << std::endl;
   std::cout << event->mimeData()->text().toStdString() << std::endl;

   std::wstring uri = event->mimeData()->text().toStdWString();
   m_app.addPlugin( uri, true );

   event->acceptProposedAction();
   QWidget::dropEvent( event );
}

void
Track::dragEnterEvent( QDragEnterEvent* event )
{
   if ( event->mimeData()->hasFormat("text/plain") )
   {
      event->acceptProposedAction();
   }
   std::cout << __func__ << std::endl;
   QWidget::dragEnterEvent( event );
}

void
Track::dragLeaveEvent( QDragLeaveEvent* event )
{
   std::cout << __func__ << std::endl;
   QWidget::dragLeaveEvent( event );
}

void
Track::dragMoveEvent(QDragMoveEvent* event )
{
   std::cout << __func__ << std::endl;
   QWidget::dragMoveEvent( event );
}

void
Track::focusInEvent( QFocusEvent* event )
{
   m_trackInfo.m_hasFocus = true;
   update();
   QWidget::focusInEvent( event );
}

void
Track::focusOutEvent( QFocusEvent* event )
{
   m_trackInfo.m_hasFocus = true;
   update();
   QWidget::focusOutEvent( event );
}

void
Track::enterEvent( QEvent* event )
{
   QWidget::enterEvent( event );
}

void
Track::leaveEvent( QEvent* event )
{
   QWidget::leaveEvent( event );
}


uint64_t
Track::readSamples( double pts, float* dst, uint32_t dstFrames, uint32_t dstChannels, uint32_t dstRate )
{
   //std::cout << "No audioEnd in track " << id() << std::endl;
   uint64_t dstSamples = dstFrames * dstChannels;
   de::audio::DSP_FILLZERO( dst, dstSamples );

//   if ( isBypassed() )
//   {
//      return dstSamples;
//   }

   if ( m_audioEnd )
   {
      uint64_t dstSamples = m_audioEnd->readSamples( pts, dst, dstFrames, dstChannels, dstRate );

      int iVolume = getVolume();
      float fVolume = 0.0001f * ( iVolume * iVolume );
      de::audio::DSP_MUL_LIMITED( dst, dstSamples, fVolume );

      // Calc LevelMeter data

      // Now 'dst' contains valid audio data processed by VST plugin. Lets compute min/max of data...

      // |---|   |---|
      // |   |   |   |
      // |---|   |---|
      // |   |   |   |
      // |   |   |   |
      // +---+   +---+
      // | L |   | R |

      // Fast interleaved stereo path O(1) = one loop over samples
      if ( dstChannels == 0 )
      {
         //emit audioMeterData( m_Lmin, m_Lmax, m_Rmin, m_Rmax );
      }
      if ( dstChannels == 1 )
      {
         float m_Lmin = std::numeric_limits< float >::max();
         float m_Lmax = std::numeric_limits< float >::lowest();

         float const* p1 = dst;
         for ( uint64_t i = 0; i < dstFrames; ++i )
         {
            float sampleL = *p1;
            m_Lmin = std::min( m_Lmin, sampleL );
            m_Lmax = std::max( m_Lmax, sampleL );
            p1 += dstChannels;
         }

         emit audioMeterData( m_Lmin, m_Lmax, 0.f, 0.f );
      }
      else // if ( dstChannels >= 2 )
      {
         float m_Lmin = std::numeric_limits< float >::max();
         float m_Lmax = std::numeric_limits< float >::lowest();
         float m_Rmin = std::numeric_limits< float >::max();
         float m_Rmax = std::numeric_limits< float >::lowest();

         float const* p1 = dst;
         float const* p2 = p1;
         for ( uint64_t i = 0; i < dstFrames; ++i )
         {
            float sampleL = *p2;
            m_Lmin = std::min( m_Lmin, sampleL );
            m_Lmax = std::max( m_Lmax, sampleL );
            p2++;
            float sampleR = *p2;
            m_Rmin = std::min( m_Rmin, sampleR );
            m_Rmax = std::max( m_Rmax, sampleR );
            p1 += dstChannels;
            p2 = p1;
         }

         emit audioMeterData( m_Lmin, m_Lmax, m_Rmin, m_Rmax );
      }
   }

   return dstSamples;
}
