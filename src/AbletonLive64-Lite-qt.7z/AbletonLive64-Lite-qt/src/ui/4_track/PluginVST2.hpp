#ifndef DE_LIVE_PLUGIN_VST2X_HPP
#define DE_LIVE_PLUGIN_VST2X_HPP

#include "LiveSkin.hpp"
#include "ImageButton.hpp"
#include <de/audio/dsp/IDspChainElement.hpp>
#include <de/audio/plugin/IPlugin.hpp>
//#pragma warning(push)
//#pragma warning(disable : 4996)
#include <pluginterfaces/vst2.x/aeffectx.h>  // de_vst2sdk
//#pragma warning(pop)

struct App;

// ============================================================================
class PluginEditorWindow : public QWidget
// ============================================================================
{
   Q_OBJECT
   bool m_enableClosing;
public:
   PluginEditorWindow( QWidget* parent = 0 );
   ~PluginEditorWindow() override;
signals:
   void closed();
public slots:
   void enableClosing();
   void disableClosing();
protected:
   void closeEvent( QCloseEvent* event ) override;
};

// ============================================================================
struct IPlugin : public de::audio::IDspChainElement
// ============================================================================
{
   virtual ~IPlugin() = default;

   virtual int
   id() const = 0;

   virtual void
   setId( int id ) = 0;

   virtual de::audio::PluginInfo const &
   pluginInfo() const = 0;

   virtual std::wstring const &
   uri() const = 0;

   virtual bool isEditorVisible() const = 0;
   virtual void showEditor() = 0;
   virtual void hideEditor() = 0;

   virtual int editorW() const = 0;
   virtual int editorH() const = 0;
   virtual int editorX() const = 0;
   virtual int editorY() const = 0;
   virtual void moveEditor( int x, int y ) = 0;

   bool isBypassed() const { return pluginInfo().m_isBypassed; }
   int numPrograms() const { return pluginInfo().numPrograms(); }
   int numParams() const { return pluginInfo().numParams(); }
   int numInputs() const { return pluginInfo().numInputs(); }
   int numOutputs() const { return pluginInfo().numOutputs(); }
   bool hasEditor() const { return pluginInfo().hasEditor(); }
   bool isSynth() const { return pluginInfo().isSynth(); }

//   int getVendorVersion();
//   std::string getVendorString();
//   std::string getProductString();

   //uint32_t getSampleRate() const override;
   //uint64_t getSamplePos() const;
   //uint64_t getBlockSize() const;
   //uint64_t getChannelCount() const;

};

// ============================================================================
class PluginVST2 : public QWidget, public IPlugin
// ============================================================================
{
   Q_OBJECT
public:
   PluginVST2( App & app, QWidget* parent = 0 );
   ~PluginVST2();

signals:
   void audioMeterData( float l_low, float l_high, float r_low, float r_high );
   void addedSynth( de::audio::IDspChainElement* );
   void removedSynth( de::audio::IDspChainElement* );

public:
   int id() const override { return m_id; }
   void setId( int id ) override { m_id = id; }

   de::audio::PluginInfo const & pluginInfo() const { return m_pluginInfo; }
   std::wstring const & uri() const { return m_uri; }

   bool isMoreVisible() const { return m_btnMore->isChecked(); }
   bool isEditorVisible() const { return m_btnEditor->isChecked(); }
   int editorW() const override { return m_x; }
   int editorH() const override { return m_y; }
   int editorX() const override { return m_w; }
   int editorY() const override { return m_h; }

//   int numPrograms() const { return m_vst ? m_vst->numPrograms : 0; }
//   int numParams() const { return m_vst ? m_vst->numParams : 0; }
//   int numInputs() const { return m_vst ? m_vst->numInputs : 0; }
//   int numOutputs() const { return m_vst ? m_vst->numOutputs : 0; }
   bool getFlags( int32_t m ) const { return m_vst ? ((m_vst->flags & m) == m) : 0; }
//   bool hasEditor() const { return m_pluginInfo.hasEditor(); }
//   bool isSynth() const override { return m_pluginInfo.isSynth(); }

   int getVendorVersion();
   std::string getVendorString();
   std::string getProductString();

   //uint32_t getSampleRate() const override;
   //uint64_t getSamplePos() const;
   //uint64_t getBlockSize() const;
   //uint64_t getChannelCount() const;

   uint64_t readSamples( double pts, float* dst, uint32_t dstFrames, uint32_t dstChannels, uint32_t dstRate ) override;

public slots:
   //void setUri( std::wstring const & uri ) { m_uri = uri; }
   //bool openPlugin( std::wstring const & uri );
   bool openPlugin( de::audio::PluginInfo const & pluginInfo );
   void closePlugin();

   void setBypassed( bool bypassed ) override;
   void setMoreVisible( bool visible );

   void setEditorVisible( bool visible );
   void showEditor() override;
   void hideEditor() override;
   void moveEditor( int x, int y ) override
   {
      m_x = x;
      m_y = y;
      if ( m_editorWindow )
      {
         m_editorWindow->move( m_x, m_y );
      }
   }

   void allNotesOff();
   void sendNote( de::audio::Note const & note ) override;

   void aboutToStart( uint32_t dstFrames, uint32_t dstChannels, uint32_t dstRate ) override;
   void clearInputSignals() override { m_inputSignal = nullptr; }
   void setInputSignal( int i, de::audio::IDspChainElement* input ) override { m_inputSignal = input; }

protected slots:
   void on_editorClosed();
protected:
   void updateLayout();
//   void stopUpdateTimer();
//   void startUpdateTimer();
   void sendVstMidi( uint8_t byte1, uint8_t data1, uint8_t data2 );

   static VstIntPtr
   hostCallback_static(
      AEffect* effect,
      VstInt32 opcode,
      VstInt32 index,
      VstIntPtr value,
      void *ptr,
      float opt );

   VstIntPtr
   hostCallback(
      VstInt32 opcode,
      VstInt32 index,
      VstIntPtr value,
      void* ptr,
      float opt );

   intptr_t
   dispatcher(
      int32_t opcode,
      int32_t index = 0,
      intptr_t value = 0,
      void *ptr = nullptr,
      float opt = 0.0f ) const;

   void
   processVstMidiEvents();

   const char**
   getCapabilities() const;

   void resizeEvent( QResizeEvent* event ) override;
   void paintEvent( QPaintEvent* event ) override;
   void mouseDoubleClickEvent( QMouseEvent* event ) override;
   void enterEvent( QEvent* event ) override;
   void leaveEvent( QEvent* event ) override;
   void focusInEvent( QFocusEvent* event ) override;
   void focusOutEvent( QFocusEvent* event ) override;
/*
   QSize sizeHint() const override;
   void mousePressEvent( QMouseEvent* event ) override;
   void mouseReleaseEvent( QMouseEvent* event ) override;
   void mouseMoveEvent( QMouseEvent* event ) override;
   void wheelEvent( QWheelEvent* event ) override;
   void keyPressEvent( QKeyEvent* event ) override;
   void keyReleaseEvent( QKeyEvent* event ) override;
*/
   ImageButton* createEnableButton(); // Bypass button
   ImageButton* createMoreButton(); // More button
   ImageButton* createEditorButton();  // Show/hide (plugin) editor window button
   ImageButton* createUpdateButton();  // UpdateFrom button
   ImageButton* createSaveButton(); // Save button
protected:
   DE_CREATE_LOGGER("PluginVST2")
   App & m_app;
public:
   de::audio::PluginInfo m_pluginInfo;
protected:
   QString m_title;
// LiveApp :: Widgets
   ImageButton* m_btnEnabled;
   ImageButton* m_btnMore;
   ImageButton* m_btnEditor;
   ImageButton* m_btnLoadPreset;
   ImageButton* m_btnSavePreset;
// Layout
   QImage m_imgTitleH;
   QImage m_imgTitleV;
   QImage m_imgEditorContent;
   QFont5x8 m_font5x8;
   QRect m_rcPanel;
   QRect m_rcHeader;
   QRect m_rcMeter;
// #ifdef USE_BENNI_VST2x_HOST
   bool m_hasFocus;
   bool m_isMinimized;
   bool m_isLoaded;
   bool m_isDirty;
   bool m_isMore;
   int m_id;
   uint32_t m_sampleRate;     // rate in Hz
   uint32_t m_bufferFrames;   // frames per channel
   de::audio::IDspChainElement* m_inputSignal;
   uint64_t m_dllHandle; // HMODULE
   AEffect* m_vst;
   PluginEditorWindow* m_editorWindow; // HWND
   int m_x;
   int m_y;
   int m_w;
   int m_h;
   std::atomic< uint64_t > m_framePos;
   std::wstring m_uri;                 // PluginVST2 file name
   std::string m_directoryMultiByte;
   VstTimeInfo m_timeInfo;
   // VST seems to work channelwise / planar, not interleaved audio.
   std::vector< float > m_outBuffer;
   std::vector< float*> m_outBufferHeads;
   std::vector< float > m_inBuffer;
   std::vector< float*> m_inBufferHeads;
   // VST midi event handling
   std::vector< VstMidiEvent > m_vstMidiEvents;
   std::vector< char > m_vstEventBuffer;
   struct
   {
      std::unique_lock< std::mutex >
      lock() const { return std::unique_lock<std::mutex>(m_mutex); }

      std::vector< VstMidiEvent > events;
   private:
      std::mutex mutable m_mutex;
   } m_vstMidi;
//#endif

};

#endif
