#include "MidiParserTest.hpp"

namespace de {
namespace midi {

} // end namespace midi
} // end namespace de
