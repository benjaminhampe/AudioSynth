/// (c) 2017 - 20180 Benjamin Hampe <benjaminhampe@gmx.de>

#ifndef DE_LIVE_DATA_DSP_NETWORK_HPP
#define DE_LIVE_DATA_DSP_NETWORK_HPP

#include <iterator>
#include <de/audio/dsp/Mixer.hpp>
#include "TrackInfoManager.hpp"

namespace de {
namespace audio {

// ============================================================================
struct Instrument : public IDspChainElement
// ============================================================================
{
   // ---===--- Track Network ---===---
   TrackInfo m_trackInfo;
   //MidiMeter* m_midiMeter;
   //std::vector< IMidiSpurElement* > m_midiFx;// the rest of the audio Spur is a series of effects.
   //bool m_isBypassed;
   //bool m_isAudioOnly;
   //int m_volume;
   //int m_trackId;
   IDspChainElement* m_audioInput;
   IDspChainElement* m_audioEnd;    // AudioSpurEnd, for convenience to auto-connect end with a mixer
   IPlugin* m_audioSynth; // The linking element between MIDI and Audio Spur, either a Player or Synthesizer
   std::vector< IPlugin* > m_audioEffects; // Series of audio effects.
   //std::vector< LevelMeter > m_audioMeters;

   // ==============================================================
   Instrument()
   // ==============================================================
      : m_audioInput( nullptr )
      , m_audioEnd( nullptr )
      , m_audioSynth( nullptr )
   {}

   bool isBypassed() const override { return m_trackInfo.m_isBypassed; }
   void setBypassed( bool bypassed ) override { m_trackInfo.m_isBypassed = bypassed; }
   void clearInputSignals() { m_audioInput = nullptr; }
   void setInputSignal( int i, IDspChainElement* input ) { m_audioInput = input; }

   uint64_t
   readSamples( double pts, float* dst, uint32_t dstFrames, uint32_t dstChannels, uint32_t dstRate ) override
   {
      return m_audioEnd->readSamples( pts, dst, dstFrames, dstChannels, dstRate );
   }

};

// ============================================================================
struct Network : public IDspChainElement
// ============================================================================
{
   std::vector< Instrument > m_tracks;  // all tracks
   Instrument* m_master;                 // fix non user track
   std::vector< Instrument* > m_returns; // all return tracks
   std::vector< Instrument* > m_user;    // all user tracks ( 1 Audio + 1 Midi )
   std::vector< Instrument* > m_userAudio; // all user tracks ( 1 Audio + 1 Midi )
   std::vector< Instrument* > m_userMidi; // all user tracks ( 1 Audio + 1 Midi )

   //IDspChainElement* m_inputSignal;
   Mixer m_userMixer;
   Mixer m_returnMixer;

   // ==============================================================
   Network()
   // ==============================================================
      : m_master( nullptr )
   {}

   void
   aboutToStart( uint32_t dstFrames, uint32_t dstChannels, uint32_t dstRate ) override
   {

   }

   uint64_t
   readSamples( double pts, float* dst, uint32_t dstFrames, uint32_t dstChannels, uint32_t dstRate ) override
   {
      if ( m_master )
      {
         return m_master->readSamples( pts, dst, dstFrames, dstChannels, dstRate );
      }
      else
      {
         uint64_t dstSamples = dstFrames * dstChannels;
         DSP_FILLZERO( dst, dstSamples );
         return dstSamples;
      }

   }

};

// DoubleBuffered Network
// ============================================================================
struct DoubleBufferedNetwork : public IDspChainElement
// ============================================================================
{
   Network m_networkA;
   Network m_networkB;

   Network* m_front;   // What the engine currently uses ( read only network )
   Network* m_back;    // What we can make changes to ( write network )

   bool m_wantSwitch;

   // ==============================================================
   DoubleBufferedNetwork()
   // ==============================================================
      : m_front( nullptr )
      , m_back( nullptr )
      , m_wantSwitch( false )
   {
      m_front = &m_networkA;
      m_back = &m_networkB;
   }

   void
   aboutToStart( uint32_t dstFrames, uint32_t dstChannels, uint32_t dstRate ) override
   {

   }

   uint64_t
   readSamples( double pts, float* dst, uint32_t dstFrames, uint32_t dstChannels, uint32_t dstRate ) override
   {
      if ( m_wantSwitch )
      {
         auto tmp = m_back;
         m_back = m_front;
         m_front = tmp;
         m_wantSwitch = false;
      }

      return m_front->readSamples( pts, dst, dstFrames, dstChannels, dstRate );
   }

//   void updateNetwork( Network* network )
//   {

//   }
};



} // end namespace live
} // end namespace de


#endif















/*


   static TrackChain
   create( TrackInfo const & trackInfo, IDspChainElement* audioInput )
   {
      TrackChain tc;

      int id = trackInfo.m_id;
//      int found = findIndex( id );
//      if ( found > -1 )
//      {
//         DE_ERROR("Track id ",id," already exist")
//         return nullptr;
//      }
      //      bool wasBypassed = isBypassed();
      //      setBypassed( true );

      trackInfo.m_plugins

      if ( trackInfo.isAudioOnly() )
      {
         tc.m_audioEnd = audioInput;
      }
      else
      {
         if ( audioInput )
         {
            DE_ERROR("Got inputSignal and synthesizer, nothing connected (yet)")
         }

         tc.m_audioEnd = m_audioSynth;

         if ( !m_audioSynth )
         {
            DE_ERROR("No synthesizer to connect")
            m_audioEnd = m_audioInput;
         }
      }

      // Connect dsp chain
      for ( int i = 0; i < m_audioEffects.size(); ++i )
      {
         auto fx = m_audioEffects[ i ];
         fx->setInputSignal( 0, m_audioEnd );
         m_audioEnd = fx;
      }

      // setBypassed( wasBypassed );
   }

public:
   //void updateFromTrackInfo();
   void updateDspChain()
   {
      //      bool wasBypassed = isBypassed();
      //      setBypassed( true );

      if ( m_trackInfo.isAudioOnly() )
      {
         if ( m_audioSynth )
         {
            DE_ERROR("Error synthesizer found and bypassed")
         }

         m_audioEnd = m_audioInput;
      }
      else
      {
         if ( m_audioInput )
         {
            DE_ERROR("Got inputSignal and synthesizer, nothing connected (yet)")
         }

         m_audioEnd = m_audioSynth;

         if ( !m_audioSynth )
         {
            DE_ERROR("No synthesizer to connect")
            m_audioEnd = m_audioInput;
         }
      }

      // Connect dsp chain
      for ( int i = 0; i < m_audioEffects.size(); ++i )
      {
         auto fx = m_audioEffects[ i ];
         fx->setInputSignal( 0, m_audioEnd );
         m_audioEnd = fx;
      }

      // setBypassed( wasBypassed );
   }

// ============================================================================
struct Track : public IDspChainElement
// ============================================================================
{
   Track( App & app ); // , int id = -1, std::string name = "UnknownSpur", eTrackType type = eTrackTypeCount
   ~Track();

   int id() const { return m_trackInfo.id(); }
   bool isAudioOnly() const { return m_trackInfo.isAudioOnly(); }
   std::string const & name() const { return m_trackInfo.name(); }

   void clear();
   void setTrackInfo( TrackInfo const & trackInfo );

   IPlugin* addPlugin( std::wstring const & uri );
   IPlugin* addPlugin( PluginInfo const & plugin );
   bool addPlugin( IPlugin* plugin );

   void writeXML( tinyxml2::XMLDocument & doc, tinyxml2::XMLElement* parent ) const
   {
      m_trackInfo.writeXML( doc, parent );
   }
   bool readXML( int i, tinyxml2::XMLElement* track )
   {
      return m_trackInfo.readXML( i, track );
   }

//   Clips const & clips() const;
//   Clips & clips();
//   void addClip( Clip clip );
//   void addClip( double timeBeg, double timeEnd, std::string name = "Clip" );

   void sendNote( Note const & note ) override
   {
      //if ( isAudioOnly() ) return;
      if ( m_audioSynth )
      {
         m_audioSynth->sendNote( note );
      }
   }

   // IDspChainElement stuff
   bool isBypassed() const override { return m_trackInfo.m_isBypassed; }
   void setBypassed( bool bypassed ) override { m_trackInfo.m_isBypassed = bypassed; }

   void clearInputSignals() { m_audioInput = nullptr; }
   void setInputSignal( int i, IDspChainElement* input ) { m_audioInput = input; }

   void
   aboutToStart( uint32_t dstFrames, uint32_t dstChannels, uint32_t dstRate ) override
   {

   }

   uint64_t
   readSamples( double pts, float* dst, uint32_t dstFrames, uint32_t dstChannels, uint32_t dstRate ) override
   {
      if ( m_audioEnd )
      {
         return m_audioEnd->readSamples( pts, dst, dstFrames, dstChannels, dstRate );
      }
      else
      {
         uint64_t dstSamples = dstFrames * dstChannels;
         DSP_FILLZERO( dst, dstSamples );
         return dstSamples;
      }

   }
public:
   //void updateFromTrackInfo();
   void updateDspChain();

   DE_CREATE_LOGGER("Track")
   App & m_app;
   TrackInfo m_trackInfo;
//   // ---===--- Track XmlData ---===---
//   std::string m_name;
//   bool m_isBypassed;
//   bool m_ownedAndDeletedByQt;
//   eTrackType m_type; // 0 = master, 1 = return, 2 = audio-only, 3 = midi+audio
//   int m_id;      // 0 = master fx chain, 1+x = return A+x chains, 1000 + x = user audio only chains, 2000 + x = user midi + audio chains
//   int m_volume;
   //std::vector< PluginInfo > m_plugins; // Series of audio or midi or one synth effects.

   // ---===--- Track Network ---===---
   //MidiMeter* m_midiMeter;
   //std::vector< IMidiSpurElement* > m_midiFx;// the rest of the audio Spur is a series of effects.
   IDspChainElement* m_audioInput;
   IPlugin* m_audioSynth; // The linking element between MIDI and Audio Spur, either a Player or Synthesizer
   IDspChainElement* m_audioEnd;    // AudioSpurEnd, for convenience to auto-connect end with a mixer
   std::vector< IPlugin* > m_audioEffects; // Series of audio effects.
   //std::vector< LevelMeter > m_audioMeters;


};


*/
