/// (c) 2017 - 20180 Benjamin Hampe <benjaminhampe@gmx.de>

#ifndef DE_AUDIO_DSP_CHAININFO_HPP
#define DE_AUDIO_DSP_CHAININFO_HPP

#include <de/audio/dsp/IDspChainElement.hpp>
#include <de/audio/plugin/IPlugin.hpp>
//#include <de/audio/dsp/LevelMeter.hpp>

namespace de {
namespace audio {

// ============================================================================
struct InstrumentInfo
// ============================================================================
{
   DE_CREATE_LOGGER("InstrumentInfo")

   bool m_isAudioOnly; // false = All Midi and audio fx + Synth, true = Audio fx only, like master spur.
   bool m_isBypassed;

   std::vector< int > m_pluginIds;

   std::vector< DspPluginInfo > m_elements;
   int m_midiMeter;
   
   MidiMeter* m_midiMeter;
   //std::vector< IMidiChainElement* > m_midiEffects;// the rest of the audio chain is a series of effects.

   // IDspChainElement* m_inputSignal;
   // IPlugin* m_audioSynth; // The linking element between MIDI and Audio chain, either a Player or Synthesizer
   // IDspChainElement* m_audioEnd;    // AudioChainEnd, for convenience to auto-connect end with a mixer
   // std::vector< int > m_audioEffects;
   // //std::vector< LevelMeter > m_audioMeters;
public:
   DspChainInfo( bool bIsAudioOnly );
   ~DspChainInfo() override;
   bool isBypassed() const override { return m_isBypassed; }
   bool isAudioOnly() const { return m_isAudioOnly; }

   bool addPlugin( std::wstring uri );
   bool updateDspChain();


   void clearInputSignals() { m_inputSignal = nullptr; }
   void setInputSignal( int i, IDspChainElement* input )
   {
      m_inputSignal = input;
      updateDspChain();
   }

   void sendNote( Note const & note ) override
   {
      if ( m_audioSynth )
      {
         m_audioSynth->sendNote( note );
      }
   }

   void setBypassed( bool bypassed ) override { m_isBypassed = bypassed; }
   void aboutToStart( uint32_t dstFrames, uint32_t dstChannels, uint32_t dstRate ) override;
   uint64_t readSamples( double pts, float* dst, uint32_t dstFrames, uint32_t dstChannels, uint32_t dstRate ) override;
};

} // end namespace audio
} // end namespace de

#endif
