#include "PluginEditor.hpp"
#include "App.hpp"

#ifndef UNICODE
#define UNICODE
#endif

#ifndef WIN32_LEAN_AND_MEAN
#define WIN32_LEAN_AND_MEAN
#endif

#ifdef _WIN32_WINNT
#undef _WIN32_WINNT
#endif
#define _WIN32_WINNT 0x0600 // CreateEventEx() needs atleast this API version = WinXP or so.

#include <windows.h>
#include <synchapi.h>
#include <process.h>
#include <mmdeviceapi.h>
#include <audioclient.h>
//#include <commdlg.h>
//#include <QFileDialog>
//#define ASSERT_THROW(c,e) if(!(c)) { throw std::runtime_error(e); }
//#define CLOSE_HANDLE(x)   if((x)) { CloseHandle(x); x = nullptr; }
//#define RELEASE(x)        if((x)) { (x)->Release(); x = nullptr; }

PluginEditor::PluginEditor( App & app, QWidget* parent )
   : QWidget( parent )
   , m_app( app )
   , m_hasFocus( false )
   , m_isMinimized( false )
   , m_plugin( nullptr )
   , m_editorWindow( nullptr )
   , m_title("Plugin")
   , m_btnEnabled( nullptr )
   , m_btnMore( nullptr )
   , m_btnEditor( nullptr )
   , m_btnLoadPreset( nullptr )
   , m_btnSavePreset( nullptr )
{
   setObjectName( "PluginEditor" );
   setContentsMargins( 0,0,0,0 );
   setMinimumSize( 158 + 9, 190 );
   setMaximumSize( 158 + 9, 190 );

   m_editorWindow = new PluginEditorWindow( nullptr );
   m_editorWindow->hide();

   connect( m_editorWindow, SIGNAL(closed()), this, SLOT(on_editorClosed()), Qt::QueuedConnection );
//   m_editorWindow->show();
//   m_editorWindow->raise();
   // m_editorImage->setImage( m_editorWindow->grab().toImage().scaledToHeight( 128 ), true );
   // m_editorImage->setImagePreserveAspectWoH( true );
   //m_editorImage->show();

   m_btnEnabled = createEnableButton();
   m_btnMore = createMoreButton();
   m_btnEditor = createEditorButton();
   m_btnLoadPreset = createUpdateButton();
   m_btnSavePreset = createSaveButton();

   //m_audioMeter = new AudioMeter( m_app, this );
   m_levelMeter = new GLevelMeter( this );

   connect( m_btnEnabled, SIGNAL(toggled(bool)), this, SLOT(on_bypassed(bool)) );
   connect( m_btnMore, SIGNAL(toggled(bool)), this, SLOT(on_visibleMore(bool)) );
   connect( m_btnEditor, SIGNAL(toggled(bool)), this, SLOT(on_visibleEditor(bool)) );

#if 0 // #ifdef USE_BENNI_VST2x_HOST
   m_isLoaded = false;
   m_isDirty = true;
   m_isSynth = false;
   m_hasEditor = false;
   m_id = -1;
   m_volume = 100;
   m_sampleRate = 0;
   m_bufferFrames = 0;
   m_inputSignal = nullptr;
   m_dllHandle = 0; // HMODULE on Windows
   m_vst = nullptr;  // A real pointer to a C++ class
   m_framePos = 0;   // ?
#endif

   //aboutToStart( 64, 2, 48000 );

   updateLayout();
//   startUpdateTimer();
}

PluginEditor::~PluginEditor()
{
//   stopUpdateTimer();
   //closePlugin();
   if ( m_plugin )
   {
      delete m_plugin;
      m_plugin = nullptr;
   }
}

void PluginEditor::setPlugin( de::audio::IPlugin* plugin )
{
   if ( m_plugin )
   {
      delete m_plugin;
      m_plugin = nullptr;
   }

   m_plugin = plugin;
   updateFromPlugin();
}

void PluginEditor::updateFromPlugin()
{
   if ( m_plugin )
   {
      m_title = QString::fromStdWString( m_plugin->getName() );
   }

   updateLayout();
}

void
PluginEditor::updateLayout()
{
   int w = 17 + 9;
   int h = 190;

   if ( m_isMinimized )
   {
      setMinimumSize( QSize( w, h ) );
      setMaximumSize( QSize( w, h ) );
      m_rcPanel = QRect( 0,0,w - 9,h );
      m_rcMeter = QRect( w-1-9,0,9,h );
      m_rcHeader = m_rcPanel;
      //setWidgetBounds( m_audioMeter, m_rcMeter );
      setWidgetBounds( m_levelMeter, m_rcMeter );

      int x = 2;
      int y = 2;
      setWidgetBounds( m_btnEnabled, QRect( x,y,13,13 ) ); y += 16;
      setWidgetBounds( m_btnEditor, QRect( x,y,13,13 ) ); y += 16;
      setWidgetBounds( m_btnMore, QRect() );
      setWidgetBounds( m_btnLoadPreset, QRect() );
      setWidgetBounds( m_btnSavePreset, QRect() );
   }
   else
   {
      w = 158 + 9;
      setMinimumSize( QSize( w, h ) );
      setMaximumSize( QSize( w, h ) );
      m_rcMeter = QRect( w-1-9,0,9,h );
      //setWidgetBounds( m_audioMeter, m_rcMeter );
      setWidgetBounds( m_levelMeter, m_rcMeter );
      m_rcPanel = QRect( 0,0,w - 9,h );
      m_rcHeader = QRect( 0,0,w - 9,17 );

      int x = 2;
      int y = 2;
      setWidgetBounds( m_btnEnabled, QRect( x,y,13,13 ) ); x += 16;
      setWidgetBounds( m_btnMore, QRect( x,y,13,13 ) ); x += 16;
      setWidgetBounds( m_btnEditor, QRect( x,y,13,13 ) ); x += 16;

      x = 8;
      y = 22;
      setWidgetBounds( m_btnLoadPreset, QRect( x,y,13,13 ) ); x += 16;
      setWidgetBounds( m_btnSavePreset, QRect( x,y,13,13 ) ); x += 16;
   }

   update();
}

void
PluginEditor::resizeEvent( QResizeEvent* event )
{
   updateLayout();
   QWidget::resizeEvent( event );
}

void
PluginEditor::paintEvent( QPaintEvent* event )
{
   int w = width();
   int h = height();

   if ( w > 1 && h > 1 )
   {
      QPainter dc( this );
      dc.setRenderHint( QPainter::NonCosmeticDefaultPen );

      // Draw effect background
      //dc.fillRect( rect(), m_hasFocus ? skin.focusColor : skin.panelColor );

      LiveSkin const & skin = m_app.m_skin;
      int r = skin.getInt( LiveSkin::Radius );
      int th = m_rcHeader.height();

      dc.setPen( Qt::NoPen );

      // Draw big content rr
      dc.setBrush( QBrush( skin.contentColor ) );
      dc.drawRoundedRect( m_rcPanel, r, r );

      // Draw title rr with second border
      dc.setBrush( QBrush( skin.titleColor ) );

      dc.drawRoundedRect( QRect( m_rcPanel.x(),
                                 m_rcPanel.y(),
                                 m_rcPanel.width(),
                                 th + r ), r, r );

      // Draw straight rect over title for correction
      dc.setBrush( QBrush( skin.contentColor ) );
      dc.drawRect( QRect( m_rcPanel.x(),
                          m_rcPanel.y() + th,
                          m_rcPanel.width(),
                          2*r ) );

      dc.setBrush( QBrush( skin.symbolColor ) );
      dc.drawRoundedRect( QRect( m_rcPanel.x() + 9,
                                 m_rcPanel.y() + th + 25,
                                 140, 120 ), r,r );

      m_font5x8.drawText( dc, 53,5, m_title, skin.symbolColor );

      dc.end();
   }

   QWidget::paintEvent( event );
}

void
PluginEditor::mouseDoubleClickEvent( QMouseEvent* event )
{
//   int mx = event->x();
//   int my = event->y();

//   if ( isMouseOverRect( mx, my, m_rcHeader ) )
//   {
//      m_isMinimized = !m_isMinimized;
//      updateLayout();
//      if ( m_plugin )
//      {
//         m_spur->updateLayout();
//      }
//   }

   QWidget::mouseDoubleClickEvent( event );
}

/*

void
PluginEditor::mouseReleaseEvent( QMouseEvent* event )
{
   //   int mx = event->x();
   //   int my = event->y();

   if ( m_dragMode > 0 )
   {
      if ( m_dragMode == 1 )
      {
      }

      updateLayout();
      m_dragMode = 0;
   }

   QWidget::mouseReleaseEvent( event );
}
void
PluginEditor::mousePressEvent( QMouseEvent* event )
{
   int mx = event->x();
   int my = event->y();

   if ( m_dragMode > 0 )
   {

   }
   else
   {
      if ( m_app.m_isDetailVisible && m_app.m_isClipEditorVisible )
      {
         if ( m_isOverSplitV )
         {
            m_dragMode = 1;
            m_dragData = m_app.m_vsplitterPos; // Store original pos.
            //m_app.m_dragData = m_app.m_rcV.y(); // Store original pos.
            m_dragStartX = mx;
            m_dragStartY = my;
            updateLayout();
         }
      }
   }

   QWidget::mousePressEvent( event );
}


void
PluginEditor::mouseMoveEvent( QMouseEvent* event )
{
   int mx = event->x();
   int my = event->y();

   // === Find hover splitter ===
   m_isOverSplitV = isMouseOverRect( mx, my, m_rcV );
   //m_app.m_isOverSplitH = isMouseOverRect( mx, my, m_app.m_rc1Splitter );

   if ( m_app.m_isDetailVisible && m_app.m_isClipEditorVisible )
   {
      // === Update layout when splitting v ===
      if ( m_dragMode == 1 ) // vsplit
      {
         m_app.m_vsplitterPos = m_dragData - (my - m_dragStartY);
         int y1 = m_rcHeader.y() + m_rcHeader.height();
         int y2 = m_rcFooter.y();
         if ( m_app.m_vsplitterPos < y1 )
         {
            m_app.m_vsplitterPos = y1;
         }
         else if ( m_app.m_vsplitterPos > y2 )
         {
            m_app.m_vsplitterPos = y2;
         }

         updateLayout();
      }
   }


   QWidget::mouseMoveEvent( event );
}




void
PluginEditor::wheelEvent( QWheelEvent* event )
{
   //   int mx = event->x();
   //   int my = event->y();
   //   me.m_wheelY = event->angleDelta().y();
   //   if ( me.m_wheelX != 0.0f )
   //   {
   //      me.m_flags |= de::MouseEvent::WheelX;
   //   }
   //   if ( me.m_wheelY != 0.0f )
   //   {
   //      me.m_flags |= de::MouseEvent::WheelY;
   //   }

   QWidget::wheelEvent( event );
}

void
PluginEditor::keyPressEvent( QKeyEvent* event )
{
   //DE_DEBUG("KeyPress(",event->key(),")")
   QWidget::keyPressEvent( event );
}

void
PluginEditor::keyReleaseEvent( QKeyEvent* event )
{
   //DE_DEBUG("KeyRelease(",event->key(),")")
   QWidget::keyReleaseEvent( event );
}
*/

void
PluginEditor::on_focusChanged( bool focused )
{
   m_hasFocus = focused;
   update();
}

void
PluginEditor::on_bypassed( bool bypassed )
{
   //m_isBypassed = checked;
}

void
PluginEditor::on_visibleMore( bool checked )
{
   //m_qpeak->setVisible( checked );
   //m_volume->setVisible( checked );
}

void
PluginEditor::on_visibleEditor( bool checked )
{
   if ( m_editorWindow )
   {
      if ( checked )
      {
         m_editorWindow->show();
      }
      else
      {
         m_editorWindow->hide();
      }
   }

}

void
PluginEditor::on_editorClosed()
{
   DE_ERROR("Editor closed")
   if ( m_btnEditor )
   {
      m_btnEditor->blockSignals( true );
      m_btnEditor->setChecked( false );
      m_btnEditor->blockSignals( false );
   }
}

void
PluginEditor::resizeEditor( QRect const & pos )
{
   if ( m_editorWindow )
   {
      m_editorWindow->setMinimumSize( pos.width(), pos.height() );
      m_editorWindow->setMaximumSize( pos.width(), pos.height() );
      m_editorWindow->move( pos.x(), pos.y() );
   }
}


ImageButton*
PluginEditor::createEnableButton()
{
   auto btn = new ImageButton( this );
   btn->setToolTip("This DSP element is now (e)nabled = not bypassed");

   LiveSkin const & skin = m_app.m_skin;

   int b = 13;

   btn->setCheckable( true );
   btn->setChecked( true );

   auto symColor = skin.symbolColor;
   auto bgColor = skin.windowColor;
   auto fgColor = skin.panelColor; // or panelColor

   //QFont font = getFontAwesome( 14 );
   std::string
   msg = "  #####\n"
         " #     #\n"
         "#       #\n"
         "#   #   #\n"
         "#   #   #\n"
         "#   #   #\n"
         "#       #\n"
         " #     #\n"
         "  #####\n";

   // [idle]
   QImage ico = createAsciiArt( symColor, fgColor, msg );
   QImage img = createCircleImage( b,b, bgColor, fgColor, ico );
   btn->setImage( 0, img );
   // [idle_hover]
   btn->setImage( 1, img );

   // [active]
   ico = createAsciiArt( skin.activeColor, fgColor, msg );
   img = createCircleImage( b,b, bgColor, fgColor, ico );
   btn->setImage( 2, img );
   // [active_hover]
   btn->setImage( 3, img );

   return btn;
}

ImageButton*
PluginEditor::createMoreButton()
{
   auto btn = new ImageButton( this );
   btn->setToolTip("All DSP options are visible now");

   LiveSkin const & skin = m_app.m_skin;
   int b = 13;

   btn->setCheckable( true );
   btn->setChecked( false );

   auto symColor = skin.symbolColor;
   auto bgColor = skin.windowColor;
   auto fgColor = skin.panelColor; // or panelColor

   //QFont font = getFontAwesome( 14 );
   std::string
   msg = "#######\n"
         " #####\n"
         " #####\n"
         "  ###\n"
         "  ###\n"
         "   #\n"
         "   #\n";
   // [idle]
   QImage ico = createAsciiArt( symColor, fgColor, msg );
   QImage img = createCircleImage( b,b, bgColor, fgColor, ico );
   btn->setImage( 0, img );
   // [idle_hover]
   btn->setImage( 1, img );

   // [active]
   msg = "#\n"
         "###\n"
         "#####\n"
         "#######\n"
         "#####\n"
         "###\n"
         "#\n";
   ico = createAsciiArt( skin.activeColor, fgColor, msg );
   img = createCircleImage( b,b, bgColor, fgColor, ico );
   btn->setImage( 2, img );
   // [active_hover]
   btn->setImage( 3, img );

   return btn;
}


ImageButton*
PluginEditor::createEditorButton()
{
   auto btn = new ImageButton( this );
   LiveSkin const & skin = m_app.m_skin;
   int b = 13;

   btn->setCheckable( true );
   btn->setChecked( false );

   auto symColor = skin.symbolColor;
   auto bgColor = skin.windowColor;
   auto fgColor = skin.panelColor; // or panelColor

   //QFont font = getFontAwesome( 14 );
   std::string
   msg = "# #####\n"
         " \n"
         "# #####\n"
         " \n"
         "# #####\n";

   // [idle]
   QImage ico = createAsciiArt( symColor, fgColor, msg );
   QImage img = createCircleImage( b,b, bgColor, fgColor, ico );
   btn->setImage( 0, img );
   // [idle_hover]
   btn->setImage( 1, img );

   // [active]
   ico = createAsciiArt( skin.activeColor, fgColor, msg );
   img = createCircleImage( b,b, bgColor, fgColor, ico );
   btn->setImage( 2, img );
   // [active_hover]
   btn->setImage( 3, img );

   return btn;
}

ImageButton*
PluginEditor::createUpdateButton()
{
   auto btn = new ImageButton( this );
   LiveSkin const & skin = m_app.m_skin;
   int b = 13;

   btn->setCheckable( true );
   btn->setChecked( false );

   auto symColor = skin.symbolColor;
   auto bgColor = skin.windowColor;
   auto fgColor = skin.panelColor; // or panelColor

   //QFont font = getFontAwesome( 14 );
   std::string
   msg = "   ##\n"
         "  #\n"
         " #     #\n"
         "###   ###\n"
         " #     #\n"
         "      #\n"
         "    ##\n";

   // [idle]
   QImage ico = createAsciiArt( symColor, fgColor, msg );
   QImage img = createCircleImage( b,b, bgColor, fgColor, ico );
   btn->setImage( 0, img );
   // [idle_hover]
   btn->setImage( 1, img );

   // [active]
   ico = createAsciiArt( skin.activeColor, fgColor, msg );
   img = createCircleImage( b,b, bgColor, fgColor, ico );
   btn->setImage( 2, img );
   // [active_hover]
   btn->setImage( 3, img );

   return btn;
}


ImageButton*
PluginEditor::createSaveButton()
{
   auto btn = new ImageButton( this );
   LiveSkin const & skin = m_app.m_skin;
   int b = 13;

   btn->setCheckable( true );
   btn->setChecked( false );

   auto symColor = skin.symbolColor;
   auto bgColor = skin.windowColor;
   auto fgColor = skin.panelColor; // or panelColor

   //QFont font = getFontAwesome( 14 );
   std::string
   msg = "######\n"
         "##   ##\n"
         "##   ##\n"
         "#######\n"
         "#######\n"
         "#######\n"
         "#######\n";

   // [idle]
   QImage ico = createAsciiArt( symColor, fgColor, msg );
   QImage img = createCircleImage( b,b, bgColor, fgColor, ico );
   btn->setImage( 0, img );
   // [idle_hover]
   btn->setImage( 1, img );

   // [active]
   ico = createAsciiArt( skin.activeColor, fgColor, msg );
   img = createCircleImage( b,b, bgColor, fgColor, ico );
   btn->setImage( 2, img );
   // [active_hover]
   btn->setImage( 3, img );

   return btn;
}

