#ifndef DE_LIVE_SPUR_CONTENT_STACK_HPP
#define DE_LIVE_SPUR_CONTENT_STACK_HPP

#include "Track.hpp"
#include <de/audio/dsp/Mixer.hpp>
#include <QMimeData>
#include <QStackedWidget>

struct App;

typedef std::vector< Track* > TrackList;

// ============================================================================
class TrackManager : public QWidget
// ============================================================================
{
   Q_OBJECT
   DE_CREATE_LOGGER("TrackManager")
   App & m_app;
   bool m_isBypassed;
   int m_currentTrackId;


   TrackList m_tracks; // all return tracks

   Track* m_master;                 // fix non user track
   TrackList m_returns; // all return tracks
   TrackList m_user;    // all user tracks ( 1 Audio + 1 Midi )
   TrackList m_userAudio; // all user tracks ( 1 Audio + 1 Midi )
   TrackList m_userMidi; // all user tracks ( 1 Audio + 1 Midi )

   QStackedWidget* m_stack; // all tracks
   //IDspChainElement* m_inputSignal;
   de::audio::Mixer m_userMixer;
   de::audio::Mixer m_returnMixer;

public:
   TrackManager( App & app, QWidget* parent = 0 );
   ~TrackManager() override;

   //std::string const & uri() const { return m_uri; }
   Track* master() { return m_master; }
   int currentTrackId() const { return m_currentTrackId; }

   Track const* currentTrack() const { return m_currentTrackId > -1 ? m_tracks[ m_currentTrackId ] : nullptr; }
   Track* currentTrack() { return m_currentTrackId > -1 ? m_tracks[ m_currentTrackId ] : nullptr; }

   size_t size() const { return m_tracks.size(); }

   typedef TrackList::const_iterator const_iterator;
   const_iterator begin() const { return m_tracks.begin(); }
   const_iterator end() const { return m_tracks.end(); }

   typedef TrackList::iterator iterator;
   iterator begin() { return m_tracks.begin(); }
   iterator end() { return m_tracks.end(); }

   bool
   hasTrack( int trackId ) const
   {
      return findTrack( trackId ) > -1;
   }

   Track*
   getTrack( int trackId )
   {
      int found = findTrack( trackId );
      if ( found > -1 )
      {
         return m_tracks[ found ];
      }

      return nullptr;
   }

   int
   findTrack( int trackId ) const
   {
      for ( size_t i = 0; i < m_tracks.size(); ++i )
      {
         auto p = m_tracks[ i ];
         if ( p && p->trackId() == trackId ) { return i; }
      }

      return -1;
   }

signals:
   void currentTrackIdChanged( int trackId );
   void currentTrackChanged( Track* track );

public slots:
   void setCurrentTrackId( int trackId );

   void clear();
//   bool addTrack( int id = -1, std::string name = "UnnamedTrack", eTrackType type = eTrackTypeCount );
//   bool addTrack( Track* Track );
//   void updateDspChain();

   //IPlugin* addPlugin( std::wstring uri );

   void sendNote( de::audio::Note const & note )
   {
      for ( auto track : m_userMidi )
      {
         if ( track ) track->sendNote( note );
      }
   }

//   void setUri( std::string const & uri ) { m_uri = uri; }
//   bool load();
//   bool save() const;

protected slots:
   void on_currentTrackIdChanged( int index );
   //void on_currentTrackChanged( Track* track );
/*
   void dropEvent( QDropEvent* event ) override;

   bool hasFocus() const { return m_hasFocus; }
   int getPluginCount() const { return m_plugins.size(); }

   void updateLayout();
   //void updateDspChain();
   void resizeEvent( QResizeEvent* event ) override;
   void paintEvent( QPaintEvent* event ) override;

   void enterEvent( QEvent* event ) override;
   void leaveEvent( QEvent* event ) override;
   void focusInEvent( QFocusEvent* event ) override;
   void focusOutEvent( QFocusEvent* event ) override;

   void dragEnterEvent( QDragEnterEvent* event ) override;
   void dragLeaveEvent( QDragLeaveEvent* event ) override;
   void dragMoveEvent(QDragMoveEvent* event ) override;
*/

private:
};

#endif // DE_Q_IMAGEWIDGET_HPP
