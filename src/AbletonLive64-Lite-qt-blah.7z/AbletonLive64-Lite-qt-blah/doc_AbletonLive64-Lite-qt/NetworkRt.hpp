/// (c) 2017 - 20180 Benjamin Hampe <benjaminhampe@gmx.de>

#ifndef DE_AUDIO_DSP_PLUGINCHAIN_SPUR_HPP
#define DE_AUDIO_DSP_PLUGINCHAIN_SPUR_HPP

#include <de/audio/dsp/IDspChainElement.hpp>
#include <de/audio/plugin/IPlugin.hpp>
//#include <de/audio/dsp/LevelMeter.hpp>

namespace de {
namespace audio {

// A PluginContainer is a linear DSP chain of midiFxs, one midi2audio synthesizer and audioFxs.
// + <optional> 1 MidiInputMeter signalling any MIDI input ( not for audio-only )
// + <optional> Chain of MidiFx = 1x MidiPlugin + 1x MidiMeter
// + <optional> 1 synthesizer = ( 1x IPlugin + 1x LevelMeter ), gets replaced with next synth added.
// + <optional> Linear chain of effects each adding ( 1x IPlugin + 1x LevelMeter )

// ============================================================================
struct LiveInstrument : public IDspChainElement
// ============================================================================
{
   DE_CREATE_LOGGER("LiveInstrument")
   bool m_isAudioOnly; // false = All Midi and audio fx + Synth, true = Audio fx only, like master spur.
   bool m_isBypassed;

   std::vector< int > m_pluginIds;

   //MidiMeter* m_midiMeter;
   //std::vector< IMidiChainElement* > m_midiEffects;// the rest of the audio chain is a series of effects.

   // IDspChainElement* m_inputSignal;
   // IPlugin* m_audioSynth; // The linking element between MIDI and Audio chain, either a Player or Synthesizer
   // IDspChainElement* m_audioEnd;    // AudioChainEnd, for convenience to auto-connect end with a mixer
   // std::vector< int > m_audioEffects;
   // //std::vector< LevelMeter > m_audioMeters;
public:
   LiveInstrument( bool bIsAudioOnly );
   ~LiveInstrument() override;
   bool isBypassed() const override { return m_isBypassed; }
   bool isAudioOnly() const { return m_isAudioOnly; }

   bool addPlugin( std::wstring uri );
   bool updateDspChain();


   void clearInputSignals() { m_inputSignal = nullptr; }
   void setInputSignal( int i, IDspChainElement* input )
   {
      m_inputSignal = input;
      updateDspChain();
   }

   void sendNote( Note const & note ) override
   {
      if ( m_audioSynth )
      {
         m_audioSynth->sendNote( note );
      }
   }

   void setBypassed( bool bypassed ) override { m_isBypassed = bypassed; }
   void aboutToStart( uint32_t dstFrames, uint32_t dstChannels, uint32_t dstRate ) override;
   uint64_t readSamples( double pts, float* dst, uint32_t dstFrames, uint32_t dstChannels, uint32_t dstRate ) override;
};

} // end namespace audio
} // end namespace de

#endif
