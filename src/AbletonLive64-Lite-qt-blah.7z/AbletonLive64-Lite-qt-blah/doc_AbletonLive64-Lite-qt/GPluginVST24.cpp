#include "PluginVST24.hpp"
#include "App.hpp"

#ifndef UNICODE
#define UNICODE
#endif

#ifndef WIN32_LEAN_AND_MEAN
#define WIN32_LEAN_AND_MEAN
#endif

#ifdef _WIN32_WINNT
#undef _WIN32_WINNT
#endif
#define _WIN32_WINNT 0x0600 // CreateEventEx() needs atleast this API version = WinXP or so.

#include <windows.h>
#include <synchapi.h>
#include <process.h>
#include <mmdeviceapi.h>
#include <audioclient.h>
//#include <commdlg.h>
//#include <QFileDialog>
//#define ASSERT_THROW(c,e) if(!(c)) { throw std::runtime_error(e); }
//#define CLOSE_HANDLE(x)   if((x)) { CloseHandle(x); x = nullptr; }
//#define RELEASE(x)        if((x)) { (x)->Release(); x = nullptr; }

PluginVST24::PluginVST24( App & app, Spur* parent )
   : QWidget( parent )
   , m_app( app )
   , m_spur( parent )
   , m_title("Plugin")
   , m_btnEnabled( nullptr )
   , m_btnMore( nullptr )
   , m_btnEditor( nullptr )
   , m_btnLoadPreset( nullptr )
   , m_btnSavePreset( nullptr )
{
   setObjectName( "PluginVST24" );
   setContentsMargins( 0,0,0,0 );
   setMinimumSize( 158 + 9, 190 );
   setMaximumSize( 158 + 9, 190 );

   m_editorWindow = new PluginVST24_EditorWindow( nullptr );
   m_editorWindow->hide();
   connect( m_editorWindow, SIGNAL(closed()), this, SLOT(on_editorClosed()), Qt::QueuedConnection );
//   m_editorWindow->show();
//   m_editorWindow->raise();
   // m_editorImage->setImage( m_editorWindow->grab().toImage().scaledToHeight( 128 ), true );
   // m_editorImage->setImagePreserveAspectWoH( true );
   //m_editorImage->show();

   // LevelMeter:
//   m_updateTimerId = 0;
//   m_Lmin = m_Lmax = m_Rmin = m_Rmax = 0.0f;
//   m_colorGradient.addStop( 0.0f, 0xFFFFFFFF );
//   m_colorGradient.addStop( 0.1f, 0xFF000000 );
//   m_colorGradient.addStop( 0.5f, 0xFF00FF00 );
//   m_colorGradient.addStop( 0.6f, 0xFF002000 );
//   m_colorGradient.addStop( 0.8f, 0xFF00FFFF );
//   m_colorGradient.addStop( 1.0f, 0xFF0000FF );
//   m_colorGradient.addStop( 1.1f, 0xFFFF00FF );

   m_hasFocus = false;
   m_isMinimized = false;
   m_btnEnabled = createEnableButton();
   m_btnMore = createMoreButton();
   m_btnEditor = createEditorButton();
   m_btnLoadPreset = createUpdateButton();
   m_btnSavePreset = createSaveButton();

   //m_audioMeter = new AudioMeter( m_app, this );
   m_levelMeter = new GLevelMeter( this );

   connect( m_btnEnabled, SIGNAL(toggled(bool)), this, SLOT(on_bypassed(bool)) );
   connect( m_btnMore, SIGNAL(toggled(bool)), this, SLOT(on_visibleMore(bool)) );
   connect( m_btnEditor, SIGNAL(toggled(bool)), this, SLOT(on_visibleEditor(bool)) );

// #ifdef USE_BENNI_VST2x_HOST
   m_isLoaded = false;
   m_isDirty = true;
   m_isSynth = false;
   m_hasEditor = false;
   m_id = -1;
   m_volume = 100;
   m_sampleRate = 0;
   m_bufferFrames = 0;
   m_inputSignal = nullptr;
   m_editorWindow = nullptr;
   m_dllHandle = 0; // HMODULE on Windows
   m_vst = nullptr;  // A real pointer to a C++ class
   m_framePos = 0;   // ?
// #endif

   aboutToStart( 64, 2, 48000 );

   updateLayout();
//   startUpdateTimer();
}

PluginVST24::~PluginVST24()
{
//   stopUpdateTimer();
   closePlugin();
}

void PluginVST24::setBypassed( bool bypassed )
{
   m_btnEnabled->blockSignals( true );
   m_btnEnabled->setChecked( !bypassed );
   m_btnEnabled->blockSignals( false );
}

void PluginVST24::setVisibleMore( bool visible )
{
   m_btnMore->setChecked( visible );
}

void PluginVST24::setVisibleEditor( bool visible )
{
   m_btnEditor->setChecked( visible );
}


//void PluginVST24::stopUpdateTimer()
//{
//   if ( m_updateTimerId )
//   {
//      killTimer( m_updateTimerId );
//      m_updateTimerId = 0;
//   }
//}

//void PluginVST24::startUpdateTimer()
//{
//   stopUpdateTimer();
//   m_updateTimerId = startTimer( 37, Qt::CoarseTimer );
//}

//QSize
//PluginVST24::sizeHint() const
//{
//   if ( m_isMinimized )
//   {
//      return QSize( 23, 190 );
//   }
//   else
//   {
//      return QSize( 159 + 8, 190 );
//   }
//}

void
PluginVST24::updateLayout()
{
   int w = 17 + 9;
   int h = 190;

   if ( m_isMinimized )
   {
      setMinimumSize( QSize( w, h ) );
      setMaximumSize( QSize( w, h ) );
      m_rcPanel = QRect( 0,0,w - 9,h );
      m_rcMeter = QRect( w-1-9,0,9,h );
      m_rcHeader = m_rcPanel;
      //setWidgetBounds( m_audioMeter, m_rcMeter );
      setWidgetBounds( m_levelMeter, m_rcMeter );

      int x = 2;
      int y = 2;
      setWidgetBounds( m_btnEnabled, QRect( x,y,13,13 ) ); y += 16;
      setWidgetBounds( m_btnEditor, QRect( x,y,13,13 ) ); y += 16;
      setWidgetBounds( m_btnMore, QRect() );
      setWidgetBounds( m_btnLoadPreset, QRect() );
      setWidgetBounds( m_btnSavePreset, QRect() );
   }
   else
   {
      w = 158 + 9;
      setMinimumSize( QSize( w, h ) );
      setMaximumSize( QSize( w, h ) );
      m_rcMeter = QRect( w-1-9,0,9,h );
      //setWidgetBounds( m_audioMeter, m_rcMeter );
      setWidgetBounds( m_levelMeter, m_rcMeter );
      m_rcPanel = QRect( 0,0,w - 9,h );
      m_rcHeader = QRect( 0,0,w - 9,17 );

      int x = 2;
      int y = 2;
      setWidgetBounds( m_btnEnabled, QRect( x,y,13,13 ) ); x += 16;
      setWidgetBounds( m_btnMore, QRect( x,y,13,13 ) ); x += 16;
      setWidgetBounds( m_btnEditor, QRect( x,y,13,13 ) ); x += 16;

      x = 8;
      y = 22;
      setWidgetBounds( m_btnLoadPreset, QRect( x,y,13,13 ) ); x += 16;
      setWidgetBounds( m_btnSavePreset, QRect( x,y,13,13 ) ); x += 16;
   }

   update();
}

void
PluginVST24::resizeEvent( QResizeEvent* event )
{
   updateLayout();
   QWidget::resizeEvent( event );
}

void
PluginVST24::paintEvent( QPaintEvent* event )
{
   int w = width();
   int h = height();

   if ( w > 1 && h > 1 )
   {
      QPainter dc( this );
      dc.setRenderHint( QPainter::NonCosmeticDefaultPen );

      // Draw effect background
      //dc.fillRect( rect(), m_hasFocus ? skin.focusColor : skin.panelColor );

      LiveSkin const & skin = m_app.m_skin;
      int r = skin.getInt( LiveSkin::Radius );
      int th = m_rcHeader.height();

      dc.setPen( Qt::NoPen );

      // Draw big content rr
      dc.setBrush( QBrush( skin.contentColor ) );
      dc.drawRoundedRect( m_rcPanel, r, r );

      // Draw title rr with second border
      dc.setBrush( QBrush( skin.titleColor ) );

      dc.drawRoundedRect( QRect( m_rcPanel.x(),
                                 m_rcPanel.y(),
                                 m_rcPanel.width(),
                                 th + r ), r, r );

      // Draw straight rect over title for correction
      dc.setBrush( QBrush( skin.contentColor ) );
      dc.drawRect( QRect( m_rcPanel.x(),
                          m_rcPanel.y() + th,
                          m_rcPanel.width(),
                          2*r ) );

      dc.setBrush( QBrush( skin.symbolColor ) );
      dc.drawRoundedRect( QRect( m_rcPanel.x() + 9,
                                 m_rcPanel.y() + th + 25,
                                 140, 120 ), r,r );

      m_font5x8.drawText( dc, 53,5, m_title, skin.symbolColor );

      dc.end();
   }

   QWidget::paintEvent( event );
}

void
PluginVST24::mouseDoubleClickEvent( QMouseEvent* event )
{
   int mx = event->x();
   int my = event->y();

   if ( isMouseOverRect( mx, my, m_rcHeader ) )
   {
      m_isMinimized = !m_isMinimized;
      updateLayout();
      if ( m_spur )
      {
         m_spur->updateLayout();
      }
   }

   QWidget::mouseDoubleClickEvent( event );
}

/*

void
PluginVST24::mouseReleaseEvent( QMouseEvent* event )
{
   //   int mx = event->x();
   //   int my = event->y();

   if ( m_dragMode > 0 )
   {
      if ( m_dragMode == 1 )
      {
      }

      updateLayout();
      m_dragMode = 0;
   }

   QWidget::mouseReleaseEvent( event );
}
void
PluginVST24::mousePressEvent( QMouseEvent* event )
{
   int mx = event->x();
   int my = event->y();

   if ( m_dragMode > 0 )
   {

   }
   else
   {
      if ( m_app.m_isDetailVisible && m_app.m_isClipEditorVisible )
      {
         if ( m_isOverSplitV )
         {
            m_dragMode = 1;
            m_dragData = m_app.m_vsplitterPos; // Store original pos.
            //m_app.m_dragData = m_app.m_rcV.y(); // Store original pos.
            m_dragStartX = mx;
            m_dragStartY = my;
            updateLayout();
         }
      }
   }

   QWidget::mousePressEvent( event );
}


void
PluginVST24::mouseMoveEvent( QMouseEvent* event )
{
   int mx = event->x();
   int my = event->y();

   // === Find hover splitter ===
   m_isOverSplitV = isMouseOverRect( mx, my, m_rcV );
   //m_app.m_isOverSplitH = isMouseOverRect( mx, my, m_app.m_rc1Splitter );

   if ( m_app.m_isDetailVisible && m_app.m_isClipEditorVisible )
   {
      // === Update layout when splitting v ===
      if ( m_dragMode == 1 ) // vsplit
      {
         m_app.m_vsplitterPos = m_dragData - (my - m_dragStartY);
         int y1 = m_rcHeader.y() + m_rcHeader.height();
         int y2 = m_rcFooter.y();
         if ( m_app.m_vsplitterPos < y1 )
         {
            m_app.m_vsplitterPos = y1;
         }
         else if ( m_app.m_vsplitterPos > y2 )
         {
            m_app.m_vsplitterPos = y2;
         }

         updateLayout();
      }
   }


   QWidget::mouseMoveEvent( event );
}




void
PluginVST24::wheelEvent( QWheelEvent* event )
{
   //   int mx = event->x();
   //   int my = event->y();
   //   me.m_wheelY = event->angleDelta().y();
   //   if ( me.m_wheelX != 0.0f )
   //   {
   //      me.m_flags |= de::MouseEvent::WheelX;
   //   }
   //   if ( me.m_wheelY != 0.0f )
   //   {
   //      me.m_flags |= de::MouseEvent::WheelY;
   //   }

   QWidget::wheelEvent( event );
}

void
PluginVST24::keyPressEvent( QKeyEvent* event )
{
   //DE_DEBUG("KeyPress(",event->key(),")")
   QWidget::keyPressEvent( event );
}

void
PluginVST24::keyReleaseEvent( QKeyEvent* event )
{
   //DE_DEBUG("KeyRelease(",event->key(),")")
   QWidget::keyReleaseEvent( event );
}
*/

void
PluginVST24::on_focusChanged( bool focused )
{
   m_hasFocus = focused;
   update();
}

void
PluginVST24::on_bypassed( bool bypassed )
{
   //m_isBypassed = checked;
}

void
PluginVST24::on_visibleMore( bool checked )
{
   //m_qpeak->setVisible( checked );
   //m_volume->setVisible( checked );
}

void
PluginVST24::on_visibleEditor( bool checked )
{
   if ( m_editorWindow )
   {
      if ( checked )
      {
         m_editorWindow->show();
      }
      else
      {
         m_editorWindow->hide();
      }
   }

}

void
PluginVST24::on_editorClosed()
{
   DE_ERROR("Editor closed")
   if ( m_btnEditor )
   {
      m_btnEditor->blockSignals( true );
      m_btnEditor->setChecked( false );
      m_btnEditor->blockSignals( false );
   }
}

void
PluginVST24::resizeEditor( QRect const & pos )
{
   if ( m_editorWindow )
   {
      m_editorWindow->setMinimumSize( pos.width(), pos.height() );
      m_editorWindow->setMaximumSize( pos.width(), pos.height() );
      m_editorWindow->move( pos.x(), pos.y() );
   }
}

bool
PluginVST24::openPlugin()
{
   if ( m_isLoaded )
   {
      std::wcout << "PluginVST24 already loaded, " << m_uri << std::endl;
      closePlugin();
   }

   if ( m_uri.empty() )
   {
      std::wcout << "PluginVST24 empty filename" << std::endl;
      return false;
   }

   // Plugin needs path/directory of itself
   {
      wchar_t buf[ MAX_PATH + 1 ] {};
      wchar_t* namePtr = nullptr;
      auto const r = GetFullPathName( m_uri.c_str(), _countof(buf), buf, &namePtr );
      if ( r && namePtr )
      {
         *namePtr = 0;
         char mbBuf[ _countof(buf) * 4 ] {};
         if ( auto s = WideCharToMultiByte(CP_OEMCP, 0, buf, -1, mbBuf, sizeof(mbBuf), 0, 0) )
         {
            m_directoryMultiByte = mbBuf;
         }
      }
   }

   HMODULE dll = reinterpret_cast< HMODULE >( m_dllHandle );
   dll = LoadLibrary( m_uri.c_str() );
   if ( !dll )
   {
      std::wcout << "Can't open VST DLL " << m_uri << std::endl;
      return false;
   }

   typedef AEffect* (VstEntryProc)(audioMasterCallback);
   auto* entryProc = reinterpret_cast< VstEntryProc* >( GetProcAddress(dll, "VSTPluginMain") );
   if ( !entryProc )
   {
      entryProc = reinterpret_cast< VstEntryProc* >( GetProcAddress(dll, "main") );
   }
   if ( !entryProc )
   {
      std::wcout << "No VST entry point found, " << m_uri << std::endl;
      return false;
   }

   m_dllHandle = uint64_t( dll );
   m_vst = entryProc( hostCallback_static );
   if ( !m_vst )
   {
      std::wcout << "Not a VST plugin I, " << m_uri << std::endl;
      return false;
   }

   if ( m_vst->magic != kEffectMagic )
   {
      std::wcout << "Not a VST plugin with kEffectMagic, " << m_uri << std::endl;
      return false;
   }

   m_vst->user = this;

   m_title = QString::fromStdWString( de::FileSystem::fileBase( m_uri ) );

   m_isSynth = getFlags( effFlagsIsSynth );

   m_hasEditor = getFlags( effFlagsHasEditor );

   std::wcout << "VST open plugin '" << m_uri << "'" << std::endl;
   std::cout << "VST directoryMB '" << m_directoryMultiByte << "'" << std::endl;
   std::cout << "VST plugin is synth = " << m_isSynth << std::endl;
   std::cout << "VST plugin has editor = " << m_hasEditor << std::endl;
   std::cout << "VST plugin programCount = " << numPrograms() << std::endl;
   std::cout << "VST plugin parameterCount = " << numParams() << std::endl;
   std::cout << "VST plugin inputCount = " << numInputs() << std::endl;
   std::cout << "VST plugin outputCount = " << numOutputs() << std::endl;
   std::cout << "VST plugin can float replacing = " << getFlags( effFlagsCanReplacing ) << std::endl;
   std::cout << "VST plugin can double replacing = " << getFlags( effFlagsCanDoubleReplacing ) << std::endl;
   std::cout << "VST plugin has program chunks = " << getFlags( effFlagsProgramChunks ) << std::endl;

//   m_inBuffer.resize( m_vst->numInputs * getBlockSize() );
//   for( int i = 0; i < m_vst->numInputs; ++i )
//   {
//      m_inBufferHeads.push_back( &m_inBuffer[ i * getBlockSize() ] );
//   }

//   m_outBuffer.resize( m_vst->numOutputs * getBlockSize() );
//   for( int i = 0; i < m_vst->numOutputs; ++i )
//   {
//      m_outBufferHeads.push_back( &m_outBuffer[ i * getBlockSize() ] );
//   }

   std::cout << "VST plugin uses " << m_bufferFrames << " frames per channel." << std::endl;

   dispatcher(effOpen);

   m_isDirty = true;
   aboutToStart(64, 2, 48000);

   if( hasEditor() )
   {
      m_editorWindow = new PluginVST24_EditorWindow( nullptr );
      m_editorWindow->hide();
      connect( m_editorWindow, SIGNAL(closed()), this, SLOT(on_editorClosed()), Qt::QueuedConnection );
      dispatcher(effEditOpen, 0, 0, (void*)m_editorWindow->winId() );
      ERect* erc = nullptr;
      dispatcher(effEditGetRect, 0, 0, &erc);
      int x = erc->left;
      int y = erc->top;
      int w = erc->right - x;
      int h = erc->bottom - y;
      resizeEditor( QRect( x,y,w,h ) );
      m_editorWindow->show();
      m_editorWindow->raise();
//      m_editorImage->setImage( m_editorWindow->grab().toImage().scaledToHeight( 128 ), true );
//      m_editorImage->setImagePreserveAspectWoH( true );
//      m_editorImage->show();
      //m_editorPixmap = m_editorWindow->grab().scaledToHeight( 64 );
//      m_loadButton->setIcon( QIcon( m_editorPixmap ) );
//      m_loadButton->setIconSize( m_editorPixmap.size() );
//      m_loadButton->setText("");
      //ShowWindow(m_editorWinHandle, SW_SHOW);
   }

   if ( isSynth() )
   {
      emit addedSynth( this );
   }

   m_isLoaded = true;

   update();

   return m_isLoaded;
}


void
PluginVST24::closePlugin()
{
   if ( !m_isLoaded ) return; // Already closed

   m_isLoaded = false;  // Set this first, so the audio callback does bypass this dsp element.

   if ( isSynth() )
   {
      emit removedSynth( this ); // Unregister synth from MIDI keyboards
   }

   dispatcher(effMainsChanged, 0, 0);  // Stop plugin
   dispatcher(effStopProcess);         // Stop plugin

   if ( m_editorWindow )               // Stop plugin
   {                                   // Stop plugin
      m_editorWindow->enableClosing(); // Stop plugin
      dispatcher(effEditClose);        // Stop plugin
      m_editorWindow->close();         // Stop plugin
      delete m_editorWindow;           // Stop plugin
      m_editorWindow = nullptr;        // Stop plugin
   }                                   // Stop plugin

   dispatcher(effClose);               // Stop plugin

   if ( m_dllHandle )                  // Close plugin
   {
      HMODULE hModule = reinterpret_cast< HMODULE >( m_dllHandle );
      FreeLibrary(hModule);
      m_dllHandle = 0;
   }

   m_inBuffer.clear();
   m_inBufferHeads.clear();
   m_outBuffer.clear();
   m_outBufferHeads.clear();
   m_framePos = 0;

   //m_loadButton->setIcon( QIcon() );
   //m_editorImage->hide();
}


void
PluginVST24::aboutToStart( uint32_t dstFrames, uint32_t dstChannels, uint32_t dstRate )
{
   if ( m_bufferFrames != dstFrames )
   {
      m_bufferFrames = dstFrames;
      m_isDirty = true;
   }

   if ( m_sampleRate != dstRate )
   {
      m_sampleRate = dstRate;
      m_isDirty = true;
   }

   if ( m_vst && m_isDirty )
   {
      m_isDirty = false;

      dispatcher(effStopProcess);
      dispatcher(effMainsChanged, 0, 0);

      // Prepare input buffer + input channel heads ( planar = non-interleaved )
      size_t chIn = numInputs();
      if ( chIn < 1 )
      {
         m_inBuffer.clear();
         m_inBufferHeads.clear();
      }
      else
      {
         auto nSamples = chIn * m_bufferFrames;
         if ( nSamples != m_inBuffer.size() )
         {
            m_inBuffer.resize( nSamples );
            for( size_t i = 0; i < chIn; ++i )
            {
               m_inBufferHeads.push_back( &m_inBuffer[ i * m_bufferFrames ] );
            }
         }
      }

      // Prepare output buffer + output channel heads ( planar = non-interleaved )
      size_t chOut = numOutputs();
      if ( chOut < 1 )
      {
         m_outBuffer.clear();
         m_outBufferHeads.clear();
      }
      else
      {
         auto nSamples = chOut * m_bufferFrames;
         if ( nSamples != m_outBuffer.size() )
         {
            m_outBuffer.resize( nSamples );
            for( size_t i = 0; i < chOut; ++i )
            {
               m_outBufferHeads.push_back( &m_outBuffer[ i * m_bufferFrames ] );
            }
         }
      }

      // Setup VST plugin
      dispatcher(effSetSampleRate, 0, 0, 0, float( m_sampleRate ) );
      dispatcher(effSetBlockSize, 0, m_bufferFrames);
      dispatcher(effSetProcessPrecision, 0, kVstProcessPrecision32);
      dispatcher(effMainsChanged, 0, 1);
      dispatcher(effStartProcess);
      dispatcher(effSetProgram, 0, 0, 0);
   }

}

uint64_t
PluginVST24::readSamples( double pts, float* dst, uint32_t dstFrames, uint32_t dstChannels, uint32_t dstRate )
{
   using namespace de::audio; // ...DSP_functions...

   // The block of samples to process now...
   uint64_t dstSamples = dstFrames * dstChannels;

   // Handle bypass
   if ( !m_isLoaded || isBypassed() )
   {
      //std::cout << "PluginVST24::bypass\n";
      if ( m_inputSignal )
      {
         m_inputSignal->readSamples( pts, dst, dstFrames, dstChannels, dstRate );
      }
      else
      {
         DSP_FILLZERO( dst, dstSamples );
      }
      return dstSamples;
   }

   aboutToStart( dstFrames, dstChannels, dstRate );

   // Process AUDIO input ( for effects, relays, mixer, delays, filters, etc... )
   size_t chIn = numInputs();
   if ( chIn > 0 )
   {
      if ( m_inputSignal )
      {
         m_inputSignal->readSamples( pts, dst, dstFrames, dstChannels, dstRate );
      }
      else
      {
         DSP_FILLZERO( dst, dstSamples );
      }
   }

   // Process AUDIO input ( write dst to buffer heads, pointing to inBuffer )
   if ( chIn > 0 )
   {
      DSP_GET_CHANNEL( m_inBufferHeads[0], dstFrames, dst, dstFrames, 0, dstChannels );
   }
   if ( chIn > 1 )
   {
      DSP_GET_CHANNEL( m_inBufferHeads[1], dstFrames, dst, dstFrames, 1, dstChannels );
   }

   // Process MIDI input ( for synthesizer )
   processVstMidiEvents();

   // Process AUDIO output ( for all plugins )
   m_vst->processReplacing( m_vst, m_inBufferHeads.data(), m_outBufferHeads.data(), dstFrames );
   m_framePos += dstFrames; // atomic.

   // Write AUDIO output to my interleaved stereo float32 DSP chain.
   auto pDst = dst;
   for ( size_t i = 0; i < dstFrames; ++i )
   {
      for ( size_t c = 0; c < dstChannels; ++c )
      {
         auto & channelData = m_outBufferHeads[ c ];
         *pDst++ = channelData[ i ];
      }
   }

   //m_levelMeter->readSamples()


   return dstSamples;
}

std::string
PluginVST24::getVendorString() { return "AbletonLive64-Lite"; }
std::string
PluginVST24::getProductString() { return "AbletonLive64-Lite"; }
int
PluginVST24::getVendorVersion() { return 1; }
const char**
PluginVST24::getCapabilities() const
{
   static const char* hostCapabilities[] =
   {
      "sendVstEvents",
      "sendVstMidiEvents",
      "sizeWindow",
      "startStopProcess",
      "sendVstMidiEventFlagIsRealtime",
      nullptr
   };
   return hostCapabilities;
}

//uint64_t
//PluginVST24::getSamplePos() const { return m_framePos; }
//uint32_t
//PluginVST24::getSampleRate() const { return m_sampleRate; }
//uint64_t
//PluginVST24::getBlockSize() const { return m_bufferFrames; }
//uint64_t
//PluginVST24::getChannelCount() const { return m_channelCount; }

//bool
//PluginVST24::isSynth() const { return getFlags(effFlagsIsSynth); }
intptr_t
PluginVST24::dispatcher( int32_t opcode, int32_t index, intptr_t value, void *ptr, float opt ) const
{
//   if ( !m_isLoaded )
//   {
//      DE_ERROR("No plugin loaded")
//      return 0;
//   }

   if ( !m_vst )
   {
      DE_ERROR("No plugin, bad")
      return 0;
   }
   return m_vst->dispatcher( m_vst, opcode, index, value, ptr, opt );
}

void
PluginVST24::sendNote( de::audio::Note const & note )
{
   if ( !isSynth() )
   {

   }
   int channel = note.m_channel & 0x0F;
   int midiNote = note.m_midiNote & 0x7F;
   int velocity = note.m_velocity & 0x7F;

   VstMidiEvent e;
   e.type        = kVstMidiType;
   e.byteSize    = sizeof( VstMidiEvent );
   e.flags       = kVstMidiEventIsRealtime;
   e.midiData[0] = static_cast<char>( channel + 0x90);
   e.midiData[1] = static_cast<char>( midiNote );
   e.midiData[2] = static_cast<char>( velocity );

   size_t n = 0;
   if ( auto l = m_vstMidi.lock() )
   {
      m_vstMidi.events.push_back( e );
      n = m_vstMidi.events.size();
   }
   DE_DEBUG("events(",n,"), channel(",channel,"), midiNote(", midiNote,"), velocity(", velocity,")")
}


// This function is called from refillCallback() which is running in audio thread.
void
PluginVST24::processVstMidiEvents()
{
   m_vstMidiEvents.clear();
   if ( auto l = m_vstMidi.lock() )
   {
      std::swap( m_vstMidiEvents, m_vstMidi.events );
      //m_vstMidi.events.clear();
   }

   if ( !m_vstMidiEvents.empty() )
   {
      auto const n = m_vstMidiEvents.size();
      auto const byteCount = sizeof( VstEvents ) + sizeof( VstEvent* ) * n;
      m_vstEventBuffer.resize( byteCount );
      auto vstEvents = reinterpret_cast< VstEvents* >( m_vstEventBuffer.data() );
      vstEvents->numEvents = n;
      vstEvents->reserved = 0;
      for ( size_t i = 0; i < n; ++i )
      {
         vstEvents->events[ i ] = reinterpret_cast< VstEvent* >( &m_vstMidiEvents[ i ] );
      }
      DE_ERROR("Dispatch MIDI n = ",n)
      dispatcher( effProcessEvents, 0, 0, vstEvents );
   }
}

// This function is called from refillCallback() which is running in audio thread.
//float**
//PluginVST24::processAudio( uint64_t frameCount, uint64_t & outputFrameCount )
//{
//   //frameCount = std::min( uint64_t(frameCount), uint64_t(m_outBuffer.size()) / m_outputChannels );
//   m_vst->processReplacing( m_vst, m_inBufferHeads.data(), m_outBufferHeads.data(), frameCount );
//   m_framePos += frameCount;
//   outputFrameCount = frameCount;
//   return m_outBufferHeads.data();
//}

// static
VstIntPtr
PluginVST24::hostCallback_static( AEffect* effect, VstInt32 opcode, VstInt32 index, VstIntPtr value, void *ptr, float opt )
{
   if ( effect && effect->user )
   {
      auto me = static_cast< PluginVST24* >( effect->user );
      return me->hostCallback( opcode, index, value, ptr, opt );
   }

   switch( opcode )
   {
      case audioMasterVersion:    return kVstVersion;
      default:                    return 0;
   }
}

VstIntPtr
PluginVST24::hostCallback(VstInt32 opcode, VstInt32 index, VstIntPtr value, void* ptr, float)
{
   switch(opcode)
   {
      default:                                break;
      case audioMasterVersion:                return kVstVersion;
      case audioMasterCurrentId:              return m_vst->uniqueID;
      case audioMasterGetSampleRate:          return m_sampleRate;
      case audioMasterGetBlockSize:           return m_bufferFrames;
      case audioMasterGetCurrentProcessLevel: return kVstProcessLevelUnknown;
      case audioMasterGetAutomationState:     return kVstAutomationOff;
      case audioMasterGetLanguage:            return kVstLangEnglish;
      case audioMasterGetVendorVersion:       return getVendorVersion();
      case audioMasterGetVendorString:
         strcpy_s(static_cast<char*>(ptr), kVstMaxVendorStrLen, getVendorString().c_str());
         return 1;
      case audioMasterGetProductString:
         strcpy_s(static_cast<char*>(ptr), kVstMaxProductStrLen, getProductString().c_str());
         return 1;
      case audioMasterGetTime:
         m_timeInfo.flags      = 0;
         m_timeInfo.samplePos  = m_framePos;
         m_timeInfo.sampleRate = m_sampleRate;
         //DE_DEBUG("audioMasterGetTime(",m_timeInfo.samplePos,")")
         return reinterpret_cast< VstIntPtr >( &m_timeInfo );
      case audioMasterGetDirectory:
         return reinterpret_cast< VstIntPtr >( m_directoryMultiByte.c_str() );
      case audioMasterIdle:
         if ( m_editorWindow ) { dispatcher(effEditIdle); } break;
      case audioMasterSizeWindow:
         if ( m_editorWindow )
         {
            //RECT rc {};
            //GetWindowRect(m_editorWinHandle, &rc);
            //rc.right = rc.left + static_cast<int>(index);
            //rc.bottom = rc.top + static_cast<int>(value);
            //resizeEditor(rc);
            int w = int( index );
            int h = int( value );
            int x = m_editorWindow->x();
            int y = m_editorWindow->y();
            DE_DEBUG("audioMasterSizeWindow(",w,",",h,"), pos(",x,",",y,")")
            resizeEditor( QRect(x,y,w,h) );
         }
         break;
      case audioMasterCanDo:
         for ( const char** pp = getCapabilities(); *pp; ++pp )
         {
            if ( strcmp(*pp, static_cast<const char*>(ptr)) == 0 )
            {
               return 1;
            }
         }
         return 0;
   }
   return 0;
}



ImageButton*
PluginVST24::createEnableButton()
{
   auto btn = new ImageButton( this );
   btn->setToolTip("This DSP element is now (e)nabled = not bypassed");

   LiveSkin const & skin = m_app.m_skin;

   int b = 13;

   btn->setCheckable( true );
   btn->setChecked( true );

   auto symColor = skin.symbolColor;
   auto bgColor = skin.windowColor;
   auto fgColor = skin.panelColor; // or panelColor

   //QFont font = getFontAwesome( 14 );
   std::string
   msg = "  #####\n"
         " #     #\n"
         "#       #\n"
         "#   #   #\n"
         "#   #   #\n"
         "#   #   #\n"
         "#       #\n"
         " #     #\n"
         "  #####\n";

   // [idle]
   QImage ico = createAsciiArt( symColor, fgColor, msg );
   QImage img = createCircleImage( b,b, bgColor, fgColor, ico );
   btn->setImage( 0, img );
   // [idle_hover]
   btn->setImage( 1, img );

   // [active]
   ico = createAsciiArt( skin.activeColor, fgColor, msg );
   img = createCircleImage( b,b, bgColor, fgColor, ico );
   btn->setImage( 2, img );
   // [active_hover]
   btn->setImage( 3, img );

   return btn;
}

ImageButton*
PluginVST24::createMoreButton()
{
   auto btn = new ImageButton( this );
   btn->setToolTip("All DSP options are visible now");

   LiveSkin const & skin = m_app.m_skin;
   int b = 13;

   btn->setCheckable( true );
   btn->setChecked( false );

   auto symColor = skin.symbolColor;
   auto bgColor = skin.windowColor;
   auto fgColor = skin.panelColor; // or panelColor

   //QFont font = getFontAwesome( 14 );
   std::string
   msg = "#######\n"
         " #####\n"
         " #####\n"
         "  ###\n"
         "  ###\n"
         "   #\n"
         "   #\n";
   // [idle]
   QImage ico = createAsciiArt( symColor, fgColor, msg );
   QImage img = createCircleImage( b,b, bgColor, fgColor, ico );
   btn->setImage( 0, img );
   // [idle_hover]
   btn->setImage( 1, img );

   // [active]
   msg = "#\n"
         "###\n"
         "#####\n"
         "#######\n"
         "#####\n"
         "###\n"
         "#\n";
   ico = createAsciiArt( skin.activeColor, fgColor, msg );
   img = createCircleImage( b,b, bgColor, fgColor, ico );
   btn->setImage( 2, img );
   // [active_hover]
   btn->setImage( 3, img );

   return btn;
}


ImageButton*
PluginVST24::createEditorButton()
{
   auto btn = new ImageButton( this );
   LiveSkin const & skin = m_app.m_skin;
   int b = 13;

   btn->setCheckable( true );
   btn->setChecked( false );

   auto symColor = skin.symbolColor;
   auto bgColor = skin.windowColor;
   auto fgColor = skin.panelColor; // or panelColor

   //QFont font = getFontAwesome( 14 );
   std::string
   msg = "# #####\n"
         " \n"
         "# #####\n"
         " \n"
         "# #####\n";

   // [idle]
   QImage ico = createAsciiArt( symColor, fgColor, msg );
   QImage img = createCircleImage( b,b, bgColor, fgColor, ico );
   btn->setImage( 0, img );
   // [idle_hover]
   btn->setImage( 1, img );

   // [active]
   ico = createAsciiArt( skin.activeColor, fgColor, msg );
   img = createCircleImage( b,b, bgColor, fgColor, ico );
   btn->setImage( 2, img );
   // [active_hover]
   btn->setImage( 3, img );

   return btn;
}

ImageButton*
PluginVST24::createUpdateButton()
{
   auto btn = new ImageButton( this );
   LiveSkin const & skin = m_app.m_skin;
   int b = 13;

   btn->setCheckable( true );
   btn->setChecked( false );

   auto symColor = skin.symbolColor;
   auto bgColor = skin.windowColor;
   auto fgColor = skin.panelColor; // or panelColor

   //QFont font = getFontAwesome( 14 );
   std::string
   msg = "   ##\n"
         "  #\n"
         " #     #\n"
         "###   ###\n"
         " #     #\n"
         "      #\n"
         "    ##\n";

   // [idle]
   QImage ico = createAsciiArt( symColor, fgColor, msg );
   QImage img = createCircleImage( b,b, bgColor, fgColor, ico );
   btn->setImage( 0, img );
   // [idle_hover]
   btn->setImage( 1, img );

   // [active]
   ico = createAsciiArt( skin.activeColor, fgColor, msg );
   img = createCircleImage( b,b, bgColor, fgColor, ico );
   btn->setImage( 2, img );
   // [active_hover]
   btn->setImage( 3, img );

   return btn;
}


ImageButton*
PluginVST24::createSaveButton()
{
   auto btn = new ImageButton( this );
   LiveSkin const & skin = m_app.m_skin;
   int b = 13;

   btn->setCheckable( true );
   btn->setChecked( false );

   auto symColor = skin.symbolColor;
   auto bgColor = skin.windowColor;
   auto fgColor = skin.panelColor; // or panelColor

   //QFont font = getFontAwesome( 14 );
   std::string
   msg = "######\n"
         "##   ##\n"
         "##   ##\n"
         "#######\n"
         "#######\n"
         "#######\n"
         "#######\n";

   // [idle]
   QImage ico = createAsciiArt( symColor, fgColor, msg );
   QImage img = createCircleImage( b,b, bgColor, fgColor, ico );
   btn->setImage( 0, img );
   // [idle_hover]
   btn->setImage( 1, img );

   // [active]
   ico = createAsciiArt( skin.activeColor, fgColor, msg );
   img = createCircleImage( b,b, bgColor, fgColor, ico );
   btn->setImage( 2, img );
   // [active_hover]
   btn->setImage( 3, img );

   return btn;
}


/*
 *

    unsigned threadFunc() {
        ComInit comInit {};
        const HANDLE events[2] = { hClose, hRefillEvent };
        for(bool run = true; run; ) {
            const auto r = WaitForMultipleObjects(_countof(events), events, FALSE, INFINITE);
            if(WAIT_OBJECT_0 == r) {    // hClose
                run = false;
            } else if(WAIT_OBJECT_0+1 == r) {   // hRefillEvent
                UINT32 c = 0;
                audioClient->GetCurrentPadding(&c);

                const auto a = bufferFrameCount - c;
                float* data = nullptr;
                audioRenderClient->GetBuffer(a, reinterpret_cast<BYTE**>(&data));

                const auto r = refillFunc(data, a, mixFormat);
                audioRenderClient->ReleaseBuffer(a, r ? 0 : AUDCLNT_BUFFERFLAGS_SILENT);
            }
        }
        return 0;
    }

    HANDLE                  hThread { nullptr };
    IMMDeviceEnumerator*    mmDeviceEnumerator { nullptr };
    IMMDevice*              mmDevice { nullptr };
    IAudioClient*           audioClient { nullptr };
    IAudioRenderClient*     audioRenderClient { nullptr };
    WAVEFORMATEX*           mixFormat { nullptr };
    HANDLE                  hRefillEvent { nullptr };
    HANDLE                  hClose { nullptr };
    UINT32                  bufferFrameCount { 0 };
    RefillFunc              refillFunc {};
};


// This function is called from Wasapi::threadFunc() which is running in audio thread.
bool
refillCallback(
      VstPlugin& vstPlugin,
      float* const data,
      uint32_t availableFrameCount,
      const WAVEFORMATEX* const mixFormat)
{
    vstPlugin.processEvents();

    const auto nDstChannels = mixFormat->nChannels;
    const auto nSrcChannels = vstPlugin.getChannelCount();
    const auto vstSamplesPerBlock = vstPlugin.getBlockSize();

    int ofs = 0;
    while(availableFrameCount > 0) {
        size_t outputFrameCount = 0;
        float** vstOutput = vstPlugin.processAudio(availableFrameCount, outputFrameCount);

        // VST vstOutput[][] format :
        //  vstOutput[a][b]
        //      channel = a % vstPlugin.getChannelCount()
        //      frame   = b + floor(a/2) * vstPlugin.getBlockSize()

        // wasapi data[] format :
        //  data[x]
        //      channel = x % mixFormat->nChannels
        //      frame   = floor(x / mixFormat->nChannels);

        const auto nFrame = outputFrameCount;
        for(size_t iFrame = 0; iFrame < nFrame; ++iFrame) {
            for(size_t iChannel = 0; iChannel < nDstChannels; ++iChannel) {
                const int sChannel = iChannel % nSrcChannels;
                const int vstOutputPage = (iFrame / vstSamplesPerBlock) * sChannel + sChannel;
                const int vstOutputIndex = (iFrame % vstSamplesPerBlock);
                const int wasapiWriteIndex = iFrame * nDstChannels + iChannel;
                *(data + ofs + wasapiWriteIndex) = vstOutput[vstOutputPage][vstOutputIndex];
            }
        }

        availableFrameCount -= nFrame;
        ofs += nFrame * nDstChannels;
    }
    return true;
}


void mainLoop(const std::wstring& dllFilename)
{
    VstPlugin vstPlugin { dllFilename.c_str(), GetConsoleWindow() };

    Wasapi wasapi { [&vstPlugin](float* const data, uint32_t availableFrameCount, const WAVEFORMATEX* const mixFormat) {
        return refillCallback(vstPlugin, data, availableFrameCount, mixFormat);
    }};

    struct Key {
        Key(int midiNote) : midiNote { midiNote } {}
        int     midiNote {};
        bool    status { false };
    };

    std::map<int, Key> keyMap {
               {'2', {61}}, {'3', {63}},              {'5', {66}}, {'6', {68}}, {'7', {70}},
        {'Q', {60}}, {'W', {62}}, {'E', {64}}, {'R', {65}}, {'T', {67}}, {'Y', {69}}, {'U', {71}}, {'I', {72}},

               {'S', {49}}, {'D', {51}},              {'G', {54}}, {'H', {56}}, {'J', {58}},
        {'Z', {48}}, {'X', {50}}, {'C', {52}}, {'V', {53}}, {'B', {55}}, {'N', {57}}, {'M', {59}}, {VK_OEM_COMMA, {60}},
    };

    for(bool run = true; run; WaitMessage()) {
        MSG msg {};
        while(BOOL b = PeekMessage(&msg, 0, 0, 0, PM_REMOVE)) {
            if(b == -1) {
                run = false;
                break;
            }
            TranslateMessage(&msg);
            DispatchMessage(&msg);
        }

        for(auto& e : keyMap) {
            auto& key = e.second;
            const auto on = (GetKeyState(e.first) & 0x8000) != 0;
            if(key.status != on) {
                key.status = on;
                vstPlugin.sendMidiNote(0, key.midiNote, on, 100);
            }
        }
    }
}


int main() {
    volatile ComInit comInit;

    const auto dllFilename = []() -> std::wstring {
        wchar_t fn[MAX_PATH+1] {};
        OPENFILENAME ofn { sizeof(ofn) };
        ofn.lpstrFilter = L"VSTi DLL(*.dll)\0*.dll\0All Files(*.*)\0*.*\0\0";
        ofn.lpstrFile   = fn;
        ofn.nMaxFile    = _countof(fn);
        ofn.lpstrTitle  = L"Select VST DLL";
        ofn.Flags       = OFN_FILEMUSTEXIST | OFN_ENABLESIZING;
        GetOpenFileName(&ofn);
        return fn;
    } ();

    try {
        mainLoop(dllFilename);
    } catch(std::exception &e) {
        std::cout << "Exception : " << e.what() << std::endl;
    }
}

*/
