#include "DoubleBufferedNetwork.hpp"
#include "App.hpp"

namespace de {
namespace audio {

} // end namespace live
} // end namespace de



/*

// ==============================================================
Track::Track( App & app )
// ==============================================================
   : m_app( app )
//   // ---===--- XmlData ---===---
//   , m_name( name )
//   , m_isBypassed( false )
//   , m_ownedAndDeletedByQt( false )
//   , m_type( type )
//   , m_id( id )
//   , m_volume( 100 )
   // ---===--- Network ---===---
   , m_audioInput( nullptr )
   , m_audioSynth( nullptr )
   , m_audioEnd( nullptr )
{}

Track::~Track() { clear(); }

void
Track::clear()
{
   m_trackInfo.clear();
   m_audioEffects.clear();
   //m_audioInput = nullptr;
   m_audioSynth = nullptr;
   m_audioEnd = nullptr;

//   if ( m_spur )
//   {
//      if ( !m_ownedAndDeletedByQt )
//      {
//         delete m_spur;
//      }
//      m_spur = nullptr;
//   }
   m_clips.clear();
}

void
Track::setTrackInfo( TrackInfo const & trackInfo )
{
   clear();
   m_trackInfo = trackInfo;

   for ( auto const & pluginInfo : m_trackInfo.m_plugins )
   {
      auto plugin = m_app.pluginManager().addPlugin( pluginInfo );
      if ( plugin )
      {
         // TODO: regard midi plugins
         if ( plugin->isSynth() )
         {
            m_audioSynth = plugin;
         }
         else
         {
            m_audioEffects.emplace_back( plugin );
         }
      }
   }

   updateDspChain();
}

IPlugin*
Track::addPlugin( std::wstring const & uri )
{
   PluginInfo* pluginInfo = m_app.pluginDb().getPlugin( uri );
   if ( pluginInfo )
   {
      return addPlugin( *pluginInfo );
   }
   else
   {
      return nullptr;
   }
}

IPlugin*
Track::addPlugin( PluginInfo const & pluginInfo )
{
   auto plugin = m_app.pluginManager().addPlugin( pluginInfo );
   if ( !plugin )
   {
      std::wcout << "No plugin " << pluginInfo.m_uri << std::endl;
      return nullptr;
   }

   bool ok = addPlugin( plugin );
   if ( !ok )
   {
      delete plugin;
      //plugin = nullptr;
      return nullptr;
   }

   return plugin;
}

bool
Track::addPlugin( IPlugin* plugin )
{
   if ( !plugin )
   {
      DE_ERROR("Got nullptr")
      return false;
   }

   if ( isAudioOnly() && plugin->isSynth() )
   {
      std::wcout << "Track::createPlugin() - AudioOnly track cant add synth plugin " << plugin->getUri() << std::endl;
      return false;
   }

//   auto plugin = m_app.pluginManager().createPlugin( pluginInfo );
//   if ( !plugin )
//   {
//      std::wcout << "No plugin " << plugin->getUri() << std::endl;
//      return false;
//   }

   bool wasBypassed = isBypassed();
   setBypassed( true );

   m_trackInfo.addPlugin( plugin->getPluginInfo() );

   if ( plugin->isSynth() )
   {
      if ( m_audioSynth )
      {
         DE_DEBUG("Delete synthesizer")
         delete m_audioSynth;
      }
      else
      {
      }
      DE_DEBUG("Add synthesizer")
      m_audioSynth = plugin;
   }
   else
   {
      DE_DEBUG("Plugin is audio effect ", m_audioEffects.size() )
      m_audioEffects.emplace_back( plugin );
   }

   updateDspChain();
   setBypassed( wasBypassed );
   //updateLayout();

   return true;

}

void
Track::updateDspChain()
{
   bool wasBypassed = isBypassed();
   setBypassed( true );

   if ( isAudioOnly() )
   {
      if ( m_audioSynth )
      {
         DE_ERROR("Error synthesizer found and bypassed")
      }

      m_audioEnd = m_audioInput;
   }
   else
   {
      if ( m_audioInput )
      {
         DE_ERROR("Got inputSignal and synthesizer, nothing connected (yet)")
      }

      m_audioEnd = m_audioSynth;

      if ( !m_audioSynth )
      {
         DE_ERROR("No synthesizer to connect")
         m_audioEnd = m_audioInput;
      }
   }

   // Connect dsp chain
   for ( int i = 0; i < m_audioEffects.size(); ++i )
   {
      auto fx = m_audioEffects[ i ];
      fx->setInputSignal( 0, m_audioEnd );
      m_audioEnd = fx;
   }

   setBypassed( wasBypassed );
}



Clips const &
Track::clips() const { return m_clips; }

Clips &
Track::clips() { return m_clips; }

void
Track::addClip( Clip clip )
{
   m_clips.addClip( std::move( clip ) );
}

void
Track::addClip( double timeBeg, double timeEnd, std::string name )
{
   m_clips.addClip( timeBeg, timeEnd, name );
}

void
Track::writeXML( tinyxml2::XMLDocument & doc, tinyxml2::XMLElement* parent ) const
{
   tinyxml2::XMLElement* p = doc.NewElement( "track" );
   p->SetAttribute("id", m_id );
   p->SetAttribute("type", m_type );
   p->SetAttribute("name", m_name.c_str() );
   p->SetAttribute("volume", m_volume );
   p->SetAttribute("bypassed", int(m_isBypassed) );
   p->SetAttribute("plugins", int(m_plugins.size()) );

   for ( size_t i = 0; i < m_plugins.size(); ++i )
   {
      PluginInfo const & pluginInfo = m_plugins[ i ];
      pluginInfo.writeXML( doc, p );
   }

   parent->InsertEndChild( p );
}

bool
Track::readXML( int i, tinyxml2::XMLElement* p )
{
   if ( !p ) return false;
   if ( !p->Name() || (std::string( p->Name() ) != "track") ) return false;

   if ( !p->Attribute("name") )
   {
      std::cout << "Track[" << i << "] :: No name attribute" << std::endl;
   }

   m_id = p->IntAttribute("id");
   m_type = p->IntAttribute("type");
   m_name = p->Attribute( "name" ); // Crash cand.
   m_isBypassed = p->IntAttribute("bypassed") > 0;
   m_volume = p->IntAttribute("volume");

   m_plugins.clear();
   int m_checkSum = p->IntAttribute( "plugins" );

   // Read first child
   tinyxml2::XMLElement* pluginNode = p->FirstChildElement( "plugin" );
   if ( !pluginNode )
   {
      std::cout << "No <plugin> tag in <track>" << std::endl;
      return true;
   }

   // Read next children
   int k = 0;
   while ( pluginNode )
   {
      PluginInfo pluginInfo;
      if ( pluginInfo.readXML( k, plugin ) )
      {
         m_plugins.emplace_back( pluginInfo );
         k++;
      }

      pluginNode = pluginNode->NextSiblingElement( "plugin" );
   }

//      std::cout <<"Loaded dsp spur from XML " << uri << std::endl;
//      //std::cout << "[loadXml] dir = " << m_vstDirMB << std::endl;
//      std::cout << "[loadXml] expectPlugins = " << m_checkSum << std::endl;
//      std::cout << "[loadXml] loadedPlugins = " << k << std::endl;

   return true;
}
*/
