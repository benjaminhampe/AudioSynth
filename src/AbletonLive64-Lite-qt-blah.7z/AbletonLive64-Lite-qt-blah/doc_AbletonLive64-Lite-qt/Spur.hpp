/// (c) 2017 - 20180 Benjamin Hampe <benjaminhampe@gmx.de>

#ifndef DE_AUDIO_DSP_SPUR_HPP
#define DE_AUDIO_DSP_SPUR_HPP

//#include <de/audio/dsp/IDspChainElement.hpp>
#include <de/audio/plugin/IPlugin.hpp>
//#include <de/audio/dsp/LevelMeter.hpp>

namespace de {
namespace audio {

// A PluginContainer is a linear DSP chain of midiFxs, one midi2audio synthesizer and audioFxs.
// + <optional> 1 MidiInputMeter signalling any MIDI input ( not for audio-only )
// + <optional> Chain of MidiFx = 1x MidiPlugin + 1x MidiMeter
// + <optional> 1 synthesizer = ( 1x IPlugin + 1x LevelMeter ), gets replaced with next synth added.
// + <optional> Linear chain of effects each adding ( 1x IPlugin + 1x LevelMeter )

// ============================================================================
struct Spur : public IDspChainElement
// ============================================================================
{
   DE_CREATE_LOGGER("Spur")
   bool m_isAudioOnly; // false = All Midi and audio fx + Synth, true = Audio fx only, like master spur.
   bool m_isBypassed;
   //MidiMeter* m_midiMeter;
   //std::vector< IMidiChainElement* > m_midiEffects;// the rest of the audio chain is a series of effects.
   IDspChainElement* m_inputSignal;
   IPlugin* m_audioSynth; // The linking element between MIDI and Audio chain, either a Player or Synthesizer
   IDspChainElement* m_audioEnd;    // AudioChainEnd, for convenience to auto-connect end with a mixer
   std::vector< IPlugin* > m_plugins;
   std::vector< IPlugin* > m_audioEffects;
   //std::vector< LevelMeter > m_audioMeters;
public:
   Spur( bool bIsAudioOnly )
      : m_isAudioOnly( bIsAudioOnly )
      , m_isBypassed( false )
      , m_inputSignal( nullptr )
      , m_audioSynth( nullptr )
      , m_audioEnd( nullptr )
   {}

   ~Spur() override
   {
      m_isBypassed = true;

      for ( auto & p : m_audioEffects ) { if ( p ) delete p; }
      {
         m_audioEffects.clear();
      }

      if ( m_audioSynth )
      {
         delete m_audioSynth;
      }
   }

   bool addPlugin( std::wstring uri );
   //bool removePlugin( int id );
   //void clear();
   //void reset();
   bool updateDspChain();

   //int getPluginCount() const { return m_plugins.size(); }
   bool isBypassed() const override { return m_isBypassed; }
   bool isAudioOnly() const { return m_isAudioOnly; }

   void clearInputSignals() { m_inputSignal = nullptr; }
   void setInputSignal( int i, IDspChainElement* input )
   {
      m_inputSignal = input;
      updateDspChain();
   }

   void sendNote( Note const & note ) override
   {
      if ( m_audioSynth )
      {
         m_audioSynth->sendNote( note );
      }
   }

   void setBypassed( bool bypassed ) override { m_isBypassed = bypassed; }
   void aboutToStart( uint32_t dstFrames, uint32_t dstChannels, uint32_t dstRate ) override;
   uint64_t readSamples( double pts, float* dst, uint32_t dstFrames, uint32_t dstChannels, uint32_t dstRate ) override;
};

} // end namespace audio
} // end namespace de

#endif
