#include "TrackList.hpp"
#include "App.hpp"

TrackList::TrackList( App & app )
   : m_app( app )
{
   reset();
}

TrackList::~TrackList()
{
   destroy();
}

Track*
TrackList::get( int trackId )
{
   for ( size_t i = 0; i < m_all.size(); ++i )
   {
      auto p = m_all[ i ];
      if ( p && p->id() == trackId ) return p;
   }

   return nullptr;
}

int
TrackList::find( int trackId ) const
{
   for ( size_t i = 0; i < m_all.size(); ++i )
   {
      auto p = m_all[ i ];
      if ( p && p->id() == trackId ) return i;
   }

   return -1;
}

void
TrackList::setCurrentTrackId( int trackId )
{
   auto p = m_currentTrackId;
   m_currentTrackId = trackId;
   if ( p != trackId )
   {
      emit currentTrackIdChanged( trackId );
   }
}

void
TrackList::destroy()
{
   m_currentTrackId = -1;
   m_master = nullptr;
   m_returnA = nullptr;
   m_returnB = nullptr;
   m_user.clear();
   m_returns.clear();

   for ( size_t i = 0; i < m_all.size(); ++i )
   {
      auto p = m_all[ i ];
      if ( p ) delete p;
   }
   m_all.clear();
}

void
TrackList::reset()
{
   destroy();

   m_master = new Track( true, m_app );
   m_master->m_parent = this;
   m_master->m_id = 0;
   m_master->m_name = L"Master";
   //m_master->m_isAudioOnly = true;

   m_returnA = new Track( true, m_app );
   m_returnA->m_parent = this;
   m_returnA->m_id = 1;
   m_returnA->m_name = L"A - Return";
   //m_returnA->m_isAudioOnly = true;

   m_returnB = new Track( true, m_app );
   m_returnB->m_parent = this;
   m_returnB->m_id = 2;
   m_returnB->m_name = L"B - Return";
   //m_returnB->m_isAudioOnly = true;

   m_all.emplace_back( m_master );
   m_all.emplace_back( m_returnA );
   m_all.emplace_back( m_returnB );

   m_returns.emplace_back( m_master );
   m_returns.emplace_back( m_returnA );
   m_returns.emplace_back( m_returnB );

   int selectedId = 0;
   {
      Track* trk = new Track( false, m_app );
      trk->m_parent = this;
      trk->m_id = 1000 + m_user.size();
      trk->m_name = L"1 - Audio";
      //trk->m_isAudioOnly = false;
      trk->addClip( 0, 2, "Clip0-2");
      trk->addClip( 4, 6, "Clip4-6");
      trk->addClip( 8, 10, "Clip8-10");
      trk->addClip( 16, 17, "Clip16-18");
      trk->addClip( 18, 19, "Clip18-20");
      addTrack( trk );
      selectedId = trk->m_id;
   }

   {
      Track* trk = new Track( false, m_app );
      trk->m_parent = this;
      trk->m_id = 1000 + m_user.size();
      trk->m_name = L"2 - Midi";
      //trk->m_isAudioOnly = false;
      trk->addClip( 0, 1, "Clip0-1");
      trk->addClip( 1, 3, "Clip1-3");
      trk->addClip( 3, 4, "Clip3-4");
      trk->addClip( 5, 8, "Clip5-8");
      trk->addClip( 10, 16, "Clip10-16");
      trk->addClip( 17, 20, "Clip17-20");
      addTrack( trk );
   }

   {
      Track* trk = new Track( false, m_app );
      trk->m_parent = this;
      trk->m_id = 1000 + m_user.size();
      trk->m_name = L"3 - Midi";
      //trk->m_isAudioOnly = false;
      trk->addClip( 0, 0.25, "Clip0-1");
      trk->addClip( 0.5, 0.75, "Clip0-2");
      trk->addClip( 1, 1.25, "Clip1-1");
      trk->addClip( 1.5, 1.75, "Clip1-2");
      trk->addClip( 2, 2.25, "Clip2-1");
      trk->addClip( 2.5, 2.75, "Clip2-2");
      trk->addClip( 3, 3.25, "Clip3-1");
      trk->addClip( 3.5, 3.75, "Clip3-2");
      trk->addClip( 4, 4.25, "Clip4-1");
      trk->addClip( 4.5, 4.75, "Clip4-2");
      trk->addClip( 5, 5.25, "Clip5-1");
      trk->addClip( 5.5, 5.75, "Clip5-2");
      trk->addClip( 6, 6.25, "Clip6-1");
      trk->addClip( 6.5, 6.75, "Clip6-2");
      trk->addClip( 7, 7.25, "Clip7-1");
      trk->addClip( 7.5, 7.75, "Clip7-2");
      addTrack( trk );
   }

   //m_app.updateDspChain();
}

void
TrackList::addTrack( Track* track )
{
   if ( !track ) return;
   int trackId = track->id();
   int found = find( trackId );
   if ( found > -1 )
   {
      DE_WARN("Track id ", trackId, " already added" )
      return;
   }

   m_user.push_back( track );
   m_all.push_back( track );
}
