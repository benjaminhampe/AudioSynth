/// (c) 2017 - 20180 Benjamin Hampe <benjaminhampe@gmx.de>

#include "Track.hpp"
#include "App.hpp"

Track::Track( App & app, QWidget* parent )
   : QWidget( parent )
   , m_app( app )
   , m_hasFocus( false )
   , m_isBypassed( false )
   , m_trackId( -1 )
   , m_volume( 100 )
   , m_type( eTrackTypeCount )
   , m_name( "Unnnamed track" )
   , m_audioInput( nullptr )
   , m_audioEnd( nullptr )
   , m_audioSynth( nullptr )
{
   setObjectName( "Track" );
   setContentsMargins( 0,0,0,0 );
   setMouseTracking( true );
   //setAcceptDrops( true );         // We can drop plugins ( Midi or Audio ) into this editor widget.

   m_midiMeter = new MidiMeter( m_app, this );

   m_dummy = new SpurDummy( m_app, this );
   m_dummy->setAudioOnly( false );
}

Track::~Track()
{
   clear();
}

void
Track::clear()
{
   if ( m_audioSynth )
   {
      delete m_audioSynth;
      m_audioSynth = nullptr;
   }

   for ( auto effect : m_audioEffects )
   {
      if ( effect ) delete effect;
   }
   m_audioEffects.clear();
}

bool
Track::addPlugin( std::wstring const & uri )
{
   auto pluginInfoPtr = m_app.getPluginInfo( uri );
   if ( !pluginInfoPtr )
   {
      std::wcout << "Track::addPlugin() - No plugin info found in db " << uri << std::endl;
      return false;
   }

   auto pluginInfo = *pluginInfoPtr;

   if ( isAudioOnly() && pluginInfo.isSynth() )
   {
      std::wcout << "Track::addPlugin() - AudioOnly cant add synth " << uri << std::endl;
      return false;
   }

   m_isBypassed = true;

   auto plugin = new Plugin( m_app, this );
   if ( !plugin->openPlugin( uri ) )
   {
      std::wcout << "Cant open vst plugin " << uri << std::endl;
      delete plugin;
      return false;
   }

   if ( plugin->isSynth() )
   {
      if ( m_audioSynth )
      {
         delete m_audioSynth;
      }
      m_audioSynth = plugin;
   }
   else
   {
      m_audioEffects.emplace_back( plugin );
   }

   updateDspChain();
   updateLayout();
   return true;
}


void
Track::updateDspChain()
{
   //bool wasBypassed = isBypassed();
   //setBypassed( true );

   if ( isAudioOnly() )
   {
      if ( m_audioSynth )
      {
         DE_ERROR("Error synthesizer found and bypassed")
      }

      m_audioEnd = m_audioInput;
   }
   else
   {
      if ( m_audioInput )
      {
         DE_ERROR("Got inputSignal and synthesizer, nothing connected (yet)")
      }

      m_audioEnd = m_audioSynth;

      if ( !m_audioSynth )
      {
         DE_ERROR("No synthesizer to connect")
         m_audioEnd = m_audioInput;
      }
   }

   // Connect dsp chain
   for ( int i = 0; i < m_audioEffects.size(); ++i )
   {
      auto fx = m_audioEffects[ i ];
      fx->setInputSignal( 0, m_audioEnd );
      m_audioEnd = fx;
   }

   //setBypassed( wasBypassed );
}

uint64_t
Track::readSamples( double pts, float* dst, uint32_t dstFrames, uint32_t dstChannels, uint32_t dstRate )
{
   if ( m_audioEnd )
   {
      return m_audioEnd->readSamples( pts, dst, dstFrames, dstChannels, dstRate );
   }
   else
   {
      std::cout << "No audioEnd in track " << m_trackId << std::endl;
      uint64_t dstSamples = dstFrames * dstChannels;
      de::audio::DSP_FILLZERO( dst, dstSamples );
      return dstSamples;
   }
}

/*
void
Track::setTrack( int trackId )
{
   clear();

   m_trackId = trackId;

   auto track = m_app.tracks().getTrack( m_trackId );
   if ( !track )
   {
      return;
   }

   for ( auto const & pi : track->m_plugins )
   {
      auto editor = new PluginEditor( m_app, this );
      editor->setPlugin( audioEffect );
      m_audioEffects.emplace_back( editor );
   }


   auto track = m_app.tracks().getTrack( m_trackId );
   if ( track )
   {
      m_dummy->setAudioOnly( track->isAudioOnly() );

      auto audioSynth = track->m_audioSynth;
      if ( audioSynth )
      {
         if ( !m_audioSynth )
         {
            m_audioSynth = new PluginEditor( m_app, this );
            m_audioSynth->setPlugin( audioSynth );
         }
      }

      for ( auto audioEffect : m_track->m_audioEffects )
      {
         if ( audioEffect )
         {
            auto editor = new PluginEditor( m_app, this );
            editor->setPlugin( audioEffect );
            m_audioEffects.emplace_back( editor );
         }
      }
   }
   updateLayout();
}
*/

void
Track::updateLayout()
{
   int w = width();
   int h = height();

   int x = 0;
   int y = 0;

   setWidgetBounds( m_midiMeter, QRect(x,y,4,h) ); x += 6;

   int editorW = 0;

   if ( m_audioSynth )
   {
      editorW = m_audioSynth->maximumWidth();
      setWidgetBounds( m_audioSynth, QRect(x,y,editorW,h) ); x += editorW;
   }

   for ( auto & p : m_audioEffects )
   {
      if ( p )
      {
         editorW = p->maximumWidth();
         setWidgetBounds( p, QRect(x,y,editorW,h) ); x += editorW;
      }
   }

   int dummyW = w - x;
   if ( dummyW < 50 ) dummyW = 50;
   setWidgetBounds( m_dummy, QRect(x,y,dummyW,h) );

   update();
}

void
Track::resizeEvent( QResizeEvent* event )
{
   updateLayout();
   QWidget::resizeEvent( event );
}

//void
//Track::paintEvent( QPaintEvent* event )
//{
//   QWidget::paintEvent( event );
//}


void
Track::dropEvent( QDropEvent* event )
{
   std::cout << "Track::" << __func__ << std::endl;
   std::cout << event->mimeData()->text().toStdString() << std::endl;

   std::wstring uri = event->mimeData()->text().toStdWString();

   addPlugin( uri );

   event->acceptProposedAction();
   QWidget::dropEvent( event );
}

void
Track::dragEnterEvent( QDragEnterEvent* event )
{
   if ( event->mimeData()->hasFormat("text/plain") )
   {
      event->acceptProposedAction();
   }
   std::cout << __func__ << std::endl;
   QWidget::dragEnterEvent( event );
}

void
Track::dragLeaveEvent( QDragLeaveEvent* event )
{
   std::cout << __func__ << std::endl;
   QWidget::dragLeaveEvent( event );
}

void
Track::dragMoveEvent(QDragMoveEvent* event )
{
   std::cout << __func__ << std::endl;
   QWidget::dragMoveEvent( event );
}

void
Track::focusInEvent( QFocusEvent* event )
{
   m_hasFocus = true;
   update();
   QWidget::focusInEvent( event );
}

void
Track::focusOutEvent( QFocusEvent* event )
{
   m_hasFocus = true;
   update();
   QWidget::focusOutEvent( event );
}

void
Track::enterEvent( QEvent* event )
{
   QWidget::enterEvent( event );
}

void
Track::leaveEvent( QEvent* event )
{
   QWidget::leaveEvent( event );
}


void
Track::writeXML( tinyxml2::XMLDocument & doc, tinyxml2::XMLElement* parent ) const
{
   tinyxml2::XMLElement* p = doc.NewElement( "track" );
   p->SetAttribute("id", m_trackId );
   p->SetAttribute("type", m_type );
   p->SetAttribute("name", m_name.c_str() );
   p->SetAttribute("volume", m_volume );
   p->SetAttribute("bypassed", int(m_isBypassed) );
   p->SetAttribute("plugins", int(m_plugins.size()) );

   for ( size_t i = 0; i < m_plugins.size(); ++i )
   {
      auto plugin = m_plugins[ i ];
      if ( !plugin ) continue;

      de::audio::PluginInfo const * const pluginInfoPtr = m_app.getPluginInfo( plugin->uri() );

      if ( pluginInfoPtr )
      {
         pluginInfoPtr->writeXML( doc, p );
      }
   }

   parent->InsertEndChild( p );
}

bool
Track::readXML( int i, tinyxml2::XMLElement* p )
{
   if ( !p ) return false;
   if ( !p->Name() || (std::string( p->Name() ) != "track") ) return false;

   if ( !p->Attribute("name") )
   {
      std::cout << "Track[" << i << "] :: No name attribute" << std::endl;
   }

   m_trackId = p->IntAttribute("id");
   m_type = eTrackType( p->IntAttribute("type") );
   m_name = p->Attribute( "name" ); // Crash cand.
   m_isBypassed = p->IntAttribute("bypassed") > 0;
   //m_ = p->IntAttribute("bypassed") > 0;
   m_volume = p->IntAttribute("volume");

   m_plugins.clear();
   int m_checkSum = p->IntAttribute( "plugins" );

   // Read first child
   tinyxml2::XMLElement* pluginNode = p->FirstChildElement( "plugin" );
   if ( !pluginNode )
   {
      std::cout << "No <plugin> tag in <track>" << std::endl;
      return true;
   }

   // Read next children
   int k = 0;
   while ( pluginNode )
   {
      de::audio::PluginInfo pluginInfo;
      if ( pluginInfo.readXML( k, pluginNode ) )
      {
         addPlugin( pluginInfo.m_uri );
         k++;
      }

      pluginNode = pluginNode->NextSiblingElement( "plugin" );
   }

//      std::cout <<"Loaded dsp spur from XML " << uri << std::endl;
//      //std::cout << "[loadXml] dir = " << m_vstDirMB << std::endl;
//      std::cout << "[loadXml] expectPlugins = " << m_checkSum << std::endl;
//      std::cout << "[loadXml] loadedPlugins = " << k << std::endl;

   return true;
}


/*


void
Track::aboutToStart( uint32_t dstFrames, uint32_t dstChannels, uint32_t dstRate )
{
   uint64_t dstSamples = dstFrames * dstChannels;
   //DSP_RESIZE( m_inputBuffer, dstSamples );
}

uint64_t
Track::readSamples( double pts, float* dst, uint32_t dstFrames, uint32_t dstChannels, uint32_t dstRate )
{
   uint64_t dstSamples = dstFrames * dstChannels;
   if ( !m_isBypassed && m_audioEnd )
   {
      m_audioEnd->readSamples( pts, dst, dstFrames, dstChannels, dstRate );
   }
   else
   {
      de::audio::DSP_FILLZERO( dst, dstSamples );
   }
   return dstSamples;
}

bool
Track::addPlugin( std::wstring uri )
{
   int found = m_app.m_pluginDb.find( uri );
   if ( found < 0 )
   {
      std::wcout << "Track::addPlugin() - Plugin not in db " << uri << std::endl;
   }

   if ( m_isAudioOnly && m_app.m_pluginDb.isSynth( uri ) )
   {
      std::wcout << "Track::addPlugin() - Audio only cant add synth " << uri << std::endl;
      return false;
   }

   m_isBypassed = true;

   PluginVst2x* vst = new PluginVst2x( m_app, this );
   if ( !vst->openPlugin( uri ) )
   {
      std::wcout << "Cant open vst plugin " << uri << std::endl;
      delete vst;
      vst = nullptr;
      return false;
   }

   bool isSynth = vst->isSynth();
   if ( isSynth )
   {
      DE_DEBUG("Plugin is synth" )

      if ( m_audioSynth )
      {
         DE_DEBUG("Replace synthesizer")
         delete m_audioSynth;
      }
      else
      {
         DE_DEBUG("Add synthesizer")
      }

      m_audioSynth = vst;
   }
   else
   {
      DE_DEBUG("Plugin is audio effect ", m_audioEffects.size() )
      m_audioEffects.emplace_back( vst );
   }

   bool ok = updateDspChain();
   if ( !ok )
   {
      DE_ERROR("Cant reconnect DspChain")
   }
   m_isBypassed = false;

   updateLayout();

   return true;
}

bool
Track::updateDspChain()
{
   bool wasBypassed = m_isBypassed;
   m_isBypassed = true;

   if ( m_isAudioOnly )
   {
      DE_DEBUG("Connect audio only chain :: inputSignal -> ")
      if ( m_audioSynth )
      {
         DE_ERROR("Error synthesizer found and bypassed")
      }

      m_audioEnd = m_inputSignal;
   }
   else
   {
      if ( m_inputSignal )
      {
         DE_ERROR("Got inputSignal and synthesizer, nothing connected (yet)")
      }

      m_audioEnd = m_audioSynth;

      if ( !m_audioSynth )
      {
         DE_ERROR("No synthesizer to connect")
         m_audioEnd = m_inputSignal;
      }
   }

   // Connect dsp chain

   for ( int i = 0; i < m_audioEffects.size(); ++i )
   {
      auto fx = m_audioEffects[ i ];
      fx->setInputSignal( 0, m_audioEnd );
      m_audioEnd = fx;
   }

   if ( m_audioSynth )
   {
      m_app.updateSynthesizer();
   }

   m_isBypassed = wasBypassed;
   return m_audioEnd != nullptr;
}


// A Track is a MIDI effect chain + Audio DSP chain ( VST modules ).
// ============================================================================
struct Track : public de::audio::IDspChainElement
// ============================================================================
{
   DE_CREATE_LOGGER("Track")

   bool isAudioOnly;
   bool m_isBypassed;
   std::vector< PluginVst2x* > m_plugins;
   // MidiEffectProcessors < only for MidiTrack >
   std::vector< de::audio::IMidiChainElement* > m_midiEffects;
   std::vector< de::audio::IDspChainElement* > m_audioEffects; // the rest of the audio chain is a series of effects.

   de::audio::IDspChainElement* m_audioStart; // The linking element between MIDI and Audio chain, either a Player or Synthesizer
   de::audio::IDspChainElement* m_audioEnd;    // AudioChainEnd, for convenience to auto-connect end with a mixer

   Track() { reset(); }
   ~Track() {}

   void clear()
   {
      reset();
   }

   void reset()
   {
      isAudioOnly = false;    // Can have Midi Effects and Audio Synthesizer, true = only Audio Effects after AudioPlayer
      m_isBypassed = false;
      m_audioStart = nullptr;
      m_audioEnd = nullptr;
      m_midiEffects.clear();;
      m_audioEffects.clear();
   }

   bool
   isBypassed() const { return m_isBypassed; }

   void
   setBypassed( bool bypassed ) { m_isBypassed = bypassed; }

   void
   aboutToStart( uint32_t dstFrames, uint32_t dstChannels, uint32_t dstRate ) override
   {
      uint64_t dstSamples = dstFrames * dstChannels;
      //DSP_RESIZE( m_inputBuffer, dstSamples );
   }

   uint64_t
   readSamples( double pts, float* dst, uint32_t dstFrames, uint32_t dstChannels, uint32_t dstRate ) override
   {
      uint64_t dstSamples = dstFrames * dstChannels;
      if ( !m_isBypassed && m_audioEnd )
      {
         m_audioEnd->readSamples( pts, dst, dstFrames, dstChannels, dstRate );
      }
      else
      {
         de::audio::DSP_FILLZERO( dst, dstSamples );
      }
      return dstSamples;
   }

   bool
   addPlugin( de::audio::IDspChainElement* plugin, bool reconnect = true )
   {
      if ( !plugin ) return false;

      m_isBypassed = true;

      DE_DEBUG("isSynth = ", plugin->isSynth() )

      if ( plugin->isSynth() )
      {
         // replace synthesizer
         if ( m_audioStart )
         {
            DE_DEBUG("Replace synthesizer")
            delete m_audioStart;
         }
         else
         {
            DE_DEBUG("Add synthesizer")
         }

         m_audioStart = plugin;
      }
      else
      {
         m_audioEffects.emplace_back( plugin );
         DE_DEBUG("Added VST audio effect plugin ", m_audioEffects.size() )
      }

      bool ok = reconnectDspChain();
      if ( !ok )
      {
         DE_ERROR("Cant reconnect DspChain")
      }
      m_isBypassed = false;
      return true;
   }

   bool reconnectDspChain()
   {
      m_audioEnd = nullptr;

      if ( !m_audioStart )
      {
         if ( isAudioOnly )
         {
            DE_ERROR("No player to connect")
         }
         else
         {
            DE_ERROR("No synthesizer to connect")
         }
         return false;
      }

      // Connect dsp chain
      m_audioEnd = m_audioStart;
      for ( int i = 0; i < m_audioEffects.size(); ++i )
      {
         auto fx = m_audioEffects[ i ];
         fx->setInputSignal( 0, m_audioEnd );
         m_audioEnd = fx;
      }

      return m_audioEnd != nullptr;
   }

};
*/

