/// (c) 2017 - 20180 Benjamin Hampe <benjaminhampe@gmx.de>

#ifndef DE_LIVE_DATA_TRACK_HPP
#define DE_LIVE_DATA_TRACK_HPP

#include "Clips.hpp"
#include "Spur.hpp"

struct TrackList;
struct App;

// A track manages one Audio DSP chain and several Midi Clips on a timeline.
// ============================================================================
struct Track
// ============================================================================
{
   DE_CREATE_LOGGER("Track")
   App & m_app;
   int m_id;
   bool m_isAudioOnly;
//   bool m_canHaveClips;
//   bool m_canProcessMidi;
   bool m_ownedAndDeletedByQt;
   TrackList * m_parent;
   std::wstring m_name;

   Spur* m_spur;
   Clips m_clips;

   Track( , App & app )
      : m_app( app )
      , m_id(-1)
      , m_isAudioOnly( isAudioOnly )
      //, m_canHaveClips(false) // false = Master or Return A-Z, true = MIDI or Audio clips
      //, m_canProcessMidi(false) // false = Audio only chain ( a sample player )
      , m_ownedAndDeletedByQt(false)
      , m_parent( nullptr )
      , m_name(L"Track")
      , m_spur( new Spur( isAudioOnly, app, nullptr ) )
   {
      m_spur->hide();
   }

   ~Track() { clear(); }

   int id() const { return m_id; }

//   void setIsAudioOnly( bool b )
//   {
//      if ( m_isAudioOnly == b ) return;
//      m_isAudioOnly = b;
//      if ( m_spur )
//      {
//         m_spur->setm_isAudioOnly = b;
//      }
//   }

   void clear()
   {
      if ( m_spur )
      {
         if ( !m_ownedAndDeletedByQt )
         {
            delete m_spur;
         }
         m_spur = nullptr;
      }
      m_clips.clear();
   }

   Clips const & clips() const { return m_clips; }
   Clips & clips() { return m_clips; }

   void addClip( Clip clip )
   {
      m_clips.addClip( std::move( clip ) );
   }

   void addClip( double timeBeg, double timeEnd, std::string name = "Clip" )
   {
      m_clips.addClip( timeBeg, timeEnd, name );
   }

   void addPlugin( std::wstring uri )
   {
      if ( m_spur ) m_spur->addPlugin( uri );
   }

};

#endif
