#include "TopLeftPanel.hpp"
#include <QResizeEvent>

#include "App.hpp"

TopLeftPanel::TopLeftPanel( App & app, QWidget* parent )
   : QWidget( parent )
   , m_app( app )
   , m_hasFocus( false )
   , m_isHovered( false )
{
   setObjectName( "TopLeftPanel" );
   setContentsMargins( 0,0,0,0 );
   setMouseTracking( true );

   //m_app.m_pluginExplorer = new PluginExplorer2( m_app, this );
   //m_deviceBar = new DeviceBar( m_app, this );

//   setMinimumWidth( 28 );
//   setMaximumWidth( 28 );
   m_btnShowExplorer = createShowExplorerButton();
   m_btnShowInternDevices = createShowInternDevicesButton();
   m_btnShowExternDevices = createShowExternDevicesButton();
   m_btnShowExplorer1 = createShowExplorer1Button();
   m_btnShowExplorer2 = createShowExplorer2Button();
   m_btnShowExplorer3 = createShowExplorer3Button();
   m_scrollBar = new ScrollBar( m_app, this );
   m_btnShowGrooves = createShowGroovesButton();
//   auto v = createVBox();
//   v->setContentsMargins( 0,0,0,0);
//   v->setSpacing( 5 );
//   v->addWidget( m_btnShowExplorer );
//   v->addWidget( m_btnShowInternDevices );
//   v->addWidget( m_btnShowExternDevices );
//   v->addWidget( m_btnShowExplorer1 );
//   v->addWidget( m_btnShowExplorer2 );
//   v->addWidget( m_btnShowExplorer3 );
//   v->addWidget( m_scrollBar,1 );
//   v->addWidget( m_btnShowGrooves );
//   setLayout( v );

   //m_explorerPanel = new ExplorerPanel( m_app, this );
   m_explorerContent = new ExplorerContent( m_app, this );

//   auto h = createHBox();
//   h->setContentsMargins( 0,0,0,0);
//   h->setSpacing( 0 );
//   h->addWidget( m_deviceBar );
//   h->addWidget(m_explorerPanel,1 );
//   h->addWidget(m_explorerContent,1 );
//   setLayout( h );

   connect( m_btnShowExplorer, SIGNAL(toggled(bool)),
            this, SLOT(on_toggleExplorerPanelVisible(bool)) );

}

void
TopLeftPanel::on_toggleExplorerPanelVisible( bool checked )
{
   m_app.m_isExplorerVisible = checked;
   m_app.updateLayout();
}

void
TopLeftPanel::updateLayout()
{
   int w = width();
   int h = height();
   //std::cout << "w = " << w << ", h = " << h << std::endl;

   int b = m_app.m_skin.getInt( LiveSkin::CircleButtonSize );
   int s = m_app.m_skin.getInt( LiveSkin::Spacing );
   int bs = b + s;
   //int p = m_app.m_skin.getInt( LiveSkin::Padding );

   //m_app.m_rcTopLeft = QRect( x, y, explorerW + barW, trH );
   m_rcDeviceBar = QRect( 0, 0, b, h );
   m_rcExplorerPanel = QRect( bs, 0, w - bs, h );
   m_rcExplorerContent = QRect( m_rcExplorerPanel.x() + 6,
                                m_rcExplorerPanel.y() + 6,
                                m_rcExplorerPanel.width() - 12,
                                m_rcExplorerPanel.height() - 12 );

   int x = m_rcDeviceBar.x();
   int y = m_rcDeviceBar.y();
   //w = m_rcDeviceBar.x();
   //h = m_rcDeviceBar.y();
   setWidgetBounds( m_btnShowExplorer, QRect( x, y, b, b ) ); y += bs;
   setWidgetBounds( m_btnShowInternDevices, QRect( x, y, b, b ) ); y += bs;
   setWidgetBounds( m_btnShowExternDevices, QRect( x, y, b, b ) ); y += bs;
   setWidgetBounds( m_btnShowExplorer1, QRect( x, y, b, b ) ); y += bs;
   setWidgetBounds( m_btnShowExplorer2, QRect( x, y, b, b ) ); y += bs;
   setWidgetBounds( m_btnShowExplorer3, QRect( x, y, b, b ) ); y += bs;

   int sy = h - 7*bs;
   if ( sy < 50 ) sy = 50;
   m_rcScrollBar = QRect( x, y, b, sy );
   m_rcScrollBarClient = QRect( m_rcScrollBar.x() + 7,
                                m_rcScrollBar.y() + 7,
                                9,
                                m_rcScrollBar.height() - 2*7 );

   setWidgetBounds( m_scrollBar, m_rcScrollBarClient ); y += sy + s;
   setWidgetBounds( m_btnShowGrooves, QRect( x, y, b, b ) ); y += bs;

   setWidgetBounds( m_explorerContent, m_rcExplorerContent );

   update();
}


void
TopLeftPanel::resizeEvent( QResizeEvent* event )
{
   QWidget::resizeEvent( event );
   updateLayout();
}

void TopLeftPanel::paintEvent( QPaintEvent* event )
{
   int w = width();
   int h = height();

   if ( w > 1 && h > 1 )
   {
      auto const & skin = m_app.m_skin;
      QPainter dc( this );
      dc.setRenderHint( QPainter::NonCosmeticDefaultPen );
      auto panelColor = hasFocus() ? skin.focusColor : skin.panelColor;

      int s = m_app.m_skin.getInt( LiveSkin::Spacing );

      int x = m_rcScrollBar.x();
      int y = m_rcScrollBar.y();
      w = m_rcScrollBar.width() + 3*s;
      h = m_rcScrollBar.height();

      drawRoundRectFill( dc, QRect(x,y,w,h), panelColor, skin.radius, skin.radius );
      drawRoundRectFill( dc, m_rcExplorerPanel, panelColor, skin.radius, skin.radius );
      //drawRoundRectFill( dc, x, y, w, h, bgColor, rx, ry );
      //drawRoundRectFill( dc, x+1, y+1, w-2, h-2, fgColor, rx, ry );
   }

   QWidget::paintEvent( event );
}

void
TopLeftPanel::enterEvent( QEvent* event )
{
   m_isHovered = true;
   update();
   QWidget::enterEvent( event );
}
void
TopLeftPanel::leaveEvent( QEvent* event )
{
   m_isHovered = false;
   update();
   QWidget::leaveEvent( event );
}

void
TopLeftPanel::focusInEvent( QFocusEvent* event )
{
   m_hasFocus = true;
   update();
   QWidget::focusInEvent( event );
}

void
TopLeftPanel::focusOutEvent( QFocusEvent* event )
{
   m_hasFocus = true;
   update();
   QWidget::focusOutEvent( event );
}

ImageButton*
TopLeftPanel::createShowExplorerButton()
{
   auto btn = new ImageButton( this );
   LiveSkin const & skin = m_app.m_skin;
   int bw = skin.circleButtonSize;
   int bh = skin.circleButtonSize;

   btn->setCheckable( true );
   btn->setChecked( true );

   auto symColor = skin.symbolColor;
   auto bgColor = skin.windowColor;
   auto fgColor = skin.panelColor; // or panelColor

   //QFont font = getFontAwesome( 14 );
   std::string
   msg = "#########\n"
         "#########\n"
         " #######\n"
         " #######\n"
         "  #####\n"
         "  #####\n"
         "   ###\n"
         "   ###\n"
         "    #\n";
   // [idle]
   QImage ico = createAsciiArt( symColor, fgColor, msg );
   QImage img = createCircleImage( bw,bh, bgColor, fgColor, ico );
   btn->setImage( 0, img );
   // [idle_hover]
   btn->setImage( 1, img );

   // [active]
   msg = "##\n"
         "####\n"
         "######\n"
         "########\n"
         "#########\n"
         "########\n"
         "######\n"
         "####\n"
         "##\n";

   ico = createAsciiArt( symColor, fgColor, msg );
   img = createCircleImage( bw,bh, bgColor, fgColor, ico );
   btn->setImage( 2, img );
   // [active_hover]
   btn->setImage( 3, img );

   return btn;
}

ImageButton*
TopLeftPanel::createShowInternDevicesButton()
{
   auto btn = new ImageButton( this );
   LiveSkin const & skin = m_app.m_skin;

   int bw = skin.circleButtonSize;
   int bh = skin.circleButtonSize;

   btn->setCheckable( true );
   btn->setChecked( false );

   auto symColor = skin.symbolColor;
   auto bgColor = skin.windowColor;
   auto fgColor = skin.panelColor;

   //QFont font = getFontAwesome( 14 );
   std::string
   msg = " ########### \n"
         "##         ##\n"
         "##         ##\n"
         "#############\n"
         "#############\n"
         "#############\n"
         "#############\n"
         "#############\n"
         "#############\n"
         " ########### \n";
   // [idle]
   QImage ico = createAsciiArt( symColor, fgColor, msg );
   QImage img = createCircleImage( bw,bh, bgColor, fgColor, ico );
   btn->setImage( 0, img );
   // [idle_hover]
   btn->setImage( 1, img );

   // [active]
   ico = createAsciiArt( skin.activeColor, fgColor, msg );
   img = createCircleImage( bw,bh, bgColor, fgColor, ico );
   btn->setImage( 2, img );
   // [active_hover]
   btn->setImage( 3, img );
   return btn;
}

ImageButton*
TopLeftPanel::createShowExternDevicesButton()
{
   auto btn = new ImageButton( this );
   LiveSkin const & skin = m_app.m_skin;
   int bw = skin.circleButtonSize;
   int bh = skin.circleButtonSize;

   btn->setCheckable( true );
   btn->setChecked( true );

   auto symColor = skin.symbolColor;
   auto bgColor = skin.windowColor;
   auto fgColor = skin.panelColor;

   //QFont font = getFontAwesome( 14 );
   std::string
   msg = "      ####\n"
         "   #  #######\n"
         "   #######\n"
         "##########\n"
         "   #######\n"
         "   #  #######\n"
         "      ####\n";
   // [idle]
   QImage ico = createAsciiArt( symColor, fgColor, msg );
   QImage img = createCircleImage( bw,bh, bgColor, fgColor, ico );
   btn->setImage( 0, img );
   // [idle_hover]
   btn->setImage( 1, img );

   // [active]
   ico = createAsciiArt( skin.activeColor, fgColor, msg );
   img = createCircleImage( bw,bh, bgColor, fgColor, ico );
   btn->setImage( 2, img );
   // [active_hover]
   btn->setImage( 3, img );
   return btn;
}

ImageButton*
TopLeftPanel::createShowExplorer1Button()
{
   auto btn = new ImageButton( this );
   LiveSkin const & skin = m_app.m_skin;
   int bw = skin.circleButtonSize;
   int bh = skin.circleButtonSize;

   btn->setCheckable( true );
   btn->setChecked( false );

   auto symColor = skin.symbolColor;
   auto bgColor = skin.windowColor;
   auto fgColor = skin.panelColor;

   //QFont font = getFontAwesome( 14 );
   std::string
   msg = "#####\n"
         "#####\n"
         "###########\n"
         "###     ###\n"
         "### ##  ###\n"
         "###  #  ###\n"
         "###  #  ###\n"
         "###     ###\n"
         "###########\n";
   // [idle]
   QImage ico = createAsciiArt( symColor, fgColor, msg );
   QImage img = createCircleImage( bw,bh, bgColor, fgColor, ico );
   btn->setImage( 0, img );
   // [idle_hover]
   btn->setImage( 1, img );

   // [active]
   ico = createAsciiArt( skin.activeColor, fgColor, msg );
   img = createCircleImage( bw,bh, bgColor, fgColor, ico );
   btn->setImage( 2, img );
   // [active_hover]
   btn->setImage( 3, img );
   return btn;
}

ImageButton*
TopLeftPanel::createShowExplorer2Button()
{
   auto btn = new ImageButton( this );
   LiveSkin const & skin = m_app.m_skin;
   int bw = skin.circleButtonSize;
   int bh = skin.circleButtonSize;

   btn->setCheckable( true );
   btn->setChecked( false );

   auto symColor = skin.symbolColor;
   auto bgColor = skin.windowColor;
   auto fgColor = skin.panelColor;

   //QFont font = getFontAwesome( 14 );
   std::string
   msg = "#####\n"
         "#####\n"
         "###########\n"
         "####   ####\n"
         "###  #  ###\n"
         "##  # #  ##\n"
         "##    #  ##\n"
         "##   #   ##\n"
         "### ### ###\n"
         "####   ####\n"
         "###########\n";

   // [idle]
   QImage ico = createAsciiArt( symColor, fgColor, msg );
   QImage img = createCircleImage( bw,bh, bgColor, fgColor, ico );
   btn->setImage( 0, img );
   // [idle_hover]
   btn->setImage( 1, img );

   // [active]
   ico = createAsciiArt( skin.activeColor, fgColor, msg );
   img = createCircleImage( bw,bh, bgColor, fgColor, ico );
   btn->setImage( 2, img );
   // [active_hover]
   btn->setImage( 3, img );
   return btn;
}

ImageButton*
TopLeftPanel::createShowExplorer3Button()
{
   auto btn = new ImageButton( this );
   LiveSkin const & skin = m_app.m_skin;
   int bw = skin.circleButtonSize;
   int bh = skin.circleButtonSize;

   btn->setCheckable( true );
   btn->setChecked( false );

   auto symColor = skin.symbolColor;
   auto bgColor = skin.windowColor;
   auto fgColor = skin.panelColor;

   //QFont font = getFontAwesome( 14 );
   std::string
   msg = "#####\n"
         "#####\n"
         "###########\n"
         "###     ###\n"
         "### ##  ###\n"
         "###  #  ###\n"
         "###  #  ###\n"
         "###     ###\n"
         "###########\n";
   // [idle]
   QImage ico = createAsciiArt( symColor, fgColor, msg );
   QImage img = createCircleImage( bw,bh, bgColor, fgColor, ico );
   btn->setImage( 0, img );
   // [idle_hover]
   btn->setImage( 1, img );

   // [active]

   ico = createAsciiArt( skin.activeColor, fgColor, msg );
   img = createCircleImage( bw,bh, bgColor, fgColor, ico );
   btn->setImage( 2, img );
   // [active_hover]
   btn->setImage( 3, img );
   return btn;
}

ImageButton*
TopLeftPanel::createShowGroovesButton()
{
   auto btn = new ImageButton( this );
   LiveSkin const & skin = m_app.m_skin;
   int bw = skin.circleButtonSize;
   int bh = skin.circleButtonSize;

   btn->setCheckable( true );
   btn->setChecked( false );

   auto symColor = skin.symbolColor;
   auto bgColor = skin.windowColor;
   auto fgColor = skin.panelColor;

   //QFont font = getFontAwesome( 14 );
   std::string
   msg = "  ##\n"
         " #  #\n"
         "#    #    #\n"
         "      #  #\n"
         "       ##\n"
         "  ##\n"
         " #  #\n"
         "#    #    #\n"
         "      #  #\n"
         "       ##\n";

   // [idle]
   QImage ico = createAsciiArt( symColor, fgColor, msg );
   QImage img = createCircleImage( bw,bh, bgColor, fgColor, ico );
   btn->setImage( 0, img );
   // [idle_hover]
   btn->setImage( 1, img );

   // [active]
   ico = createAsciiArt( skin.activeColor, fgColor, msg );
   img = createCircleImage( bw,bh, bgColor, fgColor, ico );
   btn->setImage( 2, img );
   // [active_hover]
   btn->setImage( 3, img );
   return btn;
}
