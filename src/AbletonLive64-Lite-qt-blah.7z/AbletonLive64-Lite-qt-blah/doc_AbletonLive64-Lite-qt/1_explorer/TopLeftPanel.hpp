#ifndef DE_LIVE_TOPLEFT_PANEL_HPP
#define DE_LIVE_TOPLEFT_PANEL_HPP

#include <QWidget>
#include <QImage>
#include <QTimer>
#include <QPainter>
#include <QPaintEvent>
#include <QResizeEvent>
#include <QMouseEvent>
#include <QKeyEvent>
#include <QDebug>
#include <QThread>

struct App;

//#include <DeviceBar.hpp>
#include "ImageButton.hpp"
#include "ScrollBar.hpp"
#include <ExplorerContent.hpp>

// ============================================================================
class TopLeftPanel : public QWidget
// ============================================================================
{
   Q_OBJECT
   //DE_CREATE_LOGGER("TopLeftPanel")
   App & m_app;
   bool m_hasFocus;
   bool m_isHovered;
public:
   QRect m_rcDeviceBar; // Computed, buttons
   QRect m_rcScrollBar; // Computed
   QRect m_rcScrollBarClient; // Computed
   QRect m_rcExplorerPanel; // Computed
   QRect m_rcExplorerContent;
   //DeviceBar* m_deviceBar;
   ImageButton* m_btnShowExplorer;
   ImageButton* m_btnShowInternDevices;
   ImageButton* m_btnShowExternDevices;
   ImageButton* m_btnShowExplorer1;
   ImageButton* m_btnShowExplorer2;
   ImageButton* m_btnShowExplorer3;
   ScrollBar* m_scrollBar;
   ImageButton* m_btnShowGrooves;

   ExplorerContent* m_explorerContent;
public:
   TopLeftPanel( App & app, QWidget* parent = 0 );
   ~TopLeftPanel() override {}

signals:
public slots:
   void updateLayout();
protected slots:
   void on_toggleExplorerPanelVisible( bool checked );

protected:
   void paintEvent( QPaintEvent* event ) override;
   void resizeEvent( QResizeEvent* event ) override;
   void enterEvent( QEvent* event ) override;
   void leaveEvent( QEvent* event ) override;
   void focusInEvent( QFocusEvent* event ) override;
   void focusOutEvent( QFocusEvent* event ) override;

   //void enterEvent( QEvent* event ) override { m_isHovered = true; QPushButton::enterEvent( event ); }
   //void leaveEvent( QEvent* event ) override { m_isHovered = false; QPushButton::leaveEvent( event ); }

   //void updateLayout( int w, int h );

   //void resizeEvent( QResizeEvent* event ) override;
   //void paintEvent( QPaintEvent* event ) override;

   // void mousePressEvent( QMouseEvent* event ) override;
   // void mouseReleaseEvent( QMouseEvent* event ) override;
   // void mouseMoveEvent( QMouseEvent* event ) override;
   // void wheelEvent( QWheelEvent* event ) override;

   // void keyPressEvent( QKeyEvent* event ) override;
   // void keyReleaseEvent( QKeyEvent* event ) override;

//   void hideEvent( QHideEvent* event ) override;
//   void showEvent( QShowEvent* event ) override;

private:
   ImageButton* createShowExplorerButton();
   ImageButton* createShowInternDevicesButton();
   ImageButton* createShowExternDevicesButton();
   ImageButton* createShowExplorer1Button();
   ImageButton* createShowExplorer2Button();
   ImageButton* createShowExplorer3Button();
   ImageButton* createShowGroovesButton();

};

#endif // DE_Q_IMAGEWIDGET_HPP
