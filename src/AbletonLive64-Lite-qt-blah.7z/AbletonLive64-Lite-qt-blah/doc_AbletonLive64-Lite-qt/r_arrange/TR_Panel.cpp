#include "TR_Panel.hpp"
#include <QResizeEvent>

#include "App.hpp"
#include "Draw.hpp"

TR_Panel::TR_Panel( App & app, QWidget* parent )
   : QWidget(parent)
   , m_app( app )
   , m_hasFocus( false )
   , m_isHovered( false )
{
   setObjectName( "TR_Panel" );
   setContentsMargins( 0,0,0,0 );
   setMouseTracking( true );

   m_timeLineOverview = new TimeLineOverview( m_app, this );
   m_arrangement = new Arrangement( m_app, this );

   m_btnShowArrangement = createShowArrangementButton();
   m_btnShowSession = createShowSessionButton();
   m_scrollBar = new ScrollBar( m_app, this );
   m_btnComposeIO = createComposeIOButton();
   m_btnComposeR = createComposeRButton();
   m_btnComposeM = createComposeMButton();
   m_btnComposeD = createComposeDButton();

//   auto v = createVBox();
//   v->setContentsMargins( 0,0,0,0);
//   v->setSpacing( 5 );
//   v->addWidget( m_btnShowArrangement );
//   v->addWidget( m_btnShowSessionButton );
//   v->addWidget( m_scrollBar,1 );
//   v->addWidget( m_btnComposeIO );
//   v->addWidget( m_btnComposeR );
//   v->addWidget( m_btnComposeM );
//   v->addWidget( m_btnComposeD );
//   setLayout( v );
}


void
TR_Panel::updateLayout()
{
   int w = width();
   int h = height();
   int p = m_app.m_skin.getInt( LiveSkin::Padding );
   int b = m_app.m_skin.getInt( LiveSkin::CircleButtonSize );
   int s = m_app.m_skin.getInt( LiveSkin::Spacing );
   int bs = b + s;
   int c = m_app.m_skin.getInt( LiveSkin::SmallCircleButtonSize );

   m_rcViewPanel = QRect( 0, 0, w - bs, h );
   m_rcViewContent = QRect( 6, 6, w - bs - 12, h - 12 );
   m_rcComposeBar = QRect( w-1-b, 0, b, h );

   int m_timeLineH = m_timeLineOverview->computeBestHeight();

   m_rcTimeLine = QRect( m_rcViewContent.x(),
                         m_rcViewContent.y(),
                         m_rcViewContent.width(),
                         m_timeLineH );

   setWidgetBounds( m_timeLineOverview, m_rcTimeLine );

   m_rcArrangement = QRect( m_rcViewContent.x(),
                            m_rcViewContent.y() + m_timeLineH + p,
                            m_rcViewContent.width(),
                            m_rcViewContent.height() - m_timeLineH - p );

   setWidgetBounds( m_arrangement, m_rcArrangement );

   int x = m_rcComposeBar.x();
   int y = m_rcComposeBar.y();
   //w = m_rcDeviceBar.x();
   //h = m_rcDeviceBar.y();
   setWidgetBounds( m_btnShowArrangement, QRect( x, y, b, b ) ); y += bs;
   setWidgetBounds( m_btnShowSession, QRect( x, y, b, b ) ); y += bs;

   int sy = h - 2*bs - s - 4*(c+s)-s;
   if ( sy < 50 ) sy = 50;

   x += 7;
   m_rcScrollBar = QRect( x, y, bs, sy );

   m_rcScrollBarClient = QRect( m_rcScrollBar.x(),
                                m_rcScrollBar.y() + 7,
                                9,
                                m_rcScrollBar.height() - 2*7 );

   setWidgetBounds( m_scrollBar, m_rcScrollBarClient ); y += sy + s;

   x -= 1;
   setWidgetBounds( m_btnComposeIO, QRect( x, y, c, c ) ); y += c+s;
   setWidgetBounds( m_btnComposeR, QRect( x, y, c, c ) ); y += c+s;
   setWidgetBounds( m_btnComposeM, QRect( x, y, c, c ) ); y += c+s;
   setWidgetBounds( m_btnComposeD, QRect( x, y, c, c ) ); y += c+s;

   //if ( w < 4 ) return;
   //if ( h < 4 ) return;

   update();
}

void
TR_Panel::resizeEvent( QResizeEvent* event )
{
   QWidget::resizeEvent( event );
   updateLayout();
}

void TR_Panel::paintEvent( QPaintEvent* event )
{
   int w = width();
   int h = height();

   if ( w > 1 && h > 1 )
   {
      auto const & skin = m_app.m_skin;

      QPainter dc( this );
      dc.setRenderHint( QPainter::NonCosmeticDefaultPen );
      //dc.fillRect( rect(), skin.panelBlendColor );

      auto fgColor = hasFocus() ? skin.focusColor : skin.panelColor;

      int p = m_app.m_skin.getInt( LiveSkin::Padding );
      int b = m_app.m_skin.getInt( LiveSkin::CircleButtonSize );
      int s = m_app.m_skin.getInt( LiveSkin::Spacing );
      int bs = b + s;
      int x = m_rcComposeBar.x() - 2* p;
      int y = 2 * bs;
      int m = m_rcComposeBar.width() + 2*p;
      int n = h - y;
      drawRoundRectFill( dc, QRect(x,y,m,n), fgColor, skin.radius, skin.radius );
      drawRoundRectFill( dc, m_rcViewPanel, fgColor, skin.radius, skin.radius );
      //drawRoundRectFill( dc, x, y, w, h, bgColor, rx, ry );
      //drawRoundRectFill( dc, x+1, y+1, w-2, h-2, fgColor, rx, ry );
   }

   QWidget::paintEvent( event );
}

void
TR_Panel::enterEvent( QEvent* event )
{
   m_isHovered = true;
   update();
   QWidget::enterEvent( event );
}
void
TR_Panel::leaveEvent( QEvent* event )
{
   m_isHovered = false;
   update();
   QWidget::leaveEvent( event );
}

void
TR_Panel::focusInEvent( QFocusEvent* event )
{
   m_hasFocus = true;
   update();
   QWidget::focusInEvent( event );
}

void
TR_Panel::focusOutEvent( QFocusEvent* event )
{
   m_hasFocus = true;
   update();
   QWidget::focusOutEvent( event );
}








ImageButton*
TR_Panel::createShowArrangementButton()
{
   auto btn = new ImageButton( this );
   LiveSkin const & skin = m_app.m_skin;

   int cbs = skin.getInt( LiveSkin::CircleButtonSize );

   btn->setCheckable( true );
   btn->setChecked( true );

   auto symColor = skin.symbolColor;
   auto bgColor = skin.windowColor;
   auto fgColor = skin.focusColor; // or panelColor

   //QFont font = getFontAwesome( 14 );
   std::string
   msg = "###########\n"
         "###########\n"
         "###########\n"
         " \n"
         " \n"
         "###########\n"
         "###########\n"
         "###########\n"
         " \n"
         " \n"
         "###########\n"
         "###########\n"
         "###########\n"
         ;

   // [idle]
   QImage ico = createAsciiArt( symColor, fgColor, msg );
   QImage img = createCircleImage( cbs,cbs, bgColor, fgColor, ico );
   btn->setImage( 0, img );
   // [idle_hover]
   btn->setImage( 1, img );

   // [active]
   ico = createAsciiArt( skin.activeColor, fgColor, msg );
   img = createCircleImage( cbs,cbs, bgColor, fgColor, ico );
   btn->setImage( 2, img );
   // [active_hover]
   btn->setImage( 3, img );
   return btn;
}

ImageButton*
TR_Panel::createShowSessionButton()
{
   auto btn = new ImageButton( this );
   LiveSkin const & skin = m_app.m_skin;

   int cbs = skin.getInt( LiveSkin::CircleButtonSize );

   btn->setCheckable( true );
   btn->setChecked( false );

   auto symColor = skin.symbolColor;
   auto bgColor = skin.windowColor;
   auto fgColor = skin.focusColor; // or panelColor

   std::string
   msg = "###  ###  ###\n"
         "###  ###  ###\n"
         "###  ###  ###\n"
         "###  ###  ###\n"
         "###  ###  ###\n"
         "###  ###  ###\n"
         "###  ###  ###\n"
         "###  ###  ###\n"
         "###  ###  ###\n"
         ;

   // [idle]
   QImage ico = createAsciiArt( symColor, fgColor, msg );
   QImage img = createCircleImage( cbs,cbs, bgColor, fgColor, ico );
   btn->setImage( 0, img );
   // [idle_hover]
   btn->setImage( 1, img );

   // [active]
   ico = createAsciiArt( skin.activeColor, fgColor, msg );
   img = createCircleImage( cbs,cbs, bgColor, fgColor, ico );
   btn->setImage( 2, img );
   // [active_hover]
   btn->setImage( 3, img );
   return btn;
}


ImageButton*
TR_Panel::createComposeIOButton()
{
   auto btn = new ImageButton( this );
   LiveSkin const & skin = m_app.m_skin;

   int bs = skin.getInt( LiveSkin::SmallCircleButtonSize );

   btn->setCheckable( true );
   btn->setChecked( true );

   auto symColor = skin.symbolColor;
   auto bgColor = skin.panelColor;
   auto fgColor = skin.windowColor;

   std::string
   msg = "#  ###\n"
         "# #   #\n"
         "# #   #\n"
         "# #   #\n"
         "#  ###\n";

   // [idle]
   QImage ico = createAsciiArt( skin.titleColor, symColor, msg );
   QImage img = createCircleImage( bs,bs, QColor(0,0,0,0), symColor, ico );
   btn->setImage( 0, img );
   // [idle_hover]
   btn->setImage( 1, img );

   // [active]
   ico = createAsciiArt( symColor, skin.activeColor, msg );
   img = createCircleImage( bs,bs, QColor(0,0,0,0), skin.activeColor, ico );
   btn->setImage( 2, img );
   // [active_hover]
   btn->setImage( 3, img );
   return btn;
}

ImageButton*
TR_Panel::createComposeRButton()
{
   auto btn = new ImageButton( this );
   LiveSkin const & skin = m_app.m_skin;
   int bs = skin.getInt( LiveSkin::SmallCircleButtonSize );

   btn->setCheckable( true );
   btn->setChecked( true );

   auto symColor = skin.symbolColor;
   auto bgColor = skin.panelColor;
   auto fgColor = skin.windowColor;

   std::string
   msg = "####\n"
         "#   #\n"
         "####\n"
         "# #\n"
         "#  ##\n";

   // [idle]
   QImage ico = createAsciiArt( skin.titleColor, symColor, msg );
   QImage img = createCircleImage( bs,bs, QColor(0,0,0,0), symColor, ico );
   btn->setImage( 0, img );
   // [idle_hover]
   btn->setImage( 1, img );

   // [active]
   ico = createAsciiArt( symColor, skin.activeColor, msg );
   img = createCircleImage( bs,bs, QColor(0,0,0,0), skin.activeColor, ico );
   btn->setImage( 2, img );
   // [active_hover]
   btn->setImage( 3, img );
   return btn;
}

ImageButton*
TR_Panel::createComposeMButton()
{
   auto btn = new ImageButton( this );
   LiveSkin const & skin = m_app.m_skin;
   int bs = skin.getInt( LiveSkin::SmallCircleButtonSize );

   btn->setCheckable( true );
   btn->setChecked( true );

   auto symColor = skin.symbolColor;
   auto bgColor = skin.panelColor;
   auto fgColor = skin.windowColor;

   std::string
   msg = "## ##\n"
         "# # #\n"
         "# # #\n"
         "#   #\n"
         "#   #\n";

   // [idle]
   QImage ico = createAsciiArt( skin.titleColor, symColor, msg );
   QImage img = createCircleImage( bs,bs, QColor(0,0,0,0), symColor, ico );
   btn->setImage( 0, img );
   // [idle_hover]
   btn->setImage( 1, img );

   // [active]
   ico = createAsciiArt( symColor, skin.activeColor, msg );
   img = createCircleImage( bs,bs, QColor(0,0,0,0), skin.activeColor, ico );
   btn->setImage( 2, img );
   // [active_hover]
   btn->setImage( 3, img );
   return btn;
}

ImageButton*
TR_Panel::createComposeDButton()
{
   auto btn = new ImageButton( this );
   LiveSkin const & skin = m_app.m_skin;
   int bs = skin.getInt( LiveSkin::SmallCircleButtonSize );

   btn->setCheckable( true );
   btn->setChecked( false );

   auto symColor = skin.symbolColor;
   auto bgColor = skin.panelColor;
   auto fgColor = skin.windowColor;

   std::string
   msg = "####\n"
         "#   #\n"
         "#   #\n"
         "#   #\n"
         "####\n";

   // [idle]
   QImage ico = createAsciiArt( skin.titleColor, symColor, msg );
   QImage img = createCircleImage( bs,bs, QColor(0,0,0,0), symColor, ico );
   btn->setImage( 0, img );
   // [idle_hover]
   btn->setImage( 1, img );

   // [active]
   ico = createAsciiArt( symColor, skin.activeColor, msg );
   img = createCircleImage( bs,bs, QColor(0,0,0,0), skin.activeColor, ico );
   btn->setImage( 2, img );
   // [active_hover]
   btn->setImage( 3, img );
   return btn;
}
