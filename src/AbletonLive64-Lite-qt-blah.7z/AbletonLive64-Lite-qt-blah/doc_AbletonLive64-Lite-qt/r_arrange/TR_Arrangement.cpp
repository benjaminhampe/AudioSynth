#include "Arrangement.hpp"
#include "App.hpp"
#include "Draw.hpp"

// ============================================================================
Arrangement::Arrangement( App & app, QWidget* parent )
   : QWidget( parent )
   , m_app( app )
{
   setObjectName( "Arrangement" );
   setContentsMargins(0,0,0,0);
   //setMinimumWidth( 250 );

   m_hasFocus = false;
   m_isHovered = false;

   m_headHeight = 20;
   m_setHeight = 24;
   m_pinHeight = 8;
   m_trackHeight = 17;
   m_trackSpace = 2;
   m_footHeight = m_headHeight;

   m_returnA = new TR_SpurH( m_app, this );
   m_returnB = new TR_SpurH( m_app, this );
   m_master = new TR_SpurH( m_app, this );

   updateFromTrackList();

   m_app.m_trackList.setCurrentTrackId( 0 );
}

void
Arrangement::clearTracks()
{
   for ( size_t i = 0; i < m_tracks.size(); ++i )
   {
      auto p = m_tracks[ i ];
      if ( p ) delete p;
   }
   m_tracks.clear();
}

void
Arrangement::updateFromTrackList()
{
   clearTracks();

//   LiveSkin const & skin = m_app.m_skin;
//   BeatGrid const & grid = m_app.m_beatGrid;


//   Track const & track = trackList.track( i );
//   Clips const & clips = track.clips();

   TrackList const & tl = m_app.m_trackList;

   m_returnA->setTrack( tl.m_returnA );
   m_returnB->setTrack( tl.m_returnB );
   m_master->setTrack( tl.m_master );

   for ( size_t i = 0; i < tl.m_user.size(); ++i )
   {
      auto p = new TR_SpurH( m_app, this );
      p->setTrack( tl.m_user[ i ] );
      m_tracks.emplace_back( p );

   }

   updateLayout();
}


void
Arrangement::updateLayout()
{
   int w = width();
   int h = height();
   int ln = 18;

   int x = 0;
   int y = 0;

   int avail = h - 3 * ln;
   for ( int i = 0; i < m_tracks.size(); ++i )
   {
      setWidgetBounds( m_tracks[ i ], QRect( x,y,w,ln ) );
      y += ln;
   }

   setWidgetBounds( m_returnA, QRect( x,h-1 - 3*ln,w,ln ) );
   setWidgetBounds( m_returnB, QRect( x,h-1 - 2*ln,w,ln ) );
   setWidgetBounds( m_master, QRect( x,h-1 - ln,w,ln ) );
}

void
Arrangement::resizeEvent( QResizeEvent* event )
{
   updateLayout();
   QWidget::resizeEvent( event );
}

void
Arrangement::paintEvent( QPaintEvent* event )
{
   QWidget::paintEvent( event );
}

void
Arrangement::enterEvent( QEvent* event )
{
   m_isHovered = true;
   update();
   QWidget::enterEvent( event );
}
void
Arrangement::leaveEvent( QEvent* event )
{
   m_isHovered = false;
   update();
   QWidget::leaveEvent( event );
}

void
Arrangement::focusInEvent( QFocusEvent* event )
{
   m_hasFocus = true;
   update();
   QWidget::focusInEvent( event );
}

void
Arrangement::focusOutEvent( QFocusEvent* event )
{
   m_hasFocus = true;
   update();
   QWidget::focusOutEvent( event );
}



void
Arrangement::mouseMoveEvent( QMouseEvent* event )
{
   int mx = event->x();
   int my = event->y();

   updateLayout();
   QWidget::mouseMoveEvent( event );
}

void
Arrangement::mousePressEvent( QMouseEvent* event )
{
   int mx = event->x();
   int my = event->y();

   LiveSkin const & skin = m_app.m_skin;
   BeatGrid const & grid = m_app.m_beatGrid;
   TrackList const & trackList = m_app.m_trackList;

//   Track const & track = trackList.track( i );
//   Clips const & clips = track.clips();

   updateLayout();
   QWidget::mousePressEvent( event );
}

void
Arrangement::mouseReleaseEvent( QMouseEvent* event )
{
   //   int mx = event->x();
   //   int my = event->y();

   QWidget::mouseReleaseEvent( event );
}


void
Arrangement::wheelEvent( QWheelEvent* event )
{
   //   int mx = event->x();
   //   int my = event->y();
   //   me.m_wheelY = event->angleDelta().y();
   //   if ( me.m_wheelX != 0.0f )
   //   {
   //      me.m_flags |= de::MouseEvent::WheelX;
   //   }
   //   if ( me.m_wheelY != 0.0f )
   //   {
   //      me.m_flags |= de::MouseEvent::WheelY;
   //   }

   QWidget::wheelEvent( event );
}

void
Arrangement::keyPressEvent( QKeyEvent* event )
{
   //DE_DEBUG("KeyPress(",event->key(),")")
   QWidget::keyPressEvent( event );
}

void
Arrangement::keyReleaseEvent( QKeyEvent* event )
{
   //DE_DEBUG("KeyRelease(",event->key(),")")
   QWidget::keyReleaseEvent( event );
}


