#ifndef DE_LIVE_TOPRIGHT_PANEL_HPP
#define DE_LIVE_TOPRIGHT_PANEL_HPP

#include <QWidget>
#include <QImage>
#include <QTimer>
#include <QPainter>
#include <QPaintEvent>
#include <QResizeEvent>
#include <QMouseEvent>
#include <QKeyEvent>
#include <QDebug>
#include <QThread>

struct App;

//#include "ArrangePanel.hpp"
#include "TimeLineOverview.hpp"
#include "Arrangement.hpp"
//#include "ComposeBar.hpp"
#include "ImageButton.hpp"
#include "ScrollBar.hpp"

// ============================================================================
class TR_Panel : public QWidget
// ============================================================================
{
   Q_OBJECT
   //DE_CREATE_LOGGER("TR_Panel")
   App & m_app;
public:
   bool m_hasFocus;
   bool m_isHovered;

   QRect m_rcViewPanel; // Computed ( arrange + composebar = special panel )
   QRect m_rcViewContent;
   QRect m_rcComposeBar; // Computed, buttons
   QRect m_rcScrollBar; // Computed
   QRect m_rcScrollBarClient; // Computed
   QRect m_rcTimeLine;     // upper sub-rect of m_rcViewContent
   QRect m_rcArrangement;  // lower sub-rect of m_rcViewContent

   ImageButton* m_btnShowArrangement;
   ImageButton* m_btnShowSession;
   ScrollBar* m_scrollBar;
   ImageButton* m_btnComposeIO;
   ImageButton* m_btnComposeR;
   ImageButton* m_btnComposeM;
   ImageButton* m_btnComposeD;
   TimeLineOverview* m_timeLineOverview;
   Arrangement* m_arrangement;

public:
   TR_Panel( App & app, QWidget* parent = 0 );
   ~TR_Panel() override {}
signals:
public slots:
   void updateLayout();
protected:
   void paintEvent( QPaintEvent* event ) override;
   void resizeEvent( QResizeEvent* event ) override;
   void enterEvent( QEvent* event ) override;
   void leaveEvent( QEvent* event ) override;
   void focusInEvent( QFocusEvent* event ) override;
   void focusOutEvent( QFocusEvent* event ) override;
   //void mousePressEvent( QMouseEvent* event ) override;
   //void mouseReleaseEvent( QMouseEvent* event ) override;
   //void mouseMoveEvent( QMouseEvent* event ) override;
   //void wheelEvent( QWheelEvent* event ) override;
   //void keyPressEvent( QKeyEvent* event ) override;
   //void keyReleaseEvent( QKeyEvent* event ) override;
   //void hideEvent( QHideEvent* event ) override;
   //void showEvent( QShowEvent* event ) override;
private:
   ImageButton* createShowArrangementButton();
   ImageButton* createShowSessionButton();
   ImageButton* createScrollUpButton();
   ImageButton* createScrollDownButton();
   ImageButton* createComposeIOButton();
   ImageButton* createComposeRButton();
   ImageButton* createComposeMButton();
   ImageButton* createComposeDButton();
};

#endif // DE_Q_IMAGEWIDGET_HPP
