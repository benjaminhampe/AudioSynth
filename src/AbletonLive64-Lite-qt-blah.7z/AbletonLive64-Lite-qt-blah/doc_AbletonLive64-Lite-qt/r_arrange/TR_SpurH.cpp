#include "TR_SpurH.hpp"
#include "App.hpp"
#include "Draw.hpp"

// ============================================================================
TR_SpurH::TR_SpurH( App & app, QWidget* parent )
   : QWidget( parent )
   , m_app( app )
   , m_track( nullptr )
{
   setObjectName( "TR_SpurH" );
   setContentsMargins(0,0,0,0);

   m_hasFocus = false;
   m_isHovered = false;
   m_isSelected = false;

   m_trackWidth = 17;
   m_trackHeight = 17;

   connect( &m_app.m_trackList, SIGNAL(currentTrackIdChanged(int)),
           this, SLOT(on_currentTrackIdChanged(int)) );
}

void
TR_SpurH::on_currentTrackIdChanged( int trackId )
{
   m_isSelected = ((m_track ? m_track->id() : -1) == trackId );
   update();
}

void
TR_SpurH::setTrack( Track* track )
{
   m_track = track;
   updateFromTrack();
}

void
TR_SpurH::updateFromTrack()
{
   updateLayout();
}

void
TR_SpurH::updateLayout()
{
   //LiveSkin const & skin = m_app.m_skin;
   //BeatGrid const & grid = m_app.m_beatGrid;
   TrackList const & trackList = m_app.m_trackList;

   //Track const & track = trackList.track( i );
   //Clips const & clips = track.clips();
   update();
}

void
TR_SpurH::resizeEvent( QResizeEvent* event )
{
   updateLayout();
   QWidget::resizeEvent( event );
}

void
TR_SpurH::paintEvent( QPaintEvent* event )
{
   int w = width();
   int h = height();

   if ( w > 1 && h > 1 )
   {
      if ( m_track )
      {
         LiveSkin const & skin = m_app.m_skin;

         QPainter dc( this );
         dc.setRenderHint( QPainter::NonCosmeticDefaultPen );

         if ( m_isSelected )
         {
            drawRectFill( dc, rect(), skin.activeColor );
         }
         else
         {
            drawRectFill( dc, rect(), skin.contentColor );
         }

         drawLine( dc, 0,0,w-1,0, skin.panelColor );

         {
         int x = 2; // grid.time2pixel( i );
         int y = 2; // y + m_headHeight - 1 - 8;
         drawText( dc,x,y, m_track->m_isAudioOnly ? "AudioFx only" : "MIDI + AudioFx" );
         }

         int x = w - 100; // grid.time2pixel( i );
         int y = 2; // y + m_headHeight - 1 - 8;
         drawText( dc,x,y, QString::fromStdWString( m_track->m_name ) );
      }
   /*
   // Draw background
   int y = 0;
   int pxPerBeat = grid.time2pixel( 1 );
   int k = float( w ) / float( pxPerBeat );
   // Draw beat indices
   dc.fillRect( QRect(0,0,w-1,m_headHeight), skin.panelColor );
   dc.setBrush( Qt::NoBrush );
   dc.setPen( QPen( skin.windowColor ) );
   dc.setFont( QFont("Arial Black", 8) );
   for ( int i = 0; i < k; ++i )
   {
      int x = grid.time2pixel( i );
      int y1 = y + m_headHeight - 1 - 8;
      int y2 = y + m_headHeight - 2;
      drawLine( dc, x, y1, x, y2, skin.windowColor );
      drawLine( dc, x, y1, x+2, y1, skin.windowColor );

      dc.drawText( x + 4, y2-2, QString::number( i ) );
   }
   y += m_headHeight;

   // Draw ContentRect
   QRect r_content(0,m_headHeight,w,h-m_headHeight-m_footHeight);
   dc.fillRect( r_content, skin.contentColor );


   // Draw BeatGrid
   for ( int i = 0; i < k; ++i )
   {
      int x = grid.time2pixel( i );
      int y1 = m_headHeight;
      int y2 = h - 1 - m_headHeight - m_footHeight;
      drawLine( dc, x, y1, x, y2, skin.panelColor );

      x = grid.time2pixel( double(i)+0.5 );
      drawLine( dc, x, y1, x, y2, skin.semiBeatColor );

      dc.drawText( x + 7, y2-2, QString::number( i ) );
   }

   // Draw TimePin
   y = m_headHeight + m_setHeight;
   dc.fillRect( QRect(0,y,w-1,m_pinHeight), skin.panelColor );
   y += m_pinHeight;

   // Draw tracks
   for ( int i = 0; i < trackList.trackCount(); ++i )
   {
      // highlight #3
      if ( i == m_focusedTrack )
      {
         dc.fillRect( QRect(0,y,w-1,m_trackHeight), skin.editBoxColor );
      }

      Track const & track = trackList.track( i );
      Clips const & clips = track.clips();
      for ( int c = 0; c < clips.size(); ++c )
      {
         Clip const & clip = clips[ c ];
         int x1 = grid.time2pixel( clip.m_timeBeg );
         int x2 = grid.time2pixel( clip.m_timeEnd )-1;
         dc.setBrush( QBrush( toQColor( clip.m_color ) ) );
         dc.setPen( QPen( QColor(0,0,0) ) );
         dc.drawRect( QRect( x1, y+1, x2-x1, m_trackHeight-3 ) );
      }

      y += m_trackHeight;

      dc.fillRect( QRect(0,y,w-1,m_trackSpace), skin.panelColor );
      y += m_trackSpace;
   }
  */
   }

   QWidget::paintEvent( event );
}


void
TR_SpurH::dropEvent( QDropEvent* event )
{
   std::cout << __func__ << std::endl;
   std::cout << event->mimeData()->text().toStdString() << std::endl;

   std::wstring uri = event->mimeData()->text().toStdWString();

   if ( m_track )
   {
      m_track->addPlugin( uri );
   }

   event->acceptProposedAction();
}

void
TR_SpurH::dragEnterEvent( QDragEnterEvent* event )
{
   if ( event->mimeData()->hasFormat("text/plain") )
   {
      event->acceptProposedAction();
   }
   std::cout << __func__ << std::endl;
}

void
TR_SpurH::dragLeaveEvent( QDragLeaveEvent* event )
{
   std::cout << __func__ << std::endl;
}

void
TR_SpurH::dragMoveEvent( QDragMoveEvent* event )
{
   std::cout << __func__ << std::endl;
}


void
TR_SpurH::enterEvent( QEvent* event )
{
   m_isHovered = true;
   update();
   QWidget::enterEvent( event );
}
void
TR_SpurH::leaveEvent( QEvent* event )
{
   m_isHovered = false;
   update();
   QWidget::leaveEvent( event );
}

void
TR_SpurH::focusInEvent( QFocusEvent* event )
{
   m_hasFocus = true;
   update();
   QWidget::focusInEvent( event );
}

void
TR_SpurH::focusOutEvent( QFocusEvent* event )
{
   m_hasFocus = true;
   update();
   QWidget::focusOutEvent( event );
}



void
TR_SpurH::mouseMoveEvent( QMouseEvent* event )
{
   int mx = event->x();
   int my = event->y();

   updateLayout();
   QWidget::mouseMoveEvent( event );
}

void
TR_SpurH::mousePressEvent( QMouseEvent* event )
{
   int mx = event->x();
   int my = event->y();

   if ( m_isHovered )
   {
      if ( m_track && m_track->id() != m_app.m_trackList.currentId() )
      {
         m_app.m_trackList.setCurrentTrackId( m_track->id() );
         m_app.showSpurEditor();
      }
   }

   LiveSkin const & skin = m_app.m_skin;
   BeatGrid const & grid = m_app.m_beatGrid;
   TrackList const & trackList = m_app.m_trackList;

//   Track const & track = trackList.track( i );
//   Clips const & clips = track.clips();

   updateLayout();
   QWidget::mousePressEvent( event );
}

void
TR_SpurH::mouseReleaseEvent( QMouseEvent* event )
{
   //   int mx = event->x();
   //   int my = event->y();

   QWidget::mouseReleaseEvent( event );
}


void
TR_SpurH::wheelEvent( QWheelEvent* event )
{
   //   int mx = event->x();
   //   int my = event->y();
   //   me.m_wheelY = event->angleDelta().y();
   //   if ( me.m_wheelX != 0.0f )
   //   {
   //      me.m_flags |= de::MouseEvent::WheelX;
   //   }
   //   if ( me.m_wheelY != 0.0f )
   //   {
   //      me.m_flags |= de::MouseEvent::WheelY;
   //   }

   QWidget::wheelEvent( event );
}

void
TR_SpurH::keyPressEvent( QKeyEvent* event )
{
   //DE_DEBUG("KeyPress(",event->key(),")")
   QWidget::keyPressEvent( event );
}

void
TR_SpurH::keyReleaseEvent( QKeyEvent* event )
{
   //DE_DEBUG("KeyRelease(",event->key(),")")
   QWidget::keyReleaseEvent( event );
}

/*

void
Arrangement::drawTrack( QPainter & dc, QRect const & rect, Track const & track )
{
   //if ( !track ) return;

   LiveSkin const & skin = m_app.m_skin;

   if ( &track == m_app.m_trackList.current() )
   {
      drawRectFill( dc, rect, skin.activeColor );
   }
   else
   {
      drawRectFill( dc, rect, skin.contentColor );
   }

   int x = rect.topLeft().x() + rect.width() - 100; // grid.time2pixel( i );
   int y = rect.topLeft().y() + 1; // y + m_headHeight - 1 - 8;
   drawText( dc,x,y, QString::fromStdWString( track.m_name ) );
}

int w = width();
int h = height();

if ( w > 1 && h > 1 )
{
   LiveSkin const & skin = m_app.m_skin;
   BeatGrid const & grid = m_app.m_beatGrid;
   TrackList const & trackList = m_app.m_trackList;

   QPainter dc( this );
   dc.setRenderHint( QPainter::NonCosmeticDefaultPen );


   // Draw tracks
   //auto const * ctrack = m_app.m_trackList.current();
   auto const & tracks = m_app.m_trackList.tracks();

   int avail = h - 3 * 18;
   int x = 0;
   int y = 100;

   for ( int i = 0; i < tracks.size(); ++i )
   {
      auto const & track = tracks[ i ];
      drawTrack( dc, QRect( x,y,w,17 ), track ); y += 17 + 1;

   }

   auto const & rA = m_app.m_trackList.m_returnA;
   drawTrack( dc, QRect( x,h - 1-3*18,w,17 ), rA );

   auto const & rB = m_app.m_trackList.m_returnB;
   drawTrack( dc, QRect( x,h - 1-2*18,w,17 ), rB );

   auto const & master = m_app.m_trackList.m_master;
   drawTrack( dc, QRect( x,h - 1-18,w,17 ), master );


   // Draw background
   int y = 0;
   int pxPerBeat = grid.time2pixel( 1 );
   int k = float( w ) / float( pxPerBeat );
   // Draw beat indices
   dc.fillRect( QRect(0,0,w-1,m_headHeight), skin.panelColor );
   dc.setBrush( Qt::NoBrush );
   dc.setPen( QPen( skin.windowColor ) );
   dc.setFont( QFont("Arial Black", 8) );
   for ( int i = 0; i < k; ++i )
   {
      int x = grid.time2pixel( i );
      int y1 = y + m_headHeight - 1 - 8;
      int y2 = y + m_headHeight - 2;
      drawLine( dc, x, y1, x, y2, skin.windowColor );
      drawLine( dc, x, y1, x+2, y1, skin.windowColor );

      dc.drawText( x + 4, y2-2, QString::number( i ) );
   }
   y += m_headHeight;

   // Draw ContentRect
   QRect r_content(0,m_headHeight,w,h-m_headHeight-m_footHeight);
   dc.fillRect( r_content, skin.contentColor );


   // Draw BeatGrid
   for ( int i = 0; i < k; ++i )
   {
      int x = grid.time2pixel( i );
      int y1 = m_headHeight;
      int y2 = h - 1 - m_headHeight - m_footHeight;
      drawLine( dc, x, y1, x, y2, skin.panelColor );

      x = grid.time2pixel( double(i)+0.5 );
      drawLine( dc, x, y1, x, y2, skin.semiBeatColor );

      dc.drawText( x + 7, y2-2, QString::number( i ) );
   }

   // Draw TimePin
   y = m_headHeight + m_setHeight;
   dc.fillRect( QRect(0,y,w-1,m_pinHeight), skin.panelColor );
   y += m_pinHeight;

   // Draw tracks
   for ( int i = 0; i < trackList.trackCount(); ++i )
   {
      // highlight #3
      if ( i == m_focusedTrack )
      {
         dc.fillRect( QRect(0,y,w-1,m_trackHeight), skin.editBoxColor );
      }

      Track const & track = trackList.track( i );
      Clips const & clips = track.clips();
      for ( int c = 0; c < clips.size(); ++c )
      {
         Clip const & clip = clips[ c ];
         int x1 = grid.time2pixel( clip.m_timeBeg );
         int x2 = grid.time2pixel( clip.m_timeEnd )-1;
         dc.setBrush( QBrush( toQColor( clip.m_color ) ) );
         dc.setPen( QPen( QColor(0,0,0) ) );
         dc.drawRect( QRect( x1, y+1, x2-x1, m_trackHeight-3 ) );
      }

      y += m_trackHeight;

      dc.fillRect( QRect(0,y,w-1,m_trackSpace), skin.panelColor );
      y += m_trackSpace;
   }
}
*/
