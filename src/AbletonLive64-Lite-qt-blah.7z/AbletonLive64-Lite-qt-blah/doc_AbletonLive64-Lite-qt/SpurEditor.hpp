/// (c) 2017 - 20180 Benjamin Hampe <benjaminhampe@gmx.de>

#ifndef DE_LIVE_AUDIO_CHAIN_EDITOR_HPP
#define DE_LIVE_AUDIO_CHAIN_EDITOR_HPP

#include "LiveSkin.hpp"
#include <de/live/Engine.hpp>
#include "MidiMeter.hpp"
#include "AudioMeter.hpp"
#include "SpurDummy.hpp"

struct App;

// A MixerItem is a DSP chain
// audio only with only chain of audio fx effects in AudioPlugin format benni or VST.
// with optional MIDI effects + Midi2Audio Synthesizer (VST) + and or Audio fx effects (VST).
// ============================================================================
struct ChainEditor : public QWidget
// ============================================================================
{
   Q_OBJECT
   DE_CREATE_LOGGER("ChainEditor")
   App & m_app;
   bool m_hasFocus;
   de::audio::Chain* m_chain;
//   de::audio::IDspChainElement* m_inputSignal;
//   // MidiEffectProcessors < only for MidiTrack >
//   std::vector< de::audio::IMidiChainElement* > m_midiEffects;// the rest of the audio chain is a series of effects.
//   std::vector< PluginVST24* > m_audioEffects;
//   PluginVST24* m_audioSynth; // The linking element between MIDI and Audio chain, either a Player or Synthesizer
//   de::audio::IDspChainElement* m_audioEnd;    // AudioChainEnd, for convenience to auto-connect end with a mixer


   MidiMeter* m_midiMeter;
   SpurDummy* m_dummy;

public:
   ChainEditor( App & app, QWidget* parent = nullptr )
      : QWidget( parent )
      , m_app( app )
      , m_hasFocus( false )
      , m_chain( nullptr )
   {
      setObjectName( "ChainEditor" );
      setContentsMargins( 0,0,0,0 );
      setMouseTracking( true );
      setAcceptDrops( true );

      m_midiMeter = new MidiMeter( m_app, this );
      m_dummy = new SpurDummy( m_app, this );

      m_dummy->setAudioOnly( false );

   //   connect( &m_app.m_trackList, SIGNAL(currentTrackChanged(Track*)),
   //           this, SLOT(on_currentTrackChanged(Track*)) );

   }

   ~ChainEditor() override {}

signals:
public slots:
   void setChain( de::audio::Chain* chain );
   void updateFromChain();
   //void updateLayout();
protected:
   //void resizeEvent( QResizeEvent* event );
   //void paintEvent( QPaintEvent* event );
   void dropEvent( QDropEvent* event );
   //void dragEnterEvent( QDragEnterEvent* event );
   //void dragLeaveEvent( QDragLeaveEvent* event );
   //void dragMoveEvent(QDragMoveEvent* event );
};

#endif
