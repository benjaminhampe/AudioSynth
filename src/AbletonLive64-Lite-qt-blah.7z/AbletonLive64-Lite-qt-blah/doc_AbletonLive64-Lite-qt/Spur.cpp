/// (c) 2017 - 20180 Benjamin Hampe <benjaminhampe@gmx.de>

#include "Spur.hpp"

namespace de {
namespace audio {

void
Spur::aboutToStart( uint32_t dstFrames, uint32_t dstChannels, uint32_t dstRate )
{
   uint64_t dstSamples = dstFrames * dstChannels;
   //DSP_RESIZE( m_inputBuffer, dstSamples );
}

uint64_t
Spur::readSamples( double pts, float* dst, uint32_t dstFrames, uint32_t dstChannels, uint32_t dstRate )
{
   uint64_t dstSamples = dstFrames * dstChannels;
   if ( !m_isBypassed && m_audioEnd )
   {
      m_audioEnd->readSamples( pts, dst, dstFrames, dstChannels, dstRate );
   }
   else
   {
      de::audio::DSP_FILLZERO( dst, dstSamples );
   }
   return dstSamples;
}

bool
Spur::addPlugin( std::wstring uri )
{
   int found = m_app.m_pluginDb.find( uri );
   if ( found < 0 )
   {
      std::wcout << "Spur::addPlugin() - Plugin not in db " << uri << std::endl;
   }

   if ( m_isAudioOnly && m_app.m_pluginDb.isSynth( uri ) )
   {
      std::wcout << "Spur::addPlugin() - Audio only cant add synth " << uri << std::endl;
      return false;
   }

   m_isBypassed = true;

   PluginVST24* vst = new PluginVST24( m_app, this );
   if ( !vst->openPlugin( uri ) )
   {
      std::wcout << "Cant open vst plugin " << uri << std::endl;
      delete vst;
      vst = nullptr;
      return false;
   }

   bool isSynth = vst->isSynth();
   if ( isSynth )
   {
      DE_DEBUG("Plugin is synth" )

      if ( m_audioSynth )
      {
         DE_DEBUG("Replace synthesizer")
         delete m_audioSynth;
      }
      else
      {
         DE_DEBUG("Add synthesizer")
      }

      m_audioSynth = vst;
   }
   else
   {
      DE_DEBUG("Plugin is audio effect ", m_audioEffects.size() )
      m_audioEffects.emplace_back( vst );
   }

   bool ok = updateDspChain();
   if ( !ok )
   {
      DE_ERROR("Cant reconnect DspChain")
   }
   m_isBypassed = false;

   updateLayout();

   return true;
}

bool
Spur::updateDspChain()
{
   bool wasBypassed = m_isBypassed;
   m_isBypassed = true;

   if ( m_isAudioOnly )
   {
      DE_DEBUG("Connect audio only spur :: inputSignal -> ")
      if ( m_audioSynth )
      {
         DE_ERROR("Error synthesizer found and bypassed")
      }

      m_audioEnd = m_inputSignal;
   }
   else
   {
      if ( m_inputSignal )
      {
         DE_ERROR("Got inputSignal and synthesizer, nothing connected (yet)")
      }

      m_audioEnd = m_audioSynth;

      if ( !m_audioSynth )
      {
         DE_ERROR("No synthesizer to connect")
         m_audioEnd = m_inputSignal;
      }
   }

   // Connect dsp chain

   for ( int i = 0; i < m_audioEffects.size(); ++i )
   {
      auto fx = m_audioEffects[ i ];
      fx->setInputSignal( 0, m_audioEnd );
      m_audioEnd = fx;
   }

   // if ( m_audioSynth )
   // {
      // m_app.updateSynthesizer();
   // }

   m_isBypassed = wasBypassed;
   return m_audioEnd != nullptr;
}





} // end namespace audio
} // end namespace de











/*
// A Spur is a MIDI effect chain + Audio DSP chain ( VST modules ).
// ============================================================================
struct Spur : public de::audio::IDspChainElement
// ============================================================================
{
   DE_CREATE_LOGGER("Track")

   bool isAudioOnly;
   bool m_isBypassed;
   std::vector< PluginVST24* > m_plugins;
   // MidiEffectProcessors < only for MidiTrack >
   std::vector< de::audio::IMidiChainElement* > m_midiEffects;
   std::vector< de::audio::IDspChainElement* > m_audioEffects; // the rest of the audio chain is a series of effects.

   de::audio::IDspChainElement* m_audioStart; // The linking element between MIDI and Audio chain, either a Player or Synthesizer
   de::audio::IDspChainElement* m_audioEnd;    // AudioChainEnd, for convenience to auto-connect end with a mixer

   Spur() { reset(); }
   ~Spur() {}

   void clear()
   {
      reset();
   }

   void reset()
   {
      isAudioOnly = false;    // Can have Midi Effects and Audio Synthesizer, true = only Audio Effects after AudioPlayer
      m_isBypassed = false;
      m_audioStart = nullptr;
      m_audioEnd = nullptr;
      m_midiEffects.clear();;
      m_audioEffects.clear();
   }

   bool
   isBypassed() const { return m_isBypassed; }

   void
   setBypassed( bool bypassed ) { m_isBypassed = bypassed; }

   void
   aboutToStart( uint32_t dstFrames, uint32_t dstChannels, uint32_t dstRate ) override
   {
      uint64_t dstSamples = dstFrames * dstChannels;
      //DSP_RESIZE( m_inputBuffer, dstSamples );
   }

   uint64_t
   readSamples( double pts, float* dst, uint32_t dstFrames, uint32_t dstChannels, uint32_t dstRate ) override
   {
      uint64_t dstSamples = dstFrames * dstChannels;
      if ( !m_isBypassed && m_audioEnd )
      {
         m_audioEnd->readSamples( pts, dst, dstFrames, dstChannels, dstRate );
      }
      else
      {
         de::audio::DSP_FILLZERO( dst, dstSamples );
      }
      return dstSamples;
   }

   bool
   addPlugin( de::audio::IDspChainElement* plugin, bool reconnect = true )
   {
      if ( !plugin ) return false;

      m_isBypassed = true;

      DE_DEBUG("isSynth = ", plugin->isSynth() )

      if ( plugin->isSynth() )
      {
         // replace synthesizer
         if ( m_audioStart )
         {
            DE_DEBUG("Replace synthesizer")
            delete m_audioStart;
         }
         else
         {
            DE_DEBUG("Add synthesizer")
         }

         m_audioStart = plugin;
      }
      else
      {
         m_audioEffects.emplace_back( plugin );
         DE_DEBUG("Added VST audio effect plugin ", m_audioEffects.size() )
      }

      bool ok = reconnectDspChain();
      if ( !ok )
      {
         DE_ERROR("Cant reconnect DspChain")
      }
      m_isBypassed = false;
      return true;
   }

   bool reconnectDspChain()
   {
      m_audioEnd = nullptr;

      if ( !m_audioStart )
      {
         if ( isAudioOnly )
         {
            DE_ERROR("No player to connect")
         }
         else
         {
            DE_ERROR("No synthesizer to connect")
         }
         return false;
      }

      // Connect dsp chain
      m_audioEnd = m_audioStart;
      for ( int i = 0; i < m_audioEffects.size(); ++i )
      {
         auto fx = m_audioEffects[ i ];
         fx->setInputSignal( 0, m_audioEnd );
         m_audioEnd = fx;
      }

      return m_audioEnd != nullptr;
   }

};
*/
