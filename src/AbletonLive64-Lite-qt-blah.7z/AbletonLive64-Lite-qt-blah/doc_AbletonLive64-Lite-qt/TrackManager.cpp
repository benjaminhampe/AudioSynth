#include "TrackManager.hpp"
#include "App.hpp"

TrackManager::TrackManager( App & app, QWidget* parent )
   : QWidget( parent )
   , m_app( app )
   , m_isBypassed( false )
   , m_currentTrackId( -1 )
   , m_master( nullptr )
{
   setObjectName( "TrackManager" );
   setContentsMargins( 0,0,0,0 );
   setMouseTracking( true );
   setMinimumHeight( 190 );
   setMaximumHeight( 190 );
   //setAcceptDrops( true );

   m_stack = new QStackedWidget( this );

   auto v = new QVBoxLayout;
   v->setContentsMargins(0,0,0,0);
   v->setSpacing(0);
   v->addWidget( m_stack );
   setLayout( v );

//   connect(pageComboBox, SIGNAL(activated(int)),
//        stackedWidget, SLOT(setCurrentIndex(int)));

   connect( this, SIGNAL(currentTrackIdChanged(int)),
            this, SLOT(on_currentTrackIdChanged(int)) );

}

TrackManager::~TrackManager()
{
   clear();
}

void
TrackManager::clear()
{
   m_currentTrackId = -1;
   m_master = nullptr;
   m_returns.clear();
   m_user.clear();
   m_userAudio.clear();
   m_userMidi.clear();

   for ( size_t i = 0; i < m_tracks.size(); ++i )
   {
      auto p = m_tracks[ i ];
      if ( p ) delete p;
   }
   m_tracks.clear();
}

void
TrackManager::setCurrentTrackId( int trackId )
{
   auto oldId = m_currentTrackId;
   m_currentTrackId = trackId;
   if ( oldId != trackId )
   {
      emit currentTrackIdChanged( trackId );
   }
}

void
TrackManager::on_currentTrackIdChanged( int trackId )
{
   m_stack->setCurrentIndex( findTrack( trackId ) );
}

//void
//TrackManager::createFromTracks()
//{
//   for ( auto & track : m_app.tracks() )
//   {
//      //auto chain = m_app.m_engine.m_network.m_chains[ i ];
//      if ( track )
//      {
//         auto editor = new SpurEditor( m_app, this );
//         editor->setTrack( track );
//         m_stack->addWidget( editor ); // Qt controls spur deletion now!
//         //track->m_ownedAndDeletedByQt = true;
//      }
//   }
//}



/*
void
TrackManager::createDefault()
{
   clear();
   addTrack( 0, "Master", eTrackMaster );
   addTrack( 1000, "A - Return", eTrackReturn );
   addTrack( 1001, "B - Return", eTrackReturn );
   addTrack( 2000, "1 - Audio", eTrackAudio );
   addTrack( 2001, "2 - Audio", eTrackAudio );
   addTrack( 3001, "3 - Midi", eTrackMidi );
   addTrack( 3002, "4 - Midi", eTrackMidi );
   addTrack( 3003, "5 - Midi", eTrackMidi );
   setCurrentTrackId( 0 );
}

bool
TrackManager::addTrack( int id, std::string name, eTrackType type )
{
   auto p = new Track( m_app, this );
   p->m_trackId = id;
   p->m_name = name;
   p->m_type = type;
   bool ok = addTrack( p );
   if ( !ok && p )
   {
      delete p;
   }
   return ok;
}

bool
TrackManager::addTrack( Track* track )
{
   if ( !track ) return false;

   int id = track->m_trackId;
   int found = findTrack( id );
   if (found > -1)
   {
      DE_ERROR("Track id ",id," already exist")
      return false;
   }

   // 0 = master, 1 = return, 2 = audio-only, 3 = midi+audio
   auto tt = track->m_type;
   if ( tt == eTrackMaster )
   {
      m_master = track;
   }
   else if ( tt == eTrackReturn )
   {
      m_returns.emplace_back( track );
   }
   else if ( tt == eTrackAudio )
   {
      m_user.emplace_back( track );
      m_userAudio.emplace_back( track );
   }
   else if ( tt == eTrackMidi )
   {
      m_user.emplace_back( track );
      m_userMidi.emplace_back( track );
   }

   m_tracks.emplace_back( track );
   m_stack->addWidget( track );
   return true;
}

void
TrackManager::updateDspChain()
{
   //bool wasPlaying = m_audioEndPoint.isPlaying();
   if ( !m_master )
   {
      DE_ERROR( "No m_master" )
   }

   m_app.stopAudioMaster();
   while ( m_app.isAudioMasterPlaying() )
   {
      std::cout << "Waiting for AudioMaster to stop..." << std::endl;
   }

   //m_mixer.m_isBypassed = true;

   auto nUser = m_user.size();
   if ( m_userMixer.getInputSignalCount() < nUser )
   {
      std::cout << "App::updateDspChain() :: nUser = " << nUser << std::endl;
      m_userMixer.resize( nUser );
   }

   auto nReturn = m_returns.size();
   if ( m_returnMixer.getInputSignalCount() < nReturn )
   {
      std::cout << "App::updateDspChain() :: nReturn = " << nReturn << std::endl;
      m_returnMixer.resize( nReturn );
   }

   size_t k = 0;
   for ( auto & track : m_user )
   {
      if ( !track ) continue;
      m_userMixer.setInputSignal( k, track );
      k++;
   }

   k = 0;
   for ( auto & track : m_returns )
   {
      if ( !track ) continue;
      m_returnMixer.setInputSignal( k, track );
      k++;
   }

   m_app.m_master.setInputSignal( 0, &m_userMixer );

   //m_app.m_master.setInputSignal( 0, &m_userMixer );

//   auto master = m_trackList.m_master->m_Chain;
//   master->setInputSignal( 0, &m_mixer );
//   m_audioEndPoint.setInputSignal( 0, master );

   //m_mixer.m_isBypassed = false;

//   if ( wasPlaying )
//   {
//      m_audioEndPoint.play();
//   }
}

bool
TrackManager::save() const
{
   dbRemoveFile( m_uri );

   tinyxml2::XMLDocument doc;
   tinyxml2::XMLElement* root = doc.NewElement( "tracks" );
   root->SetAttribute( "count", int( m_tracks.size() ) );

   for ( auto track : m_tracks )
   {
      if ( !track ) continue;
      track->writeXML( doc, root );
   }

   doc.InsertEndChild( root );

   auto e = doc.SaveFile( m_uri.c_str() );
   if ( e != tinyxml2::XML_SUCCESS )
   {
      std::cout << "Cant save <tracks> xml " << m_uri << ", e = " << int(e) << std::endl;
      return false;
   }

   auto n = m_tracks.size();
   std::cout <<"Saved <tracks> xml " << m_uri << " with " << n << " tracks" << std::endl;
   return true;
}

bool
TrackManager::load()
{
   tinyxml2::XMLDocument doc;
   auto e = doc.LoadFile( m_uri.c_str() );
   if ( e != tinyxml2::XML_SUCCESS )
   {
      std::cout << "Cant load <tracks> xml " << m_uri << std::endl;
      return false;
   }

   tinyxml2::XMLElement* tracks = doc.FirstChildElement( "tracks" );
   if ( !tracks )
   {
      std::cout << "No <tracks> tag in xml " << m_uri << std::endl;
      return false;
   }

   int m_checkSum = tracks->IntAttribute( "count" );

   clear();

   int k = 0;

   // Read first child <PluginInfo> of parent <PluginInfoList>
   tinyxml2::XMLElement* trackNode = tracks->FirstChildElement( "track" );
   if ( !trackNode )
   {
      std::cout << "No <track> in <tracks> xml " << m_uri << std::endl;
      return false;
   }
   else
   {
      // Read all next children <PluginInfo> of parent <PluginInfoList>
      while ( trackNode )
      {
         auto track = new Track( m_app, this );
         if ( track->readXML( k, trackNode ) )
         {
            bool ok = addTrack( track );
            if ( !ok )
            {
               DE_ERROR("No <track> added")
               delete track;
            }
            else
            {
               k++;
            }
         }
         else
         {
            DE_ERROR("Got <track> read error")
            delete track;
         }
         trackNode = trackNode->NextSiblingElement( "track" );
      }
   }

   std::cout <<"<tracks> OK loaded. " << m_uri << std::endl;
   //std::cout << "[loadXml] dir = " << m_vstDirMB << std::endl;
   std::cout << "<tracks> expect <track> tags = " << m_checkSum << std::endl;
   std::cout << "<tracks> loaded <track> tags = " << k << std::endl;

   return true;
}

void TrackManager::dropEvent( QDropEvent* event )
{
   std::cout << __func__ << std::endl;
   std::cout << event->mimeData()->text().toStdString() << std::endl;

   std::wstring uri = event->mimeData()->text().toStdWString();

   auto spurEditor = (SpurEditor*)m_stack->currentWidget();
   if ( spurEditor )
   {
      spurEditor->addPlugin( uri );
   }

   update();

   event->acceptProposedAction();
}


void
TrackManager::setSpur( Spur * spur )
{
  m_spur = spur;
  if ( m_spur )
  {
     setWidgetBounds( m_spur, rect() );
     m_spur->show();
  }
}

void
TrackManager::resizeEvent( QResizeEvent* event )
{
   updateLayout();
   QWidget::resizeEvent( event );
}

void TrackManager::paintEvent( QPaintEvent* event )
{
//   int w = width();
//   int h = height();

//   if ( w > 0 && h > 0 )
//   {
//      QPainter dc( this );
//      dc.setRenderHint( QPainter::NonCosmeticDefaultPen );
//      dc.fillRect( rect(), QColor(255,127,25) );
//   }

   QWidget::paintEvent( event );
}

void TrackManager::dropEvent( QDropEvent* event )
{
   std::cout << __func__ << std::endl;
   std::cout << event->mimeData()->text().toStdString() << std::endl;

   std::wstring uri = event->mimeData()->text().toStdWString();

   m_spur->add
   PluginVST24* plugin = new PluginVST24( m_app, this );
   if ( plugin->openPlugin( uri ) )
   {
      m_plugins.emplace_back( plugin );
      updateDspChain();
   }
   else
   {
      std::wcout << "Cant open plugin " << uri << std::endl;
      delete plugin;
   }

   update();

   event->acceptProposedAction();
}

void TrackManager::dragEnterEvent( QDragEnterEvent* event )
{
   if ( event->mimeData()->hasFormat("text/plain") )
   {
      event->acceptProposedAction();
   }
   std::cout << __func__ << std::endl;
}

void TrackManager::dragLeaveEvent( QDragLeaveEvent* event )
{
   std::cout << __func__ << std::endl;
}

void TrackManager::dragMoveEvent(QDragMoveEvent* event )
{
   std::cout << __func__ << std::endl;
}

void
TrackManager::focusInEvent( QFocusEvent* event )
{
   m_hasFocus = true;
   update();
   QWidget::focusInEvent( event );
}

void
TrackManager::focusOutEvent( QFocusEvent* event )
{
   m_hasFocus = true;
   update();
   QWidget::focusOutEvent( event );
}

void
TrackManager::enterEvent( QEvent* event )
{
   QWidget::enterEvent( event );
}

void
TrackManager::leaveEvent( QEvent* event )
{
   QWidget::leaveEvent( event );
}

*/
