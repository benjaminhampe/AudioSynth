#ifndef DE_LIVE_PLUGIN_VST2X_HPP
#define DE_LIVE_PLUGIN_VST2X_HPP

#include "LiveSkin.hpp"
#include "ImageButton.hpp"
#include "Meter.hpp"

#include <de/audio/plugin/IPlugin.hpp>

struct App;

// ============================================================================
class PluginEditorWindow : public QWidget
// ============================================================================
{
   Q_OBJECT
   bool m_enableClosing;
public:
   PluginEditorWindow( QWidget* parent = 0 ) : QWidget( parent ), m_enableClosing(false) {}
   ~PluginEditorWindow() override {}
signals:
   void closed();
public slots:
   void enableClosing() { m_enableClosing = true; }
   void disableClosing() { m_enableClosing = false; }
protected:
   void closeEvent( QCloseEvent* event ) override
   {
      if ( !m_enableClosing ) { event->ignore(); }
      hide();
      emit closed();
      //event->
   }
};

// ============================================================================
class PluginEditor : public QWidget
// ============================================================================
{
   Q_OBJECT
public:
   PluginEditor( App & m_app, QWidget* parent );
   ~PluginEditor();
   bool isBypassed() const { return !m_btnEnabled->isChecked(); }
signals:
public slots:
   void updateFromPlugin();
   void updateLayout();
   void setPlugin( de::audio::IPlugin* plugin );
   void setBypassed( bool bypassed )
   {
      m_btnEnabled->blockSignals( true );
      m_btnEnabled->setChecked( !bypassed );
      if ( m_plugin )
      {
         m_plugin->setBypassed( bypassed );
      }
      m_btnEnabled->blockSignals( false );
   }
   void setVisibleMore( bool visible )
   {
      m_btnMore->setChecked( visible );
   }
   void setVisibleEditor( bool visible )
   {
      m_btnEditor->setChecked( visible );
   }

protected slots:
   void resizeEditor( QRect const & clientRc );

   void on_focusChanged( bool focused );
   void on_bypassed( bool bypassed );
   void on_visibleMore( bool visible );
   void on_visibleEditor( bool visible );
   void on_editorClosed();
   //void on_loadButton( bool checked );
protected:
   //QSize sizeHint() const override;
   void resizeEvent( QResizeEvent* event ) override;
   void paintEvent( QPaintEvent* event ) override;
   void mouseDoubleClickEvent( QMouseEvent* event ) override;
/*
   void mousePressEvent( QMouseEvent* event ) override;
   void mouseReleaseEvent( QMouseEvent* event ) override;
   void mouseMoveEvent( QMouseEvent* event ) override;
   void wheelEvent( QWheelEvent* event ) override;
   void keyPressEvent( QKeyEvent* event ) override;
   void keyReleaseEvent( QKeyEvent* event ) override;
*/
   ImageButton* createEnableButton();
   ImageButton* createMoreButton();
   ImageButton* createEditorButton();
   ImageButton* createUpdateButton();
   ImageButton* createSaveButton();
protected:
   DE_CREATE_LOGGER("PluginEditor")
   App & m_app;
   bool m_hasFocus;
   bool m_isMinimized;
   de::audio::IPlugin* m_plugin;
   PluginEditorWindow* m_editorWindow; // HWND

   QString m_title;
   ImageButton* m_btnEnabled;
   ImageButton* m_btnMore;
   ImageButton* m_btnEditor;
   ImageButton* m_btnLoadPreset;
   ImageButton* m_btnSavePreset;


   AudioMeter* m_audioMeter;
   GLevelMeter* m_levelMeter;

   QImage m_imgTitleH;
   QImage m_imgTitleV;
   QImage m_imgEditorContent;

   QFont5x8 m_font5x8;
   //int m_btnW;

   QRect m_rcPanel;
   QRect m_rcHeader;
   QRect m_rcMeter;


public:
   // std::wstring const & getUri() const { return m_uri; }
   // bool isMoreVisible() const { return m_btnMore->isChecked(); }
   // bool isEditorVisible() const { return m_btnEditor->isChecked(); }

   // int numPrograms() const { return m_vst ? m_vst->numPrograms : 0; }
   // int numParams() const { return m_vst ? m_vst->numParams : 0; }
   // int numInputs() const { return m_vst ? m_vst->numInputs : 0; }
   // int numOutputs() const { return m_vst ? m_vst->numOutputs : 0; }
   // bool getFlags( int32_t m ) const { return m_vst ? ((m_vst->flags & m) == m) : 0; }
   // bool hasEditor() const { return m_hasEditor; }
   // bool isSynth() const override { return m_isSynth; }

   // int getVendorVersion();
   // std::string getVendorString();
   // std::string getProductString();

   //uint32_t getSampleRate() const override;
   //uint64_t getSamplePos() const;
   //uint64_t getBlockSize() const;
   //uint64_t getChannelCount() const;

};

#endif
