/// (c) 2017 - 20180 Benjamin Hampe <benjaminhampe@gmx.de>

#ifndef DE_LIVE_SpurInfo_HPP
#define DE_LIVE_SpurInfo_HPP

#include <de/audio/dsp/IDspChainElement.hpp>
#include <de/audio/dsp/Mixer.hpp>
#include <de/audio/plugin/IPlugin.hpp>
#include <de/audio/stream/Stream.hpp>
#include <QString>

namespace de {
namespace audio {

// ============================================================================
struct SpurPluginInfo
// ============================================================================
{
   bool m_isValid;
   int m_id;
   SpurPluginType::eType m_type;
   QString m_uri;
   QString m_name;

   SpurPluginInfo()
      : m_isValid( false )
      , m_id(-1)
      , m_type( SpurPluginType::eTypeCount )
   {}

   SpurPluginInfo( int id, QString uri, SpurPluginType::eType type )
      : m_isValid( false )
      , m_id( id )
      , m_type( type )
      , m_uri( uri )
      , m_name( QString::fromStdWString(
                  de::FileSystem::fileBase( uri.toStdWString() ) ) )
   {}

   void
   writeXML( tinyxml2::XMLDocument & doc, tinyxml2::XMLElement* root ) const
   {
      tinyxml2::XMLElement* plugin = doc.NewElement( "plugin" );
      plugin->SetAttribute("id", m_id );
      plugin->SetAttribute("type", int(m_type) );
      //plugin->SetAttribute("synth", int(m_isSynth) );
      plugin->SetAttribute("name", m_name.toStdString().c_str() );
      plugin->SetAttribute("uri", m_uri.toStdString().c_str() );
      root->InsertEndChild( plugin );
   }

   bool
   readXML( int i, tinyxml2::XMLElement* plugin )
   {
      //BENNI_ASSERT(plugin,"No plugin ptr")
      //BENNI_ASSERT(plugin->Name(),"No plugin->Name() ptr")
      //BENNI_ASSERT(std::string( plugin->Name() ) != "plugin","plugin->Name() != plugin")

      if ( !plugin )
      {
         std::cout << "SpurPluginInfo.readXML(" << i << ") :: Got nullptr" << std::endl;
         return false;
      }

      if ( !plugin->Name() || (std::string( plugin->Name() ) != "plugin") )
      {
         std::cout << "SpurPluginInfo.readXML(" << i << ") :: Not a <plugin> tag" << std::endl;
         return false;
      }

      bool ok = true;

      if ( plugin->Attribute("uri" ) )
      {
         std::string uri = plugin->Attribute("uri" );
         m_uri = QString::fromStdString( uri );
      }
      else
      {
         std::cout << "SpurPluginInfo.readXML(" << i << ") :: No 'uri' attribute" << std::endl;
         m_uri = "";
         ok = false;
      }

      m_id = plugin->IntAttribute("id");
      m_type = SpurPluginType::eType( plugin->IntAttribute("type") );

      if ( plugin->Attribute( "name" ) )
      {
         std::string name = plugin->Attribute( "name" );
         m_name = QString::fromStdString( name );
      }
      else
      {
         m_name = "";
         ok = false;
      }

      m_isValid = ok;
      return ok;
   }
};

// struct Instrument
// A PluginContainer is a linear DSP chain of midiFxs, one midi2audio synthesizer and audioFxs.
// + <optional> 1 MidiInputMeter signalling any MIDI input ( not for audio-only )
// + <optional> Chain of MidiFx = 1x MidiPlugin + 1x MidiMeter
// + <optional> 1 synthesizer = ( 1x IPlugin + 1x LevelMeter ), gets replaced with next synth added.
// + <optional> Linear chain of effects each adding ( 1x IPlugin + 1x LevelMeter )
// ============================================================================
struct SpurInfo
// ============================================================================
{
   DE_CREATE_LOGGER("SpurInfo")
   std::string m_name;
   bool m_isBypassed;
   int m_type; // 0 = master, 1 = return, 2 = audio-only, 3 = midi+audio
   int m_id;      // 0 = master fx chain, 1+x = return A+x chains, 1000 + x = user audio only chains, 2000 + x = user midi + audio chains
   int m_volume;
   std::vector< PluginInfo > m_plugins; // Series of audio or midi or one synth effects.

public:
   SpurInfo( int id = -1, std::string name = "UnknownChain", int type = -1 );
   ~SpurInfo();
   void clear();
   bool isAudioOnly() const { return m_type < 3; }
   std::string const & name() const { return m_name; }

   void
   writeXML( tinyxml2::XMLDocument & doc, tinyxml2::XMLElement* network ) const;

   bool
   readXML( int i, tinyxml2::XMLElement* chain );

   //int findPlugin( int id ) const;

   // if returns false ( not added ) then caller has to delete it.
   bool addPlugin( SpurPluginInfo* plugin );

   bool addPlugin( std::wstring const & uri );
};

// ============================================================================
struct NetworkInfo
// ============================================================================
{
   DE_CREATE_LOGGER("NetworkInfo")
   std::vector< SpurInfo* > m_spuren; // We use pointers so vector can resize.

   SpurInfo* m_master; // fix non user track
   std::vector< SpurInfo* > m_returns; // all return tracks
   std::vector< SpurInfo* > m_user;
   std::vector< SpurInfo* > m_userMidi;
   std::vector< SpurInfo* > m_userAudio;

public:
   NetworkInfo();
   ~NetworkInfo();
   bool load( std::string const & uri );
   bool save( std::string const & uri ) const;
   void clear();
   void createDefault();
   int findSpur( int id ) const;
   void addSpur( int id = -1, std::string name = "UnknownChain", int type = -1 );
};

// ============================================================================
struct DriverInfo
// ============================================================================
{
   std::string m_deviceUuid;
   std::string m_deviceName;  // expected name we are looking for
   int m_api; // 0 = WASAPI
   int m_deviceIndex;         // expected device index, -1 = default system device
   int m_sampleRate;
   int m_frameCount;
   int m_channelCount;
   int m_firstChannel;

   de::audio::Stream* m_stream;

   DriverInfo()
      : m_api( 0 )
      , m_deviceIndex( 0 )
      , m_sampleRate( 0 )
      , m_frameCount( 0 )
      , m_channelCount( 2 )
      , m_firstChannel( 0 )
   {}
};


} // end namespace live
} // end namespace de


#endif
