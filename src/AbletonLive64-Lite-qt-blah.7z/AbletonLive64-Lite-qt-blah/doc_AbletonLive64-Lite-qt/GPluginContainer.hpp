#ifndef DE_LIVE_PLUGIN_VST2X_HPP
#define DE_LIVE_PLUGIN_VST2X_HPP

#include <LiveSkin.hpp>
#include <QFont5x8.hpp>
#include <ImageButton.hpp>
#include <AudioMeter.hpp>
#include <GLevelMeter.hpp>

#include <de/audio/dsp/IDspChainElement.hpp>
#include <de/audio/vst/IPlugin.hpp>

//#pragma warning(push)
//#pragma warning(disable : 4996)
#include <pluginterfaces/vst2.x/aeffectx.h>  // de_vst2sdk
//#pragma warning(pop)

struct App;

// ============================================================================
class PluginVST24_EditorWindow : public QWidget
// ============================================================================
{
   Q_OBJECT
   bool m_enableClosing;
public:
   PluginVST24_EditorWindow( QWidget* parent = 0 ) : QWidget( parent ), m_enableClosing(false) {}
   ~PluginVST24_EditorWindow() override {}
signals:
   void closed();
public slots:
   void enableClosing() { m_enableClosing = true; }
   void disableClosing() { m_enableClosing = false; }
protected:
   void closeEvent( QCloseEvent* event ) override
   {
      if ( !m_enableClosing ) { event->ignore(); }
      hide();
      emit closed();
      //event->
   }
};

struct Spur;

// ============================================================================
class PluginVST24 : public QWidget, public de::audio::IDspChainElement
// ============================================================================
{
   DE_CREATE_LOGGER("PluginVST24")
   Q_OBJECT
public:
   PluginVST24( App & m_app, Spur* parent = 0 );
   ~PluginVST24();
   std::wstring const & getUri() const { return m_uri; }
   bool isBypassed() const override { return !m_btnEnabled->isChecked(); }
   bool isMoreVisible() const { return m_btnMore->isChecked(); }
   bool isEditorVisible() const { return m_btnEditor->isChecked(); }

   int numPrograms() const { return m_vst ? m_vst->numPrograms : 0; }
   int numParams() const { return m_vst ? m_vst->numParams : 0; }
   int numInputs() const { return m_vst ? m_vst->numInputs : 0; }
   int numOutputs() const { return m_vst ? m_vst->numOutputs : 0; }
   bool getFlags( int32_t m ) const { return m_vst ? ((m_vst->flags & m) == m) : 0; }
   bool hasEditor() const { return m_hasEditor; }
   bool isSynth() const override { return m_isSynth; }

   int getVendorVersion();
   std::string getVendorString();
   std::string getProductString();

   //uint32_t getSampleRate() const override;
   //uint64_t getSamplePos() const;
   //uint64_t getBlockSize() const;
   //uint64_t getChannelCount() const;

   uint64_t
   readSamples( double pts,
                float* dst,
                uint32_t dstFrames,
                uint32_t dstChannels,
                uint32_t dstRate ) override;
signals:
   void addedSynth( de::audio::IDspChainElement* );
   void removedSynth( de::audio::IDspChainElement* );
public slots:
   void on_focusChanged( bool focused );

   void setUri( std::wstring const & uri ) { m_uri = uri; }
   bool openPlugin();
   void closePlugin();

   inline bool
   openPlugin( std::wstring const & uri )
   {
      setUri( uri );
      return openPlugin();
   }

   void setBypassed( bool bypassed ) override;

   void setVisibleMore( bool visible );
   void setVisibleEditor( bool visible );

   void sendNote( de::audio::Note const & note ) override;

   void aboutToStart( uint32_t dstFrames, uint32_t dstChannels, uint32_t dstRate ) override;
   void clearInputSignals() override { m_inputSignal = nullptr; }
   void setInputSignal( int i, de::audio::IDspChainElement* input ) override { m_inputSignal = input; }

protected slots:
   void on_bypassed( bool bypassed );
   void on_visibleMore( bool visible );
   void on_visibleEditor( bool visible );
   void on_editorClosed();
   //void on_loadButton( bool checked );
protected:
   //QSize sizeHint() const override;
   void resizeEvent( QResizeEvent* event ) override;
   void paintEvent( QPaintEvent* event ) override;
   void mouseDoubleClickEvent( QMouseEvent* event ) override;
/*
   void mousePressEvent( QMouseEvent* event ) override;
   void mouseReleaseEvent( QMouseEvent* event ) override;
   void mouseMoveEvent( QMouseEvent* event ) override;
   void wheelEvent( QWheelEvent* event ) override;
   void keyPressEvent( QKeyEvent* event ) override;
   void keyReleaseEvent( QKeyEvent* event ) override;
*/
   ImageButton* createEnableButton();
   ImageButton* createMoreButton();
   ImageButton* createEditorButton();
   ImageButton* createUpdateButton();
   ImageButton* createSaveButton();
protected:
   App & m_app;
   Spur* m_spur;

   QString m_title;
   ImageButton* m_btnEnabled;
   ImageButton* m_btnMore;
   ImageButton* m_btnEditor;
   ImageButton* m_btnLoadPreset;
   ImageButton* m_btnSavePreset;
   AudioMeter* m_audioMeter;
   GLevelMeter* m_levelMeter;

   QImage m_imgTitleH;
   QImage m_imgTitleV;
   QImage m_imgEditorContent;

   QFont5x8 m_font5x8;
   //int m_btnW;

   QRect m_rcPanel;
   QRect m_rcHeader;
   QRect m_rcMeter;

// #ifdef USE_BENNI_VST2x_HOST
   bool m_hasFocus;
   bool m_isMinimized;
   bool m_isLoaded;
   bool m_isDirty;
   bool m_isSynth;
   bool m_hasEditor;
   int m_id;
   int m_volume;
   uint32_t m_sampleRate;     // rate in Hz
   uint32_t m_bufferFrames;   // frames per channel
   de::audio::IDspChainElement* m_inputSignal;

   uint64_t m_dllHandle; // HMODULE
   AEffect* m_vst;
   PluginVST24_EditorWindow* m_editorWindow; // HWND

   std::wstring m_uri;                 // Plugin file name
   std::string m_directoryMultiByte;
   std::atomic< uint64_t > m_framePos;
   VstTimeInfo m_timeInfo;

   // VST seems to work channelwise / planar, not interleaved audio.
   std::vector< float > m_outBuffer;
   std::vector< float* > m_outBufferHeads;
   std::vector< float > m_inBuffer;
   std::vector< float* > m_inBufferHeads;
   // VST midi event handling
   std::vector< VstMidiEvent > m_vstMidiEvents;
   std::vector< char > m_vstEventBuffer;

   struct
   {
      std::unique_lock< std::mutex >
      lock() const
      {
         return std::unique_lock<std::mutex>(m_mutex);
      }

      std::vector< VstMidiEvent > events;
   private:
      std::mutex mutable m_mutex;
   } m_vstMidi;

   // LevelMeter:
//   int m_updateTimerId;
//   float m_Lmin;
//   float m_Lmax;
//   float m_Rmin;
//   float m_Rmax;
//   de::LinearColorGradient m_colorGradient;

//   void stopUpdateTimer();
//   void startUpdateTimer();

protected:
   void updateLayout();
   void resizeEditor( QRect const & clientRc );

   //uint64_t
   //readVstSamples( double pts, float* dst, uint32_t dstFrames, uint32_t dstChannels, uint32_t dstRate );
   static VstIntPtr
   hostCallback_static( AEffect* effect, VstInt32 opcode, VstInt32 index, VstIntPtr value, void *ptr, float opt );
   VstIntPtr
   hostCallback(VstInt32 opcode, VstInt32 index, VstIntPtr value, void* ptr, float);
   intptr_t
   dispatcher( int32_t opcode, int32_t index = 0, intptr_t value = 0, void *ptr = nullptr, float opt = 0.0f) const;
   void
   processVstMidiEvents();
   const char**
   getCapabilities() const;

//   void setParameterProc( VstInt32 index, float parameter )
//   {

//   }

//   static void SetParameterProc_static( AEffect* effect, VstInt32 index, float value )
//   {
//      if ( !effect ) return;
//      DE_DEBUG("Set VST Parameter[",index," / ",effect->numParams,"] = ", value )
//   }

//   static float GetParameterProc_static( AEffect* effect, VstInt32 index )
//   {
//      if ( !effect ) return;
//      DE_DEBUG("Get VST Parameter[",index," / ",effect->numParams,"]")

//   }
//#endif

};

#endif
