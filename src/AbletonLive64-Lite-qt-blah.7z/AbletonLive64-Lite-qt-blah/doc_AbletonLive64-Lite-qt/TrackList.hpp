/// (c) 2017 - 20180 Benjamin Hampe <benjaminhampe@gmx.de>

#ifndef DE_LIVE_DATA_TRACKLIST_HPP
#define DE_LIVE_DATA_TRACKLIST_HPP

#include "Track.hpp"

// ============================================================================
struct TrackList : public QObject
// ============================================================================
{
   Q_OBJECT
public:
   DE_CREATE_LOGGER("Track")
   App & m_app;
   int m_currentTrackId;
   std::vector< Track* > m_all; // all tracks
   std::vector< Track* > m_user; // all user tracks ( 1 Audio + 1 Midi )
   Track* m_master;              // fix non user track
   Track* m_returnA;             // fix non user track
   Track* m_returnB;             // fix non user track

   //std::vector< Track* > m_return; // all fix tracks 0 = master, 1+x Return A+x
   std::vector< Track* > m_returns; // all return tracks
public:
   TrackList( App & app );
   ~TrackList();

   Track* get( int trackId );
   int find( int trackId ) const;

   int currentId() const { return m_currentTrackId; }
   Track const* current() const { return m_currentTrackId > -1 ? m_all[ m_currentTrackId ] : nullptr; }
   Track* current() { return m_currentTrackId > -1 ? m_all[ m_currentTrackId ] : nullptr; }

   std::vector< Track* > const & tracks() const { return m_all; }
   std::vector< Track* > & tracks() { return m_all; }

   size_t size() const { return m_all.size(); }
   size_t trackCount() const { return m_user.size(); }

   Track const* operator[] ( size_t i ) const { return m_all[ i ]; }
   Track* operator[] ( size_t i ) { return m_all[ i ]; }

signals:
   //void currentTrackChanged( Track* track );
   void currentTrackIdChanged( int );
   void changedTrackList();

public slots:
   void setCurrentTrackId( int trackId );
   void destroy();
   void reset();
   void addTrack( Track* track );
};

#endif
