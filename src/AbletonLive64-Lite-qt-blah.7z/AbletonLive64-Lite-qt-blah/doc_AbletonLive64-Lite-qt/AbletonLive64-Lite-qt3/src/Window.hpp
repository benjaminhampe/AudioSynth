/// (c) 2017 - 20180 Benjamin Hampe <benjaminhampe@gmx.de>

#ifndef DE_LIVE_MAINWINDOW_HPP
#define DE_LIVE_MAINWINDOW_HPP

#include "Body.hpp"

class Window : public QMainWindow
{
   DE_CREATE_LOGGER("Window")
   Q_OBJECT
   Body* m_body;

public:
   Window();
   ~Window() override;
   void createMenuBar();
public slots:
   void onMenuFileExit();
   void onMenuFileOpen();
   void onShowAboutDialog();
protected:

};

#endif
