/// (c) 2017 - 20180 Benjamin Hampe <benjaminhampe@gmx.de>

#ifndef DE_LIVE_FXPANEL_HPP
#define DE_LIVE_FXPANEL_HPP

#include <LiveData.hpp>

struct App;

// ============================================================================
class FxPanel : public QWidget
// ============================================================================
{
   Q_OBJECT
   App & m_app;

public:
   FxPanel( App & app, QWidget* parent = nullptr );
   ~FxPanel() override;
// protected slots:
   // void on_showExplorer( bool checked );
   // void on_showHelpPanel( bool checked );
   // void on_showClipAndFxPanel( bool checked );
protected:
   //void updateImage();

   void resizeEvent( QResizeEvent* event ) override;
   void paintEvent( QPaintEvent* event ) override;
   void mousePressEvent( QMouseEvent* event ) override;
   void mouseReleaseEvent( QMouseEvent* event ) override;
   void mouseMoveEvent( QMouseEvent* event ) override;
   void wheelEvent( QWheelEvent* event ) override;
   void keyPressEvent( QKeyEvent* event ) override;
   void keyReleaseEvent( QKeyEvent* event ) override;

   //void enterEvent( QEvent* event ) override { m_isHovered = true; QPushButton::enterEvent( event ); }
   //void leaveEvent( QEvent* event ) override { m_isHovered = false; QPushButton::leaveEvent( event ); }
   // void hideEvent( QHideEvent* event ) override;
   // void showEvent( QShowEvent* event ) override;


};

#endif
