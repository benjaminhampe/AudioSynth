#include <Create.hpp>

void
createTapButton( App & app )
{
   int bw = 32;
   int bh = 17;
   LiveSkin const & skin = app.m_skin;
   auto & btn = app.getButton( Button::Tap );
   btn.setSize( bw, bh );

   QFont font = getFontAwesome( 14 );
   QString msg = "TAP";
   // [idle]
   QImage ico = createImageFromText( 0,0, msg, font, skin.eTextColor, skin.eFillColor );
   QImage img = createRectImage( bw,bh, skin.ePenColor, skin.eFillColor, ico );
   btn.setImage( 0, img );
   // [idle_hover]
   btn.setImage( 1, img );

   // [active]
   ico = createImageFromText( 1,1, msg, font, skin.eTextColor, skin.activeColor );
   img = createRectImage( bw,bh, skin.ePenColor, skin.activeColor, ico );
   btn.setImage( 2, img );
   // [active_hover]
   btn.setImage( 3, img );
}

void
createBpmEdit( App & app )
{
   int bw = 48;
   int bh = 17;
   LiveSkin const & skin = app.m_skin;
   auto & btn = app.getButton( Button::EdtBpm );
   btn.setSize( bw, bh );

   QFont font = getFontAwesome( 14 );
   QString msg = "120.00";
   // [idle]
   QImage ico = createImageFromText( 1,1, msg, font, skin.eTextColor, skin.eFillColor );
   QImage img = createRectImage( bw,bh, skin.ePenColor, skin.eFillColor, ico );
   btn.setImage( 0, img );
   // [idle_hover]
   btn.setImage( 1, img );

   // [active]
   ico = createImageFromText( 1,1, msg, font, skin.eTextColor, skin.activeColor );
   img = createRectImage( bw,bh, skin.ePenColor, skin.activeColor, ico );
   btn.setImage( 2, img );
   // [active_hover]
   btn.setImage( 3, img );
}

void
createNudgeSlowButton( App & app )
{
   int bw = 16;
   int bh = 17;
   LiveSkin const & skin = app.m_skin;
   auto & btn = app.getButton( Button::NudgeSlow );
   btn.setCheckable( true );
   btn.setChecked( false );
   btn.setSize( bw, bh );

   std::string
   msg = "## #  #   #\n"
         "## #  #   #\n"
         "## #  #   #\n"
         "## #  #   #\n"
         "## #  #   #\n"
         "## #  #   #\n"
         "## #  #   #\n";

   // [idle]
   QImage ico = createAsciiArt( skin.eTextColor, skin.eFillColor, msg );
   QImage img = createRectImage( bw,bh, skin.ePenColor, skin.eFillColor, ico );
   btn.setImage( 0, img );
   // [idle_hover]
   btn.setImage( 1, img );

   // [active]
   ico = createAsciiArt( skin.eTextColor, skin.activeColor, msg );
   img = createRectImage( bw,bh, skin.ePenColor, skin.activeColor, ico );
   btn.setImage( 2, img );
   // [active_hover]
   btn.setImage( 3, img );
}

void
createNudgeFastButton( App & app )
{
   int bw = 16;
   int bh = 17;

   LiveSkin const & skin = app.m_skin;
   auto & btn = app.getButton( Button::NudgeFast );
   btn.setCheckable( true );
   btn.setChecked( false );
   btn.setSize( bw, bh );

   std::string
   msg = "#   #  # ##\n"
         "#   #  # ##\n"
         "#   #  # ##\n"
         "#   #  # ##\n"
         "#   #  # ##\n"
         "#   #  # ##\n"
         "#   #  # ##\n";

   // [idle]
   QImage ico = createAsciiArt( skin.eTextColor, skin.eFillColor, msg );
   QImage img = createRectImage( bw,bh, skin.ePenColor, skin.eFillColor, ico );
   btn.setImage( 0, img );
   // [idle_hover]
   btn.setImage( 1, img );

   // [active]
   ico = createAsciiArt( skin.eTextColor, skin.activeColor, msg );
   img = createRectImage( bw,bh, skin.ePenColor, skin.activeColor, ico );
   btn.setImage( 2, img );
   // [active_hover]
   btn.setImage( 3, img );
}

void
createBeatSignatureEdit( App & app )
{
   int bw = 50;
   int bh = 17;

   LiveSkin const & skin = app.m_skin;
   auto & btn = app.getButton( Button::EdtSig );
   btn.setSize( bw, bh );

   QFont font = getFontAwesome( 14 );
   QString msg = "  4  /  4  ";
   // [idle]
   QImage ico = createImageFromText( 1,1, msg, font, skin.eTextColor, skin.eFillColor );
   QImage img = createRectImage( bw,bh, skin.ePenColor, skin.eFillColor, ico );
   btn.setImage( 0, img );
   // [idle_hover]
   btn.setImage( 1, img );

   // [active]
   ico = createImageFromText( 1,1, msg, font, skin.eTextColor, skin.activeColor );
   img = createRectImage( bw,bh, skin.ePenColor, skin.activeColor, ico );
   btn.setImage( 2, img );
   // [active_hover]
   btn.setImage( 3, img );
}

void
createMetronomToggle( App & app )
{
   int bw = 24;
   int bh = 17;

   LiveSkin const & skin = app.m_skin;
   auto & btn = app.getButton( Button::Metronom );
   btn.setCheckable( true );
   btn.setChecked( false );
   btn.setSize( bw, bh );

   std::string msg = "  ###      ###\n"
                  " #   #    #####\n"
                  "#     #  #######\n"
                  "#     #  #######\n"
                  "#     #  #######\n"
                  " #   #    #####\n"
                  "  ###      ###\n";
   // [idle]
   QImage ico = createAsciiArt( skin.eTextColor, skin.eFillColor, msg );
   QImage img = createRectImage( bw,bh, skin.ePenColor, skin.eFillColor, ico );
   btn.setImage( 0, img );
   // [idle_hover]
   btn.setImage( 1, img );

   // [active]
   ico = createAsciiArt( skin.eTextColor, skin.activeColor, msg );
   img = createRectImage( bw,bh, skin.ePenColor, skin.activeColor, ico );
   btn.setImage( 2, img );
   // [active_hover]
   btn.setImage( 3, img );
}

void
createDisplayFollowToggle( App & app )
{
   int bw = 24;
   int bh = 17;

   LiveSkin const & skin = app.m_skin;
   auto & btn = app.getButton( Button::DisplayFollow );
   btn.setCheckable( true );
   btn.setChecked( false );
   btn.setSize( bw, bh );

   //QFont font = getFontAwesome( 14 );
   std::string
   msg = "        #\n"
         "     #  ##\n"
         " #  ### ###\n"
         "     #  ##\n"
         "        #\n";

   // [idle]
   QImage ico = createAsciiArt( skin.eTextColor, skin.eFillColor, msg );
   QImage img = createRectImage( bw,bh, skin.ePenColor, skin.eFillColor, ico );
   btn.setImage( 0, img );
   // [idle_hover]
   btn.setImage( 1, img );

   // [active]
   ico = createAsciiArt( skin.eTextColor, skin.activeColor, msg );
   img = createRectImage( bw,bh, skin.ePenColor, skin.activeColor, ico );
   btn.setImage( 2, img );
   // [active_hover]
   btn.setImage( 3, img );
}

void
createArrangmentPosEdit( App & app )
{
   int bw = 86;
   int bh = 17;

   LiveSkin const & skin = app.m_skin;
   auto & btn = app.getButton( Button::EdtPos );
   btn.setSize( bw, bh );

   QFont font = getFontAwesome( 14 );
   QString msg = "    1 .   1 .   1";
   // [idle]
   QImage ico = createImageFromText( 1,1, msg, font, skin.eTextColor, skin.eFillColor );
   QImage img = createRectImage( bw,bh, skin.ePenColor, skin.eFillColor, ico );
   btn.setImage( 0, img );
   // [idle_hover]
   btn.setImage( 1, img );

   // [active]
   ico = createImageFromText( 1,1, msg, font, skin.eTextColor, skin.activeColor );
   img = createRectImage( bw,bh, skin.ePenColor, skin.activeColor, ico );
   btn.setImage( 2, img );
   // [active_hover]
   btn.setImage( 3, img );
}

void
createPlayButton( App & app )
{
   int bw = 17;
   int bh = 17;

   LiveSkin const & skin = app.m_skin;
   auto & btn = app.getButton( Button::Play );
   btn.setCheckable( true );
   btn.setChecked( false );
   btn.setSize( bw, bh );

   QFont font = getFontAwesome( 14 );
   QString msg = QChar(fa::play);

   // [idle]
   QImage ico = createImageFromText( 1,1, msg, font, skin.eTextColor, skin.eFillColor );
   QImage img = createRectImage( bw,bh, skin.ePenColor, skin.eFillColor, ico, 0, 1 );
   btn.setImage( 0, img );
   // [idle_hover]
   btn.setImage( 1, img );

   // [active]
   ico = createImageFromText( 1,1, msg, font, skin.playColor, skin.eFillColor );
   img = createRectImage( bw,bh, skin.ePenColor, skin.eFillColor, ico, 0, 1 );
   btn.setImage( 2, img );
   // [active_hover]
   btn.setImage( 3, img );
}

void
createStopButton( App & app )
{
   int bw = 17;
   int bh = 17;

   LiveSkin const & skin = app.m_skin;
   auto & btn = app.getButton( Button::Stop );
   btn.setCheckable( true );
   btn.setChecked( false );
   btn.setSize( bw, bh );

   QFont font = getFontAwesome( 14 );
   QString msg = QChar(fa::stop);

   // [idle]
   QImage ico = createImageFromText( 1,1, msg, font, skin.eTextColor, skin.eFillColor );
   QImage img = createRectImage( bw,bh, skin.ePenColor, skin.eFillColor, ico, 0, 1 );
   btn.setImage( 0, img );
   // [idle_hover]
   btn.setImage( 1, img );

   // [active]
   ico = createImageFromText( 1,1, msg, font, skin.playColor, skin.eFillColor );
   img = createRectImage( bw,bh, skin.ePenColor, skin.eFillColor, ico, 0, 1 );
   btn.setImage( 2, img );
   // [active_hover]
   btn.setImage( 3, img );
}


void
createRecordButton( App & app )
{
   int bw = 17;
   int bh = 17;

   LiveSkin const & skin = app.m_skin;
   auto & btn = app.getButton( Button::Rec );
   btn.setCheckable( true );
   btn.setChecked( false );
   btn.setSize( bw, bh );

   QFont font = getFontAwesome( 14 );
   QString msg = QChar(fa::stopcircle);

   // [idle]
   QImage ico = createImageFromText( 1,1, msg, font, skin.eTextColor, skin.eFillColor );
   QImage img = createRectImage( bw,bh, skin.ePenColor, skin.eFillColor, ico, 0, 1 );
   btn.setImage( 0, img );
   // [idle_hover]
   btn.setImage( 1, img );

   // [active]
   ico = createImageFromText( 1,1, msg, font, skin.playColor, skin.eFillColor );
   img = createRectImage( bw,bh, skin.ePenColor, skin.eFillColor, ico, 0, 1 );
   btn.setImage( 2, img );
   // [active_hover]
   btn.setImage( 3, img );
}







void
createOverdubButton( App & app )
{
   int bw = 32;
   int bh = 17;
   LiveSkin const & skin = app.m_skin;
   auto & btn = app.getButton( Button::Overdub );
   btn.setCheckable( true );
   btn.setChecked( false );
   btn.setSize( bw, bh );

   QFont font = getFontAwesome( 14 );
   QString msg = "OVR";

   // [idle]
   QImage ico = createImageFromText( 1,1, msg, font, skin.eTextColor, skin.eFillColor );
   QImage img = createRectImage( bw,bh, skin.ePenColor, skin.eFillColor, ico );
   btn.setImage( 0, img );
   // [idle_hover]
   btn.setImage( 1, img );

   // [active]
   ico = createImageFromText( 1,1, msg, font, skin.eTextColor, skin.activeColor );
   img = createRectImage( bw,bh, skin.ePenColor, skin.activeColor, ico );
   btn.setImage( 2, img );
   // [active_hover]
   btn.setImage( 3, img );
}

void
createBackToArrangementButton( App & app )
{
   int bw = 24;
   int bh = 17;
   LiveSkin const & skin = app.m_skin;
   auto & btn = app.getButton( Button::BackToArrangement );
//   btn.setCheckable( true );
//   btn.setChecked( false );
   btn.setSize( bw, bh );


   std::string
   msg = "#########\n"
         "             #\n"
         "            ##\n"
         "#########  #######\n"
         "            ##\n"
         "             #\n"
         "#########\n";
   // [idle]
   QImage ico = createAsciiArt( skin.eTextColor, skin.eFillColor, msg );
   QImage img = createRectImage( bw,bh, skin.ePenColor, skin.eFillColor, ico );
   btn.setImage( 0, img );
   // [idle_hover]
   btn.setImage( 1, img );

   // [active]
   ico = createAsciiArt( skin.eTextColor, skin.activeColor, msg );
   img = createRectImage( bw,bh, skin.ePenColor, skin.activeColor, ico );
   btn.setImage( 2, img );
   // [active_hover]
   btn.setImage( 3, img );
}

void
createBarComboBox( App & app )
{
   int bw = 48;
   int bh = 17;
   LiveSkin const & skin = app.m_skin;
   auto & btn = app.getButton( Button::ComboBar );
//   btn.setCheckable( true );
//   btn.setChecked( false );
   btn.setSize( bw, bh );

   QFont font = getFontAwesome( 14 );
   QString msg = "1 Bar v";

   // [idle]
   QImage ico = createImageFromText( 1,1, msg, font, skin.eTextColor, skin.eFillColor );
   QImage img = createRectImage( bw,bh, skin.ePenColor, skin.eFillColor, ico );
   btn.setImage( 0, img );
   // [idle_hover]
   btn.setImage( 1, img );

   // [active]
   ico = createImageFromText( 1,1, msg, font, skin.eTextColor, skin.activeColor );
   img = createRectImage( bw,bh, skin.ePenColor, skin.activeColor, ico );
   btn.setImage( 2, img );
   // [active_hover]
   btn.setImage( 3, img );
}

void
createPenButton( App & app )
{
   int bw = 24;
   int bh = 17;

   LiveSkin const & skin = app.m_skin;
   auto & btn = app.getButton( Button::Pen );
   btn.setCheckable( true );
   btn.setChecked( false );
   btn.setSize( bw, bh );

   //QFont font = getFontAwesome( 14 );
   std::string msg = "      #\n"
                  "     ###\n"
                  "    ## ##\n"
                  "   ## ####\n"
                  "  ## ####\n"
                  " ## ####\n"
                  "## ####\n"
                  "# ####\n"
                  "#  ##\n"
                  "####\n";
   // [idle]
   QImage ico = createAsciiArt( skin.eTextColor, skin.eFillColor, msg );
   QImage img = createRectImage( bw,bh, skin.ePenColor, skin.eFillColor, ico );
   btn.setImage( 0, img );
   // [idle_hover]
   btn.setImage( 1, img );

   // [active]
   ico = createAsciiArt( skin.eTextColor, skin.activeColor, msg );
   img = createRectImage( bw,bh, skin.ePenColor, skin.activeColor, ico );
   btn.setImage( 2, img );
   // [active_hover]
   btn.setImage( 3, img );
}


void
createLoopStartEdit( App & app )
{
   int bw = 86;
   int bh = 17;

   LiveSkin const & skin = app.m_skin;
   auto & btn = app.getButton( Button::EdtLoopStart );
   btn.setSize( bw, bh );

   QFont font = getFontAwesome( 14 );
   QString msg = "    1 .   1 .   1";
   // [idle]
   QImage ico = createImageFromText( 1,1, msg, font, skin.eTextColor, skin.eFillColor );
   QImage img = createRectImage( bw,bh, skin.ePenColor, skin.eFillColor, ico );
   btn.setImage( 0, img );
   // [idle_hover]
   btn.setImage( 1, img );

   // [active]
   ico = createImageFromText( 1,1, msg, font, skin.eTextColor, skin.activeColor );
   img = createRectImage( bw,bh, skin.ePenColor, skin.activeColor, ico );
   btn.setImage( 2, img );
   // [active_hover]
   btn.setImage( 3, img );
}


void
createLoopLengthEdit( App & app )
{
   int bw = 86;
   int bh = 17;

   LiveSkin const & skin = app.m_skin;
   auto & btn = app.getButton( Button::EdtLoopLength );
   btn.setSize( bw, bh );

   QFont font = getFontAwesome( 14 );
   QString msg = "    4 .   0 .   0";
   // [idle]
   QImage ico = createImageFromText( 1,1, msg, font, skin.eTextColor, skin.eFillColor );
   QImage img = createRectImage( bw,bh, skin.ePenColor, skin.eFillColor, ico );
   btn.setImage( 0, img );
   // [idle_hover]
   btn.setImage( 1, img );

   // [active]
   ico = createImageFromText( 1,1, msg, font, skin.eTextColor, skin.activeColor );
   img = createRectImage( bw,bh, skin.ePenColor, skin.activeColor, ico );
   btn.setImage( 2, img );
   // [active_hover]
   btn.setImage( 3, img );
}

void
createPunchInButton( App & app )
{
   int bw = 24;
   int bh = 17;
   LiveSkin const & skin = app.m_skin;
   auto & btn = app.getButton( Button::PunchInToggle );
//   btn.setCheckable( true );
//   btn.setChecked( false );
   btn.setSize( bw, bh );

   //QFont font = getFontAwesome( 14 );
   std::string msg = "######\n"
                     "      #\n"
                     "       #\n"
                     "        #\n"
                     "         ######\n";
   // [idle]
   QImage ico = createAsciiArt( skin.eTextColor, skin.eFillColor, msg );
   QImage img = createRectImage( bw,bh, skin.ePenColor, skin.eFillColor, ico );
   btn.setImage( 0, img );
   // [idle_hover]
   btn.setImage( 1, img );

   // [active]
   ico = createAsciiArt( skin.eTextColor, skin.activeColor, msg );
   img = createRectImage( bw,bh, skin.ePenColor, skin.activeColor, ico );
   btn.setImage( 2, img );
   // [active_hover]
   btn.setImage( 3, img );
}

void
createLoopButton( App & app )
{
   int bw = 24;
   int bh = 17;
   LiveSkin const & skin = app.m_skin;
   auto & btn = app.getButton( Button::LoopToggle );
   btn.setCheckable( true );
   btn.setChecked( false );
   btn.setSize( bw, bh );

   std::string msg = " ###########\n"
                     "#           #\n"
                     "#           #\n"
                     "#           #\n"
                     "#           #\n"
                     "#       #   #\n"
                     "#      ##   #\n"
                     " ###  ######\n"
                     "       ##\n"
                     "        #\n";
   // [idle]
   QImage ico = createAsciiArt( skin.eTextColor, skin.eFillColor, msg );
   QImage img = createRectImage( bw,bh, skin.ePenColor, skin.eFillColor, ico );
   btn.setImage( 0, img );
   // [idle_hover]
   btn.setImage( 1, img );

   // [active]
   ico = createAsciiArt( skin.eTextColor, skin.activeColor, msg );
   img = createRectImage( bw,bh, skin.ePenColor, skin.activeColor, ico );
   btn.setImage( 2, img );
   // [active_hover]
   btn.setImage( 3, img );
}

void
createPunchOutButton( App & app )
{
   int bw = 24;
   int bh = 17;
   LiveSkin const & skin = app.m_skin;
   auto & btn = app.getButton( Button::PunchOutToggle );
   btn.setCheckable( true );
   btn.setChecked( false );
   btn.setSize( bw, bh );

   std::string msg = "         ######\n"
                     "        #\n"
                     "       #\n"
                     "      #\n"
                     "######\n";
   // [idle]
   QImage ico = createAsciiArt( skin.eTextColor, skin.eFillColor, msg );
   QImage img = createRectImage( bw,bh, skin.ePenColor, skin.eFillColor, ico );
   btn.setImage( 0, img );
   // [idle_hover]
   btn.setImage( 1, img );

   // [active]
   ico = createAsciiArt( skin.eTextColor, skin.activeColor, msg );
   img = createRectImage( bw,bh, skin.ePenColor, skin.activeColor, ico );
   btn.setImage( 2, img );
   // [active_hover]
   btn.setImage( 3, img );
}

void
createKeyMidiButton( App & app )
{
   int bw = 16;
   int bh = 17;
   LiveSkin const & skin = app.m_skin;
   auto & btn = app.getButton( Button::KeyMidiToggle );
   btn.setCheckable( true );
   btn.setChecked( false );
   btn.setSize( bw, bh );

   std::string msg = "ooooooooooo\n"
                     "o o#o o#o o\n"
                     "o o#o o#o o\n"
                     "o o#o o#o o\n"
                     "o o#o o#o o\n"
                     "o o#o o#o o\n"
                     //"o o#o o#o o\n"
                     "o  o   o  o\n"
                     "o  o   o  o\n"
                     "o  o   o  o\n"
                     "o  o   o  o\n"
                     "ooooooooooo\n";
   // [idle]
   QImage ico = createAsciiArt( skin.eTextColor, skin.eFillColor, msg );
   QImage img = createRectImage( bw,bh, skin.ePenColor, skin.eFillColor, ico );
   btn.setImage( 0, img );
   // [idle_hover]
   btn.setImage( 1, img );

   // [active]
   ico = createAsciiArt( skin.eTextColor, skin.activeColor, msg );
   img = createRectImage( bw,bh, skin.ePenColor, skin.activeColor, ico );
   btn.setImage( 2, img );
   // [active_hover]
   btn.setImage( 3, img );
}

void
createKeyMidiInButton( App & app )
{
   int bw = 8;
   int bh = 8;
   LiveSkin const & skin = app.m_skin;
   auto & btn = app.getButton( Button::KeyMidiInLED );
   btn.setCheckable( true );
   btn.setChecked( false );
   btn.setSize( bw, bh );

   // [idle]
   QImage img = createRectImage( bw,bh, skin.ePenColor, skin.eFillColor );
   btn.setImage( 0, img );
   // [idle_hover]
   btn.setImage( 1, img );

   // [active]
   img = createRectImage( bw,bh, skin.ePenColor, skin.activeColor );
   btn.setImage( 2, img );
   // [active_hover]
   btn.setImage( 3, img );
}

void
createKeyMidiOutButton( App & app )
{
   int bw = 8;
   int bh = 8;
   LiveSkin const & skin = app.m_skin;
   auto & btn = app.getButton( Button::KeyMidiOutLED );
   btn.setCheckable( true );
   btn.setChecked( false );
   btn.setSize( bw, bh );

   // [idle]
   QImage img = createRectImage( bw,bh, skin.ePenColor, skin.eFillColor );
   btn.setImage( 0, img );
   // [idle_hover]
   btn.setImage( 1, img );

   // [active]
   img = createRectImage( bw,bh, skin.ePenColor, skin.activeColor );
   btn.setImage( 2, img );
   // [active_hover]
   btn.setImage( 3, img );
}


void
createKeyMappingButton( App & app )
{
   int bw = 32;
   int bh = 17;
   LiveSkin const & skin = app.m_skin;
   auto & btn = app.getButton( Button::KeyMapToggle );
   btn.setSize( bw, bh );

   QFont font = getFontAwesome( 14 );
   QString msg = "KEY";
   // [idle]
   QImage ico = createImageFromText( 0,0, msg, font, skin.eTextColor, skin.eFillColor );
   QImage img = createRectImage( bw,bh, skin.ePenColor, skin.eFillColor, ico );
   btn.setImage( 0, img );
   // [idle_hover]
   btn.setImage( 1, img );

   // [active]
   ico = createImageFromText( 1,1, msg, font, skin.eTextColor, skin.activeColor );
   img = createRectImage( bw,bh, skin.ePenColor, skin.activeColor, ico );
   btn.setImage( 2, img );
   // [active_hover]
   btn.setImage( 3, img );
}

void
createMidiMappingButton( App & app )
{
   int bw = 32;
   int bh = 17;
   LiveSkin const & skin = app.m_skin;
   auto & btn = app.getButton( Button::MidiMapToggle );
   btn.setSize( bw, bh );

   QFont font = getFontAwesome( 14 );
   QString msg = "MIDI";
   // [idle]
   QImage ico = createImageFromText( 0,0, msg, font, skin.eTextColor, skin.eFillColor );
   QImage img = createRectImage( bw,bh, skin.ePenColor, skin.eFillColor, ico );
   btn.setImage( 0, img );
   // [idle_hover]
   btn.setImage( 1, img );

   // [active]
   ico = createImageFromText( 1,1, msg, font, skin.eTextColor, skin.activeColor );
   img = createRectImage( bw,bh, skin.ePenColor, skin.activeColor, ico );
   btn.setImage( 2, img );
   // [active_hover]
   btn.setImage( 3, img );
}

void
createCpuUsageEdit( App & app )
{
   int bw = 32;
   int bh = 17;
   LiveSkin const & skin = app.m_skin;
   auto & btn = app.getButton( Button::CpuUsage );
   btn.setSize( bw, bh );

   QFont font = getFontAwesome( 14 );
   QString msg = "1 %";
   // [idle]
   QImage ico = createImageFromText( 0,0, msg, font, skin.eTextColor, skin.eFillColor );
   QImage img = createRectImage( bw,bh, skin.ePenColor, skin.eFillColor, ico );
   btn.setImage( 0, img );
   // [idle_hover]
   btn.setImage( 1, img );

   // [active]
   ico = createImageFromText( 1,1, msg, font, skin.eTextColor, skin.activeColor );
   img = createRectImage( bw,bh, skin.ePenColor, skin.activeColor, ico );
   btn.setImage( 2, img );
   // [active_hover]
   btn.setImage( 3, img );
}

void
createDiskUsageEdit( App & app )
{
   int bw = 17;
   int bh = 17;
   LiveSkin const & skin = app.m_skin;
   auto & btn = app.getButton( Button::DiskUsage );
   btn.setSize( bw, bh );

   QFont font = getFontAwesome( 14 );
   QString msg = "D";
   // [idle]
   QImage ico = createImageFromText( 0,0, msg, font, skin.eTextColor, skin.eFillColor );
   QImage img = createRectImage( bw,bh, skin.ePenColor, skin.eFillColor, ico );
   btn.setImage( 0, img );
   // [idle_hover]
   btn.setImage( 1, img );

   // [active]
   ico = createImageFromText( 1,1, msg, font, skin.eTextColor, skin.activeColor );
   img = createRectImage( bw,bh, skin.ePenColor, skin.activeColor, ico );
   btn.setImage( 2, img );
   // [active_hover]
   btn.setImage( 3, img );
}

void
createLiveMidiInLED( App & app )
{
   int bw = 8;
   int bh = 8;
   LiveSkin const & skin = app.m_skin;
   auto & btn = app.getButton( Button::MidiInLED );
   btn.setCheckable( true );
   btn.setChecked( false );
   btn.setSize( bw, bh );

   // [idle]
   QImage img = createRectImage( bw,bh, skin.ePenColor, skin.eFillColor );
   btn.setImage( 0, img );
   // [idle_hover]
   btn.setImage( 1, img );

   // [active]
   img = createRectImage( bw,bh, skin.ePenColor, skin.activeColor );
   btn.setImage( 2, img );
   // [active_hover]
   btn.setImage( 3, img );
}

void
createLiveMidiOutLED( App & app )
{
   int bw = 8;
   int bh = 8;
   LiveSkin const & skin = app.m_skin;
   auto & btn = app.getButton( Button::MidiOutLED );
   btn.setCheckable( true );
   btn.setChecked( false );
   btn.setSize( bw, bh );

   // [idle]
   QImage img = createRectImage( bw,bh, skin.ePenColor, skin.eFillColor );
   btn.setImage( 0, img );
   // [idle_hover]
   btn.setImage( 1, img );

   // [active]
   img = createRectImage( bw,bh, skin.ePenColor, skin.activeColor );
   btn.setImage( 2, img );
   // [active_hover]
   btn.setImage( 3, img );
}


// DeviceBar


void
createShowExplorerButton( App & app )
{
   LiveSkin const & skin = app.m_skin;
   int bw = skin.circleButtonSize;
   int bh = skin.circleButtonSize;

   auto & btn = app.getButton( Button::ShowExplorer );
   btn.setCheckable( true );
   btn.setChecked( true );
   btn.setSize( bw, bh );

   auto bgColor = skin.windowColor;
   auto fgColor = skin.focusColor; // or panelColor

   //QFont font = getFontAwesome( 14 );
   std::string
   msg = "#########\n"
         "#########\n"
         " #######\n"
         " #######\n"
         "  #####\n"
         "  #####\n"
         "   ###\n"
         "   ###\n"
         "    #\n";
   // [idle]
   QImage ico = createAsciiArt( bgColor, fgColor, msg );
   QImage img = createCircleImage( bw,bh, bgColor, fgColor, ico );
   btn.setImage( 0, img );
   // [idle_hover]
   btn.setImage( 1, img );

   // [active]
   msg = "##\n"
         "####\n"
         "######\n"
         "########\n"
         "#########\n"
         "########\n"
         "######\n"
         "####\n"
         "##\n";

   ico = createAsciiArt( bgColor, fgColor, msg );
   img = createCircleImage( bw,bh, bgColor, fgColor, ico );
   btn.setImage( 2, img );
   // [active_hover]
   btn.setImage( 3, img );
}



void
createShowInternDevicesButton( App & app )
{
   LiveSkin const & skin = app.m_skin;
   int bw = skin.circleButtonSize;
   int bh = skin.circleButtonSize;

   auto & btn = app.getButton( Button::ShowInternDevices );
   btn.setCheckable( true );
   btn.setChecked( false );
   btn.setSize( bw, bh );

   auto bgColor = skin.windowColor;
   auto fgColor = skin.focusColor; // or panelColor

   //QFont font = getFontAwesome( 14 );
   std::string
   msg = " ########### \n"
         "##         ##\n"
         "##         ##\n"
         "#############\n"
         "#############\n"
         "#############\n"
         "#############\n"
         "#############\n"
         "#############\n"
         " ########### \n";
   // [idle]
   QImage ico = createAsciiArt( bgColor, fgColor, msg );
   QImage img = createCircleImage( bw,bh, bgColor, fgColor, ico );
   btn.setImage( 0, img );
   // [idle_hover]
   btn.setImage( 1, img );

   // [active]
   ico = createAsciiArt( skin.activeColor, fgColor, msg );
   img = createCircleImage( bw,bh, bgColor, fgColor, ico );
   btn.setImage( 2, img );
   // [active_hover]
   btn.setImage( 3, img );
}




void
createShowExternDevicesButton( App & app )
{
   LiveSkin const & skin = app.m_skin;
   int bw = skin.circleButtonSize;
   int bh = skin.circleButtonSize;

   auto & btn = app.getButton( Button::ShowExternDevices );
   btn.setCheckable( true );
   btn.setChecked( true );
   btn.setSize( bw, bh );

   auto bgColor = skin.windowColor;
   auto fgColor = skin.focusColor; // or panelColor

   //QFont font = getFontAwesome( 14 );
   std::string
   msg = "      ####\n"
         "   #  #######\n"
         "   #######\n"
         "##########\n"
         "   #######\n"
         "   #  #######\n"
         "      ####\n";
   // [idle]
   QImage ico = createAsciiArt( bgColor, fgColor, msg );
   QImage img = createCircleImage( bw,bh, bgColor, fgColor, ico );
   btn.setImage( 0, img );
   // [idle_hover]
   btn.setImage( 1, img );

   // [active]
   ico = createAsciiArt( skin.activeColor, fgColor, msg );
   img = createCircleImage( bw,bh, bgColor, fgColor, ico );
   btn.setImage( 2, img );
   // [active_hover]
   btn.setImage( 3, img );
}

void createShowExplorer1Button( App & app )
{
   LiveSkin const & skin = app.m_skin;
   int bw = skin.circleButtonSize;
   int bh = skin.circleButtonSize;

   auto & btn = app.getButton( Button::ShowExplorer1 );
   btn.setCheckable( true );
   btn.setChecked( false );
   btn.setSize( bw, bh );

   auto bgColor = skin.windowColor;
   auto fgColor = skin.focusColor; // or panelColor

   //QFont font = getFontAwesome( 14 );
   std::string
   msg = "#####\n"
         "#####\n"
         "###########\n"
         "###     ###\n"
         "### ##  ###\n"
         "###  #  ###\n"
         "###  #  ###\n"
         "###     ###\n"
         "###########\n";
   // [idle]
   QImage ico = createAsciiArt( bgColor, fgColor, msg );
   QImage img = createCircleImage( bw,bh, bgColor, fgColor, ico );
   btn.setImage( 0, img );
   // [idle_hover]
   btn.setImage( 1, img );

   // [active]
   ico = createAsciiArt( skin.activeColor, fgColor, msg );
   img = createCircleImage( bw,bh, bgColor, fgColor, ico );
   btn.setImage( 2, img );
   // [active_hover]
   btn.setImage( 3, img );
}

void createShowExplorer2Button( App & app )
{
   LiveSkin const & skin = app.m_skin;
   int bw = skin.circleButtonSize;
   int bh = skin.circleButtonSize;

   auto & btn = app.getButton( Button::ShowExplorer2 );
   btn.setCheckable( true );
   btn.setChecked( false );
   btn.setSize( bw, bh );

   auto bgColor = skin.windowColor;
   auto fgColor = skin.focusColor; // or panelColor

   //QFont font = getFontAwesome( 14 );
   std::string
   msg = "#####\n"
         "#####\n"
         "###########\n"
         "####   ####\n"
         "###  #  ###\n"
         "##  # #  ##\n"
         "##    #  ##\n"
         "##   #   ##\n"
         "### ### ###\n"
         "####   ####\n"
         "###########\n";

   // [idle]
   QImage ico = createAsciiArt( bgColor, fgColor, msg );
   QImage img = createCircleImage( bw,bh, bgColor, fgColor, ico );
   btn.setImage( 0, img );
   // [idle_hover]
   btn.setImage( 1, img );

   // [active]
   ico = createAsciiArt( skin.activeColor, fgColor, msg );
   img = createCircleImage( bw,bh, bgColor, fgColor, ico );
   btn.setImage( 2, img );
   // [active_hover]
   btn.setImage( 3, img );
}

void createShowExplorer3Button( App & app )
{
   LiveSkin const & skin = app.m_skin;
   int bw = skin.circleButtonSize;
   int bh = skin.circleButtonSize;

   auto & btn = app.getButton( Button::ShowExplorer3 );
   btn.setCheckable( true );
   btn.setChecked( false );
   btn.setSize( bw, bh );

   auto bgColor = skin.windowColor;
   auto fgColor = skin.focusColor; // or panelColor

   //QFont font = getFontAwesome( 14 );
   std::string
   msg = "#####\n"
         "#####\n"
         "###########\n"
         "###     ###\n"
         "### ##  ###\n"
         "###  #  ###\n"
         "###  #  ###\n"
         "###     ###\n"
         "###########\n";
   // [idle]
   QImage ico = createAsciiArt( bgColor, fgColor, msg );
   QImage img = createCircleImage( bw,bh, bgColor, fgColor, ico );
   btn.setImage( 0, img );
   // [idle_hover]
   btn.setImage( 1, img );

   // [active]

   ico = createAsciiArt( skin.activeColor, fgColor, msg );
   img = createCircleImage( bw,bh, bgColor, fgColor, ico );
   btn.setImage( 2, img );
   // [active_hover]
   btn.setImage( 3, img );
}

void
createShowGroovesButton( App & app )
{
   LiveSkin const & skin = app.m_skin;
   int bw = skin.circleButtonSize;
   int bh = skin.circleButtonSize;

   auto & btn = app.getButton( Button::ShowGrooves );
   btn.setCheckable( true );
   btn.setChecked( false );
   btn.setSize( bw, bh );

   auto bgColor = skin.windowColor;
   auto fgColor = skin.focusColor; // or panelColor

   //QFont font = getFontAwesome( 14 );
   std::string
   msg = "  ##\n"
         " #  #\n"
         "#    #    #\n"
         "      #  #\n"
         "       ##\n"
         "  ##\n"
         " #  #\n"
         "#    #    #\n"
         "      #  #\n"
         "       ##\n";

   // [idle]
   QImage ico = createAsciiArt( bgColor, fgColor, msg );
   QImage img = createCircleImage( bw,bh, bgColor, fgColor, ico );
   btn.setImage( 0, img );
   // [idle_hover]
   btn.setImage( 1, img );

   // [active]
   ico = createAsciiArt( skin.activeColor, fgColor, msg );
   img = createCircleImage( bw,bh, bgColor, fgColor, ico );
   btn.setImage( 2, img );
   // [active_hover]
   btn.setImage( 3, img );
}


// ComposeBar

void
createShowArrangementButton( App & app )
{
   LiveSkin const & skin = app.m_skin;
   int bw = skin.circleButtonSize;
   int bh = skin.circleButtonSize;

   auto & btn = app.getButton( Button::ShowArrangementPanel );
   btn.setCheckable( true );
   btn.setChecked( true );
   btn.setSize( bw, bh );

   auto bgColor = skin.windowColor;
   auto fgColor = skin.focusColor; // or panelColor

   //QFont font = getFontAwesome( 14 );
   std::string
   msg = "###########\n"
         "###########\n"
         "###########\n"
         " \n"
         " \n"
         "###########\n"
         "###########\n"
         "###########\n"
         " \n"
         " \n"
         "###########\n"
         "###########\n"
         "###########\n"
         ;

   // [idle]
   QImage ico = createAsciiArt( bgColor, fgColor, msg );
   QImage img = createCircleImage( bw,bh, bgColor, fgColor, ico );
   btn.setImage( 0, img );
   // [idle_hover]
   btn.setImage( 1, img );

   // [active]
   ico = createAsciiArt( skin.activeColor, fgColor, msg );
   img = createCircleImage( bw,bh, bgColor, fgColor, ico );
   btn.setImage( 2, img );
   // [active_hover]
   btn.setImage( 3, img );
}


void
createShowSessionButton( App & app )
{
   LiveSkin const & skin = app.m_skin;
   int bw = skin.circleButtonSize;
   int bh = skin.circleButtonSize;

   auto & btn = app.getButton( Button::ShowSessionPanel );
   btn.setCheckable( true );
   btn.setChecked( false );
   btn.setSize( bw, bh );

   auto bgColor = skin.windowColor;
   auto fgColor = skin.focusColor; // or panelColor

   std::string
   msg = "###  ###  ###\n"
         "###  ###  ###\n"
         "###  ###  ###\n"
         "###  ###  ###\n"
         "###  ###  ###\n"
         "###  ###  ###\n"
         "###  ###  ###\n"
         "###  ###  ###\n"
         "###  ###  ###\n"
         ;

   // [idle]
   QImage ico = createAsciiArt( bgColor, fgColor, msg );
   QImage img = createCircleImage( bw,bh, bgColor, fgColor, ico );
   btn.setImage( 0, img );
   // [idle_hover]
   btn.setImage( 1, img );

   // [active]
   ico = createAsciiArt( skin.activeColor, fgColor, msg );
   img = createCircleImage( bw,bh, bgColor, fgColor, ico );
   btn.setImage( 2, img );
   // [active_hover]
   btn.setImage( 3, img );
}

void createScrollUpButton( App & app )
{
   LiveSkin const & skin = app.m_skin;
   int bw = 9;
   int bh = 9;

   auto & btn = app.getButton( Button::ScrollUp );
   btn.setCheckable( true );
   btn.setChecked( false );
   btn.setSize( bw, bh );

   auto bgColor = skin.windowColor;
   auto fgColor = skin.focusColor; // or panelColor

   //QFont font = getFontAwesome( 14 );
   std::string
   msg = "    #\n"
         "   ###\n"
         "   ###\n"
         "  #####\n"
         "  #####\n"
         " #######\n"
         " #######\n"
         "#########\n"
         "#########\n";

   // [idle]
   QImage ico = createAsciiArt( bgColor, fgColor, msg );
   QImage img = createCircleImage( bw,bh, bgColor, fgColor, ico );
   btn.setImage( 0, img );
   // [idle_hover]
   btn.setImage( 1, img );

   // [active]
   ico = createAsciiArt( skin.searchBarH, fgColor, msg );
   img = createCircleImage( bw,bh, bgColor, fgColor, ico );
   btn.setImage( 2, img );
   // [active_hover]
   btn.setImage( 3, img );
}

void createScrollDownButton( App & app )
{
   LiveSkin const & skin = app.m_skin;
   int bw = 9;
   int bh = 9;

   auto & btn = app.getButton( Button::ScrollDown );
   btn.setCheckable( true );
   btn.setChecked( false );
   btn.setSize( bw, bh );

   auto bgColor = skin.windowColor;
   auto fgColor = skin.focusColor; // or panelColor

   std::string
   msg = "#########\n"
         "#########\n"
         " #######\n"
         " #######\n"
         "  #####\n"
         "  #####\n"
         "   ###\n"
         "   ###\n"
         "    #\n";

   // [idle]
   QImage ico = createAsciiArt( bgColor, fgColor, msg );
   QImage img = createCircleImage( bw,bh, bgColor, fgColor, ico );
   btn.setImage( 0, img );
   // [idle_hover]
   btn.setImage( 1, img );

   // [active]
   ico = createAsciiArt( skin.searchBarH, fgColor, msg );
   img = createCircleImage( bw,bh, bgColor, fgColor, ico );
   btn.setImage( 2, img );
   // [active_hover]
   btn.setImage( 3, img );
}

void createComposeIOButton( App & app )
{
   LiveSkin const & skin = app.m_skin;
   int bw = 11;
   int bh = 11;

   auto & btn = app.getButton( Button::ShowIO );
   btn.setCheckable( true );
   btn.setChecked( true );
   btn.setSize( bw, bh );

   std::string
   msg = "#  ###\n"
         "# #   #\n"
         "# #   #\n"
         "# #   #\n"
         "#  ###\n";

   // [idle]
   auto bgColor = skin.panelColor;
   auto fgColor = skin.windowColor;
   QImage ico = createAsciiArt( bgColor, fgColor, msg );
   QImage img = createCircleImage( bw,bh, bgColor, fgColor, ico );
   btn.setImage( 0, img );
   // [idle_hover]
   btn.setImage( 1, img );

   // [active]
   ico = createAsciiArt( skin.windowColor, skin.activeColor, msg );
   img = createCircleImage( bw,bh, QColor(0,0,0,0), skin.activeColor, ico );
   btn.setImage( 2, img );
   // [active_hover]
   btn.setImage( 3, img );
}

void createComposeRButton( App & app )
{
   LiveSkin const & skin = app.m_skin;
   int bw = 11;
   int bh = 11;

   auto & btn = app.getButton( Button::ShowReturn );
   btn.setCheckable( true );
   btn.setChecked( true );
   btn.setSize( bw, bh );

   std::string
   msg = "####\n"
         "#   #\n"
         "####\n"
         "# #\n"
         "#  ##\n";

   // [idle]
   auto bgColor = skin.panelColor;
   auto fgColor = skin.windowColor;
   QImage ico = createAsciiArt( bgColor, fgColor, msg );
   QImage img = createCircleImage( bw,bh, bgColor, fgColor, ico );
   btn.setImage( 0, img );
   // [idle_hover]
   btn.setImage( 1, img );

   // [active]
   ico = createAsciiArt( skin.windowColor, skin.activeColor, msg );
   img = createCircleImage( bw,bh, QColor(0,0,0,0), skin.activeColor, ico );
   btn.setImage( 2, img );
   // [active_hover]
   btn.setImage( 3, img );
}

void createComposeMButton( App & app )
{
   LiveSkin const & skin = app.m_skin;
   int bw = 11;
   int bh = 11;

   auto & btn = app.getButton( Button::ShowMixer );
   btn.setCheckable( true );
   btn.setChecked( true );
   btn.setSize( bw, bh );

   std::string
   msg = "## ##\n"
         "# # #\n"
         "# # #\n"
         "#   #\n"
         "#   #\n";

   // [idle]
   auto bgColor = skin.panelColor;
   auto fgColor = skin.windowColor;
   QImage ico = createAsciiArt( bgColor, fgColor, msg );
   QImage img = createCircleImage( bw,bh, bgColor, fgColor, ico );
   btn.setImage( 0, img );
   // [idle_hover]
   btn.setImage( 1, img );

   // [active]
   ico = createAsciiArt( skin.windowColor, skin.activeColor, msg );
   img = createCircleImage( bw,bh, QColor(0,0,0,0), skin.activeColor, ico );
   btn.setImage( 2, img );
   // [active_hover]
   btn.setImage( 3, img );
}

void createComposeDButton( App & app )
{
   LiveSkin const & skin = app.m_skin;
   int bw = 11;
   int bh = 11;

   auto & btn = app.getButton( Button::ShowDelays );
   btn.setCheckable( true );
   btn.setChecked( false );
   btn.setSize( bw, bh );

   std::string
   msg = "####\n"
         "#   #\n"
         "#   #\n"
         "#   #\n"
         "####\n";

   // [idle]
   auto bgColor = skin.panelColor;
   auto fgColor = skin.windowColor;
   QImage ico = createAsciiArt( bgColor, fgColor, msg );
   QImage img = createCircleImage( bw,bh, bgColor, fgColor, ico );
   btn.setImage( 0, img );
   // [idle_hover]
   btn.setImage( 1, img );

   // [active]
   ico = createAsciiArt( skin.windowColor, skin.activeColor, msg );
   img = createCircleImage( bw,bh, QColor(0,0,0,0), skin.activeColor, ico );
   btn.setImage( 2, img );
   // [active_hover]
   btn.setImage( 3, img );
}

// Footer

void
createShowHelpButton( App & app )
{
   LiveSkin const & skin = app.m_skin;
   int bw = skin.circleButtonSize;
   int bh = skin.circleButtonSize;

   auto & btn = app.getButton( Button::ShowQuickHelp );
   btn.setCheckable( true );
   btn.setChecked( true );
   btn.setSize( bw, bh );

   auto bgColor = skin.windowColor;
   auto fgColor = skin.focusColor; // or panelColor

   //QFont font = getFontAwesome( 14 );
   std::string
   msg = "##\n"
         "####\n"
         "######\n"
         "########\n"
         "#########\n"
         "########\n"
         "######\n"
         "####\n"
         "##\n";

   // [idle]
   QImage ico = createAsciiArt( bgColor, fgColor, msg );
   QImage img = createCircleImage( bw,bh, bgColor, fgColor, ico );
   btn.setImage( 0, img );
   // [idle_hover]
   btn.setImage( 1, img );

   // [active]
   msg = "    #\n"
         "   ###\n"
         "   ###\n"
         "  #####\n"
         "  #####\n"
         " #######\n"
         " #######\n"
         "#########\n"
         "#########\n";

   ico = createAsciiArt( bgColor, fgColor, msg );
   img = createCircleImage( bw,bh, bgColor, fgColor, ico );
   btn.setImage( 2, img );
   // [active_hover]
   btn.setImage( 3, img );
}

void
createShowClipPanelButton( App & app )
{
   LiveSkin const & skin = app.m_skin;
   int bw = skin.circleButtonSize;
   int bh = skin.circleButtonSize;

   auto & btn = app.getButton( Button::ShowEditPanel );
   btn.setCheckable( true );
   btn.setChecked( true );
   btn.setSize( bw, bh );

   auto bgColor = skin.windowColor;
   auto fgColor = skin.focusColor; // or panelColor

   //QFont font = getFontAwesome( 14 );
   std::string
   msg = "       ##\n"
         "     ####\n"
         "   ######\n"
         " ########\n"
         "#########\n"
         " ########\n"
         "   ######\n"
         "     ####\n"
         "       ##\n";

   // [idle]
   QImage ico = createAsciiArt( bgColor, fgColor, msg );
   QImage img = createCircleImage( bw,bh, bgColor, fgColor, ico );
   btn.setImage( 0, img );
   // [idle_hover]
   btn.setImage( 1, img );

   // [active]
   msg = "    #\n"
         "   ###\n"
         "   ###\n"
         "  #####\n"
         "  #####\n"
         " #######\n"
         " #######\n"
         "#########\n"
         "#########\n";

   ico = createAsciiArt( bgColor, fgColor, msg );
   img = createCircleImage( bw,bh, bgColor, fgColor, ico );
   btn.setImage( 2, img );
   // [active_hover]
   btn.setImage( 3, img );
}
