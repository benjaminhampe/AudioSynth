﻿#ifndef DE_LIVE_ARRANGEMENT_HPP
#define DE_LIVE_ARRANGEMENT_HPP

#include <LiveSkin.hpp>
#include <LiveData.hpp>
#include <UI.hpp>
#include <TimeLineOverview.hpp>
#include <QImage>

struct App;

// ============================================================================
struct Arrangement
// ============================================================================
{
   Arrangement( App & app );
   void reset();
   void layout( QRect const & clipRect );
   void draw( QPainter & dc );

protected:
   void updateImage();


   App & m_app;
   QRect m_clipRect;
   QRect m_rectTimeLine;
   QRect m_rectArrange;
   TimeLineOverview m_timelineOverview;


   QImage m_img;

   bool m_isDirty;

   int m_focusedTrack;
   int m_headHeight;
   int m_setHeight;
   int m_pinHeight;
   int m_trackHeight;
   int m_trackSpace;
   int m_footHeight;

   //TimeLineOverview m_overview;

};

#endif // G_LOPASS1_HPP
