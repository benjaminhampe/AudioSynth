                                          | RtAudioStream 
   +-------+   +------+   +-------+   +-------------+
   | Voice +-> | Note +-> | Synth +-> | MixerStream |
   +-------+   +------+   +-------+   +-------------+
                        
                           addVoice

                                       addDspInput