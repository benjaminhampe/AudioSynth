﻿#ifndef DE_LIVE_APP_HPP
#define DE_LIVE_APP_HPP

#include <LiveSkin.hpp>
#include <LiveData.hpp>
#include <UI.hpp>
#include <Header.hpp>
//#include <Footer.hpp>
#include <PluginExplorer.hpp>
#include <Arrangement.hpp>
#include <ClipEditor.hpp>
#include <FxPanel.hpp>

// ============================================================================
struct App
// ============================================================================
{
   App();
   ~App();
   void reset();
   DE_CREATE_LOGGER("App")
   std::string m_mediaDirMB;
   LiveSkin m_skin;       // Draw
   BeatGrid m_beatGrid;   // Arrangement
   TrackList m_trackList; // Arrangement
   //std::vector< Clip > m_clips;

   de::audio::MixerStream m_audioEndPoint; // Soundcard
   PluginExplorer m_pluginExplorer;
   Arrangement m_arrangement;
   ClipEditor m_clipEditor;
   FxPanel* m_fxPanel;
   QString m_longText;

   //[UI]
   std::vector< Panel > m_panels;
   std::vector< Button > m_buttons;
   std::vector< Splitter > m_splitters;
   std::vector< ScrollBar > m_scrollbars;
   Layout m_layout;
   Header m_header;

   int m_hoverPanel;
   int m_hoverButton;
   bool m_isOverDeviceScrollBar;
   bool m_isOverComposeScrollBar;
   bool m_isOverExplorer;
   bool m_isOverArrangement;
   bool m_isOverClipEditor;
   bool m_isOverFxEditor;
   bool m_isOverQickHelp;
   bool m_isOverViewClipEdit;
   bool m_isOverViewFxEdit;
   bool m_isOverSplitV;
   bool m_isOverSplitH;
   bool m_isDragging;
   int m_dragMode;
   int m_dragData;
   int m_dragStartX;
   int m_dragStartY;

   int findButton( int mx, int my ) const;

   Button const & getButton( int id ) const;
   Button & getButton( int id );

   void init();

   void updateLayout( int w, int h );

//   //Live2_Panel :: DeviceBar
//   Button m_btnShowExplorer;
//   Button m_btnInternDevice;
//   Button m_btnExternDevice;
//   Button m_btnExplorer1;
//   Button m_btnExplorer2;
//   Button m_btnExplorer3;
//   ScrollBar m_leftScrollBar;
//   Button m_btnGroove;

   //Live2_Panel :: PluginTree
   //   QTreeWidgetItem* m_selectedItem;
   //   QTreeWidgetItem* m_synthNode;
   //   QTreeWidgetItem* m_effectNode;

   //Live3_Panel m_arrangePanel;
//   Button m_btnShowArrangement;
//   Button m_btnShowSession;
//   Button m_btnUnknown;
//   Button m_btnShowHelp;
//   Button m_btnShowClipPanel;

   // GPianoKeyboard* m_Piano2D;
   //   static App &
   //   get()
   //   {
   //      static App s_instance;
   //      return s_instance;
   //   }


};

#endif // G_LOPASS1_HPP
