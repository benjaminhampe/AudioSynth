#include "FxPanel.hpp"
#include "App.hpp"
#include <QResizeEvent>

FxPanel::FxPanel( App & app, QWidget* parent )
   : QWidget( parent )
   , m_app( app )
{
   setMouseTracking( true );
   setMinimumSize(100,100);
}

FxPanel::~FxPanel()
{}

void
FxPanel::resizeEvent( QResizeEvent* event )
{
   int w = event->size().width();
   int h = event->size().height();

   //update();
   QWidget::resizeEvent( event );
}

void
FxPanel::paintEvent( QPaintEvent* event )
{
   int w = width();
   int h = height();

   if ( w > 1 && h > 1 )
   {
      LiveSkin const & skin = m_app.m_skin;
      Layout const & layout = m_app.m_layout;
      int s = 5;
      int r = skin.radius;

      QPainter dc( this );
      dc.setRenderHint( QPainter::NonCosmeticDefaultPen );
      dc.fillRect( rect(), skin.activeColor );
   }

   QWidget::paintEvent( event );
}

void
FxPanel::mouseMoveEvent( QMouseEvent* event )
{
   int mx = event->x();
   int my = event->y();
   update();
   QWidget::mouseMoveEvent( event );
}

void
FxPanel::mousePressEvent( QMouseEvent* event )
{
   int mx = event->x();
   int my = event->y();
   update();
   QWidget::mousePressEvent( event );
}

void
FxPanel::mouseReleaseEvent( QMouseEvent* event )
{
   int mx = event->x();
   int my = event->y();
   update();
   QWidget::mouseReleaseEvent( event );
}

void
FxPanel::wheelEvent( QWheelEvent* event )
{
   //DE_DEBUG("MouseWheel = ",wheel )
   int mx = event->x();
   int my = event->y();
   float wheelY = event->angleDelta().y();
   update();
   QWidget::wheelEvent( event );
}

void
FxPanel::keyPressEvent( QKeyEvent* event )
{
   //DE_DEBUG("KeyPress(",event->key(),")")
   QWidget::keyPressEvent( event );
}

void
FxPanel::keyReleaseEvent( QKeyEvent* event )
{
   //DE_DEBUG("KeyRelease(",event->key(),")")
   QWidget::keyReleaseEvent( event );
}
