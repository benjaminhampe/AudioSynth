/// (c) 2017 - 20180 Benjamin Hampe <benjaminhampe@gmx.de>

#ifndef DE_LIVE_CREATE_HPP
#define DE_LIVE_CREATE_HPP

#include <App.hpp>

// Header = EngineButtonBar
void createTapButton( App & app );
void createBpmEdit( App & app );
void createNudgeSlowButton( App & app );
void createNudgeFastButton( App & app );
void createBeatSignatureEdit( App & app );
void createMetronomToggle( App & app );
void createDisplayFollowToggle( App & app );
void createArrangmentPosEdit( App & app );
void createPlayButton( App & app );
void createStopButton( App & app );
void createRecordButton( App & app );

void createOverdubButton( App & app );
void createBackToArrangementButton( App & app );
void createBarComboBox( App & app );
void createPenButton( App & app );

void createLoopStartEdit( App & app );
void createPunchInButton( App & app );
void createLoopButton( App & app );
void createPunchOutButton( App & app );
void createLoopLengthEdit( App & app );

void createKeyMidiButton( App & app );
void createKeyMappingButton( App & app );
void createKeyMidiInButton( App & app );
void createKeyMidiOutButton( App & app );
void createMidiMappingButton( App & app );
void createCpuUsageEdit( App & app );
void createDiskUsageEdit( App & app );
void createLiveMidiInLED( App & app );
void createLiveMidiOutLED( App & app );

// DeviceBar
void createShowExplorerButton( App & app );
void createShowInternDevicesButton( App & app );
void createShowExternDevicesButton( App & app );
void createShowExplorer1Button( App & app );
void createShowExplorer2Button( App & app );
void createShowExplorer3Button( App & app );
void createShowGroovesButton( App & app );

// ComposeBar
void createShowArrangementButton( App & app );
void createShowSessionButton( App & app );
void createScrollUpButton( App & app );
void createScrollDownButton( App & app );
void createComposeIOButton( App & app );
void createComposeRButton( App & app );
void createComposeMButton( App & app );
void createComposeDButton( App & app );

// Footer
void createShowHelpButton( App & app );
void createShowClipPanelButton( App & app );


#endif
