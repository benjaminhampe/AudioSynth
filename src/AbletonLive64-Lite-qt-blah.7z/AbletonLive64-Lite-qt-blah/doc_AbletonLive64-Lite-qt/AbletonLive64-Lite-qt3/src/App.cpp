#include "App.hpp"
#include "Create.hpp"
#include "Draw.hpp"

App::App()
   : m_mediaDirMB("../../media/")
   , m_pluginExplorer( *this )
   , m_arrangement( *this )
   , m_clipEditor( *this )
{
   m_hoverPanel = -1;
   m_hoverButton = -1;
   m_isOverDeviceScrollBar = false;
   m_isOverComposeScrollBar = false;
   m_isOverExplorer = false;
   m_isOverArrangement = false;
   m_isOverClipEditor = false;
   m_isOverFxEditor = false;
   m_isOverQickHelp = false;
   m_isOverViewClipEdit = false;
   m_isOverViewFxEdit = false;
   m_isOverSplitV = false;
   m_isOverSplitH = false;
   m_isDragging = false;
   m_dragMode = 0; // 0 = Idle, 1 = splitterV, 2 = splitterH
   m_dragStartX = 0;
   m_dragStartY = 0;

   // Track1
   {
      Track trk;
      trk.m_isAudioTrack = false;
      trk.addClip( 0, 1, "Clip0-1");
      trk.addClip( 1, 3, "Clip1-3");
      trk.addClip( 3, 4, "Clip3-4");
      trk.addClip( 5, 8, "Clip5-8");
      trk.addClip( 10, 16, "Clip10-16");
      trk.addClip( 17, 20, "Clip17-20");
      m_trackList.addTrack( trk );
   }

   // Track2
   {
      Track trk;
      trk.m_isAudioTrack = true;
      trk.addClip( 0, 2, "Clip0-2");
      trk.addClip( 4, 6, "Clip4-6");
      trk.addClip( 8, 10, "Clip8-10");
      trk.addClip( 16, 17, "Clip16-18");
      trk.addClip( 18, 19, "Clip18-20");
      m_trackList.addTrack( trk );
   }

   // Track3
   {
      Track trk;
      trk.addClip( 0, 10, "Clip0-10");
      trk.addClip( 10, 20, "Clip10-32");
      m_trackList.addTrack( trk );
   }

   // Track4
   {
      Track trk;
      trk.m_isAudioTrack = true;
      trk.addClip( 0, 2, "Clip0-2");
      trk.addClip( 4, 6, "Clip4-6");
      trk.addClip( 8, 10, "Clip8-10");
      trk.addClip( 16, 17, "Clip16-18");
      trk.addClip( 18, 19, "Clip18-20");
      m_trackList.addTrack( trk );
   }

   // Track5
   {
      Track trk;
      trk.m_isAudioTrack = true;
      trk.addClip( 0, 0.25, "Clip0-1");
      trk.addClip( 0.5, 0.75, "Clip0-2");
      trk.addClip( 1, 1.25, "Clip1-1");
      trk.addClip( 1.5, 1.75, "Clip1-2");
      trk.addClip( 2, 2.25, "Clip2-1");
      trk.addClip( 2.5, 2.75, "Clip2-2");
      trk.addClip( 3, 3.25, "Clip3-1");
      trk.addClip( 3.5, 3.75, "Clip3-2");
      trk.addClip( 4, 4.25, "Clip4-1");
      trk.addClip( 4.5, 4.75, "Clip4-2");
      trk.addClip( 5, 5.25, "Clip5-1");
      trk.addClip( 5.5, 5.75, "Clip5-2");
      trk.addClip( 6, 6.25, "Clip6-1");
      trk.addClip( 6.5, 6.75, "Clip6-2");
      trk.addClip( 7, 7.25, "Clip7-1");
      trk.addClip( 7.5, 7.75, "Clip7-2");
      m_trackList.addTrack( trk );
   }

   // Create button list
   for ( size_t i = 0; i < Button::eButtonCount; ++i )
   {
      m_buttons.emplace_back();
      auto & btn = m_buttons.back();
      btn.setId( i );
   }

   for ( size_t i = 0; i < Panel::ePanelCount; ++i )
   {
      m_panels.emplace_back();
      auto & pnl = m_panels.back();
      pnl.setId( i );
   }

   for ( size_t i = 0; i < Splitter::eSplitterCount; ++i )
   {
      m_splitters.emplace_back();
      auto & spl = m_splitters.back();
      spl.setId( i );
   }

   for ( size_t i = 0; i < ScrollBar::eScrollBarCount; ++i )
   {
      m_scrollbars.emplace_back();
      auto & scr = m_scrollbars.back();
      scr.setId( i );
   }
   // Uses initialized button-list with existing id's.

   // DeviceBar
   createShowExplorerButton( *this );
   createShowInternDevicesButton( *this );
   createShowExternDevicesButton( *this );
   createShowExplorer1Button( *this );
   createShowExplorer2Button( *this );
   createShowExplorer3Button( *this );
   createShowGroovesButton( *this );

   // ComposeBar
   createShowArrangementButton( *this );
   createShowSessionButton( *this );
   createScrollUpButton( *this );
   createScrollDownButton( *this );
   createComposeIOButton( *this );
   createComposeRButton( *this );
   createComposeMButton( *this );
   createComposeDButton( *this );

   // Footer
   createShowHelpButton( *this );
   createShowClipPanelButton( *this );

   // Header
   createTapButton( *this );
   createBpmEdit( *this );
   createNudgeSlowButton( *this );
   createNudgeFastButton( *this );
   createBeatSignatureEdit( *this );
   createMetronomToggle( *this );
   createDisplayFollowToggle( *this );
   createArrangmentPosEdit( *this );
   createPlayButton( *this );
   createStopButton( *this );
   createRecordButton( *this );

   createOverdubButton( *this );
   createBackToArrangementButton( *this );
   createBarComboBox( *this );
   createPenButton( *this );

   createLoopStartEdit( *this );
   createPunchInButton( *this );
   createLoopButton( *this );
   createPunchOutButton( *this );
   createLoopLengthEdit( *this );

   createKeyMidiButton( *this );
   createKeyMappingButton( *this );
   createKeyMidiInButton( *this );
   createKeyMidiOutButton( *this );
   createMidiMappingButton( *this );
   createCpuUsageEdit( *this );
   createDiskUsageEdit( *this );
   createLiveMidiInLED( *this );
   createLiveMidiOutLED( *this );

   auto & group1 = m_header.m_btnGroup1;
   { auto & b = getButton( Button::Tap ); group1.emplace_back( &b ); }
   { auto & b = getButton( Button::EdtBpm ); group1.emplace_back( &b ); }
   { auto & b = getButton( Button::NudgeSlow ); group1.emplace_back( &b ); }
   { auto & b = getButton( Button::NudgeFast ); group1.emplace_back( &b ); }
   { auto & b = getButton( Button::EdtSig ); group1.emplace_back( &b ); }
   { auto & b = getButton( Button::Metronom ); group1.emplace_back( &b ); }

   auto & group2 = m_header.m_btnGroup2;
   { auto & b = getButton( Button::DisplayFollow ); group2.emplace_back( &b ); }
   { auto & b = getButton( Button::EdtPos ); group2.emplace_back( &b ); }
   { auto & b = getButton( Button::Play ); group2.emplace_back( &b ); }
   { auto & b = getButton( Button::Stop ); group2.emplace_back( &b ); }
   { auto & b = getButton( Button::Rec ); group2.emplace_back( &b ); }
   { auto & b = getButton( Button::Overdub ); group2.emplace_back( &b ); }
   { auto & b = getButton( Button::BackToArrangement ); group2.emplace_back( &b ); }
   { auto & b = getButton( Button::ComboBar ); group2.emplace_back( &b ); }
   { auto & b = getButton( Button::Pen ); group2.emplace_back( &b ); }

   auto & group3 = m_header.m_btnGroup3;
   { auto & b = getButton( Button::EdtLoopStart ); group3.emplace_back( &b ); }
   { auto & b = getButton( Button::PunchInToggle ); group3.emplace_back( &b ); }
   { auto & b = getButton( Button::LoopToggle ); group3.emplace_back( &b ); }
   { auto & b = getButton( Button::PunchOutToggle ); group3.emplace_back( &b ); }
   { auto & b = getButton( Button::EdtLoopLength ); group3.emplace_back( &b ); }

   auto & group4 = m_header.m_btnGroup4;
   { auto & b = getButton( Button::KeyMidiToggle ); group4.emplace_back( &b ); }
   { auto & b = getButton( Button::KeyMapToggle ); group4.emplace_back( &b ); }
   { auto & b = getButton( Button::KeyMidiInLED ); group4.emplace_back( &b ); }
   { auto & b = getButton( Button::KeyMidiOutLED ); group4.emplace_back( &b ); }
   { auto & b = getButton( Button::MidiMapToggle ); group4.emplace_back( &b ); }
   { auto & b = getButton( Button::CpuUsage ); group4.emplace_back( &b ); }
   { auto & b = getButton( Button::DiskUsage ); group4.emplace_back( &b ); }
   { auto & b = getButton( Button::MidiInLED ); group4.emplace_back( &b ); }
   { auto & b = getButton( Button::MidiOutLED ); group4.emplace_back( &b ); }

   m_layout.updateLayout( 640, 480, m_skin );
}

App::~App()
{}

void
App::reset()
{
}

void
App::updateLayout( int w, int h )
{
   m_layout.updateLayout( w, h, m_skin );

   // Header
   m_header.layout( m_layout.m_rcHeaderContent );

   m_pluginExplorer.layout( m_layout.m_rc1ExplorerContent );

   m_arrangement.layout( m_layout.m_rc1ArrangementContent );

   m_clipEditor.layout( m_layout.m_rc2ClipEditorClient );

   m_fxPanel->move( m_layout.m_rc2ClipEditorClient.topLeft() );
   m_fxPanel->setMinimumSize( m_layout.m_rc2ClipEditorClient.size() );
   m_fxPanel->setMaximumSize( m_layout.m_rc2ClipEditorClient.size() );

   // DeviceBar
   int x = m_layout.m_rc1DeviceBar.x();
   int y = m_layout.m_rc1DeviceBar.y();
   int s = 5;
   int cs = m_skin.circleButtonSize;
   int ln = cs + s;
   int needH = 7 * ( m_skin.circleButtonSize ) + 5*s;
   int availH = m_layout.m_rc1DeviceBar.height();
   int scrollH = availH - needH;
   if ( scrollH < 50) scrollH = 50;

   getButton( Button::ShowExplorer ).setPos( x,y ); y += ln;
   getButton( Button::ShowInternDevices ).setPos( x,y ); y += ln;
   getButton( Button::ShowExternDevices ).setPos( x,y ); y += ln;
   getButton( Button::ShowExplorer1 ).setPos( x,y ); y += ln;
   getButton( Button::ShowExplorer2 ).setPos( x,y ); y += ln;
   getButton( Button::ShowExplorer3 ).setPos( x,y ); y += cs;

   int dw = m_layout.m_rc1DeviceBar.width();
   m_layout.m_rc1DeviceScrollBar = QRect( x, y, dw, scrollH );
   y += scrollH;

   getButton( Button::ShowGrooves ).setPos( x,y ); y += ln;

   // ComposeBar
   x = m_layout.m_rc1ComposeBar.x();
   y = m_layout.m_rc1ComposeBar.y();
   getButton( Button::ShowArrangementPanel ).setPos( x,y ); y += ln;
   getButton( Button::ShowSessionPanel ).setPos( x,y ); y += ln;
   needH = 2 * (m_skin.circleButtonSize + s);
   availH = m_layout.m_rc1ComposeBar.height();
   scrollH = availH - needH;
   m_layout.m_rc1ComposeScrollBar = QRect( x, y, dw, scrollH );
   y += scrollH - 4*17;

   ln = 11 + 6;
   getButton( Button::ShowIO ).setPos( x+1,y ); y += ln;
   getButton( Button::ShowReturn ).setPos( x+1,y ); y += ln;
   getButton( Button::ShowMixer ).setPos( x+1,y ); y += ln;
   getButton( Button::ShowDelays ).setPos( x+1,y ); y += ln;

   // Footer
   x = m_layout.m_rc2FootBtnShowHelp.x();
   y = m_layout.m_rc2FootBtnShowHelp.y();
   getButton( Button::ShowQuickHelp ).setPos( x,y+2 );

   x = m_layout.m_rc2FootBtnShowEditor.x();
   y = m_layout.m_rc2FootBtnShowEditor.y();
   getButton( Button::ShowEditPanel ).setPos( x,y+2 );

}

//int
//App::findPanel( int mx, int my ) const
//{
//   for ( size_t i = 0; i < m_buttons.size(); ++i )
//   {
//      auto const & btn = m_buttons[ i ];
//      if ( btn.m_isVisible && isMouseOverRect( mx, my, btn.rect() ) )
//      {
//         return btn.id();
//      }
//   }
//   return -1;
//}

int
App::findButton( int mx, int my ) const
{
   for ( size_t i = 0; i < m_buttons.size(); ++i )
   {
      auto const & btn = m_buttons[ i ];
      if ( btn.m_isVisible && isMouseOverRect( mx, my, btn.rect() ) )
      {
         return btn.id();
      }
   }
   return -1;
}

Button const &
App::getButton( int id ) const
{
   int n = m_buttons.size();
   if ( id < 0 || id >= n )
   {
      throw std::runtime_error("Invalid button id " + std::to_string( id ) );
   }

   return m_buttons[ id ];
}

Button &
App::getButton( int id )
{
   int n = m_buttons.size();
   if ( id < 0 || id >= n )
   {
      throw std::runtime_error("Invalid button id " + std::to_string( id ) );
   }

   return m_buttons[ id ];
}
