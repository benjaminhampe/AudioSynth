﻿#ifndef DE_LIVE_UI_HPP
#define DE_LIVE_UI_HPP

#include <LiveSkin.hpp>

// ============================================================================
struct MouseEvent
// ============================================================================
{

   int buttonId = 0;
   bool isPressed = false;



};

// ============================================================================
struct UI_Elem
// ============================================================================
{
   virtual ~UI_Elem() = default;

   virtual int id() const = 0;
   virtual int type() const = 0;
   virtual QRect rect() const = 0;
   virtual void setRect( QRect const & pos ) = 0;
   virtual void setId( int id ) = 0;


};

// ============================================================================
struct Panel : public UI_Elem
// ============================================================================
{
   enum ePanel
   {
      PluginExplorer = 0,
      Arrangement,
      QuickHelp,
      ClipEdit,
      FxEdit,
      ExtraHelp,
      ePanelCount
   };

   int id() const override { return m_id; }
   void setId( int id ) override { m_id = id; }
   int type() const override { return 1; }
   QRect rect() const override { return m_pos; }
   void setRect( QRect const & pos ) override { m_pos = pos; }

   int m_id;
   QRect m_pos;
   bool m_hasFocus;
   QMargins m_contentMargins;

   Panel()
      : m_id( -1 )
      , m_pos( 0,0, 17,17 )
      , m_hasFocus( false )
      , m_contentMargins( 6,6,6,6 )
   {}
};

// ============================================================================
struct Button : public UI_Elem
// ============================================================================
{
   enum eButton
   {
   // DeviceBar
      ShowExplorer = 0,
      ShowInternDevices,
      ShowExternDevices,
      ShowExplorer1,
      ShowExplorer2,
      ShowExplorer3,
      //ScrollBar m_leftScrollBar;
      ShowGrooves,
   // ComposeBar
      ShowArrangementPanel,
      ShowSessionPanel,
      ScrollUp,
      ScrollDown,
      //ScrollLeft,
      //ScrollRight,
      ShowIO,
      ShowReturn,
      ShowMixer,
      ShowDelays,
   // Footer
      ShowQuickHelp,
      ShowEditPanel,
   // Header
      Tap,
      EdtBpm,
      NudgeSlow,
      NudgeFast,
      EdtSig,
      Metronom,
      DisplayFollow,
      EdtPos,
      Play,
      Stop,
      Rec,
      Overdub,
      BackToArrangement,
      ComboBar,
      Pen,
      EdtLoopStart,
      PunchInToggle,
      LoopToggle,
      PunchOutToggle,
      EdtLoopLength,
      KeyMidiToggle,
      KeyMidiInLED,
      KeyMidiOutLED,
      KeyMapToggle,
      MidiMapToggle,
      CpuUsage,
      DiskUsage, // HardDiskOverload indicator
      MidiInLED,
      MidiOutLED,
      eButtonCount
   };

   int id() const override { return m_id; }
   void setId( int id ) override { m_id = id; }

   int type() const override { return 2; }
   QRect rect() const override { return QRect( m_x, m_y, m_w, m_h ); }

   void setRect( QRect const & pos ) override
   {
      m_x = pos.x();
      m_y = pos.y();
      m_w = pos.width();
      m_h = pos.height();
   }

   int m_id;

   //QRect m_pos;
   int m_x;
   int m_y;
   int m_w;
   int m_h;

   bool m_isVisible; // hidden = not clickable / no hover
   bool m_isHovered;
   bool m_isPressed;
   //bool m_isActive;     //
   bool m_isCheckable;
   bool m_isChecked;

   QImage m_imgIdle;
   QImage m_imgIdleHover;
   QImage m_imgActive;
   QImage m_imgActiveHover;

   Button()
      : m_id( -1 )
      , m_x( 0 )
      , m_y( 0 )
      , m_w( 17 )
      , m_h( 17 )
      , m_isVisible( true )
      , m_isHovered( false )
      , m_isPressed( false )
      //, m_isActive( false )
      , m_isCheckable( false )
      , m_isChecked( false )
   {}

   int x() const { return m_x; }
   int y() const { return m_y; }
   int w() const { return m_w; }
   int h() const { return m_h; }
   void setX( int x ) { m_x = x; }
   void setY( int y ) { m_y = y; }
   void setWidth( int w ) { m_w = w; }
   void setHeight( int h ) { m_h = h; }

   void setPos( int x, int y )
   {
      m_x = x;
      m_y = y;
      //std::cout << "ButtonId(" << m_id << ").setPos(" << m_x << "," << m_y << ")" << std::endl;
   }
   void setSize( int w, int h ) { setWidth( w ); setHeight( h ); }

   void setCheckable( bool value ) { m_isCheckable = value; }
   void setChecked( bool value ) { m_isChecked = value; }

   void setImage( int i, QImage const & img )
   {
      m_w = img.width();
      m_h = img.height();
      switch( i )
      {
         case 0: m_imgIdle = img; break;
         case 1: m_imgIdleHover = img; break;
         case 2: m_imgActive = img; break;
         case 3: m_imgActiveHover = img; break;
         default: break;
      }
   }
};

// ============================================================================
struct Splitter : public UI_Elem
// ============================================================================
{
   enum eSplitter
   {
      SplitTopDown = 0,
      SplitExplorer,
      eSplitterCount
   };

   int id() const override { return m_id; }
   void setId( int id ) override { m_id = id; }

   int type() const override { return 2; }
   QRect rect() const override { return m_pos; }
   void setRect( QRect const & pos ) override { m_pos = pos; }

   int m_id;
   QRect m_pos;
   bool m_isHovered;
   bool m_isVertical;

   Splitter()
      : m_id( -1 )
      , m_pos( 0,0, 8,8 )
      , m_isHovered( false )
      , m_isVertical( true )
   {}
};


// ============================================================================
struct ScrollBar : public UI_Elem
// ============================================================================
{
   enum eScrollBar
   {
      DeviceBar = 0,
      ComposeBar,
      eScrollBarCount
   };

   int id() const override { return m_id; }
   void setId( int id ) override { m_id = id; }

   int type() const override { return 2; }
   QRect rect() const override { return m_pos; }
   void setRect( QRect const & pos ) override { m_pos = pos; }

   int m_id;
   QRect m_pos;
   bool m_isHovered;
   bool m_isVertical;

   ScrollBar()
      : m_id( -1 )
      , m_pos( 0,0, 8,8 )
      , m_isHovered( false )
      , m_isVertical( true )
   {}
};

// ============================================================================
struct Layout
// ============================================================================
{
   int m_p = 8;

//   int m_headerHeight = 17 + m_p;
//   int m_footerHeight = 16 + 12 + m_p; // panel content + 2*panel border + padding
//   int m_contentHeight = 0; // Computed max height for arrangement + midi or fx editor

   bool m_isHelpVisible = false; // Big help
   QRect m_rcHeader; // fix height
   QRect m_rc1; // variable height row1 ( plugin explorer + arrangement )
   QRect m_rcV; // fix height,splitter v rect between m_rc1 and m_rc2
   QRect m_rc2; // variable height row1 ( quick help + clip editor )
   QRect m_rcFooter; // fix height
   QRect m_rcCover; // rcV + rc2 + rcFooter to draw backround

   // Part I
   QRect m_rcHeaderContent; // fix height
   int m_deviceBarWidth = 23; // fix width
   int m_explorerWidthMin = 20; // fix width
   bool m_isExplorerVisible = true;
   int m_hsplitterPos = 200; // splitter h pos
   //int m_arrangementWidth = 0; // computed
   int m_composeBarWidth = 23; // fix width
   //QRect m_rc1Header; // Computed, buttons
   //QRect m_rc1Content; // Computed full content rect
   QRect m_rc1Left; // Computed
   QRect m_rc1Splitter; // Computed
   QRect m_rc1Right; // Computed

   QRect m_rc1DeviceBar; // Computed, buttons
   QRect m_rc1DeviceScrollBar; // Computed
   QRect m_rc1DeviceScrollBarClient; // Computed
   QRect m_rc1ExplorerPanel; // Computed
   QRect m_rc1ExplorerContent;
   QRect m_rc1ArrangementPanel; // Computed ( arrange + composebar = special panel )
   QRect m_rc1ArrangementContent;
   QRect m_rc1ComposeBar; // Computed, buttons
   QRect m_rc1ComposeScrollBar; // Computed
   QRect m_rc1ComposeScrollBarClient; // Computed
   // Part II

   // Bottom Rect Contents
   bool m_isEditPanelVisible = true;
   bool m_isQuickHelpVisible = true;
   bool m_isClipEditorVisible = true;
   int m_fxEditorHeight = 120; // fix height
   int m_clipEditorHeight = 230; // var height by splitter
   int m_vsplitterPos = m_fxEditorHeight; // splitter h pos
   int m_quickHelpWidth = 220; // fix width

   QRect m_rc2Content; // Computed full content rect
   QRect m_rc2QuickHelp;
   QRect m_rc2QuickHelpClient;
   QRect m_rc2ClipEditor;
   QRect m_rc2ClipEditorClient;
   QRect m_rc2FxEditor;
   QRect m_rc2FxEditorClient;

   // Footer Contents, Computed
   QRect m_rcFooterContent;
   QRect m_rc2FootBtnShowHelp;
   QRect m_rc2FootText;
   QRect m_rc2FootTextClient;
   QRect m_rc2FootMidi;
   QRect m_rc2FootMidiClient;
   QRect m_rc2FootFx;
   QRect m_rc2FootFxClient;
   QRect m_rc2FootBtnShowEditor; // Computed

   // Content

   void
   updateLayout( int w, int h, LiveSkin const & skin );

   void
   drawLayout( QPainter & dc, LiveSkin const & skin );
};

#endif // G_LOPASS1_HPP
