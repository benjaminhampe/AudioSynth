#include "PluginExplorer.hpp"
#include "App.hpp"
#include "Draw.hpp"

PluginExplorer::PluginExplorer( App & app )
   : m_app( app )
{
   reset();
}

void
PluginExplorer::reset()
{
   QString mediaDir = QString::fromStdString( m_app.m_mediaDirMB );
   m_imgVSTLogo.load( mediaDir + "vsti.png" );
   m_imgSynth.load( mediaDir + "vsti.png" );
   m_imgEffect.load( mediaDir + "vsti.png" );

   std::cout << "Load PluginDB ... " << std::endl;

   m_pluginDb.loadXml( m_app.m_mediaDirMB + "data/plugin_db.xml" );

   std::cout << "Loaded " << m_pluginDb.size() << " Plugins" << std::endl;
}

void
PluginExplorer::layout( QRect const & clipRect )
{
   m_clipRect = clipRect;
}

void
PluginExplorer::draw( QPainter & dc )
{
   int w = m_clipRect.width();
   int h = m_clipRect.height();

   if ( w < 1 || h < 1 )
   {
      return;
   }

   int x = m_clipRect.x();
   int y = m_clipRect.y();

   LiveSkin const & skin = m_app.m_skin;

   // Draw background
   dc.setRenderHint( QPainter::NonCosmeticDefaultPen );
   dc.fillRect( m_clipRect, skin.contentColor );


   // Draw title rect
   dc.fillRect( QRect(x, y, w, skin.searchBarH ), skin.titleColor );

   dc.setFont( QFont( "Arial Black", 10, 900, true ) );
   dc.setPen( QPen( QColor(0,0,0) ) );
   dc.setBrush( QBrush( QColor(0,0,0) ) );
   dc.drawText( x+10, y+15, QString::fromStdString( m_pluginDb.m_vstDirMB ) );
   y += skin.searchBarH;

   // Draw table header
   dc.fillRect( QRect(x, y, w, skin.tdH), skin.tdColor );
   y += skin.tdH;

   dc.setFont( QFont( "Arial", 10 ) );
   dc.setPen( QPen( QColor(0,0,0) ) );
   dc.setBrush( QBrush( QColor(0,0,0) ) );

   y += 14; // Advance to baseline, not topLeft
   for ( size_t i = 0; i < m_pluginDb.size(); ++i )
   {
      de::audio::PluginInfo const & plugin = m_pluginDb[ i ];
      dc.drawText( x, y, QString::fromStdWString( plugin.m_name ) );
      y += 14;
   }
}

