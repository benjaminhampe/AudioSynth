﻿#ifndef DE_LIVE_PLUGIN_EXPLORER_HPP
#define DE_LIVE_PLUGIN_EXPLORER_HPP

#include <LiveData.hpp>
#include <de/audio/plugin/PluginInfoList.hpp>

struct App;

// ============================================================================
struct PluginExplorer
// ============================================================================
{
   PluginExplorer( App & app );
   void reset();
   void layout( QRect const & clipRect );
   void draw( QPainter & dc );
public:
   App & m_app;
   QRect m_clipRect;
   de::audio::PluginInfoList m_pluginDb; // plugin database
   QImage m_imgVSTLogo;
   QImage m_imgSynth;
   QImage m_imgEffect;


   int m_listStart = 0; // Current scroll index y
   int m_listCount = 0; // Computed at runtime, depends on curr widget y height.

   int m_searchH = 20; // <searchBar> height
   int m_thH = 10;   // <th> height
   int m_tdH = 16;   // <td> height
   int m_tdB = 1;    // <td> border
   int m_iX = 10;// <td> icon offset x
   int m_iY = 10;// <td> icon offset y
   int m_nX = 10;// <td> name text offset x
   int m_nY = 10;// <td> name text offset y
//   QTreeWidgetItem* m_selectedItem;
//   QTreeWidgetItem* m_synthNode;
//   QTreeWidgetItem* m_effectNode;

//   bool m_isDragging;
//   int m_dragStartX;
//   int m_dragStartY;
};

#endif // G_LOPASS1_HPP
