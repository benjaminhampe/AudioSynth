﻿#ifndef DE_LIVE_HEADER_HPP
#define DE_LIVE_HEADER_HPP

#include <UI.hpp>

// Top button list: = EngineButtons, now called Header because of fix layout pos.
// Manages layout and draws Engine buttons
// Buttons are created and added by App constructor.
// ============================================================================
struct Header
// ============================================================================
{
   int m_spacing = 2;
   std::vector< Button* > m_btnGroup1;
   std::vector< Button* > m_btnGroup2;
   std::vector< Button* > m_btnGroup3;
   std::vector< Button* > m_btnGroup4;

   void
   layout( QRect const & clipRect );

   void
   draw( QPainter & dc, QRect const & clipRect, LiveSkin const & skin );

protected:
   int getGroup1Width() const
   {
      int w = 0;
      for ( auto & p : m_btnGroup1 ) { w += p->rect().width() + m_spacing; }
      return w;
   }

   int getGroup2Width() const
   {
      int w = 0;
      for ( auto & p : m_btnGroup2 ) { w += p->rect().width() + m_spacing; }
      return w;
   }

   int getGroup3Width() const
   {
      int w = 0;
      for ( auto & p : m_btnGroup3 ) { w += p->rect().width() + m_spacing; }
      return w;
   }

   int getGroup4Width() const
   {
      int w = 0;
      for ( auto & p : m_btnGroup4 ) { w += p->rect().width() + m_spacing; }
      return w;
   }

   int getTotalWidth() const
   {
      return getGroup1Width() + getGroup2Width()
           + getGroup3Width() + getGroup4Width();
   }
};

#endif // G_LOPASS1_HPP
