#include "Body.hpp"
#include "Create.hpp"
#include "Draw.hpp"
#include <QResizeEvent>

Body::Body( QWidget* parent )
   : QWidget( parent )
{
   setMouseTracking( true );
   setMinimumSize(384,78);

   m_app.m_fxPanel = new FxPanel( m_app, this );

}

Body::~Body()
{}

void
Body::resizeEvent( QResizeEvent* event )
{
   int w = event->size().width();
   int h = event->size().height();
   //topLevelWidget()->setWindowTitle( QString("WindowSize(%1,%2)").arg(w).arg(h));

   m_app.updateLayout( w, h );
   //update();
   QWidget::resizeEvent( event );
}

void
Body::paintEvent( QPaintEvent* event )
{
   int w = width();
   int h = height();

   if ( w > 1 && h > 1 )
   {
      LiveSkin const & skin = m_app.m_skin;
      Layout const & layout = m_app.m_layout;
      int s = 5;
      int r = skin.radius;

      QPainter dc( this );
      dc.setRenderHint( QPainter::NonCosmeticDefaultPen );
      dc.fillRect( rect(), skin.windowColor );

      // Part I - Left DeviceBar
      //drawRectBorder( dc, layout.m_rc1DeviceBar, QColor(255,255,255) );
      //drawRectBorder( dc, layout.m_rc1DeviceScrollBar, QColor(255,0,255) );
      drawImageButton( dc, m_app.getButton( Button::ShowExplorer ) );
      drawImageButton( dc, m_app.getButton( Button::ShowInternDevices ) );
      drawImageButton( dc, m_app.getButton( Button::ShowExternDevices ) );
      drawImageButton( dc, m_app.getButton( Button::ShowExplorer1 ) );
      drawImageButton( dc, m_app.getButton( Button::ShowExplorer2 ) );
      drawImageButton( dc, m_app.getButton( Button::ShowExplorer3 ) );
      drawImageButton( dc, m_app.getButton( Button::ShowGrooves ) );

      // Part I - Bg Left PluginExplorerPanel
      if ( layout.m_isExplorerVisible )
      {
         QRect rScrollL ( layout.m_rc1DeviceScrollBar.x(),
                          layout.m_rc1DeviceScrollBar.y() + s,
                          layout.m_rc1DeviceScrollBar.width() + (s + r + 1),
                          layout.m_rc1DeviceScrollBar.height() - 2*s );
         drawPanel( dc, rScrollL, skin );

         drawPanel( dc, layout.m_rc1ExplorerPanel, skin );

         //drawRectBorder( dc, layout.m_rc1ExplorerContent, QColor(255,255,255) );

         // Part I - Fg Left Explorer
         //drawHelpView( dc, layout.m_rc1ExplorerContent, skin );
         m_app.m_pluginExplorer.draw( dc );

      }


      // Part I - Right Arrangement Panel
      drawPanel( dc, layout.m_rc1ArrangementPanel, skin );
      QRect rScrollR ( layout.m_rc1ComposeScrollBar.x() - (s + 2*r + 1),
                       layout.m_rc1ComposeScrollBar.y(),
                       layout.m_rc1ComposeScrollBar.width() + (s + 2*r + 1),
                       layout.m_rc1ComposeScrollBar.height() );
      drawPanel( dc, rScrollR, skin );
      drawRectFill( dc, layout.m_rc1Splitter, skin.windowColor );
      m_app.m_arrangement.draw( dc );

      // Part I - Right ComposeBar
      drawImageButton( dc, m_app.getButton( Button::ShowArrangementPanel ) );
      drawImageButton( dc, m_app.getButton( Button::ShowSessionPanel ) );
      //drawRectBorder( dc, layout.m_rc1ComposeBar, QColor(255,255,255) );
      //drawRectBorder( dc, layout.m_rc1ComposeScrollBar, QColor(255,0,255) );
      drawImageButton( dc, m_app.getButton( Button::ShowIO ) );
      drawImageButton( dc, m_app.getButton( Button::ShowReturn ) );
      drawImageButton( dc, m_app.getButton( Button::ShowMixer ) );
      drawImageButton( dc, m_app.getButton( Button::ShowDelays ) );

      // Part II
      drawRectFill( dc, layout.m_rcCover, skin.windowColor ); // Fill entire header

//      if ( m_app.m_isOverSplitV )
//      {
//         drawRectBorder( dc, layout.m_rcV, QColor(255,255,255) );
//      }
      // Part II - Left QuickHelp Panel
      drawPanel( dc, layout.m_rc2QuickHelp, skin, false );
      drawHelpView( dc, layout.m_rc2QuickHelpClient, skin );

      // Part II - Right Clip editor or Fx VST DSP editor
      if ( layout.m_isEditPanelVisible )
      {
         if ( layout.m_isQuickHelpVisible )
         {
            drawPanel( dc, layout.m_rc2QuickHelp, skin );
            drawContent( dc, layout.m_rc2QuickHelpClient, skin );
         }

         if ( layout.m_isClipEditorVisible )
         {
            drawPanel( dc, layout.m_rc2ClipEditor, skin, false );
            //drawContent( dc, layout.m_rc2ClipEditorClient, skin );
            m_app.m_clipEditor.draw( dc );
         }
      }

      // Part III : Footer
      drawImageButton( dc, m_app.getButton( Button::ShowQuickHelp ) );

      // Part III : Footer
      drawPanel( dc, layout.m_rc2FootText, skin, false );
      drawContent( dc, layout.m_rc2FootTextClient, skin );

      // Part III : Footer
      drawPanel( dc, layout.m_rc2FootMidi, skin, false );
      drawContent( dc, layout.m_rc2FootMidiClient, skin );

      // Part III : Footer
      drawPanel( dc, layout.m_rc2FootFx, skin, false );
      drawContent( dc, layout.m_rc2FootFxClient, skin );

      // Part III : Footer
      drawImageButton( dc, m_app.getButton( Button::ShowEditPanel ) );

      // Part IV : Header ( always on top, therefore drawn last )
      drawRectFill( dc, layout.m_rcHeader, skin.windowColor ); // Fill entire header
      m_app.m_header.draw( dc, layout.m_rcHeaderContent, skin );

      // Debug highlighting
      if ( m_app.m_isOverDeviceScrollBar )
      {
         drawRectBorder( dc, m_app.m_layout.m_rc1DeviceScrollBarClient, 0xFFFFFFFF );
      }
      if ( m_app.m_isOverExplorer )
      {
         drawRectBorder( dc, m_app.m_layout.m_rc1ExplorerContent, 0xFFFFFFFF );
      }
      if ( m_app.m_isOverArrangement )
      {
         drawRectBorder( dc, m_app.m_layout.m_rc1ArrangementContent, 0xFFFFFFFF );
      }
      if ( m_app.m_isOverComposeScrollBar )
      {
         drawRectBorder( dc, m_app.m_layout.m_rc1ComposeScrollBarClient, 0xFFFFFFFF );
      }
      if ( m_app.m_isOverQickHelp )
      {
         drawRectBorder( dc, m_app.m_layout.m_rc2QuickHelpClient, 0xFFFFFFFF );
      }
      if ( m_app.m_isOverClipEditor )
      {
         drawRectBorder( dc, m_app.m_layout.m_rc2ClipEditorClient, 0xFFFFFFFF );
      }
      if ( m_app.m_isOverFxEditor )
      {
         drawRectBorder( dc, m_app.m_layout.m_rc2FxEditorClient, 0xFFFFFFFF );
      }

   }

   QWidget::paintEvent( event );
}


void
Body::on_showExplorer( bool checked )
{
//   m_pluginPanel->m_pluginPanel->setVisible( checked );
//   m_hSplit->updateGeometry();
}

void
Body::on_showHelpPanel( bool checked )
{
//   m_trackPanel->m_helpWidget->setVisible( checked );
//   m_vSplit->updateGeometry();
}

void
Body::on_showClipAndFxPanel( bool checked )
{
//   m_trackPanel->setVisible( checked );
//   m_vSplit->updateGeometry();
}


void
Body::hideEvent( QHideEvent* event )
{
   //DE_DEBUG("")
   QWidget::hideEvent( event );
}

void
Body::showEvent( QShowEvent* event )
{
   //DE_DEBUG("")
   QWidget::showEvent( event );
   //event->accept();
}

void
Body::mouseMoveEvent( QMouseEvent* event )
{
   int mx = event->x();
   int my = event->y();

   de::MouseEvent me;
   me.m_flags = de::MouseEvent::Moved;
   me.m_x = mx;
   me.m_y = my;
   me.m_wheelY = 0.0f;
   m_app.m_clipEditor.mouseMoveEvent( me );

   // === Find active panel ===
   m_app.m_hoverPanel = -1;
   if ( isMouseOverRect( mx, my, m_app.m_layout.m_rc1ExplorerPanel ) )
   {
      m_app.m_hoverPanel = 0;
   }
   else if ( isMouseOverRect( mx, my, m_app.m_layout.m_rc1ArrangementPanel ) )
   {
      m_app.m_hoverPanel = 1;
   }
   else if ( isMouseOverRect( mx, my, m_app.m_layout.m_rc2QuickHelp ) )
   {
      m_app.m_hoverPanel = 2;
   }
   else if ( isMouseOverRect( mx, my, m_app.m_layout.m_rc2ClipEditor ) )
   {
      m_app.m_hoverPanel = 3;
   }

   // === Find hover button ===
   int buttonId = m_app.findButton( mx,my );
   if ( buttonId > -1 )
   {
      Button & btn = m_app.getButton( buttonId );
      btn.m_isHovered = true;
   }

   int oldId = m_app.m_hoverButton;
   if ( oldId != buttonId )
   {
      if ( oldId > -1 )
      {
         Button & btn = m_app.getButton( oldId );
         btn.m_isHovered = false;
      }
   }
   m_app.m_hoverButton = buttonId;

   // === Find hover region ===

   m_app.m_isOverDeviceScrollBar = isMouseOverRect( mx, my, m_app.m_layout.m_rc1DeviceScrollBarClient );
   m_app.m_isOverExplorer = isMouseOverRect( mx, my, m_app.m_layout.m_rc1ExplorerContent );
   m_app.m_isOverArrangement = isMouseOverRect( mx, my, m_app.m_layout.m_rc1ArrangementContent );
   m_app.m_isOverComposeScrollBar = isMouseOverRect( mx, my, m_app.m_layout.m_rc1ComposeScrollBarClient );


   m_app.m_isOverClipEditor = isMouseOverRect( mx, my, m_app.m_layout.m_rc2ClipEditorClient );

   m_app.m_isOverFxEditor = isMouseOverRect( mx, my, m_app.m_layout.m_rc2FxEditorClient );
   m_app.m_isOverQickHelp = isMouseOverRect( mx, my, m_app.m_layout.m_rc2QuickHelpClient );

   // === Find hover splitter ===
   m_app.m_isOverSplitV = isMouseOverRect( mx, my, m_app.m_layout.m_rcV );
   m_app.m_isOverSplitH = isMouseOverRect( mx, my, m_app.m_layout.m_rc1Splitter );
   if ( m_app.m_isOverSplitV )
   {
      if ( cursor().shape() != Qt::SizeVerCursor )
      {
         setCursor( QCursor( Qt::SizeVerCursor ) );
      }
   }
   else if ( m_app.m_isOverSplitH )
   {
      if ( cursor().shape() != Qt::SizeHorCursor )
      {
         setCursor( QCursor( Qt::SizeHorCursor ) );
      }
   }
   else
   {
      if ( cursor().shape() != Qt::ArrowCursor )
      {
         setCursor( QCursor( Qt::ArrowCursor ) );
      }
   }

   // === Update layout when splitting v ===
   if ( m_app.m_dragMode == 1 ) // vsplit
   {
      m_app.m_layout.m_vsplitterPos = m_app.m_dragData - (my - m_app.m_dragStartY);
      int y1 = m_app.m_layout.m_rcHeader.y() + m_app.m_layout.m_rcHeader.height();
      int y2 = m_app.m_layout.m_rcFooter.y();
      if ( m_app.m_layout.m_vsplitterPos < y1 )
      {
         m_app.m_layout.m_vsplitterPos = y1;
      }
      else if ( m_app.m_layout.m_vsplitterPos > y2 )
      {
         m_app.m_layout.m_vsplitterPos = y2;
      }

      m_app.updateLayout( width(), height() );
   }

   // === Update layout when splitting h ===
   else if ( m_app.m_dragMode == 2 ) // hsplit
   {
      m_app.m_layout.m_hsplitterPos = m_app.m_dragData + (mx - m_app.m_dragStartX);
      int k = m_app.m_skin.padding + m_app.m_skin.circleButtonSize + 5;
      int x1 = k;
      int x2 = width() - 1 - k;
      if ( m_app.m_layout.m_hsplitterPos < x1 )
      {
         m_app.m_layout.m_hsplitterPos = x1;
      }
      else if ( m_app.m_layout.m_hsplitterPos >= x2 )
      {
         m_app.m_layout.m_hsplitterPos = x2;
      }

      m_app.updateLayout( width(), height() );
   }

   update();
   QWidget::mouseMoveEvent( event );
}


void
Body::mousePressEvent( QMouseEvent* event )
{
   int mx = event->x();
   int my = event->y();

   de::MouseEvent me;
   me.m_flags = de::MouseEvent::Pressed;
   me.m_x = mx;
   me.m_y = my;
   me.m_wheelY = 0.0f;
   if ( event->button() == Qt::LeftButton )
   {
      me.m_flags |= de::MouseEvent::BtnLeft;
   }
   else if ( event->button() == Qt::RightButton )
   {
      me.m_flags |= de::MouseEvent::BtnRight;
   }
   else if ( event->button() == Qt::MiddleButton )
   {
      me.m_flags |= de::MouseEvent::BtnMiddle;
   }


   m_app.m_clipEditor.mousePressEvent( me );


   int hoverId = m_app.m_hoverButton;
   if ( hoverId > -1 )
   {
      Button & btn = m_app.getButton( hoverId );
      if ( btn.m_isCheckable )
      {
         btn.m_isChecked = btn.m_isChecked;
      }
      else
      {
         btn.m_isChecked = true;
      }

   }

   if ( m_app.m_dragMode > 0 )
   {

   }
   else
   {
      if ( m_app.m_isOverSplitV )
      {
         m_app.m_dragMode = 1;
         m_app.m_dragData = m_app.m_layout.m_vsplitterPos; // Store original pos.
         //m_app.m_dragData = m_app.m_layout.m_rcV.y(); // Store original pos.
         m_app.m_dragStartX = mx;
         m_app.m_dragStartY = my;
      }
      else if ( m_app.m_isOverSplitH )
      {
         m_app.m_dragMode = 2;
         //m_app.m_dragData = m_app.m_layout.m_hsplitterPos; // Store original pos.
         m_app.m_dragData = m_app.m_layout.m_rc1Splitter.x(); // Store original pos.
         m_app.m_dragStartX = mx;
         m_app.m_dragStartY = my;
      }
   }

   update();

   QWidget::mousePressEvent( event );
}

void
Body::mouseReleaseEvent( QMouseEvent* event )
{
   int mx = event->x();
   int my = event->y();

   de::MouseEvent me;
   me.m_flags = de::MouseEvent::Released;
   me.m_x = mx;
   me.m_y = my;
   me.m_wheelY = 0.0f;
   if ( event->button() == Qt::LeftButton )
   {
      me.m_flags |= de::MouseEvent::BtnLeft;
   }
   else if ( event->button() == Qt::RightButton )
   {
      me.m_flags |= de::MouseEvent::BtnRight;
   }
   else if ( event->button() == Qt::MiddleButton )
   {
      me.m_flags |= de::MouseEvent::BtnMiddle;
   }
   m_app.m_clipEditor.mouseReleaseEvent( me );


   int hoverId = m_app.m_hoverButton;
   if ( hoverId > -1 )
   {
      Button & hoverButton = m_app.getButton( hoverId );

      if ( hoverButton.m_isCheckable )
      {
         hoverButton.m_isChecked = !hoverButton.m_isChecked;
      }
      else
      {
         hoverButton.m_isChecked = false;
      }

      auto & btnShowExplorer = m_app.getButton( Button::ShowExplorer );
      if ( hoverId == btnShowExplorer.m_id )
      {
         m_app.m_layout.m_isExplorerVisible = btnShowExplorer.m_isChecked;
         m_app.updateLayout( width(), height() );
      }

      auto & btnShowQuickHelp = m_app.getButton( Button::ShowQuickHelp );
      if ( hoverId == btnShowQuickHelp.m_id )
      {
         m_app.m_layout.m_isQuickHelpVisible = btnShowQuickHelp.m_isChecked;
         m_app.updateLayout( width(), height() );
      }

      auto & btnShowEditPanel = m_app.getButton( Button::ShowEditPanel );
      if ( hoverId == btnShowEditPanel.m_id )
      {
         m_app.m_layout.m_isEditPanelVisible = btnShowEditPanel.m_isChecked;
         m_app.updateLayout( width(), height() );
      }

   }

   if ( m_app.m_dragMode > 0 )
   {
      if ( m_app.m_dragMode == 1 )
      {
         m_app.updateLayout( width(), height() );
      }
      else if ( m_app.m_dragMode == 2 )
      {
         m_app.updateLayout( width(), height() );
      }
      m_app.m_dragMode = 0;
   }

   update();

   QWidget::mouseReleaseEvent( event );
}


void
Body::wheelEvent( QWheelEvent* event )
{
   //DE_DEBUG("MouseWheel = ",wheel )
   int mx = event->x();
   int my = event->y();

   de::MouseEvent me;
   me.m_flags = de::MouseEvent::Wheel;
   me.m_x = mx;
   me.m_y = my;
   me.m_wheelY = event->angleDelta().y();
   //   if ( me.m_wheelX != 0.0f )
   //   {
   //      me.m_flags |= de::MouseEvent::WheelX;
   //   }
   if ( me.m_wheelY != 0.0f )
   {
      me.m_flags |= de::MouseEvent::WheelY;
   }
   m_app.m_clipEditor.wheelEvent( me );

   QWidget::wheelEvent( event );
}

void
Body::keyPressEvent( QKeyEvent* event )
{
   //DE_DEBUG("KeyPress(",event->key(),")")


//   if ( m_driver )
//   {
//      de::SEvent post;
//      post.type = de::EET_KEY_EVENT;
//      post.keyEvent.Key = de::KEY_UNKNOWN;
//      post.keyEvent.Flags = de::SKeyEvent::Pressed;
//      if ( event->modifiers() & Qt::ShiftModifier ) { post.keyEvent.Flags |= de::SKeyEvent::Shift; }
//      if ( event->modifiers() & Qt::ControlModifier ) { post.keyEvent.Flags |= de::SKeyEvent::Ctrl; }
//      if ( event->modifiers() & Qt::AltModifier ) { post.keyEvent.Flags |= de::SKeyEvent::Alt; }
//      parseQtKey( event, post );
//      m_driver->postEvent( post );
//   }
   QWidget::keyPressEvent( event );
}

void
Body::keyReleaseEvent( QKeyEvent* event )
{
   //DE_DEBUG("KeyRelease(",event->key(),")")
//   de::SEvent post;
//   post.type = de::EET_KEY_EVENT;
//   post.keyEvent.Key = de::KEY_UNKNOWN;
//   post.keyEvent.Flags = de::SKeyEvent::None;
//   if ( event->modifiers() & Qt::ShiftModifier ) { post.keyEvent.Flags |= de::SKeyEvent::Shift; }
//   if ( event->modifiers() & Qt::ControlModifier ) { post.keyEvent.Flags |= de::SKeyEvent::Ctrl; }
//   if ( event->modifiers() & Qt::AltModifier ) { post.keyEvent.Flags |= de::SKeyEvent::Alt; }
//   parseQtKey( event, post );
//   m_driver->postEvent( post );


   QWidget::keyReleaseEvent( event );
}
