#include "Header.hpp"
#include "Create.hpp"
#include "Draw.hpp"

void
Header::layout( QRect const & clipRect )
{
   int clipW = clipRect.width();
   int totalW = getTotalWidth();

   int spacing = 0;
   int spacingR = 0;
   if ( clipW > totalW )
   {
      spacing = (clipW - totalW) / 3;
      spacingR = (clipW - totalW) - 2*spacing;
   }

   int x = clipRect.x();
   int y = clipRect.y();

   int xEnd = clipRect.x() + clipRect.width() - 1;


   for ( auto p : m_btnGroup1 ) { p->m_isVisible = false; }
   for ( auto p : m_btnGroup2 ) { p->m_isVisible = false; }
   for ( auto p : m_btnGroup3 ) { p->m_isVisible = false; }
   for ( auto p : m_btnGroup4 ) { p->m_isVisible = false; }

   bool ok = true;

   for ( auto p : m_btnGroup1 )
   {
      if ( ok )
      {
         p->setRect( QRect( x,y,p->w(),p->h() ) );
         p->m_isVisible = true;
      }

      if ( x + p->w() >= xEnd )
      {
         ok = false;
         break;
      }

      x += p->w() + m_spacing;
   }

   x += spacing;


   for ( auto p : m_btnGroup2 )
   {
      if ( ok )
      {
         p->setRect( QRect( x,y,p->w(),p->h() ) );
         p->m_isVisible = true;
      }

      if ( x + p->w() >= xEnd )
      {
         ok = false;
         break;
      }

      x += p->w() + m_spacing;
   }

   x += spacing;

   for ( auto p : m_btnGroup3 )
   {
      if ( ok )
      {
         p->setRect( QRect( x,y,p->w(),p->h() ) );
         p->m_isVisible = true;
      }

      if ( x + p->w() >= xEnd )
      {
         ok = false;
         break;
      }

      x += p->w() + m_spacing;
   }

   x += spacingR;

   for ( auto p : m_btnGroup4 )
   {
      if ( ok )
      {
         p->setRect( QRect( x,y,p->w(),p->h() ) );
         p->m_isVisible = true;
      }

      if ( x + p->w() >= xEnd )
      {
         ok = false;
         break;
      }

      x += p->w() + m_spacing;
   }

}

void
Header::draw( QPainter & dc, QRect const & clipRect, LiveSkin const & skin )
{
   int x1 = clipRect.x() + clipRect.width() - 1;

   // todo: draw background of header

   for ( auto p : m_btnGroup1 )
   {
      int x2 = p->x() + p->w() - 1;
      if ( x2 <= x1 )
      {
         drawImageButton( dc, *p );
      }
   }
   for ( auto p : m_btnGroup2 )
   {
      int x2 = p->x() + p->w() - 1;
      if ( x2 <= x1 )
      {
         drawImageButton( dc, *p );
      }
   }
   for ( auto p : m_btnGroup3 )
   {
      int x2 = p->x() + p->w() - 1;
      if ( x2 <= x1 )
      {
         drawImageButton( dc, *p );
      }
   }
   for ( auto p : m_btnGroup4 )
   {
      int x2 = p->x() + p->w() - 1;
      if ( x2 <= x1 )
      {
         drawImageButton( dc, *p );
      }
   }

}
