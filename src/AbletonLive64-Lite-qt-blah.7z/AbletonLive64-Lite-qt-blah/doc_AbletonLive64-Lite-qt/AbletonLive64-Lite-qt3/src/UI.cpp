#include "UI.hpp"
#include <QRect>
#include "Create.hpp"
#include "Draw.hpp"

void
Layout::updateLayout( int w, int h, LiveSkin const & skin )
{
   m_p = skin.padding;

   // Min elements
   int headerH = m_p + (m_p+1) + 17;
   int vsplitH = m_p;
   int footerH = 12 + 16 + m_p;

   // int minH =
//   int deviceBarWidth = 28;
//   int explorerWidth = m_hsplitterPos;
//   int arrangeWidth = 0;
//   int composeBarWidth = 0;

   m_rc1 = QRect();
   m_rcV = QRect();
   m_rc2 = QRect();

   // Main vertical layout compute variable heights
   int row1H = 0;
   int row2H = 0;
   if ( m_isEditPanelVisible )
   {
      if ( m_isClipEditorVisible )
      {
         row2H = m_vsplitterPos; // ClipEditor has variable height determined by splitter v.
      }
      else
      {
         row2H = 120;   // Fx-Audio DSP chain has fixed height ( yet )
      }
   }

   int availH = h - (headerH + vsplitH + footerH);
   if (availH > 0)
   {
      if ( row2H > availH )
      {
         row2H = availH;
      }
      else
      {
         row1H = availH - row2H;
      }
   }


   // Main vertical layout ( header+rc1+vsplit+rc2+footer )
   int y = 0;
   m_rcHeader = QRect( 0, y, w, headerH - 10 );
   y += headerH;

   m_rc1 = QRect( 0, y, w, row1H );
   y += row1H;

   int coverY = y;

   m_rcV = QRect( 0, y, w, vsplitH );
   y += vsplitH;

   m_rc2 = QRect( 0, y, w, row2H );
   y += row2H;

   m_rcFooter = QRect( 0, h - 1 - m_p-12-16,
                       w, 12+16 + m_p );

   m_rcCover = QRect( 0, coverY, w, h-coverY );
/*
   if ( y != h )
   {
      std::cout << "updateLayout() :: ERROR y != h " << std::endl;
   }
   else
   {
      std::cout << "updateLayout() :: OK y == h " << std::endl;
   }
*/
   m_rcHeaderContent = QRect( m_rcHeader.x() + m_p,
                              m_rcHeader.y() + m_p,
                              m_rcHeader.width() - 2*m_p,
                              17 );

   m_rcFooterContent = QRect( m_rcFooter.x() + m_p,
                              m_rcFooter.y(),
                              m_rcFooter.width() - 2*m_p,
                              12 + 16 );

   int x = 0;
   y = 0;

   // Footer Contents
   int frW = m_rcFooterContent.width();
   int frH = m_rcFooterContent.height();
   x = m_rcFooterContent.x();
   y = m_rcFooterContent.y();

   int btnW = skin.circleButtonSize;
   int fxW = 64;
   int midiW = 200;
   int restW = (btnW + m_p + m_p + midiW + m_p + fxW + m_p + btnW );
   int textW = frW - restW;

   m_rc2FootBtnShowHelp = QRect( x, y, btnW, btnW );
   x += btnW + m_p;

   m_rc2FootText = QRect( x, y, textW, frH );
   m_rc2FootTextClient = QRect( x + 6, y + 6, textW - 12, frH - 12 );
   x += textW + m_p;

   m_rc2FootMidi = QRect( x, y, midiW, frH );
   m_rc2FootMidiClient = QRect( x + 6, y + 6, midiW - 12, frH - 12 );
   x += midiW + m_p;

   m_rc2FootFx = QRect( x, y, fxW, frH );
   m_rc2FootFxClient = QRect( x + 6, y + 6, fxW - 12, frH - 12 );
   x += fxW + m_p;

   m_rc2FootBtnShowEditor = QRect( x, y, btnW, btnW );


   // Row1 Content : DeviceBar + PluginExplorer + Arrangement + ComposeBar
   //m_deviceBarWidth = 23; // fix width
   //m_explorerWidthMin = 20; // fix width
   //m_arrangementWidth = 0; // computed
   //m_composeBarWidth = 23; // fix width
   int trW = m_rc1.width() - 2*m_p; // - 2*barW;
   int trH = m_rc1.height();

   int barW = btnW + 5;
   int explorerW = 0;
   int arrangeW = 0;

   // H-Splitter
   if ( m_isExplorerVisible )
   {
      if ( trW < 2*barW + m_p )
      {

      }
      else
      {
         if ( trW < 2*barW + m_p + m_hsplitterPos )
         {
            explorerW = trW - 2*barW - m_p;
         }
         else
         {
            explorerW = m_hsplitterPos;
            arrangeW = trW - 2*barW - m_p - explorerW;
         }
      }

      if ( arrangeW < 100 )
      {
         explorerW -= 100 - arrangeW;
         arrangeW = 100;
         //m_hsplitterPos = explorerW;
      }

      x = m_rc1.x() + m_p;
      y = m_rc1.y();

      m_rc1Left = QRect( x, y, explorerW + barW, trH );
      m_rc1DeviceBar = QRect( x, y, btnW, trH );
      m_rc1ExplorerPanel = QRect( x + barW, y, explorerW, trH );
      m_rc1ExplorerContent = QRect( x + barW + 6, y + 6, explorerW - 12, trH - 12 );
      x += explorerW + barW;

      m_rc1Splitter = QRect( x, y, m_p, trH );
      x += m_p;

      m_rc1Right = QRect( x, y, arrangeW + barW, trH );
      m_rc1ArrangementPanel = QRect( x, y, arrangeW, trH );
      m_rc1ArrangementContent = QRect( x + 6, y + 6, arrangeW - 12, trH - 12 );
      m_rc1ComposeBar = QRect( x + arrangeW + 5, y, btnW, trH );
   }
   else
   {
      arrangeW = trW - 2*barW;

      x = m_rc1.x() + m_p;
      y = m_rc1.y();
      m_rc1Left = QRect();
      m_rc1DeviceBar = QRect( x, y, btnW, trH ); x += barW;
      m_rc1ExplorerPanel = QRect();
      m_rc1ExplorerContent = QRect();
      m_rc1Splitter = QRect();
      m_rc1Right = QRect( x, y, arrangeW+barW, trH );
      m_rc1ArrangementPanel = QRect( x, y, arrangeW, trH );
      m_rc1ArrangementContent = QRect( x + 6, y + 6, arrangeW - 12, trH - 12 );
      m_rc1ComposeBar = QRect( x + arrangeW + 5, y, btnW, trH );
   }

   // Bottom Rc2 sub rects
   m_rc2QuickHelp = QRect();
   m_rc2QuickHelpClient = QRect();
   m_rc2ClipEditor = QRect();
   m_rc2ClipEditorClient = QRect();

   if ( m_isEditPanelVisible )
   {
      int drW = m_rc2.width() - 2*m_p;
      int drH = m_rc2.height() - m_p;
      x = m_rc2.x() + m_p;
      y = m_rc2.y();

      int helpW = 0;
      if ( m_isQuickHelpVisible )
      {
         helpW = m_quickHelpWidth;

         m_rc2QuickHelp = QRect( x, y, helpW, drH );

         m_rc2QuickHelpClient = QRect( m_rc2QuickHelp.x() + 6,
                                       m_rc2QuickHelp.y() + 6,
                                       m_rc2QuickHelp.width() - 12,
                                       m_rc2QuickHelp.height() - 12 );

         x += helpW + m_p;
      }

      int clipW = drW - helpW - m_p;
      m_rc2ClipEditor = QRect( x, y, clipW, drH );

      m_rc2ClipEditorClient = QRect( m_rc2ClipEditor.x() + 6,
                                    m_rc2ClipEditor.y() + 6,
                                    m_rc2ClipEditor.width() - 12,
                                    m_rc2ClipEditor.height() - 12 );
   }
}
