﻿#ifndef DE_LIVE3_TIMELINE_OVERVIEW_HPP
#define DE_LIVE3_TIMELINE_OVERVIEW_HPP

#include <LiveData.hpp>

struct App;

// ============================================================================
struct TimeLineOverview
// ============================================================================
{
   TimeLineOverview( App & app );
   //~TimeLineOverview();
   void reset() { m_isHighlighted = false; }
   void paintEvent( QPainter & dc, QRect const & clipRect );
//signals:
//public slots:
//protected slots:
protected:
   void updateFromTrackList();

private:
   App & m_app;
   bool m_isHighlighted;
   int m_lineHeight;
   int m_minHeight;
};

#endif // G_LOPASS1_HPP
