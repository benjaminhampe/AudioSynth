/// (c) 2017 - 20180 Benjamin Hampe <benjaminhampe@gmx.de>

#ifndef DE_LIVE_SKIN_HPP
#define DE_LIVE_SKIN_HPP

#include <sstream>
#include <chrono>
#include <cmath>

#include <QMainWindow>
#include <QScreen>
#include <QWidget>
#include <QDesktopWidget>

#include <QWidget>
#include <QPainter>
#include <QSpinBox>
#include <QPushButton>
#include <QGridLayout>
#include <QLabel>
#include <QDial>
#include <QDebug>
#include <QThread>

#include <QWidget>
#include <QSplitter>
#include <QHBoxLayout>
#include <QVBoxLayout>
#include <QMenuBar>
#include <QMenu>
#include <QAction>
#include <QApplication>
#include <QFileDialog>

#include <QScrollArea>

#include <QVBoxLayout>
#include <QHBoxLayout>

#include <QPushButton>

#include <QFontDatabase>


#include <QFont5x8.hpp>       // Benni extra
#include <QImageWidget.hpp>   // Benni extra
#include <QColor>

#include <DarkImage.hpp>      // DarkImage
#include <de/Color.hpp>       // DarkImage
#include <de_fontawesome.hpp> // DarkImage

inline bool
isMouseOverRect( int mx, int my, QRect const & r )
{
   int w = r.width();
   int h = r.height();
   // Check canvas
   if ( w < 1 || h < 1 ) return false;

   int x1 = r.x();
   int x2 = r.x() + r.width() - 1;
   int y1 = r.y();
   int y2 = r.y() + r.height() - 1;

   // Check coords
   if ( mx < x1 || mx > x2 ) return false;
   if ( my < y1 || my > y2 ) return false;
   return true;
}

inline QWidget*
createWidget( QWidget* parent, int cm1 = 0, int cm2 = 0, int cm3 = 0, int cm4 = 0 )
{
   auto w = new QWidget( parent );
   w->setContentsMargins( cm1,cm2,cm3,cm4 );
   return w;
}

inline QHBoxLayout*
createHBox( int spacing = 0, int cm1 = 0, int cm2 = 0, int cm3 = 0, int cm4 = 0 )
{
   auto h = new QHBoxLayout();
   h->setContentsMargins( cm1,cm2,cm3,cm4 );
   h->setSpacing( spacing );
   return h;
}

inline QVBoxLayout*
createVBox( int spacing = 0, int cm1 = 0, int cm2 = 0, int cm3 = 0, int cm4 = 0 )
{
   auto v = new QVBoxLayout();
   v->setContentsMargins( cm1,cm2,cm3,cm4 );
   v->setSpacing( spacing );
   return v;
}

inline QFont getFontAwesome( int size = 10, bool bold = false )
{
   QFont font("FontAwesome", size, bold ? QFont::Bold : QFont::Normal, false );
   font.setHintingPreference( QFont::PreferFullHinting );
   font.setKerning( true );
   font.setStyleStrategy( QFont::PreferAntialias );
   return font;
}

inline void addFontAwesome463()
{
   int fontAwesome = QFontDatabase::addApplicationFont( "fontawesome463.ttf" );
   //int fontAwesome = QFontDatabase::addApplicationFont( "la-regular-400.ttf" );
   auto names = QFontDatabase::applicationFontFamilies( fontAwesome );
   for ( int i = 0; i < names.size(); ++i )
   {
      std::wcout << "Font[" << i << "] = " << names.at( i ).toStdWString() << std::endl;
   }
}

inline void setFontAwesome( QWidget* widget, int size = 10 )
{
   if ( !widget ) return;
   widget->setFont( getFontAwesome( size ) );
}

inline void setFontAwesome( QPainter & dc, int size = 10 )
{
   dc.setFont( getFontAwesome( size ) );
}

inline void
drawLine( QPainter & dc, int x1, int y1, int x2, int y2, QColor const & color )
{
   //dc.setBrush( Qt::NoBrush );
   dc.setPen( QPen( color ) );
   dc.drawLine( x1, y1, x2, y2 );
}

inline void
drawRectBorder( QPainter & dc, int x, int y, int w, int h, QColor const & color )
{
   if ( w < 1 || h < 1 ) return;
   dc.setPen( QPen( color ) );
   dc.setBrush( Qt::NoBrush );
   dc.drawRect( QRect(x,y,w-1,h-1) );
}

inline void
drawRectBorder( QPainter & dc, QRect const & pos, QColor const & color )
{
   int x = pos.x();
   int y = pos.y();
   int w = pos.width();
   int h = pos.height();
   drawRectBorder( dc, x,y,w,h, color );
}

inline void
drawRectFill( QPainter & dc, int x, int y, int w, int h, QColor const & color )
{
   if ( w < 1 || h < 1 ) return;
   dc.setPen( Qt::NoPen );
   dc.setBrush( QBrush( color ) );
   dc.drawRect( QRect(x,y,w,h) );
}


inline void
drawRectFill( QPainter & dc, QRect const & pos, QColor const & color )
{
   int x = pos.x();
   int y = pos.y();
   int w = pos.width();
   int h = pos.height();
   drawRectFill( dc, x,y,w,h, color );
}

inline void
drawRoundRectFill( QPainter & dc, int x, int y, int w, int h, QColor const & color, int rx = 6, int ry = 6 )
{
   dc.setPen( Qt::NoPen );
   dc.setBrush( QBrush( color ) );
   dc.drawRoundedRect( QRect(x,y,w,h), rx,ry );
}

//inline void
//fillRect( QPainter & dc, QRect pos, QColor color )
//{
//   fillRect( dc, pos.x(), pos.y(), pos.width(), pos.height(), color );
//}

inline void
drawRect( QPainter & dc, int x, int y, int w, int h, QColor const & fillColor, QColor const & penColor )
{
   dc.setPen( QPen( penColor ) );
   dc.setBrush( QBrush( fillColor ) );
   dc.drawRect( QRect(x,y,w-1,h-1) );
}

inline void
drawText( QPainter & dc, int x, int y, QString msg,
          QColor textColor = QColor(255,255,255) )
{
   dc.setPen( QPen( textColor ) );
   dc.setBrush( QBrush( textColor ) );
   dc.drawText( x, y, msg );
}

inline void
drawText5x8( QPainter & dc, int x, int y, QString msg,
             QColor const & textColor = QColor(255,255,255),
             de::Align::EAlign textAlign = de::Align::Default )
{
   QFont5x8().drawText( dc, x, y, msg, textColor, textAlign );
}

inline QImage
createImageFromText( int px, int py,
                     QString const & msg,
                     QFont const & font,
                     QColor const & fg = QColor(255,255,255),
                     QColor const & bg = QColor(0,0,0,0) )
{
   QPainter dc;
   dc.setFont( font );
   auto ts = dc.fontMetrics().boundingRect( msg ).size();

   int w = ts.width() + 2*px;
   int h = ts.height() + 2*py;
   QImage img( w, h, QImage::Format_ARGB32 );
   img.fill( bg );
   if ( dc.begin( &img ) )
   {
      dc.setPen( QPen( fg ) );
      dc.setBrush( QBrush( fg ) );
      dc.drawText( px, h-3 - py, msg );
      dc.end();
   }

   return img;
}

inline QImage
createRectImage( int w, int h,
                 QColor const & fg,
                 QColor const & bg,
                 QImage const & symbol = QImage(),
                 int symX = 0, int symY = 0 )
{
   QImage img( w, h, QImage::Format_ARGB32 );
   img.fill( fg );

   QPainter dc;
   if ( dc.begin( &img ) )
   {
      dc.setRenderHint( QPainter::NonCosmeticDefaultPen );
      dc.fillRect( QRect(1,1,w-2,h-2), bg );

      if ( !symbol.isNull() )
      {
         int x = symX + ( w - symbol.width() ) / 2;
         int y = symY + ( h - symbol.height() ) / 2;
         dc.drawImage( x, y, symbol );
      }

      dc.end();
   }

   return img;
}


inline QImage
createCircleImage( int w, int h, QColor const & groundColor, QColor const & shapeColor,
             QImage const & icon = QImage(), int icoX = 0, int icoY = 0 )
{
   QImage img( w, h, QImage::Format_ARGB32 );
   //img.fill( groundColor );
   img.fill( groundColor );

   QPainter dc;
   if ( dc.begin( &img ) )
   {
      dc.setRenderHint( QPainter::Antialiasing ); // NonCosmeticDefaultPen
      dc.setPen( Qt::NoPen );
      dc.setBrush( QBrush( shapeColor ) );
      dc.drawEllipse( QRect(0,0,w,h) );

      if ( !icon.isNull() )
      {
         int x = icoX + ( w - icon.width() ) / 2;
         int y = icoY + ( h - icon.height() ) / 2;
         dc.drawImage( x, y, icon );
      }

      dc.end();
   }

   return img;
}

inline QImage
loadImage( QString const & uri )
{
   QImage img;
   img.load( uri );
   return img;
}

inline bool
saveImage( QImage const & img, QString const & uri )
{
   return img.save( uri );
}
/*
inline QImage
createTransparencyArt(
      QColor fg = QColor(255,255,255),
      QColor bg = QColor(0,0,0,0),
      std::vector< std::vector< uint8_t > > const & pixmap )
{
   int w = 0;
   int h = 0;
   int m = pixmap.size();
   for ( int j = 0; j < m; ++j )
   {
      auto const & line = pixmap[ j ];
      int n = line.size();
      w = std::max( w, n );
      if ( n > 0 )
      {
         h = j + 1; // this line is new end of image.
      }
   }

   std::cout << "Create ascii image(" << w << "," << h << ") from " << m << " lines." << std::endl;

   QImage img( w, h, QImage::Format_ARGB32 );
   img.fill( bg );

   for ( int j = 0; j < m; ++j )
   {
      auto const & line = lines[ j ];
      int n = line.size();
      for ( int i = 0; i < n; ++i )
      {
         if ( line[ i ] != ' ' )
         {
            img.setPixelColor( i,j, fg );
         }
      }
   }

   return img;
}
*/

inline QImage
createAsciiArt(
      std::vector< std::string > const & lines,
      QColor fg = QColor(255,255,255),
      QColor bg = QColor(0,0,0,0) )
{
   int w = 0;
   int h = 0;
   int m = lines.size();
   for ( int j = 0; j < m; ++j )
   {
      auto const & line = lines[ j ];
      int n = line.size();
      w = std::max( w, n );
      if ( n > 0 )
      {
         h = j + 1; // this line is new end of image.
      }
   }

   //std::cout << "Create ascii image(" << w << "," << h << ") from " << m << " lines." << std::endl;

   QImage img( w, h, QImage::Format_ARGB32 );
   img.fill( bg );

   for ( int j = 0; j < m; ++j )
   {
      auto const & line = lines[ j ];
      int n = line.size();
      for ( int i = 0; i < n; ++i )
      {
         if ( line[ i ] != ' ' )
         {
            img.setPixelColor( i,j, fg );
         }
      }
   }

   return img;
}

inline QImage
createAsciiArt15(
      QColor fg = QColor(255,255,255),
      QColor bg = QColor(0,0,0,0),
      std::string const & s0 = "",
      std::string const & s1 = "",
      std::string const & s2 = "",
      std::string const & s3 = "",
      std::string const & s4 = "",
      std::string const & s5 = "",
      std::string const & s6 = "",
      std::string const & s7 = "",
      std::string const & s8 = "",
      std::string const & s9 = "",
      std::string const & s10 = "",
      std::string const & s11 = "",
      std::string const & s12 = "",
      std::string const & s13 = "",
      std::string const & s14 = "" )
{
   return createAsciiArt( std::vector< std::string >{ s0, s1, s2, s3, s4,
                                                      s5, s6, s7, s8, s9,
                                                      s10, s11, s12, s13, s14 }, fg, bg );
}

inline QImage
createAsciiArt( QColor fg, QColor bg, std::string const & multiLineText )
{
   return createAsciiArt( dbStrSplit( multiLineText, '\n' ), fg, bg );
}


// namespace de {

inline QColor
toQColor( uint32_t color )
{
   int32_t r = de::RGBA_R(color);
   int32_t g = de::RGBA_G(color);
   int32_t b = de::RGBA_B(color);
   int32_t a = de::RGBA_A(color);
   return QColor( r,g,b,a );
}

inline void
drawKey( QPainter & dc, QRect pos, QColor brushColor, QColor penColor )
{
   int x = pos.x();
   int y = pos.y();
   int w = pos.width()-1;
   int h = pos.height()-1;

   if ( h < 6 )
   {
      dc.setPen( Qt::NoPen );
      dc.setBrush( QBrush( brushColor ) );
      dc.drawRect( pos );
   }
   else
   {
      dc.setPen( Qt::NoPen );
      dc.setBrush( QBrush( brushColor ) );
      dc.drawRect( QRect(x+1,y+1,w-2,h-2) );

      dc.setPen( QPen( penColor ) );
      dc.drawLine( x+1,y, x+w-2, y );
      dc.drawLine( x+1,y+h-1, x+w-2, y+h-1 );
      dc.drawLine( x,y+1, x, y+h-2 );
      dc.drawLine( x+w-1,y+1, x+w-1, y+h-2 );
   }
}

inline QColor
blendRGB( QColor from, QColor to, float t )
{
   int32_t r = from.red();
   int32_t g = from.green();
   int32_t b = from.blue();
   //int32_t a = from.alpha();
   int32_t dr = int( to.red() ) - r;
   int32_t dg = int( to.green() ) - g;
   int32_t db = int( to.blue() ) - b;
   //int32_t da = int( to.alpha() ) - a;

   r = std::clamp( int32_t( t * dr + float( r ) ), 0, 255 );
   g = std::clamp( int32_t( t * dg + float( g ) ), 0, 255 );
   b = std::clamp( int32_t( t * db + float( b ) ), 0, 255 );
   //a = std::clamp( int32_t( t * da + float( a ) ), 0, 255 );
   return QColor( r, g, b );
}

struct LiveSkin
{
   int padding = 8;
   int radius = 8;

   int margin = 4;
   int titleH = 12;
   int searchBarH = 20;
   int tdH = 12;

   int circleButtonSize = 23; //16+12,23,19;

   QColor windowColor = QColor(24,30,35);  // dark blue
   QColor panelColor = QColor(103,116,140);  // semi dark blue
   QColor focusColor = QColor(127,137,147); // darker gray
   QColor activeColor = QColor( 238, 246, 13 ); // yellow highlight

   QColor titleColor = QColor(217,221,226);   // light white blue
   QColor titleTextColor = windowColor;  // same as Window
   QColor contentColor = QColor(170,178,183); // greyish
   QColor editBoxColor = QColor(232,232,232);  // almost white
   QColor tdColor = QColor(140,153,175);  // table header

   QColor blackEditColor = QColor(217,221,226);
   QColor whiteEditColor = QColor(196,200,204);

   QColor ePenColor = QColor( 166, 181, 186 ); // Engine Button
   QColor eFillColor = QColor( 146, 157, 168 );
   QColor semiBeatColor = QColor(146,156,167);  // light grey between main beat grid
   QColor eTextColor = QColor( 29, 31, 33 );

   QColor playColor = QColor(79,254,29);
   QColor recColor = QColor(254,49,34);

   QColor panelBlendColor = blendRGB( windowColor, panelColor, 0.25f );

//   enum EColor
//   {
//      Window = 0,
//      BluePanel,
//      GrayPanel,
//      Title,
//      TitleText,
//      Content,
//      EditBox,
//      EColorCount
//   };

//   static QColor
//   getQColor( EColor colorId )
//   {
//      //return toQColor( LiveSkin::getColor( colorId ) );
//      switch ( colorId )
//      {
//         case Window: return
//         case BluePanel: return
//         case GrayPanel: return
//         case Title: return
//         case TitleText: return QColor(24,30,35); // same as Window
//         case Content: return
//         case EditBox: return ;
//         default: return QColor(24,30,35); // debug violett
//      }
//   }
};

// } end namespace de

#endif
