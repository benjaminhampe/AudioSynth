#include "TimeLineOverview.hpp"
#include "App.hpp"

// ============================================================================
TimeLineOverview::TimeLineOverview( App & app )
// ============================================================================
   : m_app( app )
{
   m_lineHeight = 3;
   m_minHeight = m_lineHeight;
   updateFromTrackList();
}

void
TimeLineOverview::updateFromTrackList()
{
   int h = m_lineHeight;
   int n = m_app.m_trackList.size();
   if ( n > 0 )
   {
      h = n * m_lineHeight;
   }
   m_minHeight = h+4;
}

//void
//TimeLineOverview::resizeEvent( QResizeEvent* event )
//{
//   update();
//   QWidget::resizeEvent( event );
//}

void
TimeLineOverview::paintEvent( QPainter & dc, QRect const & clipRect )
{
   int w = clipRect.width();
   int h = clipRect.height();
   if ( w < 1 || h < 1 ) { return; }

   LiveSkin const & skin = m_app.m_skin;
   BeatGrid const & grid = m_app.m_beatGrid;
   TrackList const & trackList = m_app.m_trackList;

   // Draw gray background
   dc.fillRect( clipRect, skin.contentColor );

   // Draw tracks
   int x = clipRect.x();
   int y = clipRect.y() + 2;
   for ( int i = 0; i < trackList.trackCount(); ++i )
   {
      Track const & track = trackList.track( i );
      for ( int c = 0; c < track.clipCount(); ++c )
      {
         Clip const & clip = track.clip( c );
         int x1 = x + grid.time2pixel( clip.m_timeBeg );
         int x2 = x + grid.time2pixel( clip.m_timeEnd );
         dc.fillRect( QRect(x1, y, x2, m_lineHeight ), clip.m_color );
      }

      dc.setBrush( Qt::NoBrush );
      dc.setPen( QPen( skin.panelColor ) );
      dc.drawLine( x, y + m_lineHeight - 1, x+w-1, y+m_lineHeight-1 );
      y += m_lineHeight;

   }

   dc.setBrush( Qt::NoBrush );
   dc.setPen( QPen( QColor(0,0,0) ) );
   dc.drawRect( QRect( x,y,w-1,h-1 ) );
   dc.drawRect( QRect( x+1,y+1,w-3,h-3 ) );
}
