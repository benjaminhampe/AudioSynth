﻿#ifndef DE_LIVE2_IMAGEBUTTON_HPP
#define DE_LIVE2_IMAGEBUTTON_HPP

#include <Live0_Panel.hpp>

// ============================================================================
class ImageButton : public QPushButton
// ============================================================================
{
   Q_OBJECT
   QImage m_imgIdle;
   QImage m_imgActive;
public:
   ImageButton( QString msg, QWidget* parent = 0 );
   ~ImageButton();

signals:
public slots:
   void setImageUri( int i, QString uri );
   void setImage( int i, QImage img );
protected:
   //void updateImage();
   //void resizeEvent( QResizeEvent* event ) override;
   void paintEvent( QPaintEvent* event ) override;

protected:
};

#endif // G_LOPASS1_HPP
