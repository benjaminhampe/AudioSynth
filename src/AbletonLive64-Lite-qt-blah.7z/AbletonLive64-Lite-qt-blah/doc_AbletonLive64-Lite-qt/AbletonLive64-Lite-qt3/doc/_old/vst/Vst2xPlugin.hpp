﻿#ifndef DE_AUDIO_VST2X_PLUGIN_HPP
#define DE_AUDIO_VST2X_PLUGIN_HPP

#include <QWidget>
#include <QImage>
#include <QDebug>
#include <cstdint>
#include <sstream>
#include <vector>
#include <map>
#include <functional>
#include <algorithm>
#include <memory>
#include <mutex>
#include <atomic>
#include <thread>
#include <iostream>
#include <de/audio/dsp/IDspChainElement.hpp>
#include <QRect>
#include <QFont5x8.hpp>
//#pragma warning(push)
//#pragma warning(disable : 4996)
#include <pluginterfaces/vst2.x/aeffectx.h>  // de_vst2sdk
//#pragma warning(pop)

namespace de {
namespace audio {

struct ComInit
{
   ComInit();
   ~ComInit();
};

// ============================================================================
class IVstEditorWindow
// ============================================================================
{
   virtual ~IVstEditorWindow() = default;

   virtual uint64_t getWindowHandle() const { return 0; }

   virtual void onResizeEditor( int w, int h );
};

// ============================================================================
class Vst2xPlugin : public IDspChainElement
// ============================================================================
{
   Q_OBJECT
   DE_CREATE_LOGGER("Vst2xPlugin")

   uint64_t m_dllHandle; // HMODULE
   IVstEditorWindow* m_editorWindow;
   //uint64_t m_editorHandle; // HWND
   IDspChainElement* m_inputSignal; // For effects

   //int m_volume;
   bool m_isLoaded;
   bool m_isBypassed;
   bool m_isVstDirty;   // needs update
   // VST desc
   uint32_t m_vstRate;     // rate in Hz
   uint32_t m_bufferFrames;   // frames per channel
   uint32_t m_vstOut; // >0 expected for all plugins, >2 will be limited to 2, =1 will be doubled to 2 (stereo).
   uint32_t m_vstIn;  // = 0 for synths, >0 for all else effects

   std::wstring m_uri; // Plugin file name

   // Steinberg API
   AEffect* m_vst;
   std::atomic< uint64_t > m_framePos;
   VstTimeInfo m_timeInfo;
   std::string m_directoryMultiByte;

   // VST seems to work channelwise / planar, not interleaved audio.
   std::vector< float > m_outBuffer;
   std::vector< float* > m_outBufferHeads;
   std::vector< float > m_inBuffer;
   std::vector< float* > m_inBufferHeads;
   // VST midi event handling
   std::vector< VstMidiEvent > m_vstMidiEvents;
   std::vector< char > m_vstEventBuffer;
   struct MidiEventQueue
   {
      std::unique_lock< std::mutex >
      lock() const
      {
         return std::unique_lock<std::mutex>(m_mutex);
      }

      std::vector< VstMidiEvent > events;
   private:
      std::mutex mutable m_mutex;
   };
   MidiEventQueue m_vstMidi;

public:
   Vst2xPlugin();
   ~Vst2xPlugin();

   void clearInputSignals() { m_inputSignal = nullptr; }
   void setInputSignal( int i, IDspChainElement* input ){ m_inputSignal = input; }

   bool isSynth() const { return m_vstIn < 2 && m_vstOut >= 2; }
   bool isEffect() const { return m_vstIn >= 2 && m_vstOut >= 2; }
   uint32_t getSampleRate() const { return m_vstRate; }
   uint64_t getFramePos() const { return m_framePos; }
   uint64_t getBlockSize() const { return m_bufferFrames; }
   //uint64_t getChannelCount() const { return m_channelCount; }

   bool isBypassed() const { return m_isBypassed; }
   void setBypassed( bool enabled ) { m_isBypassed = enabled; }

   void aboutToStart( uint32_t dstFrames, uint32_t dstChannels, uint32_t dstRate ) override;
   uint64_t readSamples( double pts, float* dst, uint32_t dstFrames, uint32_t dstChannels, uint32_t dstRate ) override;

   void sendNote( Note const & note ) override;

   // void emit_addedSynth( IDspChainElement* );
   // void emit_removedSynth( IDspChainElement* );

   // VST effect plugins need audio input signals. VSTi synth plugins dont.


   // Load PluginDll x64
   bool open( std::wstring const & uri );
   void reset();
   bool getFlags( int32_t m ) const; // effFlagsHasEditor | effFlagsCanReplacing | effFlagsProgramChunks | effFlagsIsSynth, etc...
   bool hasEditor() const;
   int getVendorVersion();
   std::string getVendorString();
   std::string getProductString();

   void
   sendMidiNote( int midiChannel, int noteNumber, int velocity );

   const char**
   getCapabilities() const;

private:

   static VstIntPtr
   vstHostCallback_static( AEffect * effect,
                           VstInt32 opcode,
                           VstInt32 index,
                           VstIntPtr value,
                           void * ptr,
                           float opt );

   VstIntPtr
   vstHostCallback( VstInt32 opcode,
                    VstInt32 index,
                    VstIntPtr value,
                    void * ptr,
                    float opt );

   intptr_t
   vstDispatch( int32_t opcode,
                int32_t index = 0,
                intptr_t value = 0,
                void* ptr = nullptr,
                float opt = 0.0f ) const;

   // This function is called from refillCallback() which is running in audio thread.
   void
   processVstMidiEvents();

   void closeEditor()
   {
      if ( m_editorWindow )               // Stop plugin
      {                                   // Stop plugin
         //m_editorWindow->enableClosing(); // Stop plugin
         vstDispatch(effEditClose);        // Stop plugin
         //m_editorWindow->close();         // Stop plugin
         //delete m_editorWindow;           // Stop plugin
         m_editorWindow = nullptr;        // Stop plugin
      }
   }

   // This function is called from refillCallback() which is running in audio thread.
//   float**
//   processAudio( uint64_t frameCount, uint64_t & outputFrameCount );

   // void
   // resizeEditor( QRect const & pos )
   // {
      // if ( m_editorWindow )
      // {
         // m_editorWindow->setMinimumSize( pos.width(), pos.height() );
         // m_editorWindow->setMaximumSize( pos.width(), pos.height() );
         // m_editorWindow->move( pos.x(), pos.y() );
      // }
   // }

   // Recti
   // getEditorRect( uint64_t winHandle )
   // {
      // if( !is_open() || !hasEditor() ) return false;
      // // dispatcher(effEditOpen, 0, 0, (void*)winHandle );

      // ERect* erc = nullptr;
      // dispatcher( effEditGetRect, 0, 0, &erc );
      // int x = erc->left;
      // int y = erc->top;
      // int w = erc->right - x;
      // int h = erc->bottom - y;
   // }

   // bool
   // openEditor( uint64_t winHandle )
   // {
      // if( !hasEditor() ) return false;
      // dispatcher(effEditOpen, 0, 0, (void*)winHandle );
      // // ERect* erc = nullptr;
      // // dispatcher( effEditGetRect, 0, 0, &erc );
      // // int x = erc->left;
      // // int y = erc->top;
      // // int w = erc->right - x;
      // // int h = erc->bottom - y;
      // // resizeEditor( QRect( x,y,w,h ) );
      // //ShowWindow(winHandle, SW_SHOW);
   // }

};


} // end namespace audio
} // end namespace de

#endif // G_LOPASS1_HPP
