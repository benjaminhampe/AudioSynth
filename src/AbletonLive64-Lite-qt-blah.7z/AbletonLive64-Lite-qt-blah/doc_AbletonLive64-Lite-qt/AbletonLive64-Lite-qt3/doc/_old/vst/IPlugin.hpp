﻿#ifndef DE_AUDIO_I_PLUGIN_HPP
#define DE_AUDIO_I_PLUGIN_HPP

#include <QWidget>
#include <QImage>
#include <QDebug>
#include <cstdint>
#include <sstream>
#include <vector>
#include <map>
#include <functional>
#include <algorithm>
#include <memory>
#include <mutex>
#include <atomic>
#include <thread>
#include <iostream>
#include <de/audio/dsp/IDspChainElement.hpp>

namespace de {
namespace audio {

// ============================================================================
class IAudioPluginEditorWindow
// ============================================================================
{
   virtual ~IAudioPluginEditorWindow() = default;

   virtual uint64_t getWindowHandle() const { return 0; }

   virtual void onResizeEditor( int w, int h );
};

// ============================================================================
struct IPlugin : public IDspChainElement
// ============================================================================
{
   virtual ~IPlugin() = default;

   virtual std::wstring const & getUri() const = 0;
   virtual void setUri( std::wstring const & uri ) = 0;

   virtual bool openPlugin() = 0;
   virtual void closePlugin() = 0;

   virtual bool hasEditor() const { return false; }
   // effFlagsHasEditor | effFlagsCanReplacing | effFlagsProgramChunks | effFlagsIsSynth, etc...   
   virtual bool getFlags( int32_t m ) const { return false; }
   
   virtual int getVendorVersion() const { return 0; }
   
   virtual std::string getVendorString() { return ""; }
   
   virtual std::string getProductString() { return ""; }

   // inline
   virtual bool open( std::wstring const & uri )
   {
      setUri( uri ); return openPlugin();
   }

   // std::string m_directoryMultiByte;

   // // VST seems to work channelwise / planar, not interleaved audio.
   // std::vector< float > m_outBuffer;
   // std::vector< float* > m_outBufferHeads;
   // std::vector< float > m_inBuffer;
   // std::vector< float* > m_inBufferHeads;
   // // VST midi event handling
   // std::vector< VstMidiEvent > m_vstMidiEvents;
   // std::vector< char > m_vstEventBuffer;

   // void closeEditor()
   // {
      // if ( m_editorWindow )               // Stop plugin
      // {                                   // Stop plugin
         // //m_editorWindow->enableClosing(); // Stop plugin
         // vstDispatch(effEditClose);        // Stop plugin
         // //m_editorWindow->close();         // Stop plugin
         // //delete m_editorWindow;           // Stop plugin
         // m_editorWindow = nullptr;        // Stop plugin
      // }
   // }

   // This function is called from refillCallback() which is running in audio thread.
//   float**
//   processAudio( uint64_t frameCount, uint64_t & outputFrameCount );

   // void
   // resizeEditor( QRect const & pos )
   // {
      // if ( m_editorWindow )
      // {
         // m_editorWindow->setMinimumSize( pos.width(), pos.height() );
         // m_editorWindow->setMaximumSize( pos.width(), pos.height() );
         // m_editorWindow->move( pos.x(), pos.y() );
      // }
   // }

   // Recti
   // getEditorRect( uint64_t winHandle )
   // {
      // if( !is_open() || !hasEditor() ) return false;
      // // dispatcher(effEditOpen, 0, 0, (void*)winHandle );

      // ERect* erc = nullptr;
      // dispatcher( effEditGetRect, 0, 0, &erc );
      // int x = erc->left;
      // int y = erc->top;
      // int w = erc->right - x;
      // int h = erc->bottom - y;
   // }

   // bool
   // openEditor( uint64_t winHandle )
   // {
      // if( !hasEditor() ) return false;
      // dispatcher(effEditOpen, 0, 0, (void*)winHandle );
      // // ERect* erc = nullptr;
      // // dispatcher( effEditGetRect, 0, 0, &erc );
      // // int x = erc->left;
      // // int y = erc->top;
      // // int w = erc->right - x;
      // // int h = erc->bottom - y;
      // // resizeEditor( QRect( x,y,w,h ) );
      // //ShowWindow(winHandle, SW_SHOW);
   // }

};


} // end namespace audio
} // end namespace de

#endif // G_LOPASS1_HPP
