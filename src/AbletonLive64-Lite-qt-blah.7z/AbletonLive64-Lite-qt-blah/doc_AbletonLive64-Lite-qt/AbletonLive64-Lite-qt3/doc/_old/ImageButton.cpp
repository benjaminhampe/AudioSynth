#include "ImageButton.hpp"

inline QPushButton* createButton( QString txt, QWidget* parent )
{

   return btn;
}

ImageButton::ImageButton( QString msg, QWidget* parent )
   : QPushButton( msg, parent )
{
   setObjectName( "ImageButton" );
   setContentsMargins(0,0,0,0);
   setMinimumHeight( 16 );
   setMaximumHeight( 16 );
   setFontAwesome( this );
}

ImageButton::~ImageButton()
{

}

void
ImageButton::setImageUri( int i, QString uri )
{
   QImage img;
   if ( img.load( uri ) )
   {
      setImage( i, img );
   }
}

void
ImageButton::setImage( int i, QImage img )
{
   if ( i == 1 )
   {
      m_imgActive = img;
   }
   else
   {
      m_imgIdle = img;
   }
   setMinimumSize( img.size() );
   setMaximumSize( img.size() );
}

void
ImageButton::paintEvent( QPaintEvent* event )
{
   int w = width();
   int h = height();

   if ( w > 1 && h > 1 )
   {
      LiveSkin skin;

      QPainter dc( this );
      dc.setRenderHint( QPainter::NonCosmeticDefaultPen );

      if ( isChecked() || isDown() )
      {
         dc.drawImage( 0,0,m_imgActive );
      }
      else
      {
         dc.drawImage( 0,0,m_imgActive );
      }

//      // Draw background
//      dc.fillRect( rect(), skin.windowColor );

//      int px = 4;
//      int py = 4;

//      dc.setPen( Qt::NoPen );

//      // Draw panel background
//      QRect rc( px, py, w-2*px, h-2*py);
//      dc.setBrush( QBrush( skin.panelColor ) );
//      dc.drawRoundedRect( rc, skin.radius, skin.radius );

      dc.end();
   }

   //m_font5x8.drawText( img, 42,2, "Hypersonic", LiveSkin::getQColor( LiveSkin::TitleText ) );

   // QWidget::paintEvent( event );
}
