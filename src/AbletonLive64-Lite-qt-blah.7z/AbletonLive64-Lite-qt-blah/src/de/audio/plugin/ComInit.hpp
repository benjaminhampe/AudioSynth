#ifndef DE_COM_INIT_HPP
#define DE_COM_INIT_HPP

struct ComInit // Initialized from MainApp or MainWindow
{
   ComInit();
   ~ComInit();
};

#endif
