﻿#ifndef DE_AUDIO_PLUGIN_DATABASE_HPP
#define DE_AUDIO_PLUGIN_DATABASE_HPP

#include "ScanPluginFolder.hpp"
#include <mutex>

namespace de {
namespace audio {

// ============================================================================
struct PluginInfoDbDir
// ============================================================================
{
   std::wstring m_uri;  // directory uri of the plugins, not the xml storing data.
   bool m_recursive;
   size_t m_numSynths;
   size_t m_numEffects;
   size_t m_numDirs;
   size_t m_numFiles;
   size_t m_numBytes;

   PluginInfos m_plugins;

   std::unordered_map< std::wstring, PluginInfo* > m_lutByUri;
   //std::unordered_map< int, PluginInfo* > m_lutById;

   PluginInfoDbDir()
      : m_uri()
      , m_recursive( true )
      , m_numSynths( 0 )
      , m_numEffects( 0 )
      , m_numDirs(0)
      , m_numFiles(0)
      , m_numBytes(0)
   {}

   PluginInfoDbDir( std::wstring uri )
      : m_uri( uri )
      , m_recursive( true )
      , m_numSynths( 0 )
      , m_numEffects( 0 )
      , m_numDirs(0)
      , m_numFiles(0)
      , m_numBytes(0)
   {
      clear();
   }

   void
   clear()
   {
      m_lutByUri.clear();
      for ( size_t i = 0; i < m_plugins.size(); ++i )
      {
         auto p = m_plugins[ i ];
         if ( p ) delete p;
      }
      m_plugins.clear();
   }

   bool
   hasPlugin( std::wstring const & uri ) const
   {
      return getPlugin( uri ) != nullptr;
   }

   PluginInfo const*
   getPlugin( std::wstring const & uri ) const
   {
      auto it = m_lutByUri.find( uri );
      if ( it == m_lutByUri.end() ) return nullptr;
      else return it->second;
   }

   PluginInfo*
   getPlugin( std::wstring const & uri )
   {
      auto it = m_lutByUri.find( uri );
      if ( it == m_lutByUri.end() ) return nullptr;
      else return it->second;
   }

/*
   int
   findPluginInfo( std::wstring const & uri ) const
   {
      auto beg = m_plugins.begin();
      auto end = m_plugins.end();
      auto it = std::find_if( beg, end, [&] ( PluginInfo const & cached_plugin ) { return cached_plugin.m_uri == uri; } );
      if ( it == end ) { return -1; }
      return std::distance( beg, it );
   }
*/

   bool
   addPlugin( PluginInfo* info )
   {
      if ( !info )
      {
         std::wcout << __func__ << "() - Got nullptr" << std::endl;
         return false;
      }

      std::wstring const & uri = info->m_uri;
      if ( uri.empty() )
      {
         std::wcout << __func__ << "() - Got empty uri" << std::endl;
         return false;
      }

//      if ( !info->m_isPlugin )
//      {
//         std::wcout << __func__ << "() - Not a plugin " << uri << std::endl;
//         return false;
//      }

      PluginInfo* found = getPlugin( uri );
      if ( found )
      {
         std::wcout << __func__ << "() - Plugin already added " << uri << std::endl;
         return false;
      }

      if ( info -> isSynth() )
      {
         m_numSynths++;
      }
      else
      {
         m_numEffects++;
      }

      m_plugins.emplace_back( info );
      m_lutByUri[ uri ] = info;

      std::wcout << __func__ << "() + Added plugin " << uri << "\n";
      return true;
   }

   bool
   readXML( int i, tinyxml2::XMLElement* dirNode )
   {
      if ( !dirNode || !dirNode->Name() ) return false;
      if ( std::string( dirNode->Name() ) != "dir" ) return false;
      if ( !dirNode->Attribute("uri") )
      {
         std::cout << "Dir[" << i << "] :: No uri attrib in xml" << std::endl;
         return false;
      }
      if ( dirNode->Attribute("uri" ) )
      {
         std::string uri = dirNode->Attribute("uri" );
         m_uri = StringConv::toWStr( uri );
      }
      m_recursive = dirNode->IntAttribute("recursive") > 0;
      m_numSynths = dirNode->IntAttribute("synths");
      m_numEffects = dirNode->IntAttribute("effects");
      m_numDirs = dirNode->IntAttribute("dirs");
      m_numFiles = dirNode->IntAttribute("files");
      m_numBytes = dirNode->IntAttribute("bytes");

      return true;
   }

   void
   writeXML( tinyxml2::XMLDocument & doc, tinyxml2::XMLElement* parent ) const
   {
      if ( !parent )
      {
         return;
      }

      tinyxml2::XMLElement* dirNode = doc.NewElement( "dir" );
      if ( !dirNode )
      {
         return;
      }

      if ( m_uri.empty() )
      {
         dirNode->SetAttribute( "uri", "none" );
      }
      else
      {
         dirNode->SetAttribute( "uri", StringConv::toStr( m_uri ).c_str() );
      }

      dirNode->SetAttribute( "recursive", int( m_recursive ) );
      dirNode->SetAttribute( "synths", int( m_numSynths ) );
      dirNode->SetAttribute( "effects", int( m_numEffects ) );
      dirNode->SetAttribute( "dirs", int( m_numDirs ) );
      dirNode->SetAttribute( "files", int( m_numFiles ) );
      dirNode->SetAttribute( "bytes", int( m_numBytes ) );
      parent->InsertEndChild( dirNode );
   }

};

typedef std::vector< PluginInfoDbDir* > PluginInfoDbDirs;

// ============================================================================
struct PluginInfoDb
// ============================================================================
{
   mutable std::mutex m_mutex;
   //std::string m_uri;
   PluginInfoDbDir m_all;   // All VST dirs ( flat list )
   PluginInfoDbDirs m_dirs;  // All VST plugins sorted by directory uris

   PluginInfoDb()
   {
   }

   ~PluginInfoDb()
   {
      clearNoLock();
   }

   //void setUri( std::string const & uri ) { m_uri = uri; }
   bool save( std::string const & uri ) const;
   bool load( std::string const & uri );

   bool isSynth( std::wstring const & uri ) const;

   int
   numEffects() const
   {
      //std::lock_guard< std::mutex > lg( m_mutex );
      return m_all.m_numEffects;
   }

   int
   numSynths() const
   {
      //std::lock_guard< std::mutex > lg( m_mutex );
      return m_all.m_numSynths;
   }
   PluginInfo const*
   getPlugin( std::wstring const & uri ) const
   {
      auto it = m_all.m_lutByUri.find( uri );
      if ( it == m_all.m_lutByUri.end() ) return nullptr;
      else return it->second;
   }

   PluginInfo*
   getPlugin( std::wstring const & uri )
   {
      auto it = m_all.m_lutByUri.find( uri );
      if ( it == m_all.m_lutByUri.end() ) return nullptr;
      else return it->second;
   }

   PluginInfoDbDir const*
   findDirNoLock( std::wstring const & uri ) const
   {
      for ( size_t i = 0; i < m_dirs.size(); ++i )
      {
         auto p = m_dirs[ i ];
         if ( p && p->m_uri == uri ) return p;
      }
      return nullptr;
   }

   PluginInfoDbDir*
   findDirNoLock( std::wstring const & uri )
   {
      for ( size_t i = 0; i < m_dirs.size(); ++i )
      {
         auto p = m_dirs[ i ];
         if ( p && p->m_uri == uri ) return p;
      }
      return nullptr;
   }

   void
   clearNoLock()
   {
      //std::lock_guard< std::mutex > lg( m_mutex );
      for ( size_t i = 0; i < m_dirs.size(); ++i )
      {
         auto p = m_dirs[ i ];
         if ( p ) delete p;
      }
      m_dirs.clear();
      m_all.clear();
   }

   std::mutex & getMutex() { return m_mutex; }
   std::mutex const & getMutex() const { return m_mutex; }

   void addDirNoLock( PluginInfoDbDir* dir );
   void addDir( PluginInfoDbDir* dir )
   {
      std::lock_guard< std::mutex > lg( m_mutex );
      addDirNoLock( dir );
   }

   // PluginInfo const & operator[] ( size_t i ) const { return m_plugins[ i ]; }
   // PluginInfo & operator[] ( size_t i ) { return m_plugins[ i ]; }
   // size_t size() const { return m_plugins.size(); }

   std::wstring
   toWString() const
   {
      std::lock_guard< std::mutex > lg( m_mutex );

      std::wstringstream s;
      //s << "PluginInfoDb.XmlUri = " << StringConv::toWStr( m_uri ) << "\n";
      s << "PluginInfoDb.DirectoryCount = " << m_dirs.size() << "\n";
      s << "PluginInfoDb.PluginCount = " << m_all.m_lutByUri.size() << "\n";

//      for ( size_t i = 0; i < m_dirs.size(); ++i )
//      {
//         s << "Directory[" << i << "] " << m_dirs[ i ].m_uri << ", recursive(" << m_dirs[ i ].m_recursive << ")\n";
//      }

//      for ( size_t i = 0; i < m_plugins.size(); ++i )
//      {
//         s << "Plugin[" << i << "] " << m_plugins[ i ].toWString() << "\n";
//      }
      return s.str();
   }

/*



   int
   findDir( std::wstring const & uri ) const
   {
      std::lock_guard< std::mutex > lg( m_mutex );
      auto beg = m_dirs.begin();
      auto end = m_dirs.end();
      auto it = std::find_if( beg, end, [&] ( PluginInfoDbDir const & cached_dir ) { return cached_dir.m_uri == uri; } );
      if ( it == end ) { return -1; }
      return std::distance( beg, it );
   }

   int
   findPluginNoLock( std::wstring const & uri ) const
   {
      //std::lock_guard< std::mutex > lg( m_mutex );
      auto beg = m_plugins.begin();
      auto end = m_plugins.end();
      auto it = std::find_if( beg, end, [&] ( PluginInfo const & cached_plugin ) { return cached_plugin.m_uri == uri; } );
      if ( it == end ) { return -1; }
      return std::distance( beg, it );
   }

   PluginInfo const*
   getPlugin( std::wstring const & uri ) const
   {
      std::lock_guard< std::mutex > lg( m_mutex );
      auto beg = m_plugins.begin();
      auto end = m_plugins.end();
      auto it = std::find_if( beg, end, [&] ( PluginInfo const & cached_plugin ) { return cached_plugin.m_uri == uri; } );
      if ( it == end )
      {
         return nullptr;
      }
      else
      {
         return &(*it);
      }
   }

   PluginInfo*
   getPlugin( std::wstring const & uri )
   {
      std::lock_guard< std::mutex > lg( m_mutex );
      auto beg = m_plugins.begin();
      auto end = m_plugins.end();
      auto it = std::find_if( beg, end, [&] ( PluginInfo & cached_plugin ) { return cached_plugin.m_uri == uri; } );
      if ( it == end )
      {
         return nullptr;
      }
      else
      {
         return &(*it);
      }
   }
*/
};

} // end namespace audio
} // end namespace de

#endif
