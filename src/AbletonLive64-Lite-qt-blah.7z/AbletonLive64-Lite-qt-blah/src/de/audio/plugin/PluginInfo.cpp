﻿#include "PluginInfo.hpp"

namespace de {
namespace audio {

void
PluginInfo::reset()
{

   m_isFile = false;
   m_isPlugin = false;
   m_isVST2x = false;
   m_isSynth = false;
   m_hasEditor = false;
   m_can32Bit = false;
   m_can64Bit = false;
   m_canProgramChunks = false;
   //m_dirMultiByte = "";
   //m_pluginName = "";
   //m_rate = 0;     // rate in Hz
   m_numPrograms = 0;
   m_numParams = 0;
   m_numOutputs = 0;
   m_numInputs = 0;
   //m_flags = 0;

   m_uri = L"";
   m_name = L"";
   m_entry = "";
   m_comment = "";

   //m_vendorVersion = 0;
   //m_vendor;
   //m_product;
}

std::wstring
PluginInfo::toWString() const
{
   std::wstringstream s;
   s <<
   "name(" << m_name << "), "
   "VST2x(" << m_isVST2x << "), "
   "hasEditor(" << m_hasEditor << "), "
   "isSynth(" << m_isSynth << "), "
   "programs(" << m_numPrograms << "), "
   "params(" << m_numParams << "), "
   "outputs(" << m_numOutputs << "), "
   "inputs(" << m_numInputs << "), "
   "can32Bit(" << m_can32Bit << "), "
   "can64Bit(" << m_can64Bit << "), "
   "entry(" << StringConv::toWStr( m_entry ) << "), "
   "uri(" << m_uri << ")"
   ;

   return s.str();
}

void
PluginInfo::writeXML( tinyxml2::XMLDocument & doc, tinyxml2::XMLElement* list ) const
{
   tinyxml2::XMLElement* pin = doc.NewElement( "plugin" );

   if ( m_name.empty() )
   {
      pin->SetAttribute("name", "none" );
   }
   else
   {
      pin->SetAttribute("name", StringConv::toStr(m_name).c_str() );
   }

   pin->SetAttribute("editor", int(m_hasEditor) );
   //pin->SetAttribute("plugin", int(m_isPlugin) );
   pin->SetAttribute("synth", int(m_isSynth) );
   pin->SetAttribute("programs", m_numPrograms );
   pin->SetAttribute("params", m_numParams );
   pin->SetAttribute("outputs", m_numOutputs );
   pin->SetAttribute("inputs", m_numInputs );
   pin->SetAttribute("can32Bit", int(m_can32Bit) );
   pin->SetAttribute("can64Bit", int(m_can64Bit) );

   if ( m_entry.empty() )
   {
      pin->SetAttribute("entry", "none" );
   }
   else
   {
      pin->SetAttribute("entry", m_entry.c_str() );
   }

   if ( m_uri.empty() )
   {
      pin->SetAttribute("uri", "none" );
   }
   else
   {
      pin->SetAttribute("uri", StringConv::toStr(m_uri).c_str() );
   }

   if ( m_comment.size() > 0 )
   {
      pin->SetText( m_comment.c_str() );
   }

   list->InsertEndChild( pin );
}

bool
PluginInfo::readXML( int i, tinyxml2::XMLElement* pin )
{
   if ( !pin->Attribute("uri") )
   {
      std::cout << "Plugin[" << i << "] :: No uri attrib in xml" << std::endl;
      return false;
   }

   if ( !pin || !pin->Name() ) return false;
   if ( std::string( pin->Name() ) != "plugin" ) return false;
   //pin->SetAttribute("type", "vst24" );

   reset();

   if ( pin->Attribute( "name" ) )
   {
      std::string name = pin->Attribute( "name" );
      m_name = StringConv::toWStr( name );
   }
   if ( pin->Attribute( "entry" ) )
   {
      m_entry = pin->Attribute( "entry" );
   }
   if ( pin->Attribute("uri" ) )
   {
      std::string uri = pin->Attribute("uri" );
      m_uri = StringConv::toWStr( uri );
   }

   m_isFile = true;
   m_isPlugin = true;
   m_hasEditor = pin->IntAttribute("editor") != 0;
   m_isSynth = pin->IntAttribute("synth") != 0;
   m_numPrograms = pin->IntAttribute("programs");
   m_numParams = pin->IntAttribute("params");
   m_numOutputs = pin->IntAttribute("outputs");
   m_numInputs = pin->IntAttribute("inputs");
   m_can32Bit = pin->IntAttribute("can32Bit") != 0;
   m_can64Bit = pin->IntAttribute("can64Bit") != 0;
   return true;
}

} // end namespace audio
} // end namespace de

