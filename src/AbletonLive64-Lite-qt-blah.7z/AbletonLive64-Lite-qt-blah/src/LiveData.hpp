/// (c) 2017 - 20180 Benjamin Hampe <benjaminhampe@gmx.de>

#ifndef DE_LIVE_DATA_DATA_HPP
#define DE_LIVE_DATA_DATA_HPP

#include "LiveSkin.hpp"

#endif
