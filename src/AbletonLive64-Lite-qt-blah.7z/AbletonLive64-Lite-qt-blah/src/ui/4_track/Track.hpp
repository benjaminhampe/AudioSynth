/// (c) 2017 - 20180 Benjamin Hampe <benjaminhampe@gmx.de>

#ifndef DE_LIVE_TRACK_EDITOR_HPP
#define DE_LIVE_TRACK_EDITOR_HPP

#include "TrackInfo.hpp"
#include "Meter.hpp"
#include "Plugin.hpp"
#include "DropTarget.hpp"

#include <iterator>
#include <de/audio/dsp/IDspChainElement.hpp>
//#include <de/audio/plugin/PluginInfo.hpp>
//#include <de/audio/plugin/IPlugin.hpp>
//#include <de/audio/dsp/Mixer.hpp>

struct App;

// ============================================================================
struct Track : public QWidget, public de::audio::IDspChainElement
// ============================================================================
{
   Q_OBJECT
   DE_CREATE_LOGGER("Track")
   App & m_app;
public:
   // Interchangeable track info
   TrackInfo m_trackInfo;
   TrackInfo const & trackInfo() const { return m_trackInfo; }
   TrackInfo & trackInfo() { return m_trackInfo; }

   void setTrackInfo( TrackInfo const & ti );

//   // TrackInfo
//   bool m_hasFocus;
//   bool m_isBypassed;
//   int m_trackId; // 0 = master fx chain, 1+x = return A+x chains, 1000 + x = user audio only chains, 2000 + x = user midi + audio chains
//   int m_volume;
//   eTrackType m_type; // 0 = master, 1 = return, 2 = audio-only, 3 = midi+audio
//   std::string m_name;
//   Clips m_clips;
//   std::vector< de::audio::PluginInfo > m_plugins; // All plugin instances (midi+audio) managed/owned by this track at runtime.

   // Runtime TrackEditor
   MidiMeter* m_midiMeter; // Not in Audio-Only
   //AudioMeter* m_audioMeter; // Not in Midi
   DropTarget* m_dropTarget;
   //MidiMeter* m_midiMeter;
   //std::vector< IMidiSpurElement* > m_midiFx;// the rest of the audio Track is a series of effects.
   // Runtime DspChain
   std::vector< Plugin* > m_audioPlugins; // All (audio) plugin instances by this track at runtime (manages + owns plugins for now).

   IDspChainElement* m_audioInput;  // Link to audio DSP input ( synths can have audio input )
   IDspChainElement* m_audioEnd;    // Link to audio DSP end, for convenience to connect to a mixer.
   Plugin* m_audioSynth;            // Link between MIDI and audio chain, either a Player or Synthesizer
   std::vector< Plugin* > m_audioEffects; // Series of audio effects. // Not really used?
   //std::vector< LevelMeter > m_audioMeters;

public:
   Track( App & app, QWidget* parent = nullptr );
   ~Track() override;

   int id() const { return trackInfo().id(); }
   bool isAudioOnly() const { return trackInfo().isAudioOnly(); }
   std::string const & name() const { return trackInfo().name(); }

   bool isBypassed() const override { return trackInfo().isBypassed(); }
   void setBypassed( bool bypassed ) override { trackInfo().setBypassed( bypassed ); }
   void clearInputSignals() { m_audioInput = nullptr; }
   void setInputSignal( int i, IDspChainElement* input ) { m_audioInput = input; }

   uint64_t
   readSamples( double pts, float* dst, uint32_t dstFrames, uint32_t dstChannels, uint32_t dstRate ) override;

   void
   sendNote( de::audio::Note const & note ) override
   {
      if ( m_audioSynth ) m_audioSynth->sendNote( note );
   }

   void
   allNotesOff()
   {
      if ( m_audioSynth ) m_audioSynth->allNotesOff();
   }
   // Clips const & clips() const;
   // Clips & clips();
   // void addClip( Clip clip );
   // void addClip( double timeBeg, double timeEnd, std::string name = "Clip" );

//   void writeXML( tinyxml2::XMLDocument & doc, tinyxml2::XMLElement* parent ) const;
//   bool readXML( int i, tinyxml2::XMLElement* spur );

//   Clips const & clips() const;
//   Clips & clips();
//   void addClip( Clip clip );
//   void addClip( double timeBeg, double timeEnd, std::string name = "Clip" );
   //bool addPlugin( std::wstring const & uri );
   //void updateDspChain();
   //void setTrackInfo( int trackId );
   //void updateFromTrackInfo();

signals:
public slots:
   void updateLayout();
   void clearWidgets();
protected slots:
protected:
   void resizeEvent( QResizeEvent* event ) override;
   //void paintEvent( QPaintEvent* event ) override;
   void enterEvent( QEvent* event ) override;
   void leaveEvent( QEvent* event ) override;
   void focusInEvent( QFocusEvent* event ) override;
   void focusOutEvent( QFocusEvent* event ) override;

   void dropEvent( QDropEvent* event ) override;
   void dragEnterEvent( QDragEnterEvent* event ) override;
   void dragLeaveEvent( QDragLeaveEvent* event ) override;
   void dragMoveEvent(QDragMoveEvent* event ) override;
};

#endif
