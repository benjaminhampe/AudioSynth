/// (c) 2017 - 20180 Benjamin Hampe <benjaminhampe@gmx.de>

#include "Track.hpp"
#include "App.hpp"

Track::Track( App & app, QWidget* parent )
   : QWidget( parent )
   , m_app( app )
   , m_audioInput( nullptr )
   , m_audioEnd( nullptr )
   , m_audioSynth( nullptr )
{
   setObjectName( "Track" );
   setContentsMargins( 0,0,0,0 );
   setMouseTracking( true );
   //setAcceptDrops( true );         // We can drop plugins ( Midi or Audio ) into this editor widget.

   m_midiMeter = new MidiMeter( m_app, this );

   m_dropTarget = new DropTarget( m_app, this );
}

Track::~Track()
{
   clearWidgets();
}

void
Track::setTrackInfo( TrackInfo const & ti )
{
   m_trackInfo = ti;
   if ( m_dropTarget )
   {
      m_dropTarget->setAudioOnly( isAudioOnly() );
   }

}
void
Track::clearWidgets()
{
   if ( m_audioSynth )
   {
      delete m_audioSynth;
      m_audioSynth = nullptr;
   }

   m_audioInput = nullptr;
   m_audioEnd = nullptr;

   for ( auto effect : m_audioEffects )
   {
      if ( effect ) delete effect;
   }
   m_audioEffects.clear();
}

uint64_t
Track::readSamples( double pts, float* dst, uint32_t dstFrames, uint32_t dstChannels, uint32_t dstRate )
{
   if ( m_audioEnd )
   {
      return m_audioEnd->readSamples( pts, dst, dstFrames, dstChannels, dstRate );
   }
   else
   {
      //std::cout << "No audioEnd in track " << id() << std::endl;
      uint64_t dstSamples = dstFrames * dstChannels;
      de::audio::DSP_FILLZERO( dst, dstSamples );
      return dstSamples;
   }
}

void
Track::updateLayout()
{
   int w = width();
   int h = height();

   int x = 0;
   int y = 0;

   setWidgetBounds( m_midiMeter, QRect(x,y,4,h) ); x += 6;

   int editorW = 0;

   if ( m_audioSynth )
   {
      editorW = m_audioSynth->maximumWidth();
      setWidgetBounds( m_audioSynth, QRect(x,y,editorW,h) ); x += editorW;
   }

   for ( auto & p : m_audioEffects )
   {
      if ( p )
      {
         editorW = p->maximumWidth();
         setWidgetBounds( p, QRect(x,y,editorW,h) ); x += editorW;
      }
   }

   int dummyW = w - x;
   if ( dummyW < 50 ) dummyW = 50;
   setWidgetBounds( m_dropTarget, QRect(x,y,dummyW,h) );

   update();
}

void
Track::resizeEvent( QResizeEvent* event )
{
   updateLayout();
   QWidget::resizeEvent( event );
}

//void
//Track::paintEvent( QPaintEvent* event )
//{
//   QWidget::paintEvent( event );
//}


void
Track::dropEvent( QDropEvent* event )
{
   std::cout << "Track::" << __func__ << std::endl;
   std::cout << event->mimeData()->text().toStdString() << std::endl;

   std::wstring uri = event->mimeData()->text().toStdWString();
   m_app.addPlugin( uri );

   event->acceptProposedAction();
   QWidget::dropEvent( event );
}

void
Track::dragEnterEvent( QDragEnterEvent* event )
{
   if ( event->mimeData()->hasFormat("text/plain") )
   {
      event->acceptProposedAction();
   }
   std::cout << __func__ << std::endl;
   QWidget::dragEnterEvent( event );
}

void
Track::dragLeaveEvent( QDragLeaveEvent* event )
{
   std::cout << __func__ << std::endl;
   QWidget::dragLeaveEvent( event );
}

void
Track::dragMoveEvent(QDragMoveEvent* event )
{
   std::cout << __func__ << std::endl;
   QWidget::dragMoveEvent( event );
}

void
Track::focusInEvent( QFocusEvent* event )
{
   m_trackInfo.m_hasFocus = true;
   update();
   QWidget::focusInEvent( event );
}

void
Track::focusOutEvent( QFocusEvent* event )
{
   m_trackInfo.m_hasFocus = true;
   update();
   QWidget::focusOutEvent( event );
}

void
Track::enterEvent( QEvent* event )
{
   QWidget::enterEvent( event );
}

void
Track::leaveEvent( QEvent* event )
{
   QWidget::leaveEvent( event );
}
