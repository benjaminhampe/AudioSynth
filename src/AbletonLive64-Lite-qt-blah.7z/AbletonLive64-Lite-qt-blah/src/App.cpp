#include "App.hpp"

App::App()
{
   appName = "AbletonLive64 Lite (c) 2022 <benjaminhampe@gmx.de>";

   m_hoverPanel = eLivePanelCount;
   m_focusPanel = eLivePanelQuickHelp;

   m_body = nullptr;

   // TrackManager
   m_trackId = -1;
   m_track = nullptr;
   m_masterTrack = nullptr;

   // DeviceBar
   m_btnShowExplorer = nullptr;
   m_btnShowInternDevices = nullptr;
   m_btnShowExternDevices = nullptr;
   m_btnShowExplorer1 = nullptr;
   m_btnShowExplorer2 = nullptr;
   m_btnShowExplorer3 = nullptr;
   m_explorerScrollBar = nullptr;
   m_btnShowGrooves = nullptr;
   // PluginExplorer
   m_pluginExplorer = nullptr;
   // PluginScanner
   m_pluginScanner = nullptr;
   m_pluginDirTree = nullptr;
   m_btnShowPluginDirs = nullptr;
   m_pluginInfoTree = nullptr;
   // Footer
   m_btnShowQuickHelpPanel = nullptr;
   m_longText = nullptr;
   m_btnShowMidiKeyboard = nullptr;
   m_btnClipOverview = nullptr;
   m_btnTrackOverview = nullptr;
   m_btnShowDetailPanel = nullptr;
   // Footer II
   m_midiMasterKeyboard = nullptr;

   m_isOverSplitV = false;
   m_isOverSplitH = false;
   m_isExplorerVisible = true;
   m_isDetailVisible = true;
   m_isQuickHelpVisible = true;
   m_isClipEdVisible = false;
   m_isHelpVisible = false;

   m_deviceBarWidth = 23; // fix width
   m_explorerWidthMin = 20; // fix width
   m_hsplitterPos = 200; // splitter h pos

   m_spurEditorHeight = 190 + 12; // fix height
   m_clipEditorHeight = 300; // var height by splitter
   m_vsplitterPos = m_spurEditorHeight; // splitter h pos
   m_quickHelpWidth = 220; // fix width

   addFontAwesome463();

//   QString const appPath = qApp->applicationDirPath() + "/";
//   QString const stylePath( appPath + "themes/darcula.css" );
//   app.setStyleSheet( "file:///" + stylePath );
//   dbAddFontFamily( "fontawesome.ttf" );
//   dbAddFontFamily( "la-regular-400.ttf" );
//   dbAddFontFamily( "la-brands-400.ttf" );
//   dbAddFontFamily( "la-solid-900.ttf" );
//   QString const appPath = qApp->applicationDirPath() + "/";
//   QString const cssPath( appPath + "themes/darcula.css" );
//   app.setStyleSheet( "file:///" + cssPath );

   // Create Window
   App & m_app = *this;

   m_window = new Window( m_app );

   // Create Window children
   m_body = new Body( m_app, m_window );
   m_midiMasterKeyboard = new MidiMasterKeyboard( m_app, m_window );

   // Create Body children
   m_headerPanel = new Header( m_app, m_body );
   m_footerPanel = new FooterPanel( m_app, m_body );

   // Create DetailPanel children
   m_clipContent = new ClipContent( m_app, m_body );
   m_clipContent->setVisible( false );

   // Layout MainWindow
   auto v = createVBox();
   v->addWidget( m_body, 1 );
   v->addWidget( m_midiMasterKeyboard );
   auto m_central = new QWidget( m_window );
   m_central->setLayout( v );
   m_window->setCentralWidget( m_central );
   m_window->setWindowTitle( appName );

   // Load XML or createDefault

   m_mediaDirMB = "../../media/";
   QString mediaDir = QString::fromStdString( m_mediaDirMB );
   m_synthIcon = QIcon( mediaDir + "synthIcon.png" );
   m_effectIcon = QIcon( mediaDir + "effectIcon.png" );

//   std::cout << "Load PluginDB ... " << std::endl;
//   m_pluginDb.loadXml( m_mediaDirMB + "data/plugin_db.xml" );
//   std::cout << "Loaded " << m_pluginDb.size() << " Plugins" << std::endl;

//   int id = 0;

   QString persistRoot = QStandardPaths::standardLocations( QStandardPaths::AppDataLocation ).at(0);
   QString persistDir = persistRoot + "/";
   m_roamingDir = persistDir.toStdString();
   m_pluginDbXml = m_roamingDir + "data/plugin_info_database.xml";
   m_trackListXml = m_roamingDir + "data/tracks.xml";

   dbMakeDirectory( m_roamingDir + "data" );

   m_window->show();

   load();

   // STOP AUDIO NOW
//   bool wasPlaying = isAudioMasterPlaying();
//   stopAudioMasterBlocking();

   updateDspMixerChain();

   playAudioMaster();

   // (RE)START AUDIO, if any
   //setBypassed( wasBypassed );
   //m_userMixer.m_isBypassed = false;
//   if ( wasPlaying )
//   {
//      playAudioMaster();
//   }

   //updateDspChain();
   //load( m_app );


}

App::~App()
{
   //m_masterStream.stop();
   //clearTracks();
}


void App::hideEditorWindows()
{
   for ( auto trk : m_tracks )
   {
      if ( trk )
      {
         for ( auto plugin : trk->m_audioPlugins )
         {
            if ( plugin )
            {
               plugin->hideEditor();
            }
         }
      }
   }
}

void
App::clearTracks()
{
   bool wasPlaying = isAudioMasterPlaying();
   stopAudioMasterBlocking();

   m_trackId = -1;
   m_track = nullptr;
   m_masterTrack = nullptr;
   m_returnTracks.clear();
   m_userTracks.clear();
   m_userAudoTracks.clear();
   m_userMidiTracks.clear();

   for ( size_t i = 0; i < m_tracks.size(); ++i )
   {
      auto p = m_tracks[ i ];
      if ( p ) delete p;
   }
   m_tracks.clear();

   m_arrangement->m_master = nullptr;
   m_arrangement->m_returns.clear();
   m_arrangement->m_user.clear();

   int c = m_detailStack->count();
   for ( int i = 0; i < c; i++ )
   {
      auto w = m_detailStack->widget( i );
      if ( w )
      {
         m_detailStack->removeWidget( w );
         delete w;
      }
   }

   m_detailStack->setCurrentIndex( -1 );
}


int
App::findTrack( int id ) const
{
   for ( size_t i = 0; i < m_tracks.size(); ++i )
   {
      auto p = m_tracks[ i ];
      if ( p && p->id() == id )
      {
         //DE_DEBUG("found id = ",id, " at index = ",i)
         return i;
      }
   }

   //DE_DEBUG("No id = ",id, " found")
   return -1;
}

bool
App::hasTrack( int id ) const
{
   bool ok = findTrack( id );
   if ( ok )
   {
   }

   //DE_DEBUG("id = ",id, " has = ",ok)
   return ok;
}

Track*
App::getTrack( int id )
{
   Track* p = nullptr;

   int found = findTrack( id );
   if (found > -1)
   {
      int n = int(m_tracks.size());
      if ( found >= n )
      {
         DE_ERROR("id = ",id, " found = ",found,", n = ",n)
      }
      else
      {
         p = m_tracks[ found ];
      }
   }
   //DE_DEBUG("id = ",id, " found = ",found,", p = ",p)
   return p;
}

bool
App::addTrack( int id, std::string name, eTrackType tt )
{
   DE_DEBUG("Add track id = ",id,", name = ",name,", tt = ",int(tt)," :: START")
   TrackInfo ti;
   ti.m_id = id;
   ti.m_name = name;
   ti.m_type = tt;
   return addTrack( ti );
}

bool
App::addTrack( TrackInfo const & ti )
{
   DE_DEBUG("Add track ti ", ti.toString() )

   int found = findTrack( ti.id() );
   if (found > -1)
   {
      DE_ERROR("Track id = ", ti.id()," already exist!")
      return false;
   }

   auto track = new Track( *this, m_detailStack );
   track->setTrackInfo( ti );
   m_tracks.emplace_back( track );

   // 0 = master, 1 = return, 2 = audio-only, 3 = midi+audio
   auto itemV = new ItemV( *this, m_arrangement );
   itemV->setTrack( track );

   if ( ti.m_type == eTrackMaster )
   {
      m_masterTrack = track;
      m_arrangement->m_master = itemV;
   }
   else if ( ti.m_type == eTrackReturn )
   {
      m_returnTracks.emplace_back( track );
      m_arrangement->m_returns.emplace_back( itemV );
   }
   else if ( ti.m_type == eTrackAudio )
   {
      m_userTracks.emplace_back( track );
      m_userAudoTracks.emplace_back( track );
      m_arrangement->m_user.emplace_back( itemV );
   }
   else if ( ti.m_type == eTrackMidi )
   {
      m_userTracks.emplace_back( track );
      m_userMidiTracks.emplace_back( track );
      m_arrangement->m_user.emplace_back( itemV );
   }

   //auto chain = m_app.m_engine.m_network.m_chains[ i ];
   m_detailStack->addWidget( track ); // Qt controls spur deletion now!
   //track->m_ownedAndDeletedByQt = true;

   DE_DEBUG("Add track id = ",ti.id(),", name = ",ti.name(),", tt = ",int(ti.m_type),", track = ",track," :: END")

   setActiveTrackId( ti.id() );

   int c = ti.m_plugins.size();

   DE_DEBUG("Add track ",ti.id()," plugins ",c)

   for ( int i = 0; i < c; ++i )
   {
      de::audio::PluginInfo const & pi = ti.m_plugins[ i ];
      DE_DEBUG("Add plugin[",i,"] = ",dbStr(pi.m_name) )
      addPlugin( pi );
   }

   //setActiveTrackId( id );


   return true;
}

bool
App::addPlugin( std::wstring const & uri )
{
   if ( !m_track )
   {
      std::wcout << "App::addPlugin() - No m_track " << uri << std::endl;
      return false;
   }

   // FIND PLUGIN uri IN DATABASE

   auto p = getPluginInfo( uri );
   if ( !p )
   {
      std::wcout << "App::addPlugin() - No plugin info found in db " << uri << std::endl;
      return false;
   }

   auto const & pluginInfo = *p;

   return addPlugin( pluginInfo );
}

bool
App::addPlugin( de::audio::PluginInfo const & pluginInfo )
{
   std::string uri = dbStr(pluginInfo.m_uri);

   if ( !m_track )
   {
      DE_ERROR("No m_track, uri = ", uri )
      return false;
   }

   if ( pluginInfo.isSynth() && m_track->isAudioOnly() )
   {
      DE_ERROR("Cant add syntheziser to an Audio-Only track (yet), uri = ", uri )
      return false;
   }

   // CREATE PLUGIN ( audio still playing )

   auto plugin = new Plugin( *this, m_track );
   if ( !plugin->openPlugin( pluginInfo.m_uri ) )
   {
      DE_ERROR("Cant open VST audio plugin, uri = ", uri )
      delete plugin;
      return false;
   }

//   m_track->m_trackInfo.m_isBypassed = true;

   // STOP AUDIO NOW
#if 0
   bool wasPlaying = isAudioMasterPlaying();
   stopAudioMasterBlocking();
#endif

   // ADD to ALL list -> used in hideEditorWindows()
   m_track->m_audioPlugins.emplace_back( plugin );

   // ADD to SYNTH list
   if ( plugin->isSynth() )
   {
      DE_DEBUG("Got isSynth == true")
      // REPLACE CURRENT SYNTH OR NOT
      if ( m_track->m_audioSynth )
      {
         delete m_track->m_audioSynth; // DELETE SYNTH
      }
      m_track->m_audioSynth = plugin;  // REPLACE SYNTH
   }
   // OR ADD to EFFECT list
   else
   {
      DE_DEBUG("Got isSynth == false")
      m_track->m_audioEffects.emplace_back( plugin ); // FX LIST
   }

   // Add PLUGIN-INFO to TRACK-INFO
   // REBUILD list TRACKINFO::m_ALL -> used in hideEditorWindows()

   auto & ti = m_track->m_trackInfo;

   ti.m_plugins.clear();

   if ( m_track->m_audioSynth )
   {
      ti.m_plugins.emplace_back( m_track->m_audioSynth->pluginInfo() );
   }

   for ( auto fx : m_track->m_audioEffects )
   {
      if ( !fx ) continue;
      ti.m_plugins.emplace_back( fx->pluginInfo() );
   }

   updateDspTrackChain();
   updateDspMixerChain();

#if 0
   // DETERMINE AUDIO DSP CHAIN ENDPOINT

   m_track->m_audioEnd = m_track->m_audioInput; // Start Endpoint is audio input

   if ( m_track->isAudioOnly() )
   {
      if ( m_track->m_audioSynth )
      {
         DE_ERROR("Error synthesizer found and bypassed")
      }
   }
   else
   {
      if ( m_track->m_audioSynth )
      {
         m_track->m_audioEnd = m_track->m_audioSynth;
      }
      else
      {
         DE_ERROR("No synthesizer to connect")
      }
   }

   if ( !m_track->m_audioEnd )
   {
      DE_ERROR("ERROR Nothing to hear")
   }

   // WE HAVE ENDPOINT NOW, LETS CONNECT AUDIO FX CHAIN TO SYNTH,
   // MAKE LAST CHAIN ELEM THE NEW ENDPOINT OF ENTIRE CHAIN
   for ( auto const & p : m_track->m_audioEffects )
   {
      if ( !p ) continue;
      p->setInputSignal( 0, m_track->m_audioEnd ); // Conn to current dsp endpoint
      m_track->m_audioEnd = p; // Replace current dsp endpoint with validated us.
   }

   if ( !m_track->m_audioEnd )
   {
      DE_ERROR("ERROR Nothing to hear II")
   }

   m_track->m_trackInfo.m_isBypassed = false;

   // (RE)START AUDIO, if any
   //setBypassed( wasBypassed );
   //m_userMixer.m_isBypassed = false;
   if ( wasPlaying )
   {
      playAudioMaster();
   }
#endif
   m_track->updateLayout();
   return true;
}

void
App::updateDspTrackChain()
{
   if ( !m_track )
   {
      DE_ERROR("No m_track" )
      return; // false;
   }

#if 0
   // STOP AUDIO NOW
   bool wasPlaying = isAudioMasterPlaying();
   stopAudioMasterBlocking();
#endif

   // Add PLUGIN-INFO to TRACK-INFO
   // REBUILD list TRACKINFO::m_ALL -> used in hideEditorWindows()

   auto & ti = m_track->m_trackInfo;

   ti.m_isBypassed = true;

   // updateDspTrackChain();
   // DETERMINE AUDIO DSP CHAIN ENDPOINT

   m_track->m_audioEnd = m_track->m_audioInput; // Start Endpoint is audio input

   if ( m_track->isAudioOnly() )
   {
      if ( m_track->m_audioSynth )
      {
         DE_ERROR("Error synthesizer found and bypassed")
      }
   }
   else
   {
      if ( m_track->m_audioSynth )
      {
         m_track->m_audioEnd = m_track->m_audioSynth;
      }
      else
      {
         DE_ERROR("No synthesizer to connect")
      }
   }

   if ( !m_track->m_audioEnd )
   {
      DE_ERROR("ERROR Nothing to hear")
      return; // false;
   }

   // WE HAVE ENDPOINT NOW, LETS CONNECT AUDIO FX CHAIN TO SYNTH,
   // MAKE LAST CHAIN ELEM THE NEW ENDPOINT OF ENTIRE CHAIN
   for ( auto const & p : m_track->m_audioEffects )
   {
      if ( !p ) continue;
      p->setInputSignal( 0, m_track->m_audioEnd ); // Conn to current dsp endpoint
      m_track->m_audioEnd = p; // Replace current dsp endpoint with validated us.
   }

   if ( !m_track->m_audioEnd )
   {
      DE_ERROR("ERROR Nothing to hear II")
      return; // false;
   }

   ti.m_isBypassed = false;

#if 0
   // (RE)START AUDIO, if any
   //setBypassed( wasBypassed );
   //m_userMixer.m_isBypassed = false;
   if ( wasPlaying )
   {
      playAudioMaster();
   }
#endif

   //return true;
}

void
App::updateDspMixerChain()
{
   if ( !m_masterTrack )
   {
      DE_ERROR( "No m_masterTrack" )
      return;
   }

#if 0
   // STOP AUDIO
   bool wasPlaying = isAudioMasterPlaying();
   stopAudioMasterBlocking();
#endif

   // CONNECT user-tracks TO m_userMixer
   size_t k = 0;

   auto nUser = m_userTracks.size();
   if ( nUser > m_userMixer.getInputSignalCount() )
   {
      std::cout << "App::updateDspChain() :: nUser = " << nUser << std::endl;
      m_userMixer.resize( nUser );
   }

   k = 0;
   for ( auto & track : m_userTracks )
   {
      if ( !track ) continue;
      m_userMixer.setInputSignal( k, track );
      k++;
   }

   // CONNECT return-tracks TO m_returnTracks

   auto nReturn = m_returnTracks.size();
   if ( m_returnMixer.getInputSignalCount() < nReturn )
   {
      std::cout << "App::updateDspChain() :: nReturn = " << nReturn << std::endl;
      m_returnMixer.resize( nReturn );
   }

   k = 0;
   for ( auto & track : m_returnTracks )
   {
      if ( !track ) continue;
      m_returnMixer.setInputSignal( k, track );
      k++;
   }

   m_masterMixer.resize( 2 );
   m_masterMixer.setInputSignal( 0, &m_userMixer );
   //m_masterMixer.setInputSignal( 1, &m_returnMixer );

   // CONNECT mixer TO master audio endpoint ( Benni : RtAudioStream )

   m_masterStream.setInputSignal( 0, &m_masterMixer );

   // RESTART AUDIO, if any
#if 0
//   m_userMixer.m_isBypassed = false;

   if ( wasPlaying )
   {
      playAudioMaster();
   }
#endif
}

void
App::setActiveTrack( Track* track )
{
   if ( track )
   {
      setActiveTrackId( track->id() );
   }
   else
   {
      setActiveTrackId( -1 );
   }
}

void
App::setActiveTrackId( int id )
{
   if ( m_trackId != id )
   {
      DE_DEBUG("Active track id = ",id)

      m_trackId = id;
      m_track = getTrack( m_trackId );

      emit activatedTrackId( m_trackId );
      emit activatedTrack( m_track );

      if ( m_detailStack )
      {
         m_detailStack->setCurrentIndex( findTrack( m_trackId ) );
      }
   }
}

bool
App::load()
{
   DE_DEBUG("Load pluginDb ",m_pluginDbXml)
   bool ok = m_pluginDb.load( m_pluginDbXml );
   DE_DEBUG("Database loaded ",m_pluginDb.m_all.m_plugins.size()," plugin(s)")

   m_pluginDirTree->updateFromPluginDb();
   m_pluginInfoTree->updateFromPluginDb();

   DE_DEBUG("Load trackList ",m_trackListXml)
   if ( loadTracks( m_trackListXml ) )
   {
      ok = true;
      setActiveTrackId( 0 );
   }
   else
   {
      ok = false;
      addTrack( 0, "Master", eTrackMaster );
      addTrack( 1000, "A - Return", eTrackReturn );
      addTrack( 1001, "B - Return", eTrackReturn );
      addTrack( 2000, "1 - Audio", eTrackAudio );
      addTrack( 2001, "2 - Audio", eTrackAudio );
      addTrack( 3000, "3 - Midi", eTrackMidi );
      addTrack( 3001, "4 - Midi", eTrackMidi );
      addTrack( 3002, "5 - Midi", eTrackMidi );
      addTrack( 3003, "6 - Midi", eTrackMidi );
      setActiveTrackId( 3000 );
   }
   return ok;
}

bool
App::save( bool saveLiveSet )
{
   bool ok = true;

   DE_DEBUG("Save pluginDb")
   ok &= m_pluginDb.save( m_pluginDbXml );

   if ( saveLiveSet )
   {
      ok &= saveTracks( m_trackListXml );
      DE_DEBUG("Save tracks")
   }
   else
   {
      DE_DEBUG("No tracks saved")
   }

   return ok;
}

bool
App::saveTracks( std::string const & uri ) const
{
   dbRemoveFile( uri );

   tinyxml2::XMLDocument doc;
   tinyxml2::XMLElement* root = doc.NewElement( "tracks" );

   int c = int( m_tracks.size() );

   root->SetAttribute( "count", c );

   DE_DEBUG("Saving ",c," track(s)")

   for ( int i = 0; i < c; ++i )
   {
      Track* track = m_tracks[ i ];
      if ( !track )
      {
         DE_ERROR("Cant save track ",c," track(s)")
         continue;
      }
      DE_DEBUG("Save track ",i+1," with id = ",track->m_trackInfo.id()," and ",track->m_trackInfo.m_plugins.size()," plugin(s)")
      track->m_trackInfo.writeXML( doc, root );
   }

   doc.InsertEndChild( root );

   auto e = doc.SaveFile( uri.c_str() );
   if ( e != tinyxml2::XML_SUCCESS )
   {
      std::cout << "Cant save <tracks> xml " << uri << ", e = " << int(e) << std::endl;
      return false;
   }

   auto n = m_tracks.size();
   std::cout <<"Saved <tracks> xml " << uri << " with " << n << " tracks" << std::endl;
   return true;
}

bool
App::loadTracks( std::string const & uri )
{
   tinyxml2::XMLDocument doc;
   auto e = doc.LoadFile( uri.c_str() );
   if ( e != tinyxml2::XML_SUCCESS )
   {
      std::cout << "Cant load <tracks> xml " << uri << std::endl;
      return false;
   }

   tinyxml2::XMLElement* tracks = doc.FirstChildElement( "tracks" );
   if ( !tracks )
   {
      std::cout << "No <tracks> tag in xml " << uri << std::endl;
      return false;
   }

   int m_checkSum = tracks->IntAttribute( "count" );

   clearTracks();

   int k = 0;

   // Read first child <PluginInfo> of parent <PluginInfoList>
   tinyxml2::XMLElement* trackNode = tracks->FirstChildElement( "track" );
   if ( !trackNode )
   {
      std::cout << "No <track> in <tracks> xml " << uri << std::endl;
      return false;
   }
   else
   {
      // Read all next children <PluginInfo> of parent <PluginInfoList>
      while ( trackNode )
      {
         TrackInfo trackInfo;
         if ( trackInfo.readXML( k, trackNode ) )
         {
            bool ok = addTrack( trackInfo );
            if ( !ok )
            {
               DE_ERROR("No <track> added")
            }
            else
            {
               k++;
            }
         }
         else
         {
            DE_ERROR("Got <track> read error")
         }
         trackNode = trackNode->NextSiblingElement( "track" );
      }
   }

   std::cout <<"<tracks> OK loaded. " << uri << std::endl;
   //std::cout << "[loadXml] dir = " << m_vstDirMB << std::endl;
   std::cout << "<tracks> expect <track> tags = " << m_checkSum << std::endl;
   std::cout << "<tracks> loaded <track> tags = " << k << std::endl;

   return true;
}





void
App::showSpurEditor()
{
   m_isClipEdVisible = false;
   updateLayout();
}

void
App::showClipEditor()
{
   m_isClipEdVisible = true;
   updateLayout();
}

void
App::updateLayout()
{
   if ( m_body )
   {
      m_body->updateLayout();
   }
}

/*

bool
App::loadXml( std::string const & uri )
{

   tinyxml2::XMLDocument doc;
   auto e = doc.LoadFile( uri.c_str() );
   if ( e != tinyxml2::XML_SUCCESS )
   {
      std::cout << "Cant load NetworkData xml " << uri << std::endl;
      return false;
   }

   tinyxml2::XMLElement* root = doc.FirstChildElement( "Network" );
   if ( !root )
   {
      std::cout << "No Network tag in xml " << uri << std::endl;
      return false;
   }

   //m_vstDirMB = root->Attribute( "directory" );
   int m_checkSum = root->IntAttribute( "count" );
   //m_vstDir = QString::fromStdString( m_vstDirMB ).toStdWString();

   m_all.clear();

   // Read first child <PluginInfo> of parent <PluginInfoList>
   tinyxml2::XMLElement* spur = root->FirstChildElement( "Spur" );
   if ( !spur )
   {
      std::cout << "No PluginInfo in xml " << uri << std::endl;
      return true;
   }

   // Read all next children <PluginInfo> of parent <PluginInfoList>
   int k = 0;
   while ( spur )
   {
      SpurData spurData;
      if ( spurData.readXML( k, spur ) )
      {
         m_all.emplace_back( std::move( spurData ) );
         k++;
      }

      spur = spur->NextSiblingElement( "Spur" );
   }

   std::cout <<"Loaded Network XML " << uri << std::endl;
   //std::cout << "[loadXml] dir = " << m_vstDirMB << std::endl;
   std::cout << "[loadXml] expectSpur = " << m_checkSum << std::endl;
   std::cout << "[loadXml] loadedSpur = " << k << std::endl;

   return true;
}

bool
App::saveXml( std::string const & uri ) const
{

   tinyxml2::XMLDocument doc;
   tinyxml2::XMLElement* network = doc.NewElement( "Network" );

   network->SetAttribute( "count", int( m_all.size() ) );

   for ( int i = 0; i < m_all.size(); ++i )
   {
      m_all[ i ].writeXML( doc, network );
   }

   doc.InsertEndChild( network );

   auto e = doc.SaveFile( uri.c_str() );
   if ( e != tinyxml2::XML_SUCCESS )
   {
      std::cout << "Cant save xml " << uri << std::endl;
      return false;
   }

   std::cout <<"Saved NetworkData XML " << uri << std::endl;

   return true;
}

void
createNetwork( TrackInfo const & trackInfo )
{
   int id = trackInfo.m_id;
   int found = findIndex( id );
   if ( found > -1 )
   {
      DE_ERROR("Track id ",id," already exist")
      return nullptr;
   }

   auto track = new Track( m_app );
   track->setTrackInfo( trackInfo );

   m_tracks.emplace_back( track );

   // 0 = master, 1 = return, 2 = audio-only, 3 = midi+audio
   auto type = trackInfo.m_type;
   if ( type == eTrackMaster )
   {
      m_master = track;
   }
   else if ( type == eTrackReturn )
   {
      m_returns.emplace_back( track );
   }
   else if ( type == eTrackAudio )
   {
      m_user.emplace_back( track );
      m_userAudio.emplace_back( track );
   }
   else if ( type == eTrackMidi )
   {
      m_user.emplace_back( track );
      m_userMidi.emplace_back( track );
   }

   return track;
}
void
updateDspChain()
{
   // setBypassed( true );

   if ( m_userMixer.size() < m_user.size() )
   {
      m_userMixer.resize( m_user.size() );
   }

   size_t k = 0;
   for ( auto & track : m_user )
   {
      if ( !track ) continue;
      m_userMixer.setInputSignal( k, track );
      k++;
   }

   k = 0;
   for ( auto & track : m_returns )
   {
      if ( !track ) continue;
      m_returnMixer.setInputSignal( k, track );
      k++;
   }

   m_returnMixer.setInputSignal( k, &m_userMixer );

   m_master->setInputSignal( 0, &m_returnMixer );

   //setBypassed( false );
}

*/

