#include "GLowPass.hpp"
#include <QVBoxLayout>
#include <QHBoxLayout>
using namespace de::audio;

GLowPass::GLowPass( QWidget* parent )
    : QWidget(parent)
    , m_inputSignal( nullptr )
    , m_isBypassed( false )
{
   setObjectName( "GLowPass" );
   setContentsMargins(0,0,0,0);
   m_title = new QLabel( "LowPass", this );
   m_slider = new QSlider( this );
   m_slider->setMinimum( 0 );
   m_slider->setMaximum( 1 );
   m_slider->setValue( 0 );
   m_value = new QLabel( "Off", this );
   QVBoxLayout* v = new QVBoxLayout();
   v->setContentsMargins(0,0,0,0);
   v->setSpacing( 3 );
   v->addWidget( m_title );
   v->addWidget( m_slider,1 );
   v->addWidget( m_value );
   v->setAlignment( m_title, Qt::AlignHCenter );
   v->setAlignment( m_slider, Qt::AlignHCenter );
   v->setAlignment( m_value, Qt::AlignHCenter );
   setLayout( v );
   m_inputBuffer.resize( 1024, 0.0f );

   setBypassed( true );

   connect( m_slider, SIGNAL(valueChanged(int)), this, SLOT(on_sliderChanged(int)), Qt::QueuedConnection );
}

GLowPass::~GLowPass()
{}

void
GLowPass::on_sliderChanged( int v )
{
   if ( v < 1 )
   {
      m_isBypassed = true;
      m_value->setText( "Off" );
   }
   else
   {
      m_isBypassed = false;
      m_value->setText( "On" );
   }
}

void
GLowPass::setBypassed( bool enabled )
{
   m_isBypassed = enabled;
   if ( m_isBypassed )
   {
      m_slider->setValue(0);
      m_value->setText("Off");
   }
   else
   {
      m_slider->setValue(1);
      m_value->setText("On");
   }
}

void
GLowPass::clearInputSignals()
{
   m_inputSignal = nullptr;
}

void
GLowPass::setInputSignal( de::audio::IDspChainElement* input )
{
   m_inputSignal = input;
}

uint64_t
GLowPass::readSamples( double pts, float* dst, uint32_t dstFrames, uint32_t dstChannels, uint32_t dstRate )
{
   uint64_t dstSamples = dstFrames * dstChannels;
   if ( !m_inputSignal )
   {
      ZeroMemory( dst, dstSamples );
      return dstSamples;
   }

   DSP_RESIZE( m_inputBuffer, dstSamples );
   ZeroMemory( m_inputBuffer.data(), dstSamples );

   uint64_t retSamples = m_inputSignal->readSamples( pts, m_inputBuffer.data(), dstFrames, dstChannels, dstRate );
   if ( retSamples != dstSamples )
   {
      DE_WARN("retSamples != dstSamples")
   }

   if ( m_isBypassed )
   {
      de::audio::DSP_COPY( m_inputBuffer.data(), dst, dstSamples );
      return dstSamples;
   }

   for ( size_t c = 0; c < dstChannels; c++ )
   {
      auto pDst = dst + c;
      for ( size_t i = 0; i < dstFrames-3; i++ )
      {
         float s0 = m_inputBuffer[ int(i)*int(dstChannels) + int(c) ];
         float s1 = m_inputBuffer[ int(i+1)*int(dstChannels) + int(c) ];
         float s2 = m_inputBuffer[ int(i+2)*int(dstChannels) + int(c) ];
         float s3 = m_inputBuffer[ int(i+3)*int(dstChannels) + int(c) ];

         *pDst = 0.25f * (s0 + s1 + s2 + s3);
         pDst += dstChannels;
      }

      float s0 = m_inputBuffer[ int(dstFrames-6)*int(dstChannels) + int(c) ];
      float s1 = m_inputBuffer[ int(dstFrames-5)*int(dstChannels) + int(c) ];
      float s2 = m_inputBuffer[ int(dstFrames-4)*int(dstChannels) + int(c) ];
      float s3 = m_inputBuffer[ int(dstFrames-3)*int(dstChannels) + int(c) ];
      float s4 = m_inputBuffer[ int(dstFrames-2)*int(dstChannels) + int(c) ];
      float s5 = m_inputBuffer[ int(dstFrames-1)*int(dstChannels) + int(c) ];

      *pDst = 0.25f * (s0 + s1 + s2 + s3);
      pDst += dstChannels;

      *pDst = 0.25f * (s1 + s2 + s3 + s4);
      pDst += dstChannels;

      *pDst = 0.25f * (s2 + s3 + s4 + s5);
      pDst += dstChannels;

      *pDst = 0.5f * ( s3 + s4 );
      pDst += dstChannels;
   }
   return dstSamples;
}



/*
void
GLowPass::timerEvent( QTimerEvent* event )
{
   if ( event->timerId() == m_updateTimerId )
   {
      update();
   }
}

// ============================================================================
void GLowPass::paintEvent( QPaintEvent* event )
// ============================================================================
{
   QPainter dc(this);
   dc.fillRect( rect(), QColor( 25,25,25 ) );

   int w = width();
   int h = height();
   int h2 = height() / 2;

   uint64_t srcSamples = m_shiftBuffer.size();
   uint64_t srcFrames = srcSamples / m_channelCount;
   uint64_t srcChannels = m_channelCount;
   if (srcFrames < 2) { return; }

   float const dx = float(w) / float(srcFrames);
   float const dy = float(h) * 0.5f;

   dc.setBrush( Qt::NoBrush );
   dc.setCompositionMode( QPainter::CompositionMode_SourceOver );

   for ( uint64_t c = 0; c < srcChannels; ++c )
   {
      if ( c == 0 )
         dc.setPen( QPen( QColor(255,55,55,63) ) );
      else if ( c == 1 )
         dc.setPen( QPen( QColor(255,225,55,63) ) );
      else if ( c == 2 )
         dc.setPen( QPen( QColor(55,200,55,63) ) );
      else
         dc.setPen( QPen( QColor(255,255,255,63) ) );

      for ( uint64_t i = 1; i < srcFrames; ++i )
      {
         const float sample1 = m_shiftBuffer[ srcChannels*(i-1) + c ];
         const float sample2 = m_shiftBuffer[ srcChannels*(i) + c ];
         const int x1 = dx * (i-1);
         const int x2 = dx * (i);
         const int y1 = dy - dy * sample1;
         const int y2 = dy - dy * sample2;
         dc.drawLine( x1,y1,x2,y2 );
      }
   }

   m_font5x8.drawText( dc, w/2, 1, QString("L_min(%1), L_max(%2), R_min(%3), R_max(%4)")
      .arg( L_min).arg( L_max ).arg( R_min).arg( R_max ), 0xFFFFFFFF, de::Align::CenterTop );
}
*/
