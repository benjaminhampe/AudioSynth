#include "GSpektrometer3D.hpp"
#include "parseQtKey.hpp"
#include <QPainter>
#include <QSurfaceFormat>
#include <QOpenGLTexture>
#include <QOpenGLShaderProgram>
#include <QOpenGLBuffer>
#include <QOpenGLContext>
#include <QOpenGLVertexArrayObject>
#include <QOpenGLExtraFunctions>
//#include <QPropertyAnimation>
//#include <QPauseAnimation>
//#include <QSequentialAnimationGroup>
#include <QDebug>


#ifdef ZeroMemory // Somehow the winbase header got included (by ogl i guess)
#undef ZeroMemory // and pollutes with M$ doof macros.
#endif

//   WAV_Gradient->addColor( video::SColor(255,0,0,0), 0.00f );
//   WAV_Gradient->addColor( video::SColor(255,0,0,255), 0.25f );
//   WAV_Gradient->addColor( video::SColor(255,0,255,0), 0.50f );
//   WAV_Gradient->addColor( video::SColor(255,255,255,0), 0.75f );
//   WAV_Gradient->addColor( video::SColor(255,255,0,0), 1.00f );

//   FFT_Gradient->addColor( video::SColor(255,0,0,0), 0.00f );
//   FFT_Gradient->addColor( video::SColor(255,25,25,25), 0.10f );
//   FFT_Gradient->addColor( video::SColor(255,50,50,50), 0.20f );
//   FFT_Gradient->addColor( video::SColor(255,75,75,75), 0.30f );
//   FFT_Gradient->addColor( video::SColor(255,100,100,100), 0.40f );
//   FFT_Gradient->addColor( video::SColor(255,125,125,125), 0.45f );
//   FFT_Gradient->addColor( video::SColor(255,0,0,255), 0.50f );
//   FFT_Gradient->addColor( video::SColor(255,0,200,0), .60f );
//   FFT_Gradient->addColor( video::SColor(255,255,255,0), .80f );
//   FFT_Gradient->addColor( video::SColor(255,255,0,0), 1.0f );

GSpektrometer3D::GSpektrometer3D( QWidget* parent )
   : QWidget( parent )
   , m_driver( nullptr )
   , m_fpsTimerId( 0 )
   , m_sizeX( 1500.0f)
   , m_sizeY( 256.0f)
   , m_sizeZ( 8000.0f)
{
   setAttribute( Qt::WA_OpaquePaintEvent );
   setContentsMargins( 0,0,0,0 );
   setMinimumSize( 128, 64 );
   setSizePolicy(QSizePolicy::Expanding,QSizePolicy::Expanding);

   setFocusPolicy( Qt::StrongFocus );
   setMouseTracking( true );
   m_driver = de::gpu::createVideoDriver( width(), height(), uint64_t( winId() ) );
   m_driver->setActiveCamera( &m_Camera );
   m_Camera.setFOV(90.0f);
   //auto smgr = m_driver->getSceneManager();

//   m_gradientWavtris.addStop( 0.0f, 0xFF000000 );
//   m_gradientWavtris.addStop( 0.1f, 0xFFFFFFFF );
//   m_gradientWavtris.addStop( 0.2f, 0xFF00FF00 );
//   m_gradientWavtris.addStop( 0.3f, 0xFF002000 );
//   m_gradientWavtris.addStop( 0.5f, 0xFF00FFFF );
//   m_gradientWavtris.addStop( 1.0f, 0xFF0000FF );
//   m_gradientWavtris.addStop( 2.0f, 0xFFFF00FF );

   m_gradientWavtris.addStop( 0, de::RGBA(0,0,0) );
   m_gradientWavtris.addStop( 0.1f, de::RGBA(25,25,25) );
   m_gradientWavtris.addStop( 0.2f, de::RGBA(50,50,50) );
   m_gradientWavtris.addStop( 0.3f, de::RGBA(75,75,75) );
   m_gradientWavtris.addStop( 0.4f, de::RGBA(100,100,100) );
   m_gradientWavtris.addStop( 0.45f, de::RGBA(125,125,125) );
   m_gradientWavtris.addStop( 0.5f, de::RGBA(0,0,255) );
   m_gradientWavtris.addStop( 0.6f, de::RGBA(0,200,0) );
   m_gradientWavtris.addStop( 0.8f, de::RGBA(255,255,0) );
   m_gradientWavtris.addStop( 1.0f, de::RGBA(255,0,0) );
   m_gradientWavtris.addStop( 1.1f, de::RGBA(255,0,255) );
   m_gradientWavtris.addStop( 1.3f, de::RGBA(0,0,255) );
   m_gradientWavtris.addStop( 1.5f, de::RGBA(0,0,155) );
   m_gradientWavtris.addStop( 2.5f, de::RGBA(255,255,255) );

   setupDspElement( 256, 2, 48000 );
   startFpsTimer( 30 );

}

GSpektrometer3D::~GSpektrometer3D()
{
   stopFpsTimer();

   if ( m_driver )
   {
      m_driver->close();
      delete m_driver;
      m_driver = nullptr;
   }
}

void
GSpektrometer3D::hideEvent( QHideEvent* event )
{
   stopFpsTimer();
   DE_DEBUG("")
   event->accept();
}

void
GSpektrometer3D::showEvent( QShowEvent* event )
{
   DE_DEBUG("")
   startFpsTimer( 30 );
   event->accept();
}

void
GSpektrometer3D::setupDspElement( uint32_t dstFrames, uint32_t dstChannels, uint32_t dstRate )
{
   //DE_DEBUG("dacFrames(",dstFrames,")")
   if ( m_inputBuffer.size() != dstFrames * dstChannels )
   {
      m_inputBuffer.resize( dstFrames * dstChannels );
   }

   if ( m_channelBuffer.size() != dstFrames )
   {
      m_channelBuffer.resize( dstFrames );
   }

   m_wavdataL.setColumnCount( 2*dstFrames );
   m_wavdataR.setColumnCount( 2*dstFrames );
}


uint64_t
GSpektrometer3D::readSamples( double pts, float* dst, uint32_t dstFrames, uint32_t dstChannels, uint32_t dstRate )
{
   m_channelCount = dstChannels;

   uint64_t dstSamples = dstFrames * dstChannels;
   if ( !m_inputSignal )
   {
      de::audio::ZeroMemory( dst, dstSamples );
      return dstSamples;
   }

   setupDspElement( dstFrames, dstChannels, dstRate );
   de::audio::ZeroMemory( m_inputBuffer );
   de::audio::ZeroMemory( m_channelBuffer );

   uint64_t retSamples = m_inputSignal->readSamples( pts,
                         m_inputBuffer.data(), dstFrames, dstChannels, dstRate );
   if ( retSamples != dstSamples )
   {
      DE_WARN("retSamples != dstSamples")
   }

   // Feed L waveform
   if ( dstChannels > 0 )
   {
      de::audio::DSP_GET_CHANNEL( m_channelBuffer.data(), dstFrames,
                                  m_inputBuffer.data(), dstFrames, 0, dstChannels );
      m_wavlinesL.push( m_channelBuffer.data(), dstFrames );

      m_wavdataL.push( m_channelBuffer.data(), dstFrames );
   }
   // Feed R waveform
   if ( dstChannels > 1 )
   {
      de::audio::DSP_GET_CHANNEL( m_channelBuffer.data(), dstFrames,
                                  m_inputBuffer.data(), dstFrames, 1, dstChannels );
      m_wavlinesR.push( m_channelBuffer.data(), dstFrames );

      m_wavdataR.push( m_channelBuffer.data(), dstFrames );
   }

   de::audio::DSP_COPY( m_inputBuffer.data(), dst, dstSamples );
   return dstSamples;
}

void GSpektrometer3D::render()
{
   if ( !m_driver ) { return; } // No driver.
   int w = m_driver->getScreenWidth();
   int h = m_driver->getScreenHeight();
   if ( w < 1 || h < 1 ) { return; } // No screen.

   int expMode = 0;

   createMatrixTriangleMesh( 0, m_wavtrisL,
      m_wavdataL.m_data,
      m_sizeX, m_sizeY, m_sizeZ, m_gradientWavtris, expMode );

   createMatrixTriangleMesh( 1, m_wavtrisR,
      m_wavdataR.m_data,
      m_sizeX, m_sizeY, m_sizeZ, m_gradientWavtris, expMode );

//   createMatrixFrontTriangleMesh( 0,
//      m_wavtrisFrontL,
//      m_wavdataL.m_data[0]->data(),
//      m_wavdataL.m_data[0]->size(),
//      m_sizeX, m_sizeY, m_sizeZ, m_gradientWavtris, expMode );

//   createMatrixFrontTriangleMesh( 1,
//      m_wavtrisFrontR,
//      m_wavdataR.m_data[0]->data(),
//      m_wavdataR.m_data[0]->size(),
//      m_sizeX, m_sizeY, m_sizeZ, m_gradientWavtris, expMode );

   m_driver->setClearColor( 0.1f, 0.1f, 0.1f, 1.f ); // dark grey
   m_driver->beginRender();

   de::gpu::TRSd trs;

// Draw 'L' TriangleMatrix below
   trs = de::gpu::TRSd();
   trs.setTX( -(45.0f + m_sizeX) );
   trs.setTZ( 0.0f );
   trs.setRZ( -90.0f );
   trs.setRX( 35.0f );
   //trs.setSX( -1.0f );
   m_driver->setModelMatrix( trs.getModelMatrix() );
   m_driver->draw3D( m_wavtrisL );

// Draw 'R' TriangleMatrix below
   trs = de::gpu::TRSd();
   trs.setTX( 45.0f + m_sizeX );
   trs.setTZ(  0.0f );
   trs.setRZ( 90.0f );
   trs.setRX( 35.0f );
   m_driver->setModelMatrix( trs.getModelMatrix() );
   m_driver->draw3D( m_wavtrisR );

//// Draw 'L' TriangleFront
//   trs = de::gpu::TRSd();
//   trs.setTX( -15.0f );
//   trs.setTZ( -200.0f );
//   //trs.setSX( -1.0f );
//   m_driver->setModelMatrix( trs.getModelMatrix() );
//   m_driver->draw3D( m_wavtrisFrontL );

//// Draw 'R' TriangleFront
//   trs = de::gpu::TRSd();
//   trs.setTX( 15.0f );
//   trs.setTZ( -200.0f );
//   m_driver->setModelMatrix( trs.getModelMatrix() );
//   m_driver->draw3D( m_wavtrisFrontR );


// Draw Lines
   int n = m_wavlinesL.m_data.size();
   float fx = 4.0f / float( n );
   float dx = m_wavlinesL.m_sizeX;
   float dy = m_wavlinesL.m_sizeY;
   float dz = m_wavlinesL.m_sizeZ / float( n );
   float tz = 0.0f;
   float sx = 5.0f;
   for ( int i = n-1; i >= 0; i-- )
   {
      de::gpu::TRSd trs;
      tz = (dz * i);
      trs.setTX( -10.0f );
      trs.setTZ( tz );
      trs.setSX( -sx );
      sx -= fx;
      //sz += 0.075f;
      m_driver->setModelMatrix( trs.getModelMatrix() );
      m_driver->draw3D( *m_wavlinesL.m_data[ i ] );
   }

   tz = 0.0f;
   sx = 5.0f;
   for ( int i = n-1; i >= 0; i-- )
   {
      de::gpu::TRSd trs;
      tz = (dz * i);
      trs.setTX( 10.0f );
      trs.setTZ( tz );
      trs.setSX( sx );
      sx -= fx;
      //sz += 0.075f;
      m_driver->setModelMatrix( trs.getModelMatrix() );
      m_driver->draw3D( *m_wavlinesR.m_data[ i ] );
   }

   //m_driver->getSceneManager()->render();
   //m_driver->draw2DPerfOverlay5x8();
   m_driver->endRender();
/*
   int w = width();
   int h = height();

   if ( w != m_img.width() || h != m_img.height() )
   {
      m_img = QImage( w,h, QImage::Format_ARGB32 );
   }

   m_img.fill( QColor( 100,100,100 ) );
   uint64_t srcSamples = m_shiftBuffer.size();
   uint64_t srcFrames = srcSamples / m_channelCount;
   uint64_t srcChannels = m_channelCount;

   float const dx = float(w) / float(srcFrames);
   float const dy = float(h) * 0.5f;

   for ( uint64_t c = 0; c < srcChannels; ++c )
   {
      uint32_t color = de::RGBA(32,255,255,64); // Qt is BGRA -> yellow not cyan
      if ( c == 1 )
         color = de::RGBA(0,0,255,64); // Qt is BGRA -> red not blue

      for ( uint64_t i = 1; i < srcFrames; ++i )
      {
         const float sample1 = m_shiftBuffer[ srcChannels*(i-1) + c ];
         const float sample2 = m_shiftBuffer[ srcChannels*(i) + c ];
         const int x1 = dx * (i-1);
         const int x2 = dx * (i);
         const int y1 = dy - dy * sample1;
         const int y2 = dy - dy * sample2;
         drawLine( m_img,x1,y1,x2,y2,color );
      }

//      for ( uint64_t i = 0; i < srcFrames; ++i )
//      {
//         const float s1 = m_shiftBuffer[ srcChannels*i + c ];
//         const int x = dx * (i);
//         const int y1 = dy;
//         const int y2 = dy - dy * s1;
//         drawLine( m_img,x,y1,x,y2,color );
//      }
   }
*/
}

void GSpektrometer3D::paintEvent( QPaintEvent* event )
{
   render();
}

void GSpektrometer3D::timerEvent( QTimerEvent* event )
{
   if ( event->timerId() == m_fpsTimerId )
   {
      render();
   }
}

void GSpektrometer3D::resizeEvent( QResizeEvent* event )
{
   if ( !m_driver ) { return; } // No driver.
   int w = event->size().width();
   int h = event->size().height();
   m_driver->resize( w, h );
   //emit_canvasResized();
   // update(); // Seems to create a cycle ( infinite loop )
}

void GSpektrometer3D::startFpsTimer( int ms )
{
   stopFpsTimer();
   if ( ms < 4 ) { ms = 4; }
   if ( ms > 60000  ) { ms = 60000; }
   m_fpsTimerId = startTimer( ms, Qt::PreciseTimer );
}

void GSpektrometer3D::stopFpsTimer()
{
   if ( m_fpsTimerId )
   {
      killTimer( m_fpsTimerId );
      m_fpsTimerId = 0;
   }
}


void
GSpektrometer3D::mouseMoveEvent( QMouseEvent* event )
{
   if ( m_driver )
   {
      de::SEvent post;
      post.type = de::EET_MOUSE_EVENT;
      post.mouseEvent.m_Flags = de::SMouseEvent::Moved;
      post.mouseEvent.m_X = event->x();
      post.mouseEvent.m_Y = event->y();
      post.mouseEvent.m_Wheel = 0.0f;
      m_driver->postEvent( post );
   }
}

void
GSpektrometer3D::mousePressEvent( QMouseEvent* event )
{
   if ( m_driver )
   {
      de::SEvent post;
      post.type = de::EET_MOUSE_EVENT;
      post.mouseEvent.m_Flags = de::SMouseEvent::Pressed;
      post.mouseEvent.m_X = event->x();
      post.mouseEvent.m_Y = event->y();
      post.mouseEvent.m_Wheel = 0.0f;

      if ( event->button() == Qt::LeftButton )
      {
         post.mouseEvent.m_Flags |= de::SMouseEvent::BtnLeft;
      }
      else if ( event->button() == Qt::RightButton )
      {
         post.mouseEvent.m_Flags |= de::SMouseEvent::BtnRight;
      }
      else if ( event->button() == Qt::MiddleButton )
      {
         post.mouseEvent.m_Flags |= de::SMouseEvent::BtnMiddle;
      }
      m_driver->postEvent( post );

      // auto camera = m_driver->getActiveCamera();
      // if ( camera )
      // {
         // de::gpu::Ray3d ray = camera->computeRay( event->x(), event->y() );
         // auto a = ray.getPos() + ray.getDir() * 10.0;
         // auto b = ray.getPos() + ray.getDir() * 1000.0;
         // m_LineRenderer.add3DLine( a,b, de::randomColor() );
      // }

   }

   //m_MousePos = glm::ivec2( event->x(), event->y() ); // current mouse pos
}

void
GSpektrometer3D::mouseReleaseEvent( QMouseEvent* event )
{
   if ( m_driver )
   {
      de::SEvent post;
      post.type = de::EET_MOUSE_EVENT;
      post.mouseEvent.m_Flags = de::SMouseEvent::Released;
      post.mouseEvent.m_X = event->x();
      post.mouseEvent.m_Y = event->y();
      post.mouseEvent.m_Wheel = 0.0f;
      if ( event->button() == Qt::LeftButton )
      {
         post.mouseEvent.m_Flags |= de::SMouseEvent::BtnLeft;
      }
      else if ( event->button() == Qt::RightButton )
      {
         post.mouseEvent.m_Flags |= de::SMouseEvent::BtnRight;
      }
      else if ( event->button() == Qt::MiddleButton )
      {
         post.mouseEvent.m_Flags |= de::SMouseEvent::BtnMiddle;
      }
      m_driver->postEvent( post );
   }

   //m_MousePos = glm::ivec2( event->x(), event->y() ); // current mouse pos
   //m_MouseMove = { 0,0 };
}


void
GSpektrometer3D::wheelEvent( QWheelEvent* event )
{
   if ( m_driver )
   {
      de::SEvent post;
      post.type = de::EET_MOUSE_EVENT;
      post.mouseEvent.m_Flags = de::SMouseEvent::Wheel;
      post.mouseEvent.m_X = event->x();
      post.mouseEvent.m_Y = event->y();
      post.mouseEvent.m_Wheel = event->angleDelta().y(); //    //QPoint delta = event->pixelDelta();
      // DE_DEBUG("post.mouseEvent.m_Wheel = ",post.mouseEvent.m_Wheel)
      m_driver->postEvent( post );
   }

   //event->accept();
}

void
GSpektrometer3D::keyPressEvent( QKeyEvent* event )
{
   //DE_DEBUG("KeyPress(",event->key(),")")

   if ( m_driver )
   {
      de::SEvent post;
      post.type = de::EET_KEY_EVENT;
      post.keyEvent.Key = de::KEY_UNKNOWN;
      post.keyEvent.Flags = de::SKeyEvent::Pressed;
      if ( event->modifiers() & Qt::ShiftModifier ) { post.keyEvent.Flags |= de::SKeyEvent::Shift; }
      if ( event->modifiers() & Qt::ControlModifier ) { post.keyEvent.Flags |= de::SKeyEvent::Ctrl; }
      if ( event->modifiers() & Qt::AltModifier ) { post.keyEvent.Flags |= de::SKeyEvent::Alt; }
      parseQtKey( event, post );
      m_driver->postEvent( post );
   }

   event->accept();
}

void
GSpektrometer3D::keyReleaseEvent( QKeyEvent* event )
{
   //DE_DEBUG("KeyRelease(",event->key(),")")

   if ( m_driver )
   {
      de::SEvent post;
      post.type = de::EET_KEY_EVENT;
      post.keyEvent.Key = de::KEY_UNKNOWN;
      post.keyEvent.Flags = de::SKeyEvent::None;
      if ( event->modifiers() & Qt::ShiftModifier ) { post.keyEvent.Flags |= de::SKeyEvent::Shift; }
      if ( event->modifiers() & Qt::ControlModifier ) { post.keyEvent.Flags |= de::SKeyEvent::Ctrl; }
      if ( event->modifiers() & Qt::AltModifier ) { post.keyEvent.Flags |= de::SKeyEvent::Alt; }
      parseQtKey( event, post );
      m_driver->postEvent( post );
   }

   event->accept();
}


