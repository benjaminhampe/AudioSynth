﻿#ifndef G_SEQ16_HPP
#define G_SEQ16_HPP

#include <QWidget>
#include <QImage>
#include <QTimer>
#include <QPainter>
#include <QPaintEvent>
#include <QResizeEvent>
#include <QMouseEvent>
#include <QKeyEvent>
#include <QDebug>
#include <QThread>
#include <QSlider>
#include <QDial>
#include <QLabel>
#include <QCheckBox>
#include <QSpinBox>
#include <QDoubleSpinBox>
#include <QPushButton>

#include <QFont5x8.hpp>

#include "GSeqSynth.hpp"

// Sends timed notes to a synth
// ============================================================================
class GSeq16 : public QWidget
// ============================================================================
{
   Q_OBJECT
public:
   GSeq16( QWidget* parent = 0 );
   ~GSeq16();
signals:
public slots:
   void setSynth( int i, GSeqSynth* synth )
   {
      //if ( i < 0 || i >= m_synths.size() ) return;
      m_synth = synth;
   }
private slots:
   void on_bpm( int v );
   void on_buttonPlay( bool checked = false );

   void stopNoteTimer( )
   {
      if ( m_timerId )
      {
         killTimer( m_timerId );
         m_timerId = 0;
      }
   }

   void startNoteTimer()
   {
      stopNoteTimer();
      m_timerId = startTimer( 1, Qt::PreciseTimer );
   }
protected:
   void timerEvent( QTimerEvent* event );
public:
   struct Play
   {
      QPushButton* play;
      QSpinBox* bpm;
   };

   struct Item
   {
      bool isPlaying;
      int id;
      QCheckBox* enabled;
      QSpinBox* note;
      QSpinBox* detune;
      QSpinBox* velocity;
   };
   struct Header
   {
      QLabel* labelNote;
      QLabel* labelDetune;
      QLabel* labelVelocity;
      QLabel* labelCheck;
   };
protected:
   DE_CREATE_LOGGER("GSeq16")
   GSeqSynth* m_synth;
   int m_timerId;
   bool m_isPlaying;
   bool m_needTimerRestart;
   float m_bpm;
   float m_freq;
   float m_period;
   float m_periodStep;
   double m_timeStart;
   int m_step;
   int m_step_count;


   Play m_play;
   Header m_header;
   std::array< Item, 16 > m_items;
};

#endif // G_LOPASS1_HPP
