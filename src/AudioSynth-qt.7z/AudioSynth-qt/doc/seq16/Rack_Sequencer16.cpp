#include "Rack_Sequencer16.hpp"
#include <QVBoxLayout>
#include <QHBoxLayout>

Rack_Sequencer16::Rack_Sequencer16( QWidget* parent )
   : QImageWidget(parent)
{
   setObjectName( "Rack_Sequencer16" );
   setContentsMargins(0,0,0,0);

   m_seq = new GSeq16( this );
   m_synth = new GSeqSynth( this );
   m_adsr = new GADSR( this );
   //m_synthLFO = new GLoudnessLFO( "SeqLFO", this);
   //m_synthDelay = new GDelay( this );
   m_volumeSlider = new GVolume( "Voice Vol.", this );
   m_volumeMeter = new GLevelMeter( this );
   m_oszilloskop = new GOszilloskop( this );


   QHBoxLayout* h = new QHBoxLayout();
   h->setContentsMargins( 0,0,0,0 );
   h->setSpacing( 5 );
   h->addWidget( m_synth );
   h->addWidget( m_volumeMeter );
   h->addWidget( m_volumeSlider );
   h->addWidget( m_oszilloskop );
   h->addWidget( m_adsr );
   //h->addWidget( m_synthLFO );
   //h->addWidget( m_synthDelay );

   QVBoxLayout* v = new QVBoxLayout();
   v->setContentsMargins( 0,0,0,0 );
   v->setSpacing( 5 );
   v->addLayout( h,1 );
   v->addWidget( m_seq );
   setLayout( v );

   // [1.] Setup DSP chain
   // +-------+   +--------------+   +-------------+   +-------------+
   // | Synth |-->| VolumeSlider |-->| VolumeMeter |-->| Oszilloskop |
   // +-------+   +--------------+   +-------------+   +-------------+
   m_volumeSlider->setInputSignal( m_synth );
   m_volumeMeter->setInputSignal( m_volumeSlider );
   m_oszilloskop->setInputSignal( m_volumeMeter );

   // [2.] Tell sequencer about its synthesizer
   m_seq->setSynth( 0, m_synth );

   // [3.] Tell adsr control to control synth adsr ( could be anywhere else )
   m_adsr->setADSR( m_synth->getADSR() );

   // [4.] Setup Oszi size ( not to much to better see osc base periods )
   m_oszilloskop->setupDspElement( 256,2,48000 );
}

Rack_Sequencer16::~Rack_Sequencer16()
{
   // stopUpdateTimer();
}

uint64_t
Rack_Sequencer16::readSamples( double pts, float* dst, uint32_t dstFrames, uint32_t dstChannels, uint32_t dstRate )
{
   return m_oszilloskop->readSamples( pts, dst, dstFrames, dstChannels, dstRate );
}
