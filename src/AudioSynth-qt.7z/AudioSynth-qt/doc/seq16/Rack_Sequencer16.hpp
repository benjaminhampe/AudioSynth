﻿#ifndef G_SEQUENCER16_RACK_HPP
#define G_SEQUENCER16_RACK_HPP

#include <de/audio/dsp/IDspChainElement.hpp>

//#include "GSynth.hpp"
//#include "GLFO.hpp"
//#include "GDelay.hpp"
//#include "GMixer.hpp"
//#include "GFilter.hpp"
//#include "GLowPass.hpp"
//#include "GLoPass.hpp"


#include "GSeq16.hpp"
#include "GSeqSynth.hpp"
#include "GADSR.hpp"
#include "GLevelMeter.hpp"
#include "GVolume.hpp"
#include "GOszilloskop.hpp"

#include "QImageWidget.hpp"

// ============================================================================
class Rack_Sequencer16 : public QImageWidget, public de::audio::IDspChainElement
// ============================================================================
{
   Q_OBJECT
   DE_CREATE_LOGGER("Rack_Sequencer16")
public:
   Rack_Sequencer16( QWidget* parent = 0 );
   ~Rack_Sequencer16();

   uint64_t
   readSamples(
      double pts,
      float* dst,
      uint32_t dstFrames,
      uint32_t dstChannels,
      uint32_t dstRate ) override;

signals:
public slots:
private slots:
protected:
   GSeq16* m_seq; // Sends notes to synth
   GSeqSynth* m_synth;  // Produces sounds
   GADSR* m_adsr; // ADSR hullcurve
   //GLoudnessLFO* m_synth2LFO;
   //GDelay* m_synth2Delay;
   GOszilloskop* m_oszilloskop;
   GVolume* m_volumeSlider;
   GLevelMeter* m_volumeMeter;

};

#endif // G_OSZILLOSKOP_H
