#include "GSeq16.hpp"
#include <QVBoxLayout>
#include <QHBoxLayout>

namespace {

QDial* createDial( int val, int min, int max, QWidget* parent )
{
   auto elem = new QDial( parent );
   elem->setMinimum( min );
   elem->setMaximum( max );
   elem->setValue( val );
   return elem;
}

QSlider* createSlider( int val, int min, int max, QWidget* parent )
{
   auto elem = new QSlider( parent );
   elem->setMinimum( min );
   elem->setMaximum( max );
   elem->setValue( val );
   return elem;
}

QSpinBox* createSpinBox( int val, int min, int max, QWidget* parent )
{
   auto elem = new QSpinBox( parent );
   elem->setMinimum( min );
   elem->setMaximum( max );
   elem->setValue( val );
   elem->setSingleStep( 1 );
   return elem;
}

QVBoxLayout* createPlay( GSeq16::Play & play, QWidget* parent )
{
   play.play = new QPushButton( "Play", parent );
   play.bpm = createSpinBox( 90,1,360, parent );
   QVBoxLayout* v = new QVBoxLayout();
   v->setContentsMargins(0,0,0,0);
   v->setSpacing( 5 );
   v->addWidget( play.play,1 );
   v->addWidget( play.bpm );
   return v;
}

QVBoxLayout* createHeader( GSeq16::Header & header, QWidget* parent )
{
   header.labelNote = new QLabel( "MidiNote", parent );
   header.labelDetune = new QLabel( "Detune in ct", parent );
   header.labelVelocity = new QLabel( "Velocity", parent );
   header.labelCheck = new QLabel( "Steps", parent );
   QVBoxLayout* v = new QVBoxLayout();
   v->setContentsMargins(0,0,0,0);
   v->setSpacing( 5 );
   v->addWidget( header.labelNote );
   v->addWidget( header.labelDetune );
   v->addWidget( header.labelVelocity );
   v->addWidget( header.labelCheck );
   return v;
}

QVBoxLayout* createItem( GSeq16::Item & item, int id, QString title, QWidget* parent )
{
   item.id = id;
   item.isPlaying = false;
   item.enabled = new QCheckBox( title, parent );
   item.note = createSpinBox( 64,0,127, parent );
   item.detune = createSpinBox( 0,-100,100, parent );
   item.velocity = createSpinBox( 90,0,127, parent );

   item.enabled->setObjectName( QString::number( id ) );
   item.note->setObjectName( QString::number( id ) );
   item.detune->setObjectName( QString::number( id ) );
   item.velocity->setObjectName( QString::number( id ) );

   QVBoxLayout* v = new QVBoxLayout();
   v->setContentsMargins(0,0,0,0);
   v->setSpacing( 5 );
   v->addWidget( item.note );
   v->addWidget( item.detune );
   v->addWidget( item.velocity );
   v->addWidget( item.enabled );
   v->setAlignment( item.enabled, Qt::AlignHCenter );
   return v;
}

} // end namespace

GSeq16::GSeq16( QWidget* parent )
   : QWidget(parent)
   , m_synth( nullptr )
   , m_timerId( 0 )
   , m_isPlaying( false )
   , m_needTimerRestart( false )
   , m_bpm( 60.0f )
   , m_freq( m_bpm / 60.0f )
   , m_period( 1000.0 / m_freq ) // in [ms]
   , m_periodStep( m_period / 16.0 ) // stepTime
   , m_timeStart( dbSeconds() )
   , m_step( 0 )
   , m_step_count( 16 )
{
   setObjectName( "GSeq16" );
   setContentsMargins(0,0,0,0);

   QHBoxLayout* h = new QHBoxLayout();
   h->setContentsMargins(0,0,0,0);
   h->setSpacing( 1 );
   h->addLayout( createPlay( m_play, this ) );
   h->addLayout( createHeader( m_header, this ) );

   for ( size_t i = 0; i < m_items.size(); i++ )
   {
      auto v = createItem( m_items[ i ], i, QString::number(i+1), this );
      h->addLayout( v );
   }

   setLayout( h );

   //for ( auto & synth : m_synths ) { synth = nullptr; }

   connect( m_play.play, SIGNAL(clicked(bool)), this, SLOT(on_buttonPlay(bool)), Qt::QueuedConnection );
   connect( m_play.bpm, SIGNAL(valueChanged(int)), this, SLOT(on_bpm(int)), Qt::QueuedConnection );

   //startNoteTimer();
}

GSeq16::~GSeq16()
{
   stopNoteTimer();
}


void
GSeq16::on_buttonPlay( bool checked )
{
   if ( m_isPlaying )
   {
      stopNoteTimer();
      m_isPlaying = false;
      m_play.play->setText("Play");

   }
   else
   {

      m_play.play->setText("Stop");
      m_timeStart = dbSeconds();
      m_isPlaying = true;
      m_step = 0;
      startNoteTimer();

   }
}

void
GSeq16::on_bpm( int v )
{
   m_bpm = m_play.bpm->value();
   m_freq = m_bpm / 60.0f;
   m_period = 1000.0f / m_freq;
   m_periodStep = m_period / 16.0f;
   DE_DEBUG("bpm(",m_bpm,"), freq(",m_freq,"), period(",m_period,"), periodStep(",m_periodStep,")")

   m_needTimerRestart = true;
}


void
GSeq16::timerEvent( QTimerEvent* event )
{
   if ( event->timerId() == m_timerId && m_isPlaying )
   {
      auto noteOn = [&] ( int midiNote, int detuneInCents = 0, int velocity = 90 )
      {
         // for ( auto synth : m_synths )
         // {
            if ( m_synth )
            {
               m_synth->sendNote( de::audio::synth::Note( -1, midiNote, detuneInCents, velocity ) );
            }
         // }
      };

      double t = dbSeconds() - m_timeStart;
      t = fmod( 1000.0*t, m_period ); // in range{0,m_period} in [ms]

      double timeStart = m_periodStep * m_step;
      if ( t >= timeStart-0.5 )
      {
         auto & item = m_items[ m_step ];
         if ( item.enabled->isChecked() && !item.isPlaying )
         {
            item.isPlaying = true;
            int midiNote = item.note->value();
            int velocity = item.velocity->value();
            int detune = item.detune->value();
            noteOn( midiNote, detune, velocity );
         }

         m_step++;

      }

      if ( m_step >= m_step_count )
      {
         for ( auto & item : m_items)
         {
            item.isPlaying = false;
         }
         m_step = 0;
      }
   }
}
