#include "GSeqSynth.hpp"
#include <QVBoxLayout>
#include <QHBoxLayout>

namespace {

QDial* createDial( int val, int min, int max, QWidget* parent )
{
   auto elem = new QDial( parent );
   elem->setMinimum( min );
   elem->setMaximum( max );
   elem->setValue( val );
   return elem;
}

QSlider* createSlider( int val, int min, int max, QWidget* parent )
{
   auto elem = new QSlider( parent );
   elem->setMinimum( min );
   elem->setMaximum( max );
   elem->setValue( val );
   return elem;
}

QHBoxLayout* createItem( GSeqSynth::Item & item, QString title, QWidget* parent )
{
   item.title = new QLabel( title, parent );
   item.volumeSlider = createSlider( 10,0,100, parent );
   //item.volumeSlider->setTickInterval( 10 );
   item.volumeSlider->setTickPosition( QSlider::TicksRight );
   item.volumeSlider->setSingleStep( 1 );

   item.volumeAmount = new QLabel( "100 %", parent );
   item.detuneTitle = new QLabel( "", parent );
   item.detuneSlider = createSlider( 0,-36,36, parent );
   //item.detuneSlider->setTickInterval( 10 );
   item.detuneSlider->setTickPosition( QSlider::TicksLeft );
   item.detuneSlider->setSingleStep( 1 );

   item.detuneAmount = new QLabel( "0", parent );
   item.detune = 0;

   QVBoxLayout* v1 = new QVBoxLayout();
   v1->setContentsMargins(0,0,0,0);
   v1->setSpacing( 5 );
   v1->addWidget( item.title );
   v1->addWidget( item.volumeSlider,1 );
   v1->addWidget( item.volumeAmount );
   v1->setAlignment( item.title, Qt::AlignHCenter );
   v1->setAlignment( item.volumeSlider, Qt::AlignHCenter );
   v1->setAlignment( item.volumeAmount, Qt::AlignHCenter );

   QVBoxLayout* v2 = new QVBoxLayout();
   v2->setContentsMargins(0,0,0,0);
   v2->setSpacing( 5 );
   v2->addWidget( item.detuneTitle );
   v2->addWidget( item.detuneSlider,1 );
   v2->addWidget( item.detuneAmount );
   v2->setAlignment( item.detuneTitle, Qt::AlignHCenter );
   v2->setAlignment( item.detuneSlider, Qt::AlignHCenter );
   v2->setAlignment( item.detuneAmount, Qt::AlignHCenter );

   QHBoxLayout* h = new QHBoxLayout();
   h->setContentsMargins(0,0,0,0);
   h->setSpacing( 1 );
   h->addLayout( v1 );
   h->addLayout( v2 );
   return h;
}

} // end namespace

using namespace de::audio; // DSP_RESIZE, ZeroMemory, DSP_COPY

GSeqSynth::GSeqSynth( QWidget* parent )
    : QWidget(parent)
    , m_isPlaying( false )
{
   setObjectName( "GSeqSynth" );
   setContentsMargins(0,0,0,0);

//   m_sineVolumeLabel = new QLabel( "Sine", this );
//   m_triVolumeLabel = new QLabel( "Triangle", this );
//   m_rectVolumeLabel = new QLabel( "Rect", this );
//   m_sawVolumeLabel = new QLabel( "Saw", this );

   QHBoxLayout* h = new QHBoxLayout();
   h->setContentsMargins(0,0,0,0);
   h->setSpacing( 5 );

   auto v1 = createItem( m_sine1, "Sine1", this );
   auto v2 = createItem( m_sine2, "Sine2", this );
   auto v3 = createItem( m_sine3, "Sine3", this );
   auto v4 = createItem( m_sine4, "Sine4", this );
   auto v5 = createItem( m_sine5, "Sine5", this );
   auto v6 = createItem( m_tri, "Triangle", this );
   auto v7 = createItem( m_rect, "Rect", this );
   auto v8 = createItem( m_saw, "Saw", this );
   auto v9 = createItem( m_noise, "Noise", this );

   h->addLayout( v1 );
   h->addLayout( v2 );
   h->addLayout( v3 );
   h->addLayout( v4 );
   h->addLayout( v5 );
   h->addLayout( v6 );
   h->addLayout( v7 );
   h->addLayout( v8 );
   h->addLayout( v9 );
   setLayout( h );

   connect( m_sine1.volumeSlider, SIGNAL(valueChanged(int)), this, SLOT(on_volumeSine1(int)) );
   connect( m_sine1.detuneSlider, SIGNAL(valueChanged(int)), this, SLOT(on_detuneSine1(int)) );
   connect( m_sine2.volumeSlider, SIGNAL(valueChanged(int)), this, SLOT(on_volumeSine2(int)) );
   connect( m_sine2.detuneSlider, SIGNAL(valueChanged(int)), this, SLOT(on_detuneSine2(int)) );
   connect( m_sine3.volumeSlider, SIGNAL(valueChanged(int)), this, SLOT(on_volumeSine3(int)) );
   connect( m_sine3.detuneSlider, SIGNAL(valueChanged(int)), this, SLOT(on_detuneSine3(int)) );
   connect( m_sine4.volumeSlider, SIGNAL(valueChanged(int)), this, SLOT(on_volumeSine4(int)) );
   connect( m_sine4.detuneSlider, SIGNAL(valueChanged(int)), this, SLOT(on_detuneSine4(int)) );
   connect( m_sine5.volumeSlider, SIGNAL(valueChanged(int)), this, SLOT(on_volumeSine5(int)) );
   connect( m_sine5.detuneSlider, SIGNAL(valueChanged(int)), this, SLOT(on_detuneSine5(int)) );

   connect( m_tri.volumeSlider, SIGNAL(valueChanged(int)), this, SLOT(on_volumeTriangle(int)) );
   connect( m_tri.detuneSlider, SIGNAL(valueChanged(int)), this, SLOT(on_detuneTriangle(int)) );
   connect( m_rect.volumeSlider, SIGNAL(valueChanged(int)), this, SLOT(on_volumeRect(int)) );
   connect( m_rect.detuneSlider, SIGNAL(valueChanged(int)), this, SLOT(on_detuneRect(int)) );
   connect( m_saw.volumeSlider, SIGNAL(valueChanged(int)), this, SLOT(on_volumeSaw(int)) );
   connect( m_saw.detuneSlider, SIGNAL(valueChanged(int)), this, SLOT(on_detuneSaw(int)) );
   connect( m_noise.volumeSlider, SIGNAL(valueChanged(int)), this, SLOT(on_volumeNoise(int)) );
   connect( m_noise.detuneSlider, SIGNAL(valueChanged(int)), this, SLOT(on_detuneNoise(int)) );

   DSP_RESIZE( m_inputBuffer, 1024 );
   DSP_RESIZE( m_mixerBuffer, 1024 );

   for ( auto & note : m_notes )
   {
      note.m_isPlaying = false;
      note.m_wasPlaying = false;
   }

   m_oscs[ 0 ] = &m_oscSine1;
   m_oscs[ 1 ] = &m_oscSine2;
   m_oscs[ 2 ] = &m_oscSine3;
   m_oscs[ 3 ] = &m_oscSine4;
   m_oscs[ 4 ] = &m_oscSine5;
   m_oscs[ 5 ] = &m_oscTriangle;
   m_oscs[ 6 ] = &m_oscRect;
   m_oscs[ 7 ] = &m_oscSaw;
   m_oscs[ 8 ] = &m_oscNoise;

   m_items[ 0 ] = &m_sine1;
   m_items[ 1 ] = &m_sine2;
   m_items[ 2 ] = &m_sine3;
   m_items[ 3 ] = &m_sine4;
   m_items[ 4 ] = &m_sine5;
   m_items[ 5 ] = &m_tri;
   m_items[ 6 ] = &m_rect;
   m_items[ 7 ] = &m_saw;
   m_items[ 8 ] = &m_noise;

   on_volumeSine1( 50 );   on_detuneSine1( 0 );
   on_volumeSine2( 40 );   on_detuneSine2( 0 );
   on_volumeSine3( 30 );   on_detuneSine3( 0 );
   on_volumeSine4( 20 );   on_detuneSine4( 0 );
   on_volumeSine5( 10 );   on_detuneSine5( 0 );
   on_volumeTriangle( 0 ); on_detuneTriangle( 0 );
   on_volumeRect( 0 );     on_detuneRect( 0 );
   on_volumeSaw( 0 );      on_detuneSaw( 0 );
}

GSeqSynth::~GSeqSynth()
{
   // stopUpdateTimer();
}

void
GSeqSynth::sendNote( de::audio::synth::Note const & note )
{
   size_t slotIndex = 0;
   {
      std::lock_guard< std::mutex > lg( m_NoteListMutex );

      for ( size_t i = 0; i < m_notes.size(); ++i )
      {
         auto & slot = m_notes[ i ];
         if ( !slot.m_isPlaying )
         {
            slot.m_note = note;
            slot.m_note.m_adsr = note.m_adsr;
            slot.m_note.m_velocity = note.m_velocity;
            slot.m_note.m_midiNote = note.m_midiNote;
            slot.m_note.m_detune = note.m_detune;
            slot.m_wasPlaying = false;
            slot.m_isPlaying = true;
            slotIndex = i;
            break;
         }
      }
   }
   //DE_DEBUG("NoteOn(",note.m_midiNote,"), freq(",note.m_midiFreq,"), slot(", slotIndex,")" )
}

uint64_t
GSeqSynth::readSamples( double pts, float* dst, uint32_t dstFrames, uint32_t dstChannels, uint32_t dstRate )
{
   uint64_t dstSamples = dstFrames * dstChannels;
   DSP_RESIZE( m_mixerBuffer, dstSamples );
   ZeroMemory( m_mixerBuffer );

   DSP_RESIZE( m_inputBuffer, dstSamples );
   //ZeroMemory( dst, dstSamples );

   double dt = 1.0 / double( dstRate );

   size_t noteCount = 0;

   {
      std::lock_guard< std::mutex > lg( m_NoteListMutex );

      // Add notes to mixer
      for ( size_t i = 0; i < m_notes.size(); ++i )
      {
         auto & slot = m_notes[ i ];
         if ( slot.m_isPlaying )
         {
            // Start playing
            if ( !slot.m_wasPlaying )
            {
               slot.m_note.m_timeStart = pts; // This prevents dropouts for unsync start times < 0.0
               slot.m_wasPlaying = true;
            }

            // Stop when ADSR duration exceeded.
            double t = pts - slot.m_note.m_timeStart;
            if ( t >= slot.m_note.m_adsr.getDuration() )
            {
               slot.m_isPlaying = false;
               slot.m_wasPlaying = false;
               continue;
            }

            // Play OSC's
            for ( size_t k = 0; k < m_oscs.size(); k++ )
            {
               auto osc = m_oscs[ k ];

               int midiNote = slot.m_note.m_midiNote;
               float detune = 0.01f * slot.m_note.m_detune; // cents to -1,1
               midiNote += m_items[ k ]->detune;

               float freq = getFrequencyFromMidiNote( midiNote, detune );
               osc->setFrequency( freq );

               // Create samples
               //ZeroMemory( m_inputBuffer );

               float* pDst = m_mixerBuffer.data();
               for ( size_t f = 0; f < dstFrames; f++ )
               {
                  //float lfo1 = m_lfo.computeValue( t );
                  float adsr = slot.m_note.m_adsr.computeSample( t );
                  float sample = osc->computeSample( t ) * adsr;
                  for ( size_t c = 0; c < dstChannels; c++ )
                  {
                     *pDst += sample;
                     pDst++;
                  }
                  t += dt;
               }

               //DSP_ADD( m_inputBuffer.data(), m_mixerBuffer.data(), dstSamples );
            }
         }
      }
   }

   DSP_COPY( m_mixerBuffer.data(), dst, dstSamples );
   return dstSamples;
}

void
GSeqSynth::on_volumeSine1( int v )
{
   int vol = std::clamp( v, 0, 100 );
   m_sine1.volumeAmount->setText( QString::number(vol) + " % " );
   m_oscSine1.setVolume( vol );
}

void
GSeqSynth::on_detuneSine1( int v )
{
   //int offset = m_sine1.detuneSlider->value();
   m_sine1.detune = v;
   m_sine1.detuneAmount->setText( QString::number(v) );
}

void
GSeqSynth::on_volumeSine2( int v )
{
   int vol = std::clamp( v, 0, 100 ); // m_sine2.volumeSlider->value()
   m_sine2.volumeAmount->setText( QString::number(vol) + " % " );
   m_oscSine2.setVolume( vol );
}

void
GSeqSynth::on_detuneSine2( int v )
{
   m_sine2.detune = v;
   m_sine2.detuneAmount->setText( QString::number(v) ); // offset
}

void
GSeqSynth::on_volumeSine3( int v )
{
   int vol = std::clamp( v, 0, 100 ); // m_sine3.volumeSlider->value()
   m_sine3.volumeAmount->setText( QString::number(vol) + " % " );
   m_oscSine3.setVolume( vol );
}

void
GSeqSynth::on_detuneSine3( int v )
{
   m_sine3.detune = v;
   m_sine3.detuneAmount->setText( QString::number(v) ); // offset
}

void
GSeqSynth::on_volumeSine4( int v )
{
   int vol = std::clamp( v, 0, 100 ); // m_sine4.volumeSlider->value()
   m_sine4.volumeAmount->setText( QString::number(vol) + " % " );
   m_oscSine4.setVolume( vol );
}

void
GSeqSynth::on_detuneSine4( int v )
{
   m_sine4.detune = v;
   m_sine4.detuneAmount->setText( QString::number(v) ); // offset
}

void
GSeqSynth::on_volumeSine5( int v )
{
   int vol = std::clamp( v, 0, 100 ); // m_sine5.volumeSlider->value()
   m_sine5.volumeAmount->setText( QString::number(vol) + " % " );
   m_oscSine5.setVolume( vol );
}

void
GSeqSynth::on_detuneSine5( int v )
{
   m_sine5.detune = v;
   m_sine5.detuneAmount->setText( QString::number(v) ); // offset
}
void
GSeqSynth::on_volumeTriangle( int v )
{
   int vol = std::clamp( m_tri.volumeSlider->value(), 0, 100 );
   m_tri.volumeAmount->setText( QString::number(vol) + " % " );
   m_oscTriangle.setVolume( vol );
}
void
GSeqSynth::on_detuneTriangle( int v )
{
   m_tri.detune = v;
   m_tri.detuneAmount->setText( QString::number(v) ); // offset
}

void
GSeqSynth::on_volumeRect( int v )
{
   int vol = std::clamp( m_rect.volumeSlider->value(), 0, 100 );
   m_rect.volumeAmount->setText( QString::number(vol) + " % " );
   m_oscRect.setVolume( vol );
}

void
GSeqSynth::on_detuneRect( int v )
{
   m_rect.detune = v;
   m_rect.detuneAmount->setText( QString::number(v) ); // offset
}

void
GSeqSynth::on_volumeSaw( int v )
{
   int vol = std::clamp( m_saw.volumeSlider->value(), 0, 100 );
   m_saw.volumeAmount->setText( QString::number(vol) + " % " );
   m_oscSaw.setVolume( vol );
}

void
GSeqSynth::on_detuneSaw( int v )
{
   m_saw.detune = v;
   m_saw.detuneAmount->setText( QString::number(v) ); // offset
}

void
GSeqSynth::on_volumeNoise( int v )
{
   int vol = std::clamp( m_noise.volumeSlider->value(), 0, 100 );
   m_noise.volumeAmount->setText( QString::number(vol) + " % " );
   m_oscNoise.setVolume( vol );
}

void
GSeqSynth::on_detuneNoise( int v )
{
   m_noise.detune = v;
   m_noise.detuneAmount->setText( QString::number(v) ); // offset
}
