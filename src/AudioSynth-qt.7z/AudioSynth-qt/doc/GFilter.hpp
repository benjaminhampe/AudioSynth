#ifndef G_FILTER_HPP
#define G_FILTER_HPP

#include <QWidget>
#include <QImage>
#include <QTimer>
#include <QPainter>
#include <QPaintEvent>
#include <QResizeEvent>
#include <QMouseEvent>
#include <QKeyEvent>
#include <QDebug>
#include <QThread>

#include <QFont5x8.hpp>
#include <de/audio/dsp/IDspChainElement.hpp>
//#include <de_kissfft.hpp>
#include <de/audio/dsp/fft2.hpp>

// ============================================================================
class GFilter : public QWidget, public de::audio::IDspChainElement
// ============================================================================
{
   Q_OBJECT
   DE_CREATE_LOGGER("GFilter")
public:
   GFilter( QWidget* parent = 0 );
   ~GFilter();

   uint64_t readSamples( double pts, float* dst, uint32_t dstFrames,
               uint32_t dstChannels, uint32_t dstRate ) override;
signals:
public slots:
   void setBypassed( bool enabled )
   {
      m_isBypassed = enabled;
   }

   void clearInputSignals() { m_inputSignal = nullptr; }
   void setInputSignal( de::audio::IDspChainElement* input ) { m_inputSignal = input; }

private:
   bool m_isBypassed;
   de::audio::IDspChainElement* m_inputSignal;
   //de::audio::ShiftBuffer< float > m_shiftBuffer;
   std::vector< float > m_stereoInput;
   std::vector< float > m_stereoOutput;
   std::vector< float > m_monoInput;
   std::vector< float > m_monoOutput;
   std::vector< std::complex< double > > m_monoSpektrum;

   float L_min;
   float L_max;
   float R_min;
   float R_max;


   de::audio::FFT_R2C m_fft;
   de::audio::IFFT_C2R m_ifft;

   QFont5x8 m_font5x8;
};

#endif // G_OSZILLOSKOP_H
