﻿#ifndef G_LOPASS1_HPP
#define G_LOPASS1_HPP

#include <QWidget>
#include <QImage>
#include <QTimer>
#include <QPainter>
#include <QPaintEvent>
#include <QResizeEvent>
#include <QMouseEvent>
#include <QKeyEvent>
#include <QDebug>
#include <QThread>

#include <QFont5x8.hpp>

#include <de/audio/dsp/IDspChainElement.hpp>
#include <de/audio/dsp/OSC.hpp>

#include <QSlider>
#include <QDial>
#include <QLabel>
#include <QCheckBox>

// Placed in the DSP chain.
// Controls volume of one incoming (stereo) audio signal only.
// ============================================================================
class GLowPass : public QWidget, public de::audio::IDspChainElement
// ============================================================================
{
   Q_OBJECT
public:
   GLowPass( QWidget* parent = 0 );
   ~GLowPass();

   uint64_t
   readSamples( double pts,
                float* dst,
                uint32_t dstFrames,
                uint32_t dstChannels,
                uint32_t dstRate ) override;
signals:
public slots:
   void clearInputSignals();
   void setInputSignal( de::audio::IDspChainElement* input );
   void setBypassed( bool enabled );
private slots:
   void on_sliderChanged( int v );
protected:
   DE_CREATE_LOGGER("GLowPass")
   QLabel* m_title;
   QSlider* m_slider;
   QLabel* m_value;
   de::audio::IDspChainElement* m_inputSignal;
   bool m_isBypassed;
   std::vector< float > m_inputBuffer;
};

#endif // G_LOPASS1_HPP
