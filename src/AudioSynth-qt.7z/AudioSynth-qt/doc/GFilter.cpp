#include "GFilter.hpp"
#include <de/Bresenham.hpp>

using namespace de::audio;

GFilter::GFilter( QWidget* parent )
    : QWidget(parent)
    , m_isBypassed( true )
    , m_inputSignal( nullptr )
    //, m_fft( 256, false )
    //, m_ifft( 256, true )
{
   setObjectName( "GFilter" );
   setMinimumSize( 64,64);
   setSizePolicy(QSizePolicy::Expanding,QSizePolicy::Expanding);

//   uint32_t fftSize = m_fft.size();

//       connect( this, SIGNAL(newSamples(float*,uint32_t,uint32_t)),
//                this, SLOT(pushSamples(float*,uint32_t,uint32_t)), Qt::QueuedConnection );
}

GFilter::~GFilter()
{
}

uint64_t
GFilter::readSamples( double pts, float* dst, uint32_t dstFrames, uint32_t dstChannels, uint32_t dstRate )
{
   uint64_t dstSamples = dstFrames * dstChannels;
   DSP_RESIZE( m_stereoInput, dstSamples ); // as interleaved float*

   if ( m_inputSignal )
   {
      uint64_t ok = m_inputSignal->readSamples( pts, m_stereoInput.data(), dstFrames, dstChannels, dstRate );
      if ( ok != dstSamples )
      {
         DE_WARN("retSamples != dstSamples")
      }
   }

   if ( m_isBypassed )
   {
      de::audio::DSP_COPY( m_stereoInput.data(), dst, dstSamples );
      return dstSamples;
   }

   DSP_RESIZE( m_stereoOutput, dstSamples );// as interleaved float*
   DSP_RESIZE( m_monoInput, dstFrames );    // as float*
   DSP_RESIZE( m_monoOutput, dstFrames );   // as float*
   DSP_RESIZE( m_monoSpektrum, dstFrames ); // as complex
   m_fft.setFFTSize( dstFrames );
   m_ifft.setFFTSize( dstFrames );
   ZeroMemory( m_stereoInput );
   ZeroMemory( m_stereoOutput );
   ZeroMemory( m_monoInput );
   ZeroMemory( m_monoOutput );
   ZeroMemory( m_monoSpektrum );

   for ( size_t c = 0; c < dstChannels; c++ )
   {
      DSP_GET_CHANNEL( m_stereoInput.data(), dstFrames, m_monoInput.data(), dstFrames, c, dstChannels );
      m_fft.fft( m_monoInput.data(), m_monoSpektrum.data() );

      // Begin Filtering...


      // End Filtering...

      m_ifft.ifft( m_monoSpektrum.data(), m_monoOutput.data() );

      // Write channel to interleaved data
      float* pDst = dst + c;
      for ( size_t i = 0; i < dstFrames; i++ )
      {
         *pDst = m_monoOutput[ i ];
         pDst += dstChannels;
      }
   }

   return dstSamples;
}
