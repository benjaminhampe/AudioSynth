﻿#ifndef G_DETUNE_OSC_SYNTH_HPP
#define G_DETUNE_OSC_SYNTH_HPP

#include <QWidget>
#include <QImage>
#include <QTimer>
#include <QPainter>
#include <QPaintEvent>
#include <QResizeEvent>
#include <QMouseEvent>
#include <QKeyEvent>
#include <QDebug>
#include <QThread>
#include <QSlider>
#include <QDial>
#include <QLabel>
#include <QComboBox>
#include <QSpinBox>
#include <QDoubleSpinBox>

#include <QFont5x8.hpp>
#include <de/audio/dsp/ISynth.hpp>
#include <de/audio/dsp/IVoice.hpp>
#include <de/audio/dsp/ADSR.hpp>
#include <de/audio/dsp/OSC.hpp>
#include "GADSR.hpp"
#include "GLFO.hpp"
#include "GVolume.hpp"
#include "GLevelMeter.hpp"
#include "GOszilloskop.hpp"
#include "GSpektrometer.hpp"
//#include "GFilter.hpp"
//#include "GLowPass.hpp"
//#include "GLoPass.hpp"
//#include "GDelay.hpp"
//#include "GSoundTouch.hpp"
//#include "GLoudnessLFO.hpp"

// ============================================================================
class DetuneOscSynth : public de::audio::synth::ISynth
// ============================================================================
{
   DE_CREATE_LOGGER("DetuneOscSynth")
public:
   DetuneOscSynth();
   ~DetuneOscSynth();

   uint64_t
   readSamples(
      double pts,
      float* dst,
      uint32_t dstFrames,
      uint32_t dstChannels,
      uint32_t dstRate ) override;

   void sendNote( de::audio::synth::Note const & note ) override;


   //de::audio::ADSR const* getADSR() const { return &m_adsr; }
   //de::audio::ADSR* getADSR() { return &m_adsr; }
   //de::audio::LFOf const* getLFO() const { return &m_lfo; }
   //de::audio::LFOf* getLFO() { return &m_lfo; }

   static void
   setOscType( de::audio::MultiOSCf & osc, int v )
   {
      if ( v == 0 )
      {
         osc.setFunction( de::audio::MultiOSCf::Sine );
      }
      else if ( v == 1 )
      {
         osc.setFunction( de::audio::MultiOSCf::Triangle );
      }
      else if ( v == 2 )
      {
         osc.setFunction( de::audio::MultiOSCf::Rect );
      }
      else if ( v == 3 )
      {
         osc.setFunction( de::audio::MultiOSCf::Ramp );
      }
      else if ( v == 4 )
      {
         osc.setFunction( de::audio::MultiOSCf::Saw );
      }
      else if ( v == 5 )
      {
         osc.setFunction( de::audio::MultiOSCf::Noise );
      }
   }
   bool m_isPlaying;
//   int m_volume;
   //std::vector< float > m_inputBuffer;
   std::vector< float > m_mixerBuffer;

   de::audio::MultiOSCf m_osc;
   de::audio::MultiOSCf m_lfoPhase;
   de::audio::MultiOSCf m_lfoPulseWidth;
   de::audio::MultiOSCf m_lfoDetune;
   de::audio::ADSR m_adsr;


   // Each command triggers a note ( no release event needed, yet, more like single shots )
   // =========================================================
   struct NoteSlot
   // =========================================================
   {
      bool m_isPlaying; // default: true, so it auto starts playing
      bool m_wasPlaying;// default: false, used for sync
      de::audio::synth::Note m_note;
      de::audio::MultiOSCf m_osc;
      de::audio::MultiOSCf m_lfoPhase;
      de::audio::MultiOSCf m_lfoPulseWidth;
      de::audio::MultiOSCf m_lfoDetune;

      NoteSlot()
         : m_isPlaying( true )
         , m_wasPlaying( false ) // false triggers a sync with audio thread stream time,
      {}

      float getDuration() const { return m_note.getDuration(); }
   };
   std::array< NoteSlot, 256 > m_NoteSlots;
   std::mutex m_NoteSlotsMutex; // std::atomic< bool >
};

// Placed in the DSP chain.
// Controls volume of one incoming (stereo) audio signal only.
// ============================================================================
class GDetuneOscSynth : public QWidget, public de::audio::synth::ISynth
// ============================================================================
{
   Q_OBJECT
public:
   GDetuneOscSynth( QWidget* parent = 0 );
   ~GDetuneOscSynth();

   //de::audio::ADSR const* getADSR() const { return &m_adsr; }
   //de::audio::ADSR* getADSR() { return &m_adsr; }
   //de::audio::LFOf const* getLFO() const { return &m_lfo; }
   //de::audio::LFOf* getLFO() { return &m_lfo; }

   uint64_t
   readSamples(
      double pts,
      float* dst,
      uint32_t dstFrames,
      uint32_t dstChannels,
      uint32_t dstRate ) override;

signals:
public slots:
   void sendNote( de::audio::synth::Note const & note ) override;

private slots:
   void on_oscTypeChanged( int v );
//   void on_lfoPhaseTypeChanged( int v );
//   void on_lfoPulseWidthTypeChanged( int v );
//   void on_lfoDetuneTypeChanged( int v );

//   void on_chooseOsc( int v );
//   void on_detuneSine1( int v );
//   void on_volumeSine2( int v );
//   void on_detuneSine2( int v );
//   void on_volumeSine3( int v );
//   void on_detuneSine3( int v );
//   void on_volumeSine4( int v );
//   void on_detuneSine4( int v );
//   void on_volumeSine5( int v );
//   void on_detuneSine5( int v );

//   void on_volumeTriangle( int v );
//   void on_volumeRect( int v );
//   void on_volumeSaw( int v );
//   void on_detuneTriangle( int v );
//   void on_detuneRect( int v );
//   void on_detuneSaw( int v );

//   void on_volumeNoise( int v );
//   void on_detuneNoise( int v );
protected:
   //void timerEvent( QTimerEvent* event) override;
   //void paintEvent( QPaintEvent* event ) override;

private:
   DE_CREATE_LOGGER("GDetuneOscSynth")
   DetuneOscSynth m_synth;

   std::vector< float > m_inputBuffer;

   QLabel* m_oscLabel;
   QComboBox* m_oscEdit;
   QLabel* m_noteLabel;
   QSpinBox* m_noteEdit;
   QLabel* m_detuneLabel;
   QSpinBox* m_detuneEdit;
   GLFO* m_phase;
   GLFO* m_pulseWidth;
   GLFO* m_detune;
   GADSR* m_adsr;
   GLevelMeter* m_levelMeter;
   GVolume* m_volumeSlider;
   GOszilloskop* m_waveform;
   //GLoudnessLFO* m_pianoLFO;
   //GDelay* m_pianoDelay;

//   GADSR* m_voiceADSR;
//   GLFO* m_voiceLFO;
//   GDelay* m_voiceDelay;
//   GOszilloskop* m_voiceOszilloskop;
//   GVolume* m_voiceVolume;
//   GLevelMeter* m_voiceLevelMeter;

};

#endif // G_OSZILLOSKOP_H
