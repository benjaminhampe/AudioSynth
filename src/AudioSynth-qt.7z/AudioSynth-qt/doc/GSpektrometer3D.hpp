#ifndef DE_GPU_SPEKTROMETER3D_QWIDGET_HPP
#define DE_GPU_SPEKTROMETER3D_QWIDGET_HPP

#include <QWidget>
#include <QImage>
#include <QTimer>
#include <QPainter>
#include <QPaintEvent>
#include <QResizeEvent>
#include <QMouseEvent>
#include <QKeyEvent>

#include "ShiftMatrix.hpp"
#include <de/audio/dsp/IDspChainElement.hpp>

// =======================================================================
struct GSpektrometer3D : public QWidget, public de::audio::IDspChainElement
// =======================================================================
{
   Q_OBJECT
public:
   enum eRenderMode
   {
      eRM_LineStrips = 0,
      eRM_Triangles,
   };

   enum eProcessMode
   {
      ePM_Waveform = 0,
      ePM_Spektrum,
   };

   enum eScaleMode
   {
      eSM_PCM = 0,
      eSM_dB,
   };


   GSpektrometer3D( QWidget* parent );
   ~GSpektrometer3D() override;

   uint64_t
   readSamples( double pts, float* dst, uint32_t dstFrames,
               uint32_t dstChannels, uint32_t dstRate ) override;

//   de::gpu::IVideoDriver*
//   getVideoDriver() { return m_driver; }

//   de::gpu::ICamera*
//   getActiveCamera() { return &m_Camera; }

signals:
public slots:
   void setupDspElement( uint32_t dstFrames, uint32_t dstChannels, uint32_t dstRate );

   void clearInputSignals()
   {
      m_inputSignal = nullptr;
   }

   void setInputSignal( de::audio::IDspChainElement* input )
   {
      m_inputSignal = input;
   }

   void startFpsTimer( int ms );
   void stopFpsTimer();
protected:
   void render();
   void timerEvent( QTimerEvent* event) override;
   void paintEvent( QPaintEvent* event ) override;
   void resizeEvent( QResizeEvent* event ) override;
   void hideEvent( QHideEvent* event ) override;
   void showEvent( QShowEvent* event ) override;
   void keyPressEvent( QKeyEvent* event ) override;
   void keyReleaseEvent( QKeyEvent* event ) override;
   void mousePressEvent( QMouseEvent* event ) override;
   void mouseReleaseEvent( QMouseEvent* event ) override;
   void mouseMoveEvent( QMouseEvent* event ) override;
   void wheelEvent( QWheelEvent* event ) override;
protected:
   DE_CREATE_LOGGER("GSpektrometer3D")
   de::gpu::IVideoDriver* m_driver;
   de::gpu::ICamera m_Camera;
   int m_fpsTimerId;

   de::audio::IDspChainElement* m_inputSignal;
   uint32_t m_channelCount;
   uint32_t m_frameIndex;
   float L_min;
   float L_max;
   float R_min;
   float R_max;

   //std::vector< float > m_inputBuffer;
   //std::vector< float > m_channelBuffer;

   std::vector< float > m_inputBuffer;
   std::vector< float > m_channelBuffer;

   //de::audio::ShiftBuffer< float > m_wavlinesInBuf;
   ShiftMesh_LineStrips m_wavlinesL;
   ShiftMesh_LineStrips m_wavlinesR;

   float m_sizeX;
   float m_sizeY;
   float m_sizeZ;

   ShiftMatrix< float > m_wavdataL;
   ShiftMatrix< float > m_wavdataR;

   de::gpu::SMeshBuffer m_wavtrisL;
   de::gpu::SMeshBuffer m_wavtrisR;

   de::gpu::SMeshBuffer m_wavtrisFrontL;
   de::gpu::SMeshBuffer m_wavtrisFrontR;

   de::LinearColorGradient m_gradientWavtris;

};


/*
 *

// =======================================================================
struct ShiftMatrix3D
// =======================================================================
{
   DE_CREATE_LOGGER("ShiftMatrix3D")
   std::vector< de::gpu::SMeshBuffer* > m_data;
   std::vector< de::gpu::SMeshBuffer* > m_copy;
   de::audio::ShiftBuffer< float > m_shiftBuffer;

   bool m_isUploaded;
   uint32_t m_frameIndex;
   uint32_t m_pushCount;
   float m_sizeX;
   float m_sizeY;
   float m_sizeZ;

   de::LinearColorGradient m_ColorGradient;

   ShiftMatrix3D()
      : m_isUploaded( false )
      , m_frameIndex( 0 )
      , m_pushCount( 0 )
      , m_sizeX( 1500.0f)
      , m_sizeY( 300.0f)
      , m_sizeZ( 9000.0f)
   {
      m_data.resize( 64 );
      m_copy.resize( 64 );
      for ( size_t i = 0; i < m_data.size(); ++i )
      {
         auto row = new de::gpu::SMeshBuffer();
         m_data[ i ] = row;
         m_copy[ i ] = row;
      }

      m_ColorGradient.addStop( 0.0f, 0xFFFFFFFF );
      //m_ColorGradient.addStop( 0.1f, 0xFFFFFFFF );
      m_ColorGradient.addStop( 0.2f, 0xFF00FF00 );
      m_ColorGradient.addStop( 0.4f, 0xFF002000 );
      m_ColorGradient.addStop( 0.6f, 0xFF00FFFF );
      m_ColorGradient.addStop( 1.0f, 0xFF0000FF );
      m_ColorGradient.addStop( 2.0f, 0xFFFF00FF );

      setShiftBufferSize( 256 );
   }

   ~ShiftMatrix3D()
   {
      for ( size_t i = 0; i < m_data.size(); ++i )
      {
         SAFE_DELETE( m_data[ i ] );
      }
      m_data.clear();
      m_copy.clear();
   }

   void setShiftBufferSize( uint32_t dstFrames )
   {
      if ( m_shiftBuffer.size() != 2 * dstFrames )
      {
         m_shiftBuffer.resize( 2* dstFrames );
         m_frameIndex = 0;
      }
   }

   void push( float const* src, uint32_t srcCount )
   {
      m_shiftBuffer.push( src, srcCount );
      m_pushCount++;
      m_frameIndex += srcCount;

      if ( m_frameIndex >= m_shiftBuffer.size() )
      {
         auto n = m_data.size();
         for ( size_t i = 0; i < n-1; ++i )
         {
            m_data[ i+1 ] = m_copy[ i ];
         }
         m_data[ 0 ] = m_copy[ n-1 ];

         de::gpu::SMeshBuffer & o = *m_data[ 0 ];
         o.setLighting( false );
         o.setPrimitiveType( de::gpu::PrimitiveType::LineStrip );
         o.Vertices.clear();
         o.Vertices.reserve( srcCount );
         float dx = m_sizeX / float( m_shiftBuffer.size() );
         float dy = m_sizeY * 0.5f;
         //float dz = m_sizeZ / float ( m_data.size() );

         for ( size_t i = 0; i < m_shiftBuffer.size(); ++i )
         {
            float s = m_shiftBuffer[ i ];
            float t = std::abs( s ); // de::Math::clampf( s, -1.f, 1.f);
            float x = dx * i;
            float y = dy * s;
            float z = 0.0f;
            uint32_t color = m_ColorGradient.getColor32( t ); // de::RainbowColor::computeColor32( t );
            o.addVertex( S3DVertex(x,y,z,0,0,0,color,0,0) );
         }

//         for ( size_t i = 1; i < m_shiftBuffer.size(); ++i )
//         {
//            o.addIndex( i-1 );
//            o.addIndex( i );
//         }

         m_frameIndex = 0;

         //DE_DEBUG("Fill after ",m_pushCount," pushes, m_shiftBuffer.size(", m_shiftBuffer.size(), "), srcCount(", srcCount,")")
//         m_shiftBuffer.zeroMemory();
         m_pushCount = 0;

         m_copy.swap( m_data );

//      }
      }
   }
};
*/

#endif

