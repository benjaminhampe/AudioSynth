#ifndef DE_GPU_V4_COLOR_QWIDGET_HPP
#define DE_GPU_V4_COLOR_QWIDGET_HPP

#include <QWidget>
#include <QLabel>
#include <QDoubleSpinBox>
#include <QPushButton>

#include <de_glm.hpp>
#include <de/Logger.hpp>

struct V4ColorEdit : public QWidget
{
   Q_OBJECT
public:
   V4ColorEdit( QString txt, QWidget* parent );
   ~V4ColorEdit() override;

   int r() const { return m_R->value(); }
   int g() const { return m_G->value(); }
   int b() const { return m_B->value(); }
   int a() const { return m_A->value(); }
   QColor color() const { return QColor( r(),g(),b(),a() ); }

signals:
   void colorChanged( QColor color );

public slots:

   void setColor( int r, int g, int b, int a )
   {
      m_R->setValue(r);
      m_G->setValue(g);
      m_B->setValue(b);
      m_A->setValue(a);
   }

private slots:
   void onSpinR( int );
   void onSpinG( int );
   void onSpinB( int );
   void onSpinA( int );
   void onBtnClick( bool );

protected:
   void focusInEvent( QFocusEvent* event) override;
   void focusOutEvent( QFocusEvent* event) override;
   void enterEvent( QEvent* event) override;
   void leaveEvent( QEvent* event) override;
   void keyPressEvent( QKeyEvent* event ) override;
   void keyReleaseEvent( QKeyEvent* event ) override;
   void wheelEvent( QWheelEvent* event ) override;

   //void timerEvent( QTimerEvent* event) override;
   //void paintEvent( QPaintEvent* event ) override;
   //void resizeEvent( QResizeEvent* event ) override;
   void mousePressEvent( QMouseEvent* event ) override;
   void mouseReleaseEvent( QMouseEvent* event ) override;
   void mouseMoveEvent( QMouseEvent* event ) override;

protected:
   DE_CREATE_LOGGER("V4ColorEdit")

   QPushButton* m_Btn;
   QSpinBox* m_R;
   QSpinBox* m_G;
   QSpinBox* m_B;
   QSpinBox* m_A;

   bool m_IsHovered = false;
   bool m_IsFocused = false;

};

#endif
