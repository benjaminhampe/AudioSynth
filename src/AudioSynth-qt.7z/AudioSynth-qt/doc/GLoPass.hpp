﻿#ifndef G_LOPASS2_HPP
#define G_LOPASS2_HPP

#include <QWidget>
#include <QImage>
#include <QTimer>
#include <QPainter>
#include <QPaintEvent>
#include <QResizeEvent>
#include <QMouseEvent>
#include <QKeyEvent>
#include <QDebug>
#include <QThread>

#include <QFont5x8.hpp>

#include <de/audio/dsp/IDspChainElement.hpp>
#include <de/audio/dsp/OSC.hpp>

#include <QSlider>
#include <QDial>
#include <QLabel>
#include <QCheckBox>

// Placed in the DSP chain.
// Controls volume of one incoming (stereo) audio signal only.
// ============================================================================
struct LoPass
// ============================================================================
{
   DE_CREATE_LOGGER("GLoPass")
   bool m_isRunning;
   uint32_t m_sampleRate;
   float m_dt;
   float m_lastSample;
   LoPass()
      : m_isRunning( false )
      , m_sampleRate( 48000 )
      , m_dt( 1.0f / float( m_sampleRate ))
      , m_lastSample(0.0f)
   {}

   void setSampleRate( uint32_t sr )
   {
      m_sampleRate = sr;
      m_dt = 1.0f / float( m_sampleRate );
      m_isRunning = false;
   }

   float tick( float sample )
   {
      if ( !m_isRunning )
      {
         m_isRunning = true;
         m_lastSample = sample;
      }

      double dy = std::abs( double( sample ) - double( m_lastSample ) ); // [0,2]
      dy = std::clamp( 0.5 * dy, 0.0, 1.0 );
      double vol = 1.0;
      if ( dy > 0.005)
      {
         double a = 1.0 - dy;
         double b = a*a*a*a;
         a = b*b*b*b;
         b = a*a*a*a;
         a = b*b*b*b;
         b = a*a*a*a;
         a = b*b*b*b;
         vol = a*a*a*a;
      }

      m_lastSample = sample;
      return vol * sample;
   }
};


// Placed in the DSP chain.
// Controls volume of one incoming (stereo) audio signal only.
// ============================================================================
class GLoPass : public QWidget, public de::audio::IDspChainElement
// ============================================================================
{
   Q_OBJECT
public:
   GLoPass( QWidget* parent = 0 );
   ~GLoPass();

   uint64_t
   readSamples( double pts,
                float* dst,
                uint32_t dstFrames,
                uint32_t dstChannels,
                uint32_t dstRate ) override;
signals:
public slots:
   void clearInputSignals();
   void setInputSignal( de::audio::IDspChainElement* input );
   void setBypassed( bool enabled );
private slots:
   void on_sliderChanged( int v );
protected:
   DE_CREATE_LOGGER("GLoPass")
   QLabel* m_title;
   QSlider* m_slider;
   QLabel* m_value;

   de::audio::IDspChainElement* m_inputSignal;
   bool m_isBypassed;
   std::vector< float > m_inputBuffer;
   LoPass m_lopass;
};

#endif // G_LOPASS1_HPP
