#include "GVoice.hpp"

#if 0

GVoice::GVoice( QWidget* parent )
   : QWidget(parent)
   , m_voice(nullptr)
{
   setObjectName( "GVoice" );
   setMinimumSize( 64,64);
   qDebug() << "DSP thread id = " << QThread::currentThreadId();
}

// ============================================================================
void GVoice::paintEvent( QPaintEvent* event )
// ============================================================================
{
    QPainter dc(this);
    dc.fillRect( rect(), Qt::yellow );

    /// Draw Waveform
    dc.setPen( QPen( QColor(255,255,255,63) ) );
    dc.setBrush( Qt::NoBrush );
    //dc.drawLine( x1,y1 + (height() >> 1),x2,y2+(height() >> 1) );
}

#endif
