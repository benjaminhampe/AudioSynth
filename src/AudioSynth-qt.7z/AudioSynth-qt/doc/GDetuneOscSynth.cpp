#include "GDetuneOscSynth.hpp"
#include <QVBoxLayout>
#include <QHBoxLayout>
#include <QFormLayout>

using namespace de::audio; // DSP_RESIZE, ZeroMemory, DSP_COPY

DetuneOscSynth::DetuneOscSynth()
   : m_isPlaying( false )
{
   m_lfoPhase.setBypassed( true );
   m_lfoPulseWidth.setBypassed( true );
   m_lfoDetune.setBypassed( true );
   m_lfoPhase.setBypassValue( 0.0f );
   m_lfoPulseWidth.setBypassValue( 0.5f );
   m_lfoDetune.setBypassValue( 0.0f );

   //DSP_RESIZE( m_inputBuffer, 2*1024 );
   DSP_RESIZE( m_mixerBuffer, 2*1024 );

   for ( auto & note : m_NoteSlots )
   {
      note.m_isPlaying = false;
      note.m_wasPlaying = false;
   }

}

DetuneOscSynth::~DetuneOscSynth()
{

}

void
DetuneOscSynth::sendNote( de::audio::synth::Note const & note )
{
   auto emplaceNote = [&] ( de::audio::synth::Note const & enote )
   {
      for ( size_t i = 0; i < m_NoteSlots.size(); ++i )
      {
         auto & slot = m_NoteSlots[ i ];
         if ( !slot.m_isPlaying )
         {
            slot.m_note = enote;
            slot.m_note.m_adsr = m_adsr;
            slot.m_osc = m_osc;
            slot.m_lfoPhase = m_lfoPhase;
            slot.m_lfoPulseWidth = m_lfoPulseWidth;
            slot.m_lfoDetune = m_lfoDetune;
            slot.m_wasPlaying = false;
            slot.m_isPlaying = true;
            break;
         }
      }
   };

   {
      std::lock_guard< std::mutex > lg( m_NoteSlotsMutex );
      emplaceNote( note );
   }

   //DE_DEBUG("NoteOn(",note.m_midiNote,"), freq(",note.m_midiFreq,"), slot(", slotIndex,")" )
}

uint64_t
DetuneOscSynth::readSamples( double pts, float* dst, uint32_t dstFrames, uint32_t dstChannels, uint32_t dstRate )
{
   uint64_t dstSamples = dstFrames * dstChannels;
   //DSP_RESIZE( m_inputBuffer, dstSamples );
   DSP_RESIZE( m_mixerBuffer, dstSamples );
   ZeroMemory( m_mixerBuffer );
   //ZeroMemory( dst, dstSamples );

   double dt = 1.0 / double( dstRate );

   size_t noteCount = 0;
   {
      std::lock_guard< std::mutex > lg( m_NoteSlotsMutex );

      // Count active notes
      for ( auto & note : m_NoteSlots )
      {
         if ( note.m_isPlaying ) noteCount++;
      }

      // Add notes to mixer
      for ( size_t i = 0; i < m_NoteSlots.size(); ++i )
      {
         auto & slot = m_NoteSlots[ i ];
         if ( slot.m_isPlaying )
         {
            // Start playing
            if ( !slot.m_wasPlaying )
            {
               slot.m_note.m_timeStart = pts; // This prevents dropouts for unsync start times < 0.0
               slot.m_wasPlaying = true;
            }

            // Stop when ADSR duration exceeded.
            double t = pts - slot.m_note.m_timeStart;
            if ( t >= slot.getDuration() )
            {
               slot.m_isPlaying = false;
               slot.m_wasPlaying = false;
               continue;
            }

            // Play the OSC:
//            m_adsr.set( slot.m_note.m_attackTime,
//                        slot.m_note.m_decayTime,
//                        slot.m_note.m_sustainLevel,
//                        slot.m_note.m_releaseTime );

            float* pDst = m_mixerBuffer.data();
            for ( size_t f = 0; f < dstFrames; f++ )
            {
               int midiNote = slot.m_note.m_midiNote;
               float detune = slot.m_note.m_detune
                            + slot.m_lfoDetune.computeSample( t );
               float freq = getFrequencyFromMidiNote( midiNote, detune );
               float phase = slot.m_lfoPhase.computeSample( t );
               float pw = slot.m_lfoPulseWidth.computeSample( t );

               float adsr = slot.m_note.m_adsr.computeSample( t );
               slot.m_osc.setFrequency( freq );
               slot.m_osc.setPhase( phase );
               slot.m_osc.setPulseWidth( pw );
               float sample = slot.m_osc.computeSample( t ) * adsr;
               for ( size_t c = 0; c < dstChannels; c++ )
               {
                  *pDst += sample;
                  pDst++;
               }
               t += dt;
            }
            //glm::smoothstep()
            //DSP_ADD( m_inputBuffer.data(), m_mixerBuffer.data(), dstSamples );
         }
      }
   }

   DSP_COPY( m_mixerBuffer.data(), dst, dstSamples );
   return dstSamples;
}








GDetuneOscSynth::GDetuneOscSynth( QWidget* parent )
    : QWidget(parent)
{
   setObjectName( "GDetuneOscSynth" );
   setContentsMargins(0,0,0,0);

   m_oscLabel = new QLabel( "OSC", this );
   m_oscEdit = new QComboBox( this );
   QStringList types; types << "Sine" << "Triangle" << "Rect" << "Ramp" << "Saw" << "Noise";
   m_oscEdit->addItems( types );
   m_oscEdit->setCurrentIndex( 0 );

   m_noteLabel = new QLabel( "Note", this );
   m_noteEdit = new QSpinBox( this );
   m_noteEdit->setMinimum( -100 );
   m_noteEdit->setMaximum( 100 );
   m_noteEdit->setValue( -12 );
   m_noteEdit->setSingleStep( 1 );

   m_detuneLabel = new QLabel( "Detune", this );
   m_detuneEdit = new QSpinBox( this );
   m_detuneEdit->setMinimum( -100 );
   m_detuneEdit->setMaximum( 100 );
   m_detuneEdit->setValue( 0 );
   m_detuneEdit->setSingleStep( 1 );

   QFormLayout* f = new QFormLayout();
   f->addRow( m_oscLabel, m_oscEdit );
   f->addRow( m_noteLabel, m_noteEdit );
   f->addRow( m_detuneLabel, m_detuneEdit );

   m_phase = new GLFO( "Phase LFO", this );
   m_pulseWidth = new GLFO( "PulseWidth LFO", this );
   m_detune = new GLFO( "Detune LFO", this );
   m_adsr = new GADSR( this );

   m_phase->setValues( 0, 1.0, 0.01, 0.00 );
   m_pulseWidth->setValues( 0, 1.0, 0.01, 0.00 );
   m_detune->setValues( 0, 1.0, 0.01, 0.00 );

   m_levelMeter = new GLevelMeter( this );
   m_volumeSlider = new GVolume( "P1-Vol.", this );
   m_waveform = new GOszilloskop( this );
   //m_pianoLFO = new GLoudnessLFO( "P1-LFO", this );
   //m_pianoDelay = new GDelay( this );

   QHBoxLayout* h = new QHBoxLayout();
   h->setContentsMargins(0,0,0,0);
   h->setSpacing( 5 );
   h->addLayout( f );
   h->addWidget( m_phase );
   h->addWidget( m_pulseWidth );
   h->addWidget( m_detune );
   h->addWidget( m_adsr );
   h->addWidget( m_levelMeter );
   h->addWidget( m_volumeSlider );
   h->addWidget( m_waveform );
   setLayout( h );

   connect( m_oscEdit, SIGNAL(currentIndexChanged(int)), this, SLOT(on_oscTypeChanged(int)) );

//   connect( m_phase.minEdit, SIGNAL(valueChanged(int)),
//            this, SLOT(on_lfoRateChanged(int)), Qt::QueuedConnection );

//   connect( m_min.slider, SIGNAL(valueChanged(int)),
//            this, SLOT(on_lfoMinChanged(int)), Qt::QueuedConnection );

//   connect( m_max.slider, SIGNAL(valueChanged(int)),
//            this, SLOT(on_lfoMaxChanged(int)), Qt::QueuedConnection );

   DSP_RESIZE( m_inputBuffer, 1024 );
   m_waveform->setShiftBufferSize( 1024 );
   m_synth.setupDspElement( 1024, 2, 48000 );

   m_phase->setLFO( &m_synth.m_lfoPhase );
   m_pulseWidth->setLFO( &m_synth.m_lfoPulseWidth );
   m_detune->setLFO( &m_synth.m_lfoDetune );
   m_adsr->setADSR( &m_synth.m_adsr );
   //m_lfo1->setInputSignal( m_piano );
   //m_delay->setInputSignal( m_piano );
   //m_delay->setBypassed( true );
   m_volumeSlider->setInputSignal( &m_synth );
   m_levelMeter->setInputSignal( m_volumeSlider );
   m_waveform->setInputSignal( m_levelMeter );

   // m_mixer->setInputSignal( 0, m_pianoLevelMeter );

}

GDetuneOscSynth::~GDetuneOscSynth()
{
   // stopUpdateTimer();
}

//void
//GDetuneOscSynth::on_toneSine( int v )
//{
//   int toneOffset = m_sineDetuneSlider->value();
//   int sign = toneOffset < 0 ? -1:1;
//   toneOffset = abs( toneOffset );
//   getFrequencyFromMidiNote( toneOffset )
//   m_sineOsc.setFrequencyOffset( );;
//}


void
GDetuneOscSynth::on_oscTypeChanged( int v )
{
   DetuneOscSynth::setOscType( m_synth.m_osc, v );
}

void
GDetuneOscSynth::sendNote( de::audio::synth::Note const & note )
{
   // Use given note to copy to all active detuned oscs.
   // This pollutes with many notes but gives detune control for all osc's.
   de::audio::synth::Note enote = note;
   enote.m_voiceId = 0;
   enote.m_midiNote = note.m_midiNote + m_noteEdit->value();
   enote.m_detune = 0.01 * m_detuneEdit->value();
   m_synth.sendNote( enote );
}

uint64_t
GDetuneOscSynth::readSamples( double pts, float* dst, uint32_t dstFrames, uint32_t dstChannels, uint32_t dstRate )
{
   uint64_t dstSamples = dstFrames * dstChannels;
   DSP_RESIZE( m_inputBuffer, dstSamples );
   ZeroMemory( m_inputBuffer.data(), dstSamples );

   if ( m_waveform )
   {
      ZeroMemory( dst, dstSamples );
      uint64_t retSamples = m_waveform->readSamples( pts, m_inputBuffer.data(), dstFrames, dstChannels, dstRate );
      if ( retSamples != dstSamples )
      {
         DE_WARN("retSamples != dstSamples")
      }
   }

   DSP_COPY( m_inputBuffer.data(), dst, dstSamples );
   return dstSamples;
}


//void
//GDetuneOscSynth::on_toneSine( int v )
//{
//   int toneOffset = m_sineDetuneSlider->value();
//   int sign = toneOffset < 0 ? -1:1;
//   toneOffset = abs( toneOffset );
//   getFrequencyFromMidiNote( toneOffset )
//   m_sineOsc.setFrequencyOffset( );;
//}

/*
void
GDetuneOscSynth::on_volumeSine1( int v )
{
   int vol = std::clamp( v, 0, 100 );
   m_sine1.volumeAmount->setText( QString::number(vol) + " % " );
   m_oscSine1.setVolume( vol );
}

void
GDetuneOscSynth::on_detuneSine1( int v )
{
   //int offset = m_sine1.detuneSlider->value();
   m_sine1.detune = v;
   m_sine1.detuneAmount->setText( QString::number(v) );
}

void
GDetuneOscSynth::on_volumeSine2( int v )
{
   int vol = std::clamp( v, 0, 100 ); // m_sine2.volumeSlider->value()
   m_sine2.volumeAmount->setText( QString::number(vol) + " % " );
   m_oscSine2.setVolume( vol );
}

void
GDetuneOscSynth::on_detuneSine2( int v )
{
   m_sine2.detune = v;
   m_sine2.detuneAmount->setText( QString::number(v) ); // offset
}

void
GDetuneOscSynth::on_volumeSine3( int v )
{
   int vol = std::clamp( v, 0, 100 ); // m_sine3.volumeSlider->value()
   m_sine3.volumeAmount->setText( QString::number(vol) + " % " );
   m_oscSine3.setVolume( vol );
}

void
GDetuneOscSynth::on_detuneSine3( int v )
{
   m_sine3.detune = v;
   m_sine3.detuneAmount->setText( QString::number(v) ); // offset
}

void
GDetuneOscSynth::on_volumeSine4( int v )
{
   int vol = std::clamp( v, 0, 100 ); // m_sine4.volumeSlider->value()
   m_sine4.volumeAmount->setText( QString::number(vol) + " % " );
   m_oscSine4.setVolume( vol );
}

void
GDetuneOscSynth::on_detuneSine4( int v )
{
   m_sine4.detune = v;
   m_sine4.detuneAmount->setText( QString::number(v) ); // offset
}

void
GDetuneOscSynth::on_volumeSine5( int v )
{
   int vol = std::clamp( v, 0, 100 ); // m_sine5.volumeSlider->value()
   m_sine5.volumeAmount->setText( QString::number(vol) + " % " );
   m_oscSine5.setVolume( vol );
}

void
GDetuneOscSynth::on_detuneSine5( int v )
{
   m_sine5.detune = v;
   m_sine5.detuneAmount->setText( QString::number(v) ); // offset
}
void
GDetuneOscSynth::on_volumeTriangle( int v )
{
   int vol = std::clamp( m_tri.volumeSlider->value(), 0, 100 );
   m_tri.volumeAmount->setText( QString::number(vol) + " % " );
   m_oscTriangle.setVolume( vol );
}
void
GDetuneOscSynth::on_detuneTriangle( int v )
{
   m_tri.detune = v;
   m_tri.detuneAmount->setText( QString::number(v) ); // offset
}

void
GDetuneOscSynth::on_volumeRect( int v )
{
   int vol = std::clamp( m_rect.volumeSlider->value(), 0, 100 );
   m_rect.volumeAmount->setText( QString::number(vol) + " % " );
   m_oscRect.setVolume( vol );
}

void
GDetuneOscSynth::on_detuneRect( int v )
{
   m_rect.detune = v;
   m_rect.detuneAmount->setText( QString::number(v) ); // offset
}

void
GDetuneOscSynth::on_volumeSaw( int v )
{
   int vol = std::clamp( m_saw.volumeSlider->value(), 0, 100 );
   m_saw.volumeAmount->setText( QString::number(vol) + " % " );
   m_oscSaw.setVolume( vol );
}

void
GDetuneOscSynth::on_detuneSaw( int v )
{
   m_saw.detune = v;
   m_saw.detuneAmount->setText( QString::number(v) ); // offset
}

void
GDetuneOscSynth::on_volumeNoise( int v )
{
   int vol = std::clamp( m_noise.volumeSlider->value(), 0, 100 );
   m_noise.volumeAmount->setText( QString::number(vol) + " % " );
   m_oscNoise.setVolume( vol );
}

void
GDetuneOscSynth::on_detuneNoise( int v )
{
   m_noise.detune = v;
   m_noise.detuneAmount->setText( QString::number(v) ); // offset
}
*/
