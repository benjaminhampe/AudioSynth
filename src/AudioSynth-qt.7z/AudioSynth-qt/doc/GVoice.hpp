#ifndef G_VOICE_HPP
#define G_VOICE_HPP

#if 0

#include <QWidget>
#include <QImage>
#include <QTimer>
#include <QPainter>
#include <QPaintEvent>
#include <QResizeEvent>
#include <QMouseEvent>
#include <QKeyEvent>
#include <QDebug>
#include <QThread>

#include <de/audio/dsp/Voice.hpp>
#include <de/audio/dsp/ADSR.hpp>

// ============================================================================
class GVoice : public QWidget //, public de::audio::IDspChainElement
// ============================================================================
{
   Q_OBJECT
   DE_CREATE_LOGGER("GVoice")
public:
   explicit GVoice( QWidget* parent = 0 );
   //double getDuration() const { return m_voice ? m_voice->getDuration() : 0.0; }
signals:
//   void newSamples( float* samples, uint32_t frameCount, uint32_t channels );
public slots:

   //uint64_t
   //readSamples( double pts, float* dst, uint32_t dstFrames, uint32_t dstChannels = 2 );
protected:
   virtual void paintEvent( QPaintEvent* event ) override;
private:

   de::audio::IVoice* m_voice;
};

#endif

#endif // G_OSZILLOSKOP_H
